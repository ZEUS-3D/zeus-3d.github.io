#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#============ SOURCE FILE TO COMPILE AND BUILD LIBDNMLST.A ============#
#
#========================================> Get files from home directory.
if(! -e ./xedit22) cp ../editor/xedit22 .
#========================> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='dnamelist', job=4, iupdate=0                       \$
EOF
chmod 755 ./xedit22
./xedit22
#========================================> Compile and build LIBDNMLST.A.
../bldlib2 libdnmlst.a dnamelist.f
#====================================================> Tidy up directory.
rm -f editlp inedit output xedit21 dnamelist.f
