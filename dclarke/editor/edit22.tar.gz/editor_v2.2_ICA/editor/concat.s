#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#=========== SCRIPT FILE TO CONCATENATE FILES INTO ONE FILE ===========#
#                                                                      #
# User sets: OUTFILE, DIRECTORY                                        #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   outname='OUTFILE', ibanner=1, job=7, idump=1, ext='.f'
          , branch='DIRECTORY'                                         \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22
