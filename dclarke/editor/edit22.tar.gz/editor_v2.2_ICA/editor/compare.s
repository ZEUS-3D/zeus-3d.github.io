#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#================= SCRIPT FILE TO COMPARE TWO LISTINGS ================#
#                                                                      #
# User sets: SOURCECODE1, SOURCECODE2                                  #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE1', in2name='SOURCECODE2'
          , ibanner=1, job=5, icompar=1, ndiff=100, ignore=0,0,0       \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22
