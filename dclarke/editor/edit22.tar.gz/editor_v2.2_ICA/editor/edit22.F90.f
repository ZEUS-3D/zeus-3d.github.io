c
c **********************************************************************
c * ****************************************************************** *
c * *                                                                * *
c * * EEEEEEEEEE  DDDDDD     IIIIII TTTTTTTTTT    OOOO    RRRRRRR    * *
c * *  EE     EE   DD   DD     II   T   TT   T  OO    OO   RR    RR  * *
c * *  EE      E   DD     D    II       TT     OO      OO  RR     RR * *
c * *  EE    E     DD     DD   II       TT     OO      OO  RR    RR  * *
c * *  EEEEEEE     DD     DD   II       TT     OO      OO  RRRRRR    * *
c * *  EE    E     DD     DD   II       TT     OO      OO  RR  RR    * *
c * *  EE      E   DD     D    II       TT     OO      OO  RR   RR   * *
c * *  EE     EE   DD   DD     II       TT      OO    OO   RR    RR  * *
c * * EEEEEEEEEE  DDDDDD     IIIIII    TTTT       OOOO    RRRR   RRR * *
c * *                                                                * *
c * ****************************************************************** *
c **********************************************************************
c
c
c                EDITOR, VERSION 2.2, RELEASE OF 15MAR11
c
c                           David Alan Clarke
c              The Institute for Computational Astrophysics
c                        Saint Mary's University
c
c
c      EDITOR1.1  15DEC88
c
c      In this release, only the numbering and retargeting routines are
c  available.  For a 16,000 line code, it takes roughly 10 seconds of
c  cpu time to retarget, indent, and alphabetise the order of the decks.
c  About 7 seconds is required to number the same file.
c                                                 DAC, November 1988.
c
c      EDITOR1.2  15MAR89
c
c      The precomplier has been added.  Commands that are recognised are
c  *call, *define, *alias, *if define, *if -define, *if alias, *else,
c  and *endif.  Boolean .and., .or., .eq., and .ne. are also recognised
c  in the *if define and *if alias commands.  Precompiling a 16,000 line
c  code takes less than 7 seconds cpu.
c      Some modifications were made to TARGET and NUMBER as well.  The
c  most important new feature of TARGET is its ability to retarget while
c  accounting for mutually exclusive pieces of coding defined by the
c  EDITOR *if def and *if al statements.  For example, in the following
c  sample of coding, the two occurrences of "100    continue" will no
c  longer invoke an error message.
c
c       do 100 i=imin,imax
c         ...
c*if def,mhd
c         ...
c100    continue
c       ...
c*else
c         ...
c100    continue
c       ...
c*endif
c       ...
c
c  Instead, the two statements will be given the same new label.  The
c  most important change to NUMBER is that it will no longer count
c  executables which are excluded by EDITOR *if def and *if al commands.
c                                                 DAC, December 1988.
c
c      EDITOR1.3  15MAY89
c
c      The merger (change decks) has been added.  This is the first
c  "complete" release of EDITOR in that it is now capable of all the
c  functions that it was originally intended to have.  Recognised merge
c  commands are: *ident, *read, *delete, and *insert, which are old
c  HISTORIAN commands, along with *replace (identical to *delete) and
c  *end, which have no HISTORIAN equivalents.
c      In addition, NUMBER has been upgraded to produce a table of
c  contents listing decks both in order of appearance and alphabetically
c  TARGET has been upgraded so that it will automatically decrease the
c  increment between targets inside a deck if there are more targets
c  than the user specified ranges can handle.  Previously, TARGET would
c  issue an error message and a new increment had to be defined for the
c  entire file, even for those decks where the number of targets was
c  not a problem.
c      A fifth "job" has been added - COMPARE.  This routine compares
c  two ASCII files and currently only reports the first difference
c  between the two files.  In the future, the capability of COMPARE
c  may be expanded.
c                                                 DAC, March 1989.
c
c      EDITOR1.4 (EDIT13 + CHGED13)  15JUN89
c
c      This is the first release to have been created by MERGing the
c  previous version with a change deck using MERGE, which was installed
c  in version 1.3.
c      In this release, EDITOR has been made compatable with CFT77
c  and UNICOS, both of which provide unlimited headaches.  This has
c  resulted in a routine which will replace the "namelist" syntax
c  used under CTSS with fortran statements which call subroutines
c  in the library NAMELIST.LIB.  This library must be linked to the
c  object file when loading (segldr, fc) if the "namelist" feature is
c  to be used.  This allows the user to continue to use "namelist"
c  without being burdened by the miserable excuse of a "namelist" that
c  accompanies the CFT77 compiler.
c      In addition, a few bugs in MERGE have been found and fixed.  All
c  references to GATHER have been changed to COLLECT since "GATHER" is
c  a subroutine in one of the standard libraries.  (WHY use common words
c  for standard subroutine names?!?!)  This switch was done in EDIT13
c  itself, rather than in the change deck CHGED13.
c      Note that for large source codes (greater than 5000 lines, say)
c  it is necessary to compile EDITOR with the optimisation switch turned
c  off (e.g. CFT77 -o off edit14.f).  A bug in CFT77, what else?
c                                                   DAC, May 1989.
c
c      EDITOR1.5 (EDIT14 + CHGED14)  15SEP89
c
c      COMPAR has been extended.  It will now list the first "ndiff"
c  differences found, rather than just stopping at the first one.  The
c  comparison can be told to ignore blanks and continuation characters.
c  It can also compare the declaration lists of two files and determine
c  if the two lists are identical, regardless of order, extra blanks,
c  and whether "dimension" is used instead of "real" and "integer".
c      The naming convention of output files has been changed for
c  UNICOS.  Rather than prefixing the filenames (which is still done
c  under CTSS), the new filenames are created from the old filenames
c  by adding extensions.  For NUMBERed files, the extension is .n, for
c  reTARGETed files, the extension is .t, for MERGEd files, the
c  extension is .m, and for PRECOMpiled files, the extension is .f
c  (appropriate for the CFT77 compiler).  The new parameter "outname"
c  will allow the user to override any of these conventions.
c      The input variables "namesc1" and "namesc2" have been changed to
c  "inname" and "in2name".
c      INOREX now recognises the syntax "*if def,.not.CTSS" to be
c  synonymous with "if -def,CTSS", which is consistent with the old
c  HISTORIAN precompiler.
c      In EDIT14, TARGET did not recognise single digits attached to
c  *if, *ei or *endif (e.g., *if2, *endif2).  This feature was working
c  in some previous version, and has been reinstalled in this version.
c      A new option for PRECOMpiling has been added which will break
c  up the PRECOMpiled source code and put each subroutine into a
c  separate file (named by attaching the extension .f to the subroutine
c  name).  Each subroutine is then COMPARed with a copy which presumably
c  already exists on disc.  If the subroutine is found to be different
c  from the copy on the disc, the disc copy is updated.  Otherwise, it
c  is left alone.  In this way, MAKE will only compile those
c  subroutines that have been altered.  If no file with the subroutine
c  name is found on disc, EDITOR will write the file to disc under the
c  user-supplied directory ("branch" in the namelist).  The name of
c  the subroutine is UPDATE, and is turned on by setting "iupdate" to
c  1 in the namelist.  With "iupdate" = 1, no "masterfile" (which
c  contains all the subroutines) is written to disc.  Besides
c  increasing compilation speed, this feature is useful if CDBX is to
c  be used, since CDBX requires (stupidly) that all subroutines be
c  found in separate files.  Note that this feature is excluded for
c  CTSS.
c      A sixth job has been added.  SPLIT will split a file into
c  separate files for each deck.
c      A seventh job has been added.  CONCAT will concatenate files
c  with a common extension found in a specified directory or its
c  subdirectories into a single file with a specified name.
c                                               DAC, September 1989.
c
c      EDITOR1.5a
c
c      Changes made directly to EDITOR1.5 (no change deck) include
c  extending the line length to 128 characters, rather than 96.  This
c  allows NUMBER to include the groupname as well as the deckname on
c  the line (see EDITOR1.6).  The format of the declarations was
c  standardised throughout the source file to match the conventions
c  used in ZEUS.  Additional minor changes were made which did not alter
c  the line count and involved one line at a time each.  These were to
c  fix small bugs and irritants.
c                                               DAC, September 1989.
c
c      EDITOR1.6 (EDIT15a + CHGED15)  15SEP90
c
c      The *group (*gp) command has been introduced.  It divides the
c  files into groups of decks, and alphabetisation occurs only inside a
c  group.  In this way, related subroutines are not scattered among the
c  whole file when TARGET alphabetises the decks.  The *group command
c  has no other function.  All decks found after the most recent *group
c  command are considered to belong to that group.  A *group command
c  with no groupname means that the following decks belong to no group.
c  Decks that do not belong to a group are placed at the beginning of
c  the file.  Proper syntax:  *group GROUPNAME, much like the *deck
c  command.
c      There is no easy way to use wildcards in the makefile for the
c  list of object files to be replaced and/or loaded.  So, to overcome
c  this latest shortcoming of UNIX, UPDATE is now capable of creating
c  the makefile with all the necessary files specifically listed.
c      UPDATE has been completely revamped, and all the ISHELL commands
c  have been stripped out, to improve speed.  NUMBER has been revised
c  to list the groupname as well.  MERGE has been changed to accomodate
c  the new columns used by NUMBER.
c                                               DAC, September 1989.
c
c      EDITOR1.6a
c
c      Major changes have been made directly to EDITOR (no change deck)
c  to emmulate memory management.  To read in all of ZEUS2-D at once
c  required so much memory, that EDITOR became a "long" job, thus
c  making its execution time intolerably long.  Subroutine RFILE has
c  been added, and will read only a piece of the code in at a time,
c  thus allowing k2 to remain small enough to make EDITOR a "short" job
c  for all file sizes.  This requires more disc reads, but the
c  improvement in overall performance is significant.  So many changes
c  have been made during this conversion, that they cannot be all
c  listed.  The subprograms: EDITOR, COLLECT, MERGE, NUMBER, PRECOM,
c  SPLIT and TARGET have all been revamped.  Numerous minor changes have
c  been made elsewhere to accomodate the new file convention.  New
c  subroutines have been added to open and close files, and to put the
c  file header and footer on outfiles.  Much of the structure of the
c  code has been streamlined.  MERGE no longer uses NUMBER to number
c  "oldfile" for the purpose of merging the change deck.  Instead, it
c  calls a new subroutine MRGNMBR, which is designed specifically for
c  the needs of MERGE.  This tidies up NUMBER substantially.
c      The new file convention is as follows.  "nloldt" is the line
c  length of the disc file "oldname", while "nlold" is the line length
c  of the text array "oldfile", whose lines are each 128 characters
c  long.  "nloldt" is incremented by 1 if another line is read from
c  "oldname", while "nlold" is incremented by 1 if another line is
c  added to "oldfile".  For "oldname" and "oldfile", this is often
c  done simultaneously.  Note that "nloldt" is only reset to zero
c  if the "oldname" is to be read again from the beginning.  "nlold"
c  is reset when a new portion of "oldname" is being read into
c  "oldfile".  Similarily, "nlnewt" is incremented by 1 when a new line
c  is actually written to the disc file "newname", while "nlnew" is
c  incremented by 1 if a line is added to the text array "newfile".
c  Often, these do not happen simultaneously.
c
c  The possible text files are "oldfile"  (length = "nlold" ),
c                              "newfile"  (length = "nlnew" ), and
c                              "tmpfile"  (length = "nltmp" ).
c  The possible disc files are "oldname"  (length = "nloldt"),
c                              "newname"  (length = "nlnewt"),
c                              "readname" (length = "nlnewt"),
c                              "tmpname"  (length = "nltmpt"),
c                              "chgname"  (length = "nltmpt"),
c                              "makename" (length = "nlmakt"), and
c                               output    (length = "nldmpt").
c
c      In addition, numerous other aesthetic changes have been made
c  throughout the code.
c                                                 DAC, October 1989.
c
c      EDITOR2.0  (no change deck) 15MAR91
c
c      This is the first "official" release of EDITOR meant for general
c  use.  The first EDITOR user manual has been written to accompany the
c  code.  No change deck exists which links this version with 1.6a.
c      TARGET now recognises the "arithmetic if" statement, namely:
c
c      if (EXPRESSION) n1, n2, n3
c
c  where, if EXPRESSION is less than, equal, or greater than zero,
c  execution is transferred to statement n1, n2, or n3 respectively.
c      Function statements are now recognised even if they are preceded
c  by the function attribute (real, integer, logical, or character).
c      The OPTION statement is now recognised.
c      The namelist PRINT and WRITE statements have been activated and
c  character strings of arbitrary length can now be read in input decks.
c      Various bugs found in EDIT16A over the past year of use have
c  been corrected.  Some aesthetic changes have also been made.
c                                                   DAC, March 1991.
c
c      EDITOR2.1  (no change deck) 15APR92
c
c      GETWRD has been restructured into a more general routine, so that
c  the characters that are to be considered blanks can be specified in
c  the calling parameter list.
c      PRECOM has an additional option which will insert micro-tasking
c  directives (cmic$ statements for the Cray, c$omp statements for
c  OpenMP) into the code before nested do-loops.  This option is enabled
c  by setting iutask=1 for Cray, iutask=2 for OpenMP.
c      Various bugs found in EDIT20 over the past year of use have
c  been corrected.  Some aesthetic changes have also been made.
c      This version will run under UNICOS, CONVEXOS, SUNOS, AIX, or
c  LINUX.  One of these definition macros must be defined before
c  compilation.
c      A second compiler option (speccopt) has been added (7/2004) so
c  that selected routines (specdk) can be compiled with different
c  compiling options than the rest of the routines, which are still
c  compiled with coptions (DAC).
c                                                   DAC, April 1992.
c
c      EDITOR 2.2  (no change deck) 15MAR11
c
c      The first new release in almost 20 years, the main change here is
c  correcting (finally) the mistaken notion that differences in specific
c  FORTRTAN calls (e.g., cpu time) had to do with the OS, and not the
c  compiler specifically.  In this version, all mention of SUNOS, LINUX,
c  etc., are replaced in favour of compiler names, such as G95, IFORT,
c  etc.
c
c  Supported compilers in this release include:
c
c  CF77 (Cray), F90 (Sun), G95 (Gnu), GFORTRAN (Gnu), IFORT (Intel),
c  PGF77 (Portland Group), XLF (IBM).
c                                                   DAC, March 2011.
c
c
c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                E D I T O R                \\\\\\\\\\
c
c=======================================================================
c
       program editor
c
c    dac:editor.editor <--------------- performs editing on source codes
c                                                         december, 1988
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c    modified 2: March, 2011 by DAC; replaced OS macros with compiler
c                macros; introduced "swcase" to allow switches to be
c                case-insensitive.
c
c  PURPOSE:  EDITOR is basically a character manipulator which takes an
c  input file (a source code) and performs various tasks on that file
c  (such as numbering the lines, tidying up the FORTRAN, merging the
c  source code with a "change deck", and precompilation) before dumping
c  the results to an "outfile".  The main program is responsible for:
c
c  1.  defining the extrema for the arrays,
c  2.  reading the input parameters from "namelist" and setting the
c      defaults,
c  3.  assigning all the logical units,
c  4.  creating the output filename,
c  5.  opening and closing the diagnostic dumpfile "outfile",
c  6.  sending most of the status messages to the terminal, and
c  7.  orchestrating the tasks.
c
c      The subroutines are responsible for opening and closing all the
c  disc files that may be required, and performing all the character
c  manipulations on the input files.
c
c  EXTERNALS
c    CCLOCK
c    WCLOCK
c    FIRSTCH
c    OFILE
c    HEADER
c    NUMBER
c    TARGET
c    MERGE
c    PRECOM
c    COMPARE
c    SPLIT
c    CONCAT
c    TEST
c    FOOTER
c    CFILE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*16  first   , secnd   , firstcd , firstdk
       character*64  filename, inname  , in2name , chgdk   , outname
     1             , phrase
       integer       i       , j       , i1      , i2      , ind0
     1             , wctot   , wcmin   , wcsec   , wcms1   , wcms2
     2             , wcfrac  , ccmin   , ccsec   , ccfrac  , nph
       real          cctot   , rwctot  , ptime
c
c      External statements.
c
       integer       wclock  , firstch
       real          cclock
       external      cclock  , wclock  , firstch , ofile   , header
     1             , number  , target  , merge   , precom  , compare
     2             , split   , concat  , test    , footer  , cfile
       character*32  namelist (   2,1000)
       external      nlsdac01, nlsdac02, nlsdac03, nlsdac04, nlsdac05
     1             , nlsdac06, nlsdac07, nlsdac08, nlsdac09, nlsdac10
     2             , nlsdac11, nlsdac12, nlsdac13, nlsdac14, nlsdac15
     3             , nlsdac16, nlsdac17, nlsdac18, nlsdac19, nlsdac20
     4             , nlsdac21, nlsdac22, nlsdac23, nlsdac24
c
c-----------------------------------------------------------------------
c
c      Initialise cpu and wall clocks; set time and date.
c
c  "cctot"   elapsed cpu time (seconds, real).
c  "wctot"   elapsed wall clock time (seconds, integer) since beginning
c            of year in which job began.
c  "chtime"  character*8  word with format hh:mm:ss.
c  "chdate"  character*16 word with format dd/mm/yyyy.
c
       cctot = cclock ()
       wctot = wclock ( wcms1, chtime, chdate, 2 )
c
c      Initialise blank strings.
c
       blank8           = '        '
       blank16 ( 1:  8) = blank8
       blank16 ( 9: 16) = blank8
       blank32 ( 1: 16) = blank16
       blank32 (17: 32) = blank16
       blank64 ( 1: 32) = blank32
       blank64 (33: 64) = blank32
       blank128( 1: 64) = blank64
       blank128(65:128) = blank64
c
c      Extrema:  iemax = maximum number of errors
c                ilmax = maximum number of lines in source file
c                iomax = maximum number of origins
c                ismax = maximum number of subroutines (or decks)
c                itmax = maximum number of targets
c                icmax = maximum number of characters in a line
c                idmax = maximum number of defined switches
c                iamax = maximum number of aliases
c                ivmax = maximum number of variables listed in NAMELIST
c
       iemax = k1
       ilmax = k2
       iomax = k3
       ismax = k4
       itmax = k5
       icmax = k6
       idmax = k7
       iamax = k8
       ivmax = k9
c
c      Logical unit assignments to disc files.
c
       lunml = 59
       lulp  = 58
       ludmp = 11
       luold = 12
       lutmp = 13
       lunew = 14
       luchg = 15
       luout = 16
       lumak = 17
c
c      Input parameters
c
c      GENERAL
c  inname    name of source code to be editted (character*64).
c  ibanner   =1 => print out banner to screen at beginning of execution
c            =0 => no banner (default)
c  job       =1 => number lines in source code (default)
c            =2 => tidy source code (retarget, indent, alphabetise)
c            =3 => update source code with change decks
c            =4 => prepare source code for compilation.
c            =5 => compares two files and reports location of first
c                  difference.
c            =6 => split the source code decks into individual files.
c            =7 => concatenate files with common extension.
c  idump     =1 => diagnostic dumps are written to "output".
c            =0 => no diagnostic dumps (default).
c  safety    safety*k2 lines of "inname" are read into "oldfile(k2)" at
c            a time, allowing file to expand as common decks are
c            included, change decks merged, etc. (default = 0.9, 0.4 for
c            MERGE and PRECOM)
c  outname   name of outfile.  If unspecified, outfile will be named
c            according to internal naming convention (character*64).
c
c      NUMBER (job=1)
c  inumber   =1 => sequential numbering of source code only, as in FRED.
c            =2 => sequential, statement, and by subroutine.
c            =3 => sequential, statement, and by deck (default).
c  itable    =1 => creates a table of contents (default, inumber=3 only)
c            =0 => no table of contents
c  ixclude   =1 => won't label line with statement number if statement
c                  excluded by surrounding *if structures (default,
c                  inumber=3 only)
c            =0 => labels all executable statements.
c
c      TARGET (job=2)
c  ibegdo    lowest  target value for "goto" and "do" statements
c            (default 10).
c  ienddo    highest target value for "goto" and "do" statements
c            (default 990).
c  ibegre    lowest  target value for "read" and "decode" statements
c            (default 1010).
c  iendre    highest target value for "read" and "decode" statements
c            (default 1990).
c  ibegwr    lowest  target value for "write" and "encode" statements
c            (default 2010).
c  iendwr    highest target value for "write" and "encode" statements
c            (default 2990).
c  inc       increment between successive targets (default 10).
c  irepl     =1 => replace "do-enddo"'s with targeted "do"'s (default)
c            =0 => do not replace "do-enddo"'s.
c  ireseq    =1 => resequence 6th character in continuation statements
c                  (default).
c            =0 => no resequence.
c  indent    =0 => no uniform indentation is imposed.
c            >0 => impose uniform indentation, with "indent" spaces
c                  (default 2).
c  ialpha    =0 => no alphabetisation of decks.
c            =1 => modulo specification of "first" etc., "common decks"
c                  and ordinary "decks" are arranged alphabetically.
c                  "Common decks" are listed before ordinary "decks"
c                  (default).
c  first     name of "deck" (common or ordinary) to be listed before
c            all others (character*16, no default).
c  secnd     name of "deck" (common or ordinary) to be listed right
c            after "first" (character*16, no default).
c  firstcd   name of "common deck" to be listed before all other
c            "common decks" (character*16, no default).
c  firstdk   name of ordinary "deck" to be listed before all other
c            ordinary "decks" (character*16, no default).
c
c      MERGE (job=3)
c  chgdk     name of change deck to be merged with "inname"
c            (character*64, no default).
c  inum      =1 => a NUMBERed file will be created.
c            =0 => no NUMBERed file (default)
c  ipre      =1 => a PRECOMpiled file will be created.
c            =0 => no PRECOMpiled file (default)
c
c      PRECOM (job=4)
c  swcase    =0 => Switches (but not aliases) are case-insensitive;
c                  *def MHD and *def mhd are identical (default)
c            =1 => Switches are case-sensitive; *def MHD and *def mhd
c                  are different
c  inmlst    =0 => leave NAMELIST and associated READ's alone (default).
c            >0 => substitute all occurances of NAMELIST and associated
c                  READ's for calls to subroutines in NAMELIST.LIB.  A
c                  maximum of "inmlst" assignments can be made in the
c                  input deck per NAMELIST.  "inmlst"=1 => 1000.
c  iutask    =0 => no microtasking attempted (default)
c            =1 => insert Cray microtasking directives (cmic$) in
c                  front of parallelisable nested do-loops.
c            =2 => insert OpenMP parallelisation directives (c$omp) in
c                  front of parallelisable nested do-loops.
c            =-1, -2 => same as 1, 2, except directives are inserted
c                  before single (non-nested) loops too.
c  iupdate   =0 => PRECOMpiled source code is dumped to one file
c                  (default).
c            =1 => PRECOMpiled subroutines stored to separate files.
c                  Subroutine is written only if it is different from
c                  version on disc, or if it doesn't exist on disc.
c  branch    character*32 string indicating default directory in which
c            to store new subroutines (no default).
c  ext       desired extension for files (character*8, default='.f')
c  makename  name of makefile to be created (character*16).  If blank,
c            no makefile is created (default).  The files compiled by
c            MAKE are those in the directory 'branch'.
c  compiler  overrides default compiler used by MAKE to compile "inname"
c            (character*16).  The default compiler depends on how EDITOR
c            itself was compiled, which depends on which EDITOR compiler
c            macro was defined in edit22.s.  There is no requirement
c            that EDITOR create the makefile for "inname" with the same
c            compiler with which it was compiled.  The compiler that
c            compiled EDITOR just serves as a reasonable default.
c
c            macro       default compiler  origin
c            --------------------------------------------
c            none         gfortran         GNU
c            CF77         cf77             Cray
c            F90          f90 -f77         SUN
c            G95          g95              GNU
c            GFORTRAN     gfortran         GNU
c            IFORT        ifort            Intel
c            PGF77        pgf77            Portland Group
c            XLF          xlf              IBM
c
c  coptions  compiler options (character*128).  For convenience, two
c            generic compiler options, 'debug' and 'optimise', are
c            supported, where:
c
c  compiler  debug =>                            optimise =>
c  ------------------------------------------------------------------
c  cf77      -g                                  -O4
c  f90 -f77  -g -C -ftrap=common                 -O4
c  g95       -g -fbounds-check -ftrace=full      -O2
c  gfortran  -g -fbounds-check -ffpe-trap=i,z,o  -O2
c  ifort     -g -debug-parameters -check -fpe1   -O2 -m32
c            -traceback -m32                     -diag-disable remark
c  pgf77     -g                                  -O2
c  xlf       -g -C -qextchk -qflttrap -qsigtrap  -O4
c
c            These are in addition to '-c -o $*.o' (or equivalent) that
c            suppress the link step and give the object file the same
c            name as the module, and which are included automatically in
c            PRECOM for each of the default compilers.  If a different
c            compiler is used, the equivalent of '-c -o $*.o' should be
c            included with "coptions". (default is 'optimise')
c  speccopt  specifies compiler options for special decks named in array
c            "specdk".  Occasionally, a few routines need to be compiled
c            with special compiler options in order for the computations
c            to be done correctly, or if the compiler is having a hard
c            time optimising a routine that doesn't really need
c            optimising (character*128, default = no options).
c  specdk    those decks to be compiled with compiler options "speccopt"
c            (character*16(k4), default = blank16).
c  loader    specifies loader to be used by MAKE (character*16; default
c            is "compiler"; "segldr" for compiler "cf77").
c  loptions  specifies loader options other than -o.  These are appended
c            in PRECOM to '-o $(EXE)', which is needed for the makefile
c            (character*128, default = no options).
c  libs      are the libraries to be linked by the loader.  As many
c            libraries can be specified as will fit in character*512 (no
c            default).
c  xeq       name of executable to be created by MAKE (character*64 to
c            allow for directory specification as well, default is
c            "inname" with the extension '.x').
c
c      COMPARE (job=5)
c  in2name   name of file to be compared with "inname" (character*64, no
c            default).
c  icompar   =1 => report first "ndiff" differences (default)
c            =2 => list discrepencies in declarations
c  ndiff     number of differences to report (default=100, icompar=1
c            only).
c  ignore    integer vector indicating tolerated differences in (1)
c            continuation characters, (2) blanks, (3) comments, where
c            0 => report difference (default),
c            1 => ignore difference (for icompar=1 only).
c
c      SPLIT (job=6)
c  branch    character*32 string indicating directory into which files
c            are written (no default).
c  ext       desired extension for files (character*8, default='.src')
c
c      CONCAT (job=7)
c  branch    character*32 string indicating top directory branch in
c            which files are sought (no default).
c  ext       common extension of files (character*8, default='.src')
c
c      TEST (job=10)
c
       open ( lunml, file='inedit', status='old' )
       open ( lulp , file='editlp', status='unknown' )
       call nlsdac01 ( namelist, 1000 )
       namelist (1,   1) = 'inname                       c s'
       namelist (1,   2) = 'ibanner                      i s'
       namelist (1,   3) = 'job                          i s'
       namelist (1,   4) = 'idump                        i s'
       namelist (1,   5) = 'safety                       r s'
       namelist (1,   6) = 'outname                      c s'
       namelist (1,   7) = 'inumber                      i s'
       namelist (1,   8) = 'itable                       i s'
       namelist (1,   9) = 'ixclude                      i s'
       namelist (1,  10) = 'ibegdo                       i s'
       namelist (1,  11) = 'ienddo                       i s'
       namelist (1,  12) = 'ibegre                       i s'
       namelist (1,  13) = 'iendre                       i s'
       namelist (1,  14) = 'ibegwr                       i s'
       namelist (1,  15) = 'iendwr                       i s'
       namelist (1,  16) = 'inc                          i s'
       namelist (1,  17) = 'irepl                        i s'
       namelist (1,  18) = 'ireseq                       i s'
       namelist (1,  19) = 'indent                       i s'
       namelist (1,  20) = 'ialpha                       i s'
       namelist (1,  21) = 'first                        c s'
       namelist (1,  22) = 'secnd                        c s'
       namelist (1,  23) = 'firstcd                      c s'
       namelist (1,  24) = 'firstdk                      c s'
       namelist (1,  25) = 'chgdk                        c s'
       namelist (1,  26) = 'inum                         i s'
       namelist (1,  27) = 'ipre                         i s'
       namelist (1,  28) = 'swcase                       i s'
       namelist (1,  29) = 'inmlst                       i s'
       namelist (1,  30) = 'iutask                       i s'
       namelist (1,  31) = 'iupdate                      i s'
       namelist (1,  32) = 'branch                       c s'
       namelist (1,  33) = 'ext                          c s'
       namelist (1,  34) = 'makename                     c s'
       namelist (1,  35) = 'compiler                     c s'
       namelist (1,  36) = 'coptions                     c s'
       namelist (1,  37) = 'speccopt                     c s'
       namelist (1,  38) = 'specdk                  k4   c v'
       namelist (1,  39) = 'loader                       c s'
       namelist (1,  40) = 'loptions                     c s'
       namelist (1,  41) = 'libs                         c s'
       namelist (1,  42) = 'xeq                          c s'
       namelist (1,  43) = 'in2name                      c s'
       namelist (1,  44) = 'icompar                      i s'
       namelist (1,  45) = 'ndiff                        i s'
       namelist (1,  46) = 'ignore                  10   i v'
c
c      Default values for namelist parameters.
c
       ibanner =    0
       job     =    1
       idump   =    0
       safety  =    0.0
       inumber =    3
       itable  =    1
       ixclude =    1
       ibegdo  =   10
       ienddo  =  990
       ibegre  = 1010
       iendre  = 1990
       ibegwr  = 2010
       iendwr  = 2990
       inc     =   10
       irepl   =    1
       ireseq  =    1
       indent  =    2
       ialpha  =    1
       inum    =    0
       ipre    =    0
       swcase  =    0
       inmlst  =    0
       iutask  =    0
       iupdate =    0
       nchar   =   72
       icompar =    1
       ndiff   =  100
       do 10 i=1,10
         ignore(i) = 0
10     continue
       inname        = blank64
       in2name       = blank64
       chgdk         = blank64
       outname       = blank64
       ext           = blank8
       branch        = blank32
       makename      = blank16
       compiler      = blank16
       loader        = blank16
       coptions      = blank128
       speccopt      = blank128
       loptions      = blank128
       libs(  1:128) = blank128
       libs(129:256) = blank128
       libs(257:384) = blank128
       libs(385:512) = blank128
       xeq           = blank64
       do 11 i=1,ismax
         specdk(i)   = blank16
11     continue
c
c      Read input deck.
c
       call nlsdac02 ( lunml   , 'editpar ', namelist, 1000,   46 )
       call nlsdac03 ( inname  , 'inname  ', namelist, 1000 )
       call nlsdac04 ( ibanner , 'ibanner ', namelist, 1000 )
       call nlsdac04 ( job     , 'job     ', namelist, 1000 )
       call nlsdac04 ( idump   , 'idump   ', namelist, 1000 )
       call nlsdac05 ( safety  , 'safety  ', namelist, 1000 )
       call nlsdac03 ( outname , 'outname ', namelist, 1000 )
       call nlsdac04 ( inumber , 'inumber ', namelist, 1000 )
       call nlsdac04 ( itable  , 'itable  ', namelist, 1000 )
       call nlsdac04 ( ixclude , 'ixclude ', namelist, 1000 )
       call nlsdac04 ( ibegdo  , 'ibegdo  ', namelist, 1000 )
       call nlsdac04 ( ienddo  , 'ienddo  ', namelist, 1000 )
       call nlsdac04 ( ibegre  , 'ibegre  ', namelist, 1000 )
       call nlsdac04 ( iendre  , 'iendre  ', namelist, 1000 )
       call nlsdac04 ( ibegwr  , 'ibegwr  ', namelist, 1000 )
       call nlsdac04 ( iendwr  , 'iendwr  ', namelist, 1000 )
       call nlsdac04 ( inc     , 'inc     ', namelist, 1000 )
       call nlsdac04 ( irepl   , 'irepl   ', namelist, 1000 )
       call nlsdac04 ( ireseq  , 'ireseq  ', namelist, 1000 )
       call nlsdac04 ( indent  , 'indent  ', namelist, 1000 )
       call nlsdac04 ( ialpha  , 'ialpha  ', namelist, 1000 )
       call nlsdac03 ( first   , 'first   ', namelist, 1000 )
       call nlsdac03 ( secnd   , 'secnd   ', namelist, 1000 )
       call nlsdac03 ( firstcd , 'firstcd ', namelist, 1000 )
       call nlsdac03 ( firstdk , 'firstdk ', namelist, 1000 )
       call nlsdac03 ( chgdk   , 'chgdk   ', namelist, 1000 )
       call nlsdac04 ( inum    , 'inum    ', namelist, 1000 )
       call nlsdac04 ( ipre    , 'ipre    ', namelist, 1000 )
       call nlsdac04 ( swcase  , 'swcase  ', namelist, 1000 )
       call nlsdac04 ( inmlst  , 'inmlst  ', namelist, 1000 )
       call nlsdac04 ( iutask  , 'iutask  ', namelist, 1000 )
       call nlsdac04 ( iupdate , 'iupdate ', namelist, 1000 )
       call nlsdac03 ( branch  , 'branch  ', namelist, 1000 )
       call nlsdac03 ( ext     , 'ext     ', namelist, 1000 )
       call nlsdac03 ( makename, 'makename', namelist, 1000 )
       call nlsdac03 ( compiler, 'compiler', namelist, 1000 )
       call nlsdac03 ( coptions, 'coptions', namelist, 1000 )
       call nlsdac03 ( speccopt, 'speccopt', namelist, 1000 )
       call nlsdac07 ( specdk  , 'specdk  ', namelist, 1000 )
       call nlsdac03 ( loader  , 'loader  ', namelist, 1000 )
       call nlsdac03 ( loptions, 'loptions', namelist, 1000 )
       call nlsdac03 ( libs    , 'libs    ', namelist, 1000 )
       call nlsdac03 ( xeq     , 'xeq     ', namelist, 1000 )
       call nlsdac03 ( in2name , 'in2name ', namelist, 1000 )
       call nlsdac04 ( icompar , 'icompar ', namelist, 1000 )
       call nlsdac04 ( ndiff   , 'ndiff   ', namelist, 1000 )
       call nlsdac08 ( ignore  , 'ignore  ', namelist, 1000 )
       call nlsdac24 ( lulp    , 'editpar ', namelist, 1000 )
c
       if (job .eq. 5) idump = 1
       if (safety .eq. 0.0) then
         safety = 0.9
         if ( (job .eq. 3) .or. (job .eq. 4) ) safety = 0.4
       endif
c
       i1 = firstch ( compiler )
       i2 = firstch ( coptions )
c
c      If "compiler" was not set by user, set default according to which
c  EDITOR macro is set.  If no valid EDITOR macro is set, default is
c  "gfortran".
c
       if (compiler .eq. blank16) then
         compiler = 'gfortran'
         compiler = 'f90 -f77'
       endif
c
c      If "loader" is not set, set it to the compiler (with the
c  exception given for Cray's cf77).
c
       if (loader .eq. blank16 ) then
         loader = compiler
         if (compiler(i1:i1+3) .eq. 'cf77') loader = 'segldr'
       endif
c
c      If "coptions" is set to "debug", set "coptions" and "loptions" to
c  those appropriate for the compiler selected.
c
c  Note that in PRECOM, the compiler options -c -o $*.o are prepended to
c  all compiler options set.  These (nearly) universal options prevent
c  the link step, and give the object file the same name as the fortran
c  file (with the suffix .o)
c
       if (coptions(i2:i2+4) .eq. 'debug') then
         coptions = '-g'
         loptions = '-g'
         if (compiler(i1:i1+3) .eq. 'cf77'    ) then
           coptions = '-g'
           loptions = '-g'
         endif
         if (compiler(i1:i1+2) .eq. 'f90'     ) then
           coptions = '-g -C -ftrap=common'
           loptions = '-g'
         endif
         if (compiler(i1:i1+2) .eq. 'g95'     ) then
           coptions = '-g -fbounds-check -ftrace=full'
           loptions = '-g'
         endif
         if (compiler(i1:i1+7) .eq. 'gfortran') then
           coptions = '-g -fbounds-check -ffpe-trap=i,z,o'
           loptions = '-g'
         endif
         if (compiler(i1:i1+4) .eq. 'ifort'   ) then
           coptions ='-g -debug-parameters -check -fpe1 -traceback -m32'
           loptions = '-g -m32'
         endif
         if (compiler(i1:i1+4) .eq. 'pgf77'   ) then
           coptions = '-g -Ktrap=fp -Mbounds'
           loptions = '-g'
         endif
         if (compiler(i1:i1+2) .eq. 'xlf'     ) then
           coptions = '-g -C -qextchk -qflttrap -qsigtrap'
           loptions = '-g'
         endif
       endif
c
c      If "coptions" is set to "optimise", set "coptions" and "loptions"
c  to those appropriate for the compiler selected.
c
       if (coptions(i2:i2+5) .eq. 'optimi') then
         coptions = '-O2'
         loptions = '-O2'
         if (compiler(i1:i1+3) .eq. 'cf77'    ) then
           coptions = '-O4'
           loptions = '-O4'
         endif
         if (compiler(i1:i1+2) .eq. 'f90'     ) then
           coptions = '-O4'
           loptions = '-O4'
         endif
         if (compiler(i1:i1+2) .eq. 'g95'     ) then
           coptions = '-O2'
           loptions = '-O2'
         endif
         if (compiler(i1:i1+7) .eq. 'gfortran') then
           coptions = '-O2'
           loptions = '-O2'
         endif
         if (compiler(i1:i1+4) .eq. 'ifort'   ) then
           coptions = '-O2 -diag-disable remark -m32'
           loptions = '-O2 -m32'
         endif
         if (compiler(i1:i1+4) .eq. 'pgf77'   ) then
           coptions = '-fast'
           loptions = '-fast'
         endif
         if (compiler(i1:i1+2) .eq. 'xlf'     ) then
           coptions = '-O4'
           loptions = '-O4'
         endif
       endif
c
c      Set "phrase" which will be part of the banner.
c
       phrase        = blank64
       nph           = 24
       phrase(1:nph) = 'with an unknown compiler'
       nph           = 24
       phrase(1:nph) = 'compiled with Sun''s f90'
c
       oldname = inname
       chgname = chgdk
       tmpname = in2name
       newname = outname
       dknam1  = first
       dknam2  = secnd
       dknam3  = firstcd
       dknam4  = firstdk
c
c      Store the number of characters in each filename.
c
       do 20 j=1,64
         char1 = oldname(j:j)
         if (char1 .ne. ' ') ncharo = j
         char1 = chgname(j:j)
         if (char1 .ne. ' ') ncharc = j
         char1 = tmpname(j:j)
         if (char1 .ne. ' ') nchart = j
         char1 = newname(j:j)
         if (char1 .ne. ' ') ncharn = j
20     continue
c
c      Store the number of characters in "branch".  If last character
c  is not a '/', then append one.
c
       do 30 j=1,32
         char1 = branch (j:j)
         if (char1 .ne. ' ') ncharb = j
30     continue
       if (branch(ncharb:ncharb) .ne. '/') then
         ncharb = ncharb + 1
         branch(ncharb:ncharb) = '/'
       endif
c
c      If "newname" is still blank, create "newname" from "oldname" by
c  appending one of the following extensions:
c
c      job = 1 (number)  =>  extension = .n
c      job = 2 (target)  =>  extension = .t
c      job = 3 (merge)   =>  extension = .m
c      job = 4 (precom)  =>  extension = .f
c
c  If "oldname" is already 63 or 64 characters long, the last 1 or 2
c  characters are overwritten by the extension.  This may cause
c  duplication in the filenames, and so the user should make sure
c  all filenames (including the directory path) are 62 characters
c  long or less.
c
       if ( (newname .eq. blank64) .and. (oldname .ne. blank64) ) then
         ncharn = ncharo + 2
         newname(1:ncharo) = oldname(1:ncharo)
         if (job .eq. 1) newname(ncharo+1:ncharn) = '.n'
         if (job .eq. 2) newname(ncharo+1:ncharn) = '.t'
         if (job .eq. 3) newname(ncharo+1:ncharn) = '.m'
         if (job .eq. 4) newname(ncharo+1:ncharn) = '.f'
       endif
c
c      Default for number of variables that can be assigned per namelist
c  is 1000.
c
       if (inmlst .eq. 1) inmlst = 1000
       if ( (iutask .lt.-2) .or. (iutask .gt. 2) ) iutask = 0
c
c      Store the number of special decks to be compiled with special
c  compiler options speccopt.
c
       do 31 i=1,ismax
         if (specdk(i) .eq. blank16) go to 32
31     continue
32     continue
       nobj2 = i - 1
c
c      Write banner to crt.
c
       if (ibanner .eq. 1) then
         write (6, 2010)
       endif
       write (6, 2011) phrase(1:nph)
c
c      Initialise parameters which keep track of how many lines have
c  been read from the various disc files.  For example, if "oldname"
c  is being read into "oldfile", "nloldt" represents the total number
c  of lines read from the disc file "oldname", while "nlold" represents
c  the number of lines currently stored in the text file "oldfile".
c  These values will not be the same if the first line read from the
c  disc file was not the first line.  The disc file can be as long as
c  necessary, thus there is no bound on "nloldt".  On the other hand,
c  "nlold" must be no greater than "ilmax" (= parameter k2).
c
       nloldt = 0
       nltmpt = 0
       nlcdkt = 0
       nlnewt = 0
       nldmpt = 0
       nlmakt = 0
c
c      Initialise global logical variable "lreadall" to .false..  If the
c  entire input disc file "oldname" can be read into the text file
c  "oldfile" by a single call to RFILE, then RFILE sets "lreadall" to
c  .true..  This tells any subsequent routines requiring the contents
c  of "oldname" that it is not necessary to read the disc file again.
c
       lreadall = .false.
c
c      Open dumpfile "output" and write header.
c
       if ( (idump .eq. 1) .and. (job .ne. 1) ) then
         filename      = blank64
         filename(1:6) = 'output'
         call ofile  ( ludmp, filename, 'unknown ' )
         call header ( ludmp )
       endif
       if (ibanner .eq. 1) write (6, 2020)
c
c-----------------------------------------------------------------------
c------------------ DIRECT EXECUTION ACCORDING TO JOB ------------------
c-----------------------------------------------------------------------
c
c      Job = 1  =>  NUMBER lines in source code.
c
       if (job .eq. 1) then
         if (ibanner .eq. 1) then
           write (6, 2030)
           if (inumber .eq. 1) write (6, 2040)
           if (inumber .eq. 2) write (6, 2050)
           if (inumber .eq. 3) write (6, 2060)
           write (6, 2020)
         endif
         call number
       endif
c
c      Job = 2  =>  reTARGET source code.
c
       if (job .eq. 2) then
         if (ibanner .eq. 1) then
           write (6, 2070)
           write (6, 2080) ibegdo, ienddo, ibegre, iendre, ibegwr
     1                   , iendwr, inc
           if (ireseq .eq. 0) write (6, 2090)
           if (ireseq .eq. 1) write (6, 2100)
           if (indent .eq. 0) write (6, 2110)
           if (indent .gt. 0) then
             ind0 = indent + 6
             write (6, 2120) ind0
           endif
           if (idump  .eq. 1) write (6, 2130)
           if (ialpha .eq. 1) write (6, 2140)
           write (6, 2020)
         endif
         call target
       endif
c
c      Job = 3  =>  MERGE change deck into source file.
c
       if (job .eq. 3) then
         if (ibanner .eq. 1) then
           write (6, 2150)
           if (inum .eq. 1) write (6, 2160)
           if (inum .ne. 1) write (6, 2170)
           if (ipre .eq. 1) then
             write (6, 2180)
             if (inmlst  .gt. 0) write (6, 2200) inmlst
             if (inmlst  .eq. 0) write (6, 2210)
             if (iutask  .eq. 1) write (6, 2220)
             if (iutask  .eq.-1) write (6, 2221)
             if (iutask  .eq. 2) write (6, 2225)
             if (iutask  .eq.-2) write (6, 2226)
             if (iupdate .eq. 1) then
               write (6, 2230) branch
               if (makename .ne. blank16) then
                 write (6, 2240) makename
               else
                 write (6, 2250)
               endif
             endif
           else
             write (6, 2190)
           endif
           write (6, 2020)
         endif
         call merge
       endif
c
c      Job = 4  =>  PRECOMpile source code.
c
       if (job .eq. 4) then
         if (ibanner .eq. 1) then
           write (6, 2260)
           if (inmlst .gt. 0) write (6, 2200) inmlst
           if (inmlst .eq. 0) write (6, 2210)
           if (iutask .eq. 1) write (6, 2220)
           if (iutask .eq.-1) write (6, 2221)
           if (iutask .eq. 2) write (6, 2225)
           if (iutask .eq.-2) write (6, 2226)
           if (iupdate .eq. 1) then
             write (6, 2230) branch
             if (makename .ne. blank16) then
               write (6, 2240) makename
             else
               write (6, 2250)
             endif
           endif
           write (6, 2020)
         endif
         call precom
       endif
c
c      Job = 5  =>  COMPARE two input files.
c
       if (job .eq. 5) then
         if (ibanner .eq. 1) then
           write (6, 2270)
           if (icompar .eq. 1) then
             if (ndiff .eq. 1) write (6, 2280)
             if (ndiff .gt. 1) write (6, 2290) ndiff
             if (ignore(1) .eq. 1) write (6, 2300)
             if (ignore(2) .eq. 1) write (6, 2310)
             if (ignore(3) .eq. 1) write (6, 2320)
           endif
           if (icompar .eq. 2) write (6, 2330)
           write (6, 2020)
         endif
         call compare
       endif
c
c      Job = 6  =>  SPLIT file into separate files for each deck
c
       if (job .eq. 6) then
         if (ibanner .eq. 1) then
           write (6, 2340) branch
           write (6, 2020)
         endif
         call split
       endif
c
c      Job = 7  =>  CONCATenate files with common extension
c
       if (job .eq. 7) then
         if (ibanner .eq. 1) then
           write (6, 2350) branch, ext, newname
           write (6, 2020)
         endif
         call concat
       endif
c
c      Job = 10  =>  TESTing subroutine
c
       if (job .eq. 10) then
         if (ibanner .eq. 1) then
           write (6, 2360)
           write (6, 2020)
         endif
         call test
       endif
c
c-----------------------------------------------------------------------
c
c      Close dumpfile "outfile".
c
       if ( (idump .eq. 1) .and. (job .ne. 1) ) then
         call footer ( ludmp )
         filename      = blank64
         filename(1:6) = 'output'
         call cfile  ( ludmp, filename, nldmpt )
       endif
       close ( lunml )
       close ( lulp  )
c
c      Final wall clock time, expressed in minutes and seconds.
c
       wctot   = wclock ( wcms2, chtime, chdate, 0 ) - wctot
       if (wcms2 .lt. wcms1) then
         wcms2 = wcms2 + 1000
         wctot = wctot - 1
       endif
       wcmin   = wctot / 60
       wcsec   = wctot - wcmin * 60
       wcfrac  = wcms2 - wcms1
       rwctot  = max ( 0.0, real ( wctot ) + 0.001 * real ( wcfrac ) )
c
c      Total cpu usage, expressed in minutes and seconds.
c
       cctot   = cclock () - cctot
       ccmin   = int ( cctot / 60.0 )
       ccsec   = int ( cctot )        - ccmin * 60
       ccfrac  = int ( 1000.0 * ( cctot - real(int(cctot)) ) + 0.5 )
c
c      Percent of wall-clock time job was serviced.
c
       ptime   = 100.0
       if (rwctot .gt. 0.0) ptime = 100.0 * cctot / rwctot
c
c      Write final messages to crt, and stop.
c
       if (ibanner .eq. 1) write (6, 2020)
       write (6, 2370) wcmin, wcsec, wcfrac, ccmin, ccsec, ccfrac, ptime
       if (ibanner .eq. 1) write (6, 2380)
c
       stop
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(///,8x,'EEEEE DDDD  III TTTTT  OOO  RRRR',/
     1           ,8x,'E      D  D  I    T   O   O R   R',/
     2           ,8x,'EEEE   D  D  I    T   O   O RRRR',4x
     3           ,'EDITOR2.2 - RELEASE OF 15MAR11',/
     4           ,8x,'E      D  D  I    T   O   O R  R',/
     5           ,8x,'EEEEE DDDD  III   T    OOO  R   R',/)
2011   format(/,'EDITOR  : Running Version 2.2 ',a,/
     1       ,'EDITOR  :')
2020   format('EDITOR  :')
2030   format('EDITOR  : Source code will be NUMBERed')
2040   format('EDITOR  : sequential NUMBERing only')
2050   format('EDITOR  : sequential, statement, and subroutine '
     1       ,'NUMBERing')
2060   format('EDITOR  : sequential, statement, and deck '
     1       ,'NUMBERing')
2070   format('EDITOR  : Source code will be reTARGETed')
2080   format('EDITOR  : "goto" and "do loop" targets range from '
     1       ,i5,' to ',i5,/
     2       ,'EDITOR  : "read" and "decode"  targets range from '
     3       ,i5,' to ',i5,/
     4       ,'EDITOR  : "write" and "encode" targets range from '
     5       ,i5,' to ',i5,/
     6       ,'EDITOR  : All targets increment by ',i2)
2090   format('EDITOR  : continuation statements will NOT be '
     1       ,'resequenced.')
2100   format('EDITOR  : continuation statements will be '
     1       ,'resequenced.')
2110   format('EDITOR  : uniform indentation will NOT be applied')
2120   format('EDITOR  : uniform indentation will begin in column '
     1       ,i2)
2130   format('EDITOR  : diagnostic dumps printed to "output"')
2140   format('EDITOR  : The order of decks will be alphabetised')
2150   format('EDITOR  : Source code and change deck will be MERGEd')
2160   format('EDITOR  : a NUMBERed file will be created')
2170   format('EDITOR  : a NUMBERed file will NOT be created')
2180   format('EDITOR  : a PRECOMpiled file will be created')
2190   format('EDITOR  : a PRECOMpiled file will NOT be created')
2200   format('EDITOR  : NAMELIST''s will be substituted for calls to '
     1       ,'NLSDACxx subroutines.',/
     2       ,'EDITOR  : Maximum number of assignments per namelist is '
     3       ,i5,'.')
2210   format('EDITOR  : NAMELIST''s will not be altered.')
2220   format('EDITOR  : Nested do-loops will be Cray microtasked')
2221   format('EDITOR  : All outer do-loops will be Cray microtasked')
2225   format('EDITOR  : Nested do-loops will be microtasked for '
     1       'OpenMP')
2226   format('EDITOR  : All outer do-loops will be microtasked for '
     1       'OpenMP')
2230   format('EDITOR  : Files in directory "',a32,'" will be UPDATEd.')
2240   format('EDITOR  : makefile: "',a16,'" will be written to disc.')
2250   format('EDITOR  : NO makefile will be written to disc.')
2260   format('EDITOR  : Source code will be PRECOMpiled')
2270   format('EDITOR  : Input files will be COMPAREd')
2280   format('EDITOR  : The first difference will be reported.')
2290   format('EDITOR  : The first ',i4,' differences will be '
     1       ,'reported.')
2300   format('EDITOR  : Continuation characters will be ignored.')
2310   format('EDITOR  : Blanks will be ignored.')
2320   format('EDITOR  : Comment statements will be ignored.')
2330   format('EDITOR  : Incompatibilities in the declaration lists '
     1       ,'will be reported.')
2340   format('EDITOR  : Input file will be SPLIT into separate files '
     1       ,'for each deck (module).',/
     2       ,'EDITOR  : New files written to directory: ',a32)
2350   format('EDITOR  : Files found in or below directory ',a32,/
     1       ,'EDITOR  : with extension ',a8,' will be CONCATenated to '
     2       ,'the contents of file',/
     3       ,'EDITOR  : "',a64,'".')
2360   format('EDITOR  : TEST mode.')
2370   format('EDITOR  : Real time = ',i3,':',i2.2,'.',i3.3
     1       ,', CPU time = ',i3,':',i2.2,'.',i3.3,' (',f7.2,'%)')
2380   format('EDITOR  : Ends successfully.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                E D I T O R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                E R R M S G                \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine errmsg ( iline, ifile, ierror )
c
c    dac:editor.errmsg <-------------------------- issues error messages
c                                                         november, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine inserts the error message specified by
c  "ierror" into the text file specified by "ifile" just after the line
c  where the error was detected ("iline").
c
c  INPUT VARIABLES:
c    iline       line number after which error message is written.
c    ifile       =1 => error message written to "oldfile"
c                =2 => error message written to "tmpfile"
c                =3 => error message written to "cdkfile"
c                =4 => error message written to "newfile"
c    ierror      integer which determines which error message is to be
c                issued.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c    line        character*128 string containing the error message to be
c                written.
c
c  EXTERNALS:
c    OVERFLOW
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*128 line
       integer       iline   , ifile   , ierror
c
c      External statements
c
       external      overflow
c
c-----------------------------------------------------------------------
c
c      Error messages from ERRMSG
c
       write (line, 2010)
c
c      Error messages from CDECKS
c
       if (ierror .eq.  1) write ( line, 2020) ierror
       if (ierror .eq.  2) write ( line, 2030) ierror
c
c      Error messages from COLLECT
c
       if (ierror .eq.  3) write ( line, 2040) ierror
       if (ierror .eq.  4) write ( line, 2050) ierror
       if (ierror .eq.  5) write ( line, 2060) ierror
       if (ierror .eq.  6) write ( line, 2070) ierror
c
c      Error messages from COPY
c
       if (ierror .eq.  7) write ( line, 2080) ierror
       if (ierror .eq.  8) write ( line, 2090) ierror
       if (ierror .eq.  9) write ( line, 2100) ierror
c
c      Error messages from CTOI
c
       if (ierror .eq. 10) write ( line, 2110) ierror
c
c      Error messages from ERRSET
c
       if (ierror .eq. 12) write ( line, 2120) ierror
c
c      Error messages from INOREX
c
       if (ierror .eq. 13) write ( line, 2130) ierror
       if (ierror .eq. 14) write ( line, 2140) ierror
       if (ierror .eq. 15) write ( line, 2150) ierror
       if (ierror .eq. 16) write ( line, 2160) ierror
       if (ierror .eq. 17) write ( line, 2170) ierror
       if (ierror .eq. 18) write ( line, 2180) ierror
       if (ierror .eq. 19) write ( line, 2190) ierror
c
c      Error messages from LIST
c
       if (ierror .eq. 20) write ( line, 2200) ierror
c
c      Error messages from MERGE
c
       if (ierror .eq. 48) write ( line, 2210) ierror
       if (ierror .eq. 21) write ( line, 2220) ierror
       if (ierror .eq. 22) write ( line, 2230) ierror
       if (ierror .eq. 23) write ( line, 2240) ierror
       if (ierror .eq. 24) write ( line, 2250) ierror
       if (ierror .eq. 25) write ( line, 2260) ierror
       if (ierror .eq. 26) write ( line, 2270) ierror
c
c      Error messages from NMLST
c
       if (ierror .eq. 27) write ( line, 2280) ierror
       if (ierror .eq. 28) write ( line, 2290) ierror
       if (ierror .eq. 29) write ( line, 2300) ierror
       if (ierror .eq. 30) write ( line, 2310) ierror
       if (ierror .eq. 31) write ( line, 2320) ierror
       if (ierror .eq. 32) write ( line, 2330) ierror
       if (ierror .eq. 33) write ( line, 2340) ierror
c
c      Error messages from PRECOM
c
       if (ierror .eq. 34) write ( line, 2350) ierror
c
c      Error messages from TARGET
c
       if (ierror .eq. 35) write ( line, 2360) ierror
       if (ierror .eq. 36) write ( line, 2370) ierror
       if (ierror .eq. 37) write ( line, 2380) ierror
       if (ierror .eq. 38) write ( line, 2390) ierror
       if (ierror .eq. 39) write ( line, 2400) ierror
       if (ierror .eq. 40) write ( line, 2410) ierror
       if (ierror .eq. 41) write ( line, 2420) ierror
       if (ierror .eq. 42) write ( line, 2430) ierror
       if (ierror .eq. 43) write ( line, 2440) ierror
       if (ierror .eq. 44) write ( line, 2450) ierror
       if (ierror .eq. 45) write ( line, 2460) ierror
       if (ierror .eq. 46) write (ifile, 2470) ierror, 2*ismax
c
c      Error messages from PARALLEL
c
       if (ierror .eq. 47) write ( line, 2480) ierror
c
c      Write error message to text file specified by "ifile" after line
c  "iline".
c
       iline = iline + 1
       if (iline .gt. ilmax) call overflow ( ifile, 5 )
       if (ifile .eq. 1) oldfile(iline) = line
       if (ifile .eq. 2) tmpfile(iline) = line
       if (ifile .eq. 3) cdkfile(iline) = line
       if (ifile .eq. 4) newfile(iline) = line
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('*error ERRMSG  : **** ERROR 999 **** Unspecified '
     1       ,'error.')
c
2020   format('*error CDECKS  : **** ERROR ',i3,' **** > 10 nested '
     1       ,'*call''s.  Does a *cdeck call itself?')
2030   format('*error CDECKS  : **** ERROR ',i3,' **** Call made to an '
     1       ,'unknown common deck.')
c
2040   format('*error COLLECT : **** ERROR ',i3,' **** Expecting a '
     1       ,'character expression.')
2050   format('*error COLLECT : **** ERROR ',i3,' **** Too many '
     1       ,'switches defined.')
2060   format('*error COLLECT : **** ERROR ',i3,' **** Too many '
     1       ,'aliases defined.')
2070   format('*error COLLECT : **** ERROR ',i3,' **** Too many common '
     1       ,'decks defined.')
c
2080   format('*error COPY    : **** ERROR ',i3,' **** Syntax!  First '
     1       ,'character is illegal.')
2090   format('*error COPY    : **** ERROR ',i3,' **** Syntax!  EDITOR '
     1       ,'sentinel (*) not in column 1.')
2100   format('*error COPY    : **** ERROR ',i3,' **** Syntax!  '
     1       ,'Extra space after EDITOR sentinel (*).')
c
2110   format('*error CTOI    : **** ERROR ',i3,' **** A non-numeric '
     1       ,'character detected.')
c
2120   format('*error ERRSET  : **** ERROR ',i3,' **** Number of '
     1       ,'issued errors exceeds "k1".')
c
2130   format('*error INOREX  : **** ERROR ',i3,' **** Unrecognised '
     1       ,'EDITOR command.')
2140   format('*error INOREX  : **** ERROR ',i3,' **** More than ten '
     1       ,'nested *if statements.')
2150   format('*error INOREX  : **** ERROR ',i3,' **** Expecting a '
     1       ,'character expression.')
2160   format('*error INOREX  : **** ERROR ',i3,' **** Expecting a '
     1       ,'Boolean .and. or .or..')
2170   format('*error INOREX  : **** ERROR ',i3,' **** Expecting a '
     1       ,'Boolean .eq. or .ne..')
2180   format('*error INOREX  : **** ERROR ',i3,' **** Dangling *endif '
     1       ,'statement.')
2190   format('*error INOREX  : **** ERROR ',i3,' **** Too few *endif '
     1       ,'statements in previous deck.')
c
2200   format('*error LIST    : **** ERROR ',i3,' **** Unbalanced '
     1       ,'parentheses.')
c
2210   format('*error MERGE   : **** ERROR ',i3,' **** Too many nested '
     1       ,'*read''s.')
2220   format('*error MERGE   : **** ERROR ',i3,' **** Expecting a '
     1       ,'character expression.')
2230   format('*error MERGE   : **** ERROR ',i3,' **** Reference made '
     1       ,'to an undefined deck.')
2240   format('*error MERGE   : **** ERROR ',i3,' **** Expecting a '
     1       ,'line number to follow deck name.')
2250   format('*error MERGE   : **** ERROR ',i3,' **** Last line '
     1       ,'number must be greater than first.')
2260   format('*error MERGE   : **** ERROR ',i3,' **** Specified range '
     1       ,'not found in deck.')
2270   format('*error MERGE   : **** ERROR ',i3,' **** Cannot find '
     1       ,'specified line.  Was it deleted?')
c
2280   format('*error NMLST   : **** ERROR ',i3,' **** Missing opening '
     1       ,'delimeter /.')
2290   format('*error NMLST   : **** ERROR ',i3,' **** Missing closing '
     1       ,'delimeter /.')
2300   format('*error NMLST   : **** ERROR ',i3,' **** Too many '
     1       ,'variables in namelist.  Increase "k9".')
2310   format('*error NMLST   : **** ERROR ',i3,' **** Too many '
     1       ,'vars. in namelist.  Increase "inmlst".')
2320   format('*error NMLST   : **** ERROR ',i3,' **** No variables '
     1       ,'found in namelist.')
2330   format('*error NMLST   : **** ERROR ',i3,' **** Unrecognised '
     1       ,'syntax in dimension statement.')
2340   format('*error NMLST   : **** ERROR ',i3,' **** Blank "nlsdac" '
     1       ,'suffix!  Check declarations.')
c
2350   format('*error PRECOM  : **** ERROR ',i3,' **** Call made to an '
     1       ,'unknown common deck.')
c
2360   format('*error TARGET  : **** ERROR ',i3,' **** Unrecognised '
     1       ,'character in first five columns.')
2370   format('*error TARGET  : **** ERROR ',i3,' **** Too many '
     1       ,'targets - Going on to next deck.')
2380   format('*error TARGET  : **** ERROR ',i3,' **** Unrecognised '
     1       ,'syntax.')
2390   format('*error TARGET  : **** ERROR ',i3,' **** Expecting a '
     1       ,'numerical target.')
2400   format('*error TARGET  : **** ERROR ',i3,' **** Too many '
     1       ,'origins - Going on to next deck.')
2410   format('*error TARGET  : **** ERROR ',i3,' **** Target defined '
     1       ,'more than once.')
2420   format('*error TARGET  : **** ERROR ',i3,' **** Origin has no '
     1       ,'target.')
2430   format('*error TARGET  : **** ERROR ',i3,' **** Ambiguous '
     1       ,'targets.')
2440   format('*error TARGET  : **** ERROR ',i3,' **** Too many "do"s '
     1       ,'and/or "goto"s in this deck.')
2450   format('*error TARGET  : **** ERROR ',i3,' **** Too many '
     1       ,'"read"s in this deck.')
2460   format('*error TARGET  : **** ERROR ',i3,' **** Too many '
     1       ,'"write"s in this deck.')
2470   format(/,'TARGET  : **** ERROR ',i3,' **** More than ',i4
     1       ,' decks defined.  Part of file lost.')
c
2480   format('*error PARALLEL: **** ERROR ',i3,' **** Too many '
     1       ,'variables in do-loop.  Increase "k9".')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                E R R M S G                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                E R R S E T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine errset ( iline, ierror, istore )
c
c    dac:editor.errset <----------------------------- sets an error code
c                                                         november, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine stores the error code ("ierror") in "ierrN"
c  (where N = "istore"), and the line number in the file where the error
c  was found ("iline") in "lnerrN".  In this way, an error and its
c  location can be stored as it is detected and then written to the text
c  file (by calling ERRWRT) later on.  Care must be taken to update
c  "lnerrN" if the length of the text file is altered between the time
c  when the subroutines ERRSET and ERRWRT are called.  Alternatively,
c  one can just call ERRMSG as soon as the error message is discovered,
c  if it is convenient to insert the error message at that time.
c      The two error arrays allow errors and their line numbers to be
c  stored for two different files.  For example, "ierr1" might contain
c  the errors found in the whole source code, while "ierr2" contains a
c  list of errors found in the text file containing the common decks.
c
c  INPUT ARGUMENTS:
c    iline       line number where error occurred.
c    ierror      error code to be stored in "ierr1" or "ierr2".
c    istore      =1 => store in "ierr1" and "lnerr1"
c                =2 => store in "ierr2" and "lnerr2"
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       integer       iline   , ierror  , istore
c
c-----------------------------------------------------------------------
c
       if (istore .eq. 1) then
         nerr1   = nerr1   + 1
         nerror1 = nerror1 + 1
         if (nerr1 .ge. iemax) then
           nerr1 = iemax
           lnerr1(nerr1) = iline
           ierr1 (nerr1) = 12
           return
         endif
         lnerr1(nerr1) = iline
         ierr1 (nerr1) = ierror
       endif
c
       if (istore .eq. 2) then
         nerr2   = nerr2   + 1
         nerror2 = nerror2 + 1
         if (nerr2 .ge. iemax) then
           nerr2 = iemax
           lnerr2(nerr2) = iline
           ierr2 (nerr2) = 12
           return
         endif
         lnerr2(nerr2) = iline
         ierr2 (nerr2) = ierror
       endif
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                E R R S E T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                E R R W R T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine errwrt ( iline, ifile, ierror, insert )
c
c    dac:editor.errwrt <------------- writes error messages to text file
c                                                          october, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine scans through the list of known errors
c  "ierrN" (N = "ierror") and compares the current line number of the
c  input text file ("iline") with the line numbers where the error
c  occurred ("lnerrN").  If line "iline" should have an error associated
c  with it, ERRMSG is called to insert the error message specified by
c  "ierrN" into the output text file (specified by "ifile") after the
c  line specified by "insert".  Once the error message is written, it is
c  removed from the lists "ierrN" and "lnerrN", and the number of
c  pending errors ("nerrN") is reduced by one.
c
c  INPUT VARIABLES:
c    iline       current line number in input text file
c    ifile       text file in which error messages are inserted.
c                =1 => insert messages into "oldfile"
c                =2 => insert messages into "tmpfile"
c                =3 => insert messages into "cdkfile"
c                =4 => insert messages into "newfile"
c    ierror      =1 => check lists "ierr1" and "lnerr1"
c                =2 => check lists "ierr2" and "lnerr2"
c    insert      line number of output file after which error message
c                should be inserted.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    ERRMSG
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       integer       iline   , ifile   , ierror  , insert
       integer       i1      , ierr
c
c      External statements
c
       external      errmsg
c
c-----------------------------------------------------------------------
c
       if (ierror .eq. 1) then
         i1 = 1
10       continue
         do 20 ierr=i1,nerr1
           if (iline .eq. lnerr1(ierr)) then
             call errmsg ( insert, ifile, ierr1(ierr) )
             go to 30
           endif
20       continue
         return
30       continue
         i1 = ierr
         do 40 ierr=i1,nerr1-1
           lnerr1(ierr) = lnerr1(ierr+1)
           ierr1 (ierr) = ierr1 (ierr+1)
40       continue
         lnerr1(nerr1) = 0
         ierr1 (nerr1) = 0
         nerr1         = nerr1 - 1
         go to 10
       endif
c
       if (ierror .eq. 2) then
         i1 = 1
50       continue
         do 60 ierr=i1,nerr2
           if (iline .eq. lnerr2(ierr)) then
             call errmsg ( insert, ifile, ierr2(ierr) )
             go to 70
           endif
60       continue
         return
70       continue
         i1 = ierr
         do 80 ierr=i1,nerr2-1
           lnerr2(ierr) = lnerr2(ierr+1)
           ierr2 (ierr) = ierr2 (ierr+1)
80       continue
         lnerr2(nerr2) = 0
         ierr2 (nerr2) = 0
         nerr2         = nerr2 - 1
         go to 50
       endif
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                E R R W R T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              O V E R F L O W              \\\\\\\\\\
c
c=======================================================================
c
       subroutine overflow ( ifile, imsg )
c
c    dac:editor.overflow <------ aborts execution if text file overflows
c                                                          october, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine informs user that a text file has
c  overflowed and indicates what parameters or namelist variables need
c  to be increased.  The text file is written to the disc file specified
c  by "lunit" and "filename", and execution is aborted.
c
c  INPUT VARIABLES:
c    ifile       =1 => overflow occurred in "oldfile"
c                =2 => overflow occurred in "tmpfile"
c                =3 => overflow occurred in "cdkfile"
c                =4 => overflow occurred in "newfile"
c    imsg        =0 => no special message written to crt.
c                >0 => specifies which special message is written to crt
c
c  LOCAL VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  EXTERNALS:
c    WFILE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*64  filename
       integer       ifile   , imsg
       integer       ncharf
c
c      External statements
c
       external      wfile
c
c-----------------------------------------------------------------------
c
c      Reduce "nlxxx" by 1.
c
       if (ifile .eq. 1) nlold = nlold - 1
       if (ifile .eq. 2) nltmp = nltmp - 1
       if (ifile .eq. 3) nlcdk = nlcdk - 1
       if (ifile .eq. 4) nlnew = nlnew - 1
c
c      Open disc file "overflow.txt" on unit luout, and write contents
c  of text file that has overflowed.  Then close unit "luout".
c
       filename                     = blank64
       filename(       1:       32) = branch
       filename(ncharb+1:ncharb+12) = 'OVERFLOW.TXT'
       ncharf = ncharb + 12
       open  ( luout, file=filename, status='unknown' )
       call wfile ( luout, ifile )
       close ( luout )
c
c      Messages to crt.
c
       if (imsg .eq.  0) go to 10
       if (imsg .eq.  1) write (6, 2010)
       if (imsg .eq.  2) write (6, 2020) safety
       if (imsg .eq.  3) write (6, 2030) safety
       if (imsg .eq.  4) write (6, 2040) safety
       if (imsg .eq.  5) write (6, 2070)
       if (imsg .eq.  7) write (6, 2080)
       if (imsg .eq.  8) write (6, 2090) safety
       if (imsg .eq.  9) write (6, 2100) safety
       if (imsg .eq. 10) write (6, 2110)
c
10     continue
       if (ncharf .le. 30) write (6, 2120) filename
       if (ncharf .gt. 30) write (6, 2130) filename
       write (6, 2140)
       stop
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('OVERFLOW: File overflow in MERGE.  Increase parameter '
     1       ,'"k2".')
2020   format('OVERFLOW: File overflow in MERGE.  Specify lower value '
     1       ,'for "safety" than ',f4.2)
2030   format('OVERFLOW: File overflow in PRECOM.  Specify lower value '
     1       ,'for "safety" than ',f4.2)
2040   format('OVERFLOW: File overflow in NMLST.  Specify lower value '
     1       ,'for "safety" than ',f4.2)
2070   format('OVERFLOW: In ERRMSG, attempt to insert error message '
     1       ,'causes a file overflow.')
2080   format('OVERFLOW: File overflow in CDECKS.  Increase parameter '
     1       ,'"k2".')
2090   format('OVERFLOW: File overflow in TARGET.  Specify lower value '
     1       ,'for "safety" than ',f4.2)
2100   format('OVERFLOW: File overflow in PARALLEL.  Specify lower '
     1       ,'value for "safety" than ',f4.2)
2110   format('OVERFLOW: ')
2120   format('OVERFLOW: Overflowed text file written to file "'
     1       ,a30,'".')
2130   format('OVERFLOW: Overflowed text file written to file "'
     1       ,a28,'....')
2140   format('OVERFLOW: ABORTS!')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              O V E R F L O W              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 C F I L E                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine cfile ( lunit, filename, nlines )
c
c    dac:editor.cfile <------------------------------------ closes files
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine closes the specified logical unit, and
c  writes closing message to crt.
c
c  INPUT VARIABLES:
c    lunit       logical unit to be closed.
c    filename    name of file previously assigned to "lunit".
c    nlines      >0 => number of lines written to file
c                =0 => this was an input file - no lines written.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*64  filename
       integer       lunit
       integer       j       , ncharf   , nlines
c
c-----------------------------------------------------------------------
c
       close ( lunit )
       if (ibanner .eq. 1) then
         do 10 j=1,64
           char1 = filename(j:j)
           if (char1 .ne. ' ') ncharf = j
10       continue
         if (nlines .gt. 0) then
           if (ncharf .le. 16) write (6, 2010) filename, lunit, nlines
           if (ncharf .gt. 16) write (6, 2020) filename, lunit, nlines
         else
           if (ncharf .le. 16) write (6, 2030) filename, lunit
           if (ncharf .gt. 16) write (6, 2040) filename, lunit
         endif
       endif
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('CFILE   : File "',a16,'" on unit ',i2,' closed - '
     1       ,'written with ',i6,' lines.')
2020   format('CFILE   : File "',a14,'... on unit ',i2,' closed - '
     1       ,'written with ',i6,' lines.')
2030   format('CFILE   : File "',a16,'" on unit ',i2,' closed.')
2040   format('CFILE   : File "',a14,'... on unit ',i2,' closed.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 C F I L E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  D U M P                  \\\\\\\\\\
c
c=======================================================================
c
       subroutine dump
c
c    dac:editor.dump <--------------------- diagnostic dumps to "output"
c                                                         november, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine dumps diagnostic output from the job to
c  unit "ludmp" (filename = "output").  The output for each job is as
c  follows:
c
c  job = 1  =>  NUMBER
c  [NONE]
c
c  job = 2  =>  TARGET
c  All of the original targets, origins and associated errors are
c  tabulated, followed by the updated targets, etc.  This is done
c  separately for each subroutine.
c
c  job = 3  =>  MERGE
c  [NONE]
c
c  job = 4  =>  PRECOMpile
c  Defined switches, aliases and decks are listed, along with a list
c  of errors which may have been detected.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c    frstwrd     a 16 character word set to either ORIGINAL or UPDATED
c                by the subroutine TARGET, used to label the tables.
c    subname     a 16 character word containing the name of the current
c                subroutine set by TARGET, used to label the tables.
c
c  Both of these variables are in common block (ccom001) with TARGET.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*16  frstwrd , subname
       integer       i       , j       , imax    , j1      , j2
     1             , ifact
c
       common / ccom001  /
     1               frstwrd , subname
c
c-----------------------------------------------------------------------
c
c      OUTPUT for job = 2 (TARGET).
c
       if (job .eq. 2) then
         write (ludmp, 2010) frstwrd, subname
         write (ludmp, 2020)
         do 10 i=1,ntarg
           write (ludmp, 2030) i, lntarg(i), ittype(i), targ(i)
     1                       , iorig(i), (envir2(i,j), j=1,10)
10       continue
         write (ludmp, 2040)
         do 20 i=1,norig
           write (ludmp, 2050) i, lnorig(i), iotype(i), jstrt(i)
     1                       , jfnsh(i), orig(i), itarg(i)
20       continue
         write (ludmp, 2060)
         do 30 i=1,nerr1
           write (ludmp, 2070) i, lnerr1(i), ierr1(i)
30       continue
         write (ludmp, 2080)
         nldmpt = nldmpt + 12 + ntarg + norig + nerr1
         if (frstwrd .eq. 'UPDATED         ') then
           write (ludmp, 2080)
           nldmpt = nldmpt + 1
         endif
       endif
c
c      OUTPUT for job = 4 (PRECOM).
c
       if (job .eq. 4) then
         write (ludmp, 2090)
         imax = ifix ( (float(nswitch) + 3.1) / 4.0 )
         do 40 i=1,imax
           j1 = (i-1)*4 + 1
           j2 = min0 ( nswitch, j1 + 3 )
           write (ludmp, 2100) (swtch1(j),j=j1,j2)
40       continue
         nldmpt = nldmpt + imax + 2
         write (ludmp, 2110)
         imax = ifix ( (float(nalias) + 1.1) / 2.0 )
         do 50 i=1,imax
           j1 = 2*i - 1
           j2 = j1 + 1
           if (j2 .le. nalias) then
             write (ludmp, 2120) alias1(j1), alias2(j1), alias1(j2)
     1                         , alias2(j2)
           else
             write (ludmp, 2130) alias1(j1), alias2(j1)
           endif
50       continue
         nldmpt = nldmpt + imax + 4
         ifact = 0
         do 60 i=1,nalias
           if (ialias(i) .lt. 2) then
             if (ifact .eq. 0) then
               write (ludmp, 2140)
               nldmpt = nldmpt + 1
             endif
             ifact = 1
             write (ludmp, 2150) alias1(i)
             nldmpt = nldmpt + 1
           endif
60       continue
         write (ludmp, 2160)
         imax = ifix ( (float(ncd) + 7.1) / 8.0 )
         do 70 i=1,imax
           j1 = (i-1)*8 + 1
           j2 = min0 ( ncd, j1 + 7 )
           write (ludmp, 2170) (cdnam(j),j=j1,j2)
70       continue
         nldmpt = nldmpt + imax + 4
         write (ludmp, 2180)
         imax = ifix ( (float(ndk) + 7.1) / 8.0 )
         do 80 i=1,imax
           j1 = (i-1)*8 + 1
           j2 = min0 ( ndk, j1 + 7 )
           write (ludmp, 2170) (dknam(j),j=j1,j2)
80       continue
         nldmpt = nldmpt + imax + 8 + nerr1
         write (ludmp, 2190)
         do 90 i=1,nerr1
           write (ludmp, 2200) i, lnerr1(i), ierr1(i)
90       continue
       endif
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(a8,' TARGETS AND ORIGINS FROM MODULE: ',a8,//)
2020   format('TARGETS',/
     1       ,'       i  lntarg  ittype    targ   iorig'
     2       ,'   environment')
2030   format(3i8,3x,a5,i8,2x,10a3)
2040   format(/,'ORIGINS',/
     1       ,'       i  lnorig  iotype   jstrt   jfnsh'
     2       ,'    orig   itarg')
2050   format(5i8,3x,a5,i8)
2060   format(/,'ERRORS',/
     1       ,'       i  lnerror  ierror')
2070   format(3i8)
2080   format(/)
2090   format('DEFINED SWITCHES',/)
2100   format(4a18)
2110   format(//,'DEFINED ALIASES',/)
2120   format(1x,a16,' = ',a16,7x,a16,' = ',a16)
2130   format(1x,a16,' = ',a16)
2140   format(/)
2150   format('The following alias was never used: ',a16)
2160   format(//,'COMMAND DECKS',/)
2170   format(1x,a8,1x,a8,1x,a8,1x,a8,1x,a8,1x,a8,1x,a8,1x,a8)
2180   format(//,'ORDINARY DECKS',/)
2190   format(//,'ERRORS',/
     1       ,'       i  lnerror  ierror')
2200   format(3i8)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  D U M P                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                F O O T E R                \\\\\\\\\\
c
c=======================================================================
c
       subroutine footer ( lunit )
c
c    dac:editor.header <-------------------- writes footers for outfiles
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine writes the footer for output disc files.
c  The form of the footer written depends on "lunit".
c
c  INPUT VARIABLES:
c    lunit       = logical unit of file to be given the footer.
c                If "lunit" = "ludmp", then a dump footer is written.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       integer       lunit
c
c-----------------------------------------------------------------------
c
c      Footer for dumpfile.
c
       if (lunit .eq. ludmp) then
         write (ludmp, 2010)
         write (ludmp, 2020)
         nldmpt = nldmpt + 4
       endif
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(//)
2020   format('>>>>>>>> EDITOR EDITOR EDITOR EDITOR EDITOR EDITOR '
     1       ,'EDITOR EDITOR EDITOR <<<<<<<<')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                F O O T E R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                H E A D E R                \\\\\\\\\\
c
c=======================================================================
c
       subroutine header ( lunit )
c
c    dac:editor.header <-------------------- writes headers for outfiles
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine writes the header for output disc files.
c  The form of the header written depends on "lunit".
c
c  INPUT VARIABLES:
c    lunit       = logical unit of file to be given the header.
c               If "lunit" = "ludmp", then a dump header is written
c               If "lunit" = "lunew", and "job" = 1, a header for a
c                   NUMBERed file is written.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       integer       lunit
c
c-----------------------------------------------------------------------
c
c      Header for dumpfile.
c
       if (lunit .eq. ludmp) then
         write (ludmp, 2010)
         write (ludmp, 2020)
         if (job .eq. 5) then
           if ( (ncharo .le. 32) .and. (nchart .le. 32) )
     1       write (ludmp, 2030) oldname, tmpname
           if ( (ncharo .le. 32) .and. (nchart .gt. 32) )
     1       write (ludmp, 2040) oldname, tmpname
           if ( (ncharo .gt. 32) .and. (nchart .le. 32) )
     1       write (ludmp, 2050) oldname, tmpname
           if ( (ncharo .gt. 32) .and. (nchart .gt. 32) )
     1       write (ludmp, 2060) oldname, tmpname
         else
           if ( (ncharo .le. 32) .and. (ncharn .le. 32) )
     1       write (ludmp, 2070) oldname, newname
           if ( (ncharo .le. 32) .and. (ncharn .gt. 32) )
     1       write (ludmp, 2080) oldname, newname
           if ( (ncharo .gt. 32) .and. (ncharn .le. 32) )
     1       write (ludmp, 2090) oldname, newname
           if ( (ncharo .gt. 32) .and. (ncharn .gt. 32) )
     1       write (ludmp, 2100) oldname, newname
         endif
         write (ludmp, 2110) chtime, chdate(1:10)
         write (ludmp, 2010)
         write (ludmp, 2120)
         nldmpt = 13
       endif
c
c      Header for a NUMBERed file ("job" = 1)
c
       if ( (lunit .eq. lunew) .and. (job .eq. 1) ) then
         write (lunew, 2010)
         write (lunew, 2020)
         if (inumber .eq. 1) then
           write (lunew, 2130)
           nlnewt = 11
         endif
         if (inumber .eq. 2) then
           write (lunew, 2140)
           nlnewt = 14
         endif
         if (inumber .eq. 3) then
           write (lunew, 2150)
           nlnewt = 15
         endif
         write (lunew, 2110) chtime, chdate(1:10)
         write (lunew, 2010)
         write (lunew, 2120)
       endif
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('>>>>>>>> EDITOR EDITOR EDITOR EDITOR EDITOR EDITOR '
     1       ,'EDITOR EDITOR EDITOR <<<<<<<<')
2020   format(/,5x,'Version 2.2, David A. Clarke, I.C.A., Saint Mary''s'
     1       ,' University, 15MAR11',/)
2030   format(7x,'Comparison dump for FILE1 = "',a32,'"',/,27x
     1       ,'FILE2 = "',a32,'"',/)
2040   format(7x,'Comparison dump for FILE1 = "',a32,'"',/,27x
     1       ,'FILE2 = "',a30,'...',/)
2050   format(7x,'Comparison dump for FILE1 = "',a30,'...',/,27x
     1       ,'FILE2 = "',a32,'"',/)
2060   format(7x,'Comparison dump for FILE1 = "',a30,'...',/,27x
     1       ,'FILE2 = "',a30,'...',/)
2070   format(5x,'Diagnostic dumps for OLDFILE = "',a32,'"',/,26x
     1       ,'NEWFILE = "',a32,'"',/)
2080   format(5x,'Diagnostic dumps for OLDFILE = "',a32,'"',/,26x
     1       ,'NEWFILE = "',a30,'...',/)
2090   format(5x,'Diagnostic dumps for OLDFILE = "',a30,'...',/,26x
     1       ,'NEWFILE = "',a32,'"',/)
2100   format(5x,'Diagnostic dumps for OLDFILE = "',a30,'...',/,26x
     1       ,'NEWFILE = "',a30,'...',/)
2110   format(30x,a8,4x,a10,/)
2120   format(//)
2130   format(20x,'Columns 1-6 and 84-89 = Total Line Number',/)
2140   format(15x,'Columns 1-6 and 84-89 = Total Line Number',/
     1       ,15x,'Columns  91- 95       = Subprogram Statement Number'
     2     ,/,15x,'Columns  97-101       = Subprogram Line Number',/
     3       ,15x,'Columns 104-151       = Subprogram Name',/)
2150   format(18x,'Columns 1-6 and 84-89 = Total Line Number',/
     1       ,18x,'Columns  91- 95       = Deck Statement Number'
     2     ,/,18x,'Columns  97-101       = Deck Line Number',/
     3       ,18x,'Columns 104-111       = Group Name',/
     4       ,18x,'Columns 118-121       = Deck Name',/)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                H E A D E R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 O F I L E                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine ofile ( lunit, filename, stat )
c
c    dac:editor.ofile <------------------------------------- opens files
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine opens the specified file on the specified
c  logical unit.  Messages are sent to the crt if an error is detected.
c
c  INPUT VARIABLES:
c    lunit       logical unit on which to open file.
c    filename    name of desired file, including root directory path
c                (character*64)
c    stat        'new', 'old', or 'unknown', depending on file status.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*8   stat    , word8
       character*64  filename
       integer       lunit
       integer       j       , ncharf
c
c-----------------------------------------------------------------------
c
       do 10 j=1,64
         char1 = filename(j:j)
         if (char1 .ne. ' ') ncharf = j
10     continue
       if (ibanner .eq. 1) then
         word8 = 'output  '
         if (stat(1:3) .eq. 'old') word8 = 'input   '
         if (ncharf .le. 30) write (6, 2010) word8, filename, lunit
         if (ncharf .gt. 30) write (6, 2020) word8, filename, lunit
       endif
c
c  From DAC, 3/11: Commented out are lines that have been useful in
c  other OS/compilers.  I still need to test this with the various
c  compilers edit22 is supposed to support.
c
       open ( lunit, file=filename, status=stat, err=20 )
ccc  1             , fileopt='buffer=1024000' )
ccc    open ( lunit, file=filename, status=stat, err=20
ccc  1             , blocksize=1024000 )
       return
c
c      Problem opening file "filename".  ABORTS!
c
20     continue
       if (ncharf .le. 30) write (6, 2030) filename
       if (ncharf .gt. 30) write (6, 2040) filename
       stop
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('OFILE   : ',a6,' datafile "',a30,'" assigned on unit '
     1       ,i2,'.')
2020   format('OFILE   : ',a6,' datafile "',a28,'... assigned on unit '
     1       ,i2,'.')
2030   format('OFILE   : Problem opening file "',a30,'"',/
     1       ,'OFILE   : ABORTS!')
2040   format('OFILE   : Problem opening file "',a28,'...',/
     1       ,'OFILE   : ABORTS!')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 O F I L E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 R F I L E                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine rfile ( lunit, filename, ifile, lfirst, llast
     1                  , ierror, leof )
c
c    dac:editor.rfile <------------ reads the next portion of "filename"
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine reads the ascii data stored in the disc
c  file "filename" assigned to logical unit "lunit" into the text array
c  "xxxfile" ("oldfile", "tmpfile", cdkfile, or "newfile", depending on
c  the absolute value of "ifile").  RFILE can be directed to read all
c  of the disc file, or just the portion between lines "lfirst" and
c  "llast".  One or both of "lfirst" and "llast may be determined by
c  RFILE.
c      RFILE assumes that the disc file "filename" has already been
c  opened and that "nlxxx" ("nlold", "nltmp", "nlcdk", or "nlnew",
c  depending on the absolute value of "ifile") has been set to the
c  number of valid lines already in the text array.  Thus, there will
c  be as many as "safety" * "ilmax" - "nlxxx" lines available in the
c  text file for new ascii data from the disc file.  If "nlxxx" is zero,
c  the contents of "xxxfile", if any, will be overwritten.  The total
c  number of lines read from the disc file, including those read by any
c  previous calls to RFILE, is stored in "nlxxxt" ("nloldt", "nltmpt",
c  "nlcdkt", or "nlnewt", depending on the absolute value of "ifile").
c      If "ifile" .lt. 0, RFILE will attempt to read the lines "lfirst"
c  through "llast" from the disc file "filename" and store them into the
c  text array "xxxfile" after line "nlxxx".  If an overflow is detected,
c  a message is written to the crt telling the user to increase the
c  value of the parameter "k2", and execution is terminated.
c      If "ifile" .gt. 0, RFILE will assume that COLLECT has already
c  been called.  Starting from line "lfirst" in the disc file, RFILE
c  will only read in complete decks and will stop when reading in the
c  next full deck will cause an overflow in the text array "xxxfile".
c  An overflow is when "nlxxx" becomes greater than "safety" * "ilmax".
c
c  INPUT VARIABLES:
c    lunit       logical unit assigned to the disc file to be read.
c    filename    name of disc file to be read (character*64)
c    ifile       = 1 => read next portion of disc file into "oldfile"
c                = 2 => read next portion of disc file into "tmpfile"
c                = 3 => read next portion of disc file into "cdkfile"
c                = 4 => read next portion of disc file into "newfile"
c                =-1 => read specified segment of disc file into
c                       "oldfile"
c                =-2 => read specified segment of disc file into
c                       "tmpfile"
c                =-3 => read specified segment of disc file into
c                       "cdkfile"
c                =-4 => read specified segment of disc file into
c                       "newfile"
c    lfirst      line number of the first line in disc file to be read.
c                = 0 => one more than current value of "nlxxxt".
c    llast       line number of the last line in disc file to be read.
c                = 0          => read until an eof is detected.
c                > 0 < lfirst => read "llast" lines in total.
c                >     lfirst => read lines "lfirst" through "llast"
c                Note that for "ifile" > 0, the user-specified value of
c                "llast" is ignored.
c   ierror       = 0 => no error messages are inserted into "xxxfile".
c                = 1 => insert error messages from "ierr1" into
c                       "xxxfile"
c                = 2 => insert error messages from "ierr2" into
c                       "xxxfile"
c
c  OUTPUT VARIABLES:
c    leof        logical flag to indicate if end of file has been
c                reached.
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    ERRWRT
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   char1
       character*64  filename
       character*128 line
       integer       lunit   , lfirst  , llast   , ierror
       integer       i       , j       , ifile   , jfile   , ncharf
     1             , nerror  , nlxxx   , nlxxxt  , istop   , lavail
     2             , nlines  , idk     , length  , icd     , iline
c
c      External statements
c
       external      errwrt
c
c-----------------------------------------------------------------------
c
       jfile = iabs (ifile)
c
c      Number of characters in "filename".
c
       do 10 j=1,64
         char1 = filename(j:j)
         if (char1 .ne. ' ') ncharf = j
10     continue
c
c      Select "nerr1" or "nerr2".
c
       nerror = 0
       if (ierror .eq. 1) nerror = nerr1
       if (ierror .eq. 2) nerror = nerr2
c
c      Set values for "nlxxx" and "nlxxxt".
c
       if (jfile .eq. 1) then
         nlxxx  = nlold
         nlxxxt = nloldt
       endif
       if (jfile .eq. 2) then
         nlxxx  = nltmp
         nlxxxt = nltmpt
       endif
       if (jfile .eq. 3) then
         nlxxx  = nlcdk
         nlxxxt = nlcdkt
       endif
       if (jfile .eq. 4) then
         nlxxx  = nlnew
         nlxxxt = nlnewt
       endif
c
c      Position the disc file pointer.
c
       istop = 0
       if (lfirst .eq. 0) lfirst = nlxxxt + 1
       if (lfirst .le. nlxxxt) then
         istop  = nlxxxt - lfirst + 1
         nlxxxt = nlxxxt - istop
         do 20 i=1,istop
           backspace ( lunit )
20       continue
       endif
       if (lfirst .gt. nlxxxt+1) then
         istop  = lfirst - nlxxxt - 1
         nlxxxt = nlxxxt + istop
         do 30 i=1,istop
           read (lunit, 1010) line
30       continue
       endif
c
c      Set the number of lines still available in text array.
c
       lavail = ifix ( safety * float (ilmax) ) - nlxxx
c
       if (ifile .lt. 0) then
c
c      For "ifile" < 0, determine the number of lines to be read
c  ("nlines").
c
         if   (llast .le. 0)
     1     nlines = ilmax - lfirst + 1
         if ( (llast .gt. 0) .and. (llast .le. lfirst) )
     1     nlines = llast
         if                        (llast .gt. lfirst)
     1     nlines = llast - lfirst + 1
         nlines = min0 ( nlines, lavail )
c
       else
c
c      For "ifile" > 0, find the deck (common or ordinary) in the disc
c  file whose last line is closest to, but not greater than, the line
c  number "lfirst" + "lavail".
c
         idk = 0
         do 40 i=1,ndk
           length = idkend(i) - lfirst + 1
           if (length .gt. lavail) go to 50
           idk = i
40       continue
50       continue
c
         icd = 0
         do 60 i=1,ncd
           length = icdend(i) - lfirst + 1
           if (length .gt. lavail) go to 70
           icd = i
60       continue
70       continue
c
         if ( (idk .eq.   0) .and. (icd .eq.   0) ) go to 110
         if ( (idk .eq. ndk) .and. (icd .eq. ncd) ) leof = .true.
c
c        Set "llast", "nlines", and read the file.
c
         llast  = max0 ( idkend(idk), icdend(icd) )
         nlines = llast - lfirst + 1
c
       endif
c
       do 80 i=1,nlines
c        line = blank128
         if ( (job .eq. 3) .and. (inum .eq. 1) ) then
           read (lunit, 1010, end=90, err=130) line
         else
           read (lunit, 1020, end=90, err=130) line
         endif
         nlxxx  = nlxxx  + 1
         nlxxxt = nlxxxt + 1
         if (nlxxx .gt. ilmax) go to 120
         if (jfile .eq. 1) oldfile(nlxxx) = line
         if (jfile .eq. 2) tmpfile(nlxxx) = line
         if (jfile .eq. 3) cdkfile(nlxxx) = line
         if (jfile .eq. 4) newfile(nlxxx) = line
c
c      Insert error messages into "xxxfile", if desired.  Note that
c  ERRWRT (via ERRMSG) will increase "nlxxx" by 1, but will leave
c  "nlxxxt" unchanged.  Thus, "nlxxx" represents the total number of
c  lines currently in the text file "xxxfile", including inserted error
c  messages, while "nlxxxt" represents the total number of lines read
c  from the disc file, which do not include the error messages, but do
c  include all lines from previous reads.
c
         if (nerror .ne. 0) then
           call errwrt ( nlxxxt, jfile, ierror, nlxxx )
           if (ierror .eq. 1) nerror = nerr1
           if (ierror .eq. 2) nerror = nerr2
         endif
80     continue
       go to 100
90     continue
       leof = .true.
       if ( (jfile .eq. 1) .and. (lfirst .eq. 1) ) lreadall = .true.
100    continue
c
c      Copy "nlxxx" and "nlxxxt" to the appropriate variables.
c
       if (jfile .eq. 1) then
         nlold  = nlxxx
         nloldt = nlxxxt
       endif
       if (jfile .eq. 2) then
         nltmp  = nlxxx
         nltmpt = nlxxxt
       endif
       if (jfile .eq. 3) then
         nlcdk  = nlxxx
         nlcdkt = nlxxxt
       endif
       if (jfile .eq. 4) then
         nlnew  = nlxxx
         nlnewt = nlxxxt
       endif
c
c      Return to calling routine.
c
       return
c
c      A module in file "filename" is longer than "ilmax" lines.
c  Increase parameter "k2".  ABORTS!
c
110    continue
       if (ncharf .le. 16) write (6, 2010) filename, ilmax
       if (ncharf .gt. 16) write (6, 2020) filename, ilmax
       write (6, 2030)
       write (6, 2040)
       stop
c
c      Array bounds exceeded while reading file "filename".  Increase
c  parameter "k2".  ABORTS!
c
120    continue
       if (ncharf .le. 16) write (6, 2050) filename
       if (ncharf .gt. 16) write (6, 2060) filename
       write (6, 2030)
       write (6, 2040)
       stop
c
c      Problem reading line "iline" in file "filename".  ABORTS!
c
130    continue
       iline = i + lfirst
       if (ncharf .le. 32) write (6, 2070) iline, filename
       if (ncharf .gt. 32) write (6, 2080) iline, filename
       write (6, 2040)
       stop
c
c-----------------------------------------------------------------------
c---------------------- Read format statements -------------------------
c-----------------------------------------------------------------------
c
1010   format(a74)
1020   format(a72)
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('RFILE   : A module in file "',a16,'" is longer than '
     1       ,i6,' lines.')
2020   format('RFILE   : A module in file "',a14,'... is longer than '
     1       ,i6,' lines.')
2030   format('RFILE   : Increase parameter "k2".')
2040   format('RFILE   : ABORTS!')
2050   format('RFILE   : Array bounds exceeded while reading file "'
     1       ,a16,'".')
2060   format('RFILE   : Array bounds exceeded while reading file "'
     1       ,a14,'... .')
2070   format('RFILE   : Problem reading line ',i6,' in file "',a32
     1       ,'"')
2080   format('RFILE   : Problem reading line ',i6,' in file "',a30
     1       ,'...')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 R F I L E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 W F I L E                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine wfile ( lunit, ifile )
c
c    dac:editor.wfile <----------- writes contents of "filename" to disc
c                                                          october, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine writes the current contents of the text
c  file specified by "ifile" into the disc file assigned on logical unit
c  "lunit".  It assumes that the file has already been opened, and is
c  ready to receive ascii data.  Any EDITOR *error flags found on error
c  statements previously inserted into the text file are removed before
c  these lines are written to disc.  The parameter "nlxxxt" is augmented
c  by the number of lines written to "lunit".
c
c  INPUT VARIABLES:
c    lunit       logical unit assigned to the disc file to be written.
c    ifile       =1 => write "oldfile" to "lunit".
c                =2 => write "tmpfile" to "lunit".
c                =3 => write "cdkfile" to "lunit".
c                =4 => write "newfile" to "lunit".
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*128 line    , tmpline
       integer       lunit   , ifile
       integer       i       , j       , nlxxx   , nlxxxt  , jlen
c
c-----------------------------------------------------------------------
c
c      Set "nlxxx" and "nlxxxt"
c
       if (ifile .eq. 1) then
         nlxxx  = nlold
         nlxxxt = nloldt
       endif
       if (ifile .eq. 2) then
         nlxxx  = nltmp
         nlxxxt = nltmpt
       endif
       if (ifile .eq. 3) then
         nlxxx  = nlcdk
         nlxxxt = nlcdkt
       endif
       if (ifile .eq. 4) then
         nlxxx  = nlnew
         nlxxxt = nlnewt
       endif
c
c      Write the file
c
       if (job .eq. 1) jlen = 128
       do 30 i=1,nlxxx
         if (ifile .eq. 1) line = oldfile(i)
         if (ifile .eq. 2) line = tmpfile(i)
         if (ifile .eq. 3) line = cdkfile(i)
         if (ifile .eq. 4) line = newfile(i)
         if (line(1:6) .eq. '*error') then
           tmpline        = blank128
           tmpline(1:121) = line(8:128)
           line           = tmpline
         endif
         if (job .ne. 1) then
           jlen = 1
           do 10 j=74,1,-1
             if (line(j:j) .ne. ' ') then
               jlen = j
               go to 20
             endif
10         continue
20         continue
         endif
         write (lunit, 2010) line(1:jlen)
30     continue
       nlxxxt = nlxxxt + nlxxx
c
c      Store "nlxxxt".
c
       if (ifile .eq. 1) nloldt = nlxxxt
       if (ifile .eq. 2) nltmpt = nlxxxt
       if (ifile .eq. 3) nlcdkt = nlxxxt
       if (ifile .eq. 4) nlnewt = nlxxxt
c
c      Return to calling routine.
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(a)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 W F I L E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               C O M P A R E               \\\\\\\\\\
c
c=======================================================================
c
       subroutine compare
c
c    dac:editor.compare <---------------------- compares two input files
c                                                           august, 1989
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 5 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c
c  PURPOSE:  This subroutine compares two text files, line by line,
c  character by character, and reports any differences found.  The
c  nature of the differences reported is determined by "icompar",
c  "ndiff", and the vector "ignore".
c
c  icompar = 1  =>  will report the first "ndiff" differences found in
c                   the sequence of characters.
c  icompar = 2  =>  will compare the declaration lists at the beginning
c                   of each file, and will list discrepencies (i.e.,
c                   variables declared in one list but not the other).
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    RFILE
c    GETWRD
c    LIST
c    GETCHR
c    CFILE
c    CAPITALS
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leofo   , leoft
       character*1   char1   , char2
       character*4   word4
       character*16  word    , tmpwrd  , comnam
       character*22  blank22 , ophrase , tphrase
       character*32  word32
       character*128 line    , lold    , ltmp
       integer       lfold   , llold   , lftmp   , lltmp   , isent
     1             , iflag   , iold    , ioldt   , itmp    , itmpt
     2             , idiff   , itmpxs  , ioldxs  , jchar   , j
     3             , iold1   , ioldt1  , iold2   , ioldt2  , itmp1
     4             , itmpt1  , itmp2   , itmpt2  , jold    , jtmp
     5             , jtot    , jblnk   , j1      , j2      , jbeg
     6             , jend    , iold2t  , ipass   , nrel    , nint
     7             , nchr    , nlog    , npar    , ncom    , neqv
     8             , nxtr    , ndat    , nsav    , imax    , i
     9             , next    , jran    , match   , jopen   , jclose
       integer       iopen   , iclose  , jstart  , jstop   , nrel1
     1             , nint1   , nlog1   , nchr1   , npar1   , ncom1
     2             , neqv1   , nxtr1   , ndat1   , nsav1   , nrel2
     3             , nlog2   , nchr2   , npar2   , ncom2   , neqv2
     4             , nxtr2   , ndat2   , nsav2   , nrdis1  , nidis1
     5             , nldis1  , ncdis1  , nxdis1  , npdis1  , nbdis1
     6             , nedis1  , nddis1  , nsdis1  , nrdis2  , nidis2
     7             , nldis2  , ncdis2  , nxdis2  , npdis2  , nbdis2
     8             , nedis2  , nddis2  , nsdis2  , ntot1   , ntot2
     9             , iline   , k       , nint2   , ntot    , iwrd
c
       character*16  keywrd  (  18)
c
       character*32  rvar    (  k9,   4), ivar    (  k9,   4)
     1             , lvar    (  k9,   4), cvar    (  k9,   4)
     2             , parm    (  k9,   4), comm    (  k9,   4)
     3             , eqvl    (  k9,   4), data    (  k9,   4)
     4             , xtrn    (  k9,   4), save    (  k9,   4)
c
c      Data statements
c
       data          keywrd
     1   / 'REAL            ', 'INTEGER         ', 'LOGICAL         '
     2   , 'CHARACTER       ', 'EQUIVALENCE     ', 'IMPLICIT        '
     3   , 'DIMENSION       ', 'COMMON          ', 'PARAMETER       '
     4   , 'PROGRAM         ', 'SUBROUTINE      ', 'FUNCTION        '
     5   , 'BLOCKDATA       ', 'BLOCK           ', 'DATA            '
     6   , 'SAVE            ', 'EXTERNAL        ', 'OPTIONS         ' /
c
c      External statements
c
       external      ofile   , rfile   , getwrd  , list    , getchr
     1             , cfile   , capitals
c
c-----------------------------------------------------------------------
c
       blank22 = blank128(1:22)
c
c      Open disc files
c
       call ofile ( luold, oldname, 'old     ' )
       call ofile ( lutmp, tmpname, 'old     ' )
c
c      Read first portion of the input files "oldname" and "tmpname".
c
       nlold = 0
       lfold = 1
       llold = ilmax
       leofo = .false.
       call rfile ( luold, oldname, -1, lfold, llold, 0, leofo )
c
       nltmp = 0
       lftmp = 1
       lltmp = ilmax
       leoft = .false.
       call rfile ( lutmp, tmpname, -2, lftmp, lltmp, 0, leoft )
       write (    6, 2180)
       write (ludmp, 2180)
       nldmpt = nldmpt + 1
c
       go to (10, 200) icompar
c
c-----------------------------------------------------------------------
c  ICOMPAR = 1 :  Compare "oldfile" and "tmpfile", character for
c                 character, and report the first "ndiff" differences.
c-----------------------------------------------------------------------
c
10     continue
       isent = 0
       iflag = 0
       iold  = 0
       ioldt = 0
       itmp  = 0
       itmpt = 0
       idiff = 0
20     continue
c
c      The two disc files being compared are "oldname" and "tmpname".
c  The text arrays "oldfile" and "tmpfile" contain up to the first
c  "ilmax" lines of the respective disc files.  "ioldt" and "itmpt" are
c  the current line numbers in the disc files being compared, while
c  "iold" and "itmp" are the corresponding line numbers in the text
c  arrays.  The comparison is stopped when the end of file has been
c  reached in one or both of the disc files ("leofo" or "leoft" =
c  .true.).  If "iold" or "itmp" surpasses "nlold" or "nltmp", and the
c  end of that disc file has not been detected, more of the disc file is
c  read.
c
       iold  = iold  + 1
       ioldt = ioldt + 1
       itmp  = itmp  + 1
       itmpt = itmpt + 1
30     continue
c
       if (iold .gt. nlold) then
         if (leofo) then
           if ( (itmp .gt. nltmp) .and. (leoft) ) go to 190
           itmpxs = nltmp - itmp + 1
40         continue
           if (.not. leoft) then
             nltmp = 0
             lftmp = nltmpt + 1
             lltmp = nltmpt + ilmax
             call rfile ( lutmp, tmpname, -2, lftmp, lltmp, 0, leoft )
             itmpxs = itmpxs + nltmp
             go to 40
           endif
           if (itmpxs .eq. 1) then
             if (nchart .le. 32) then
               write (    6, 2010) tmpname
               write (ludmp, 2010) tmpname
             else
               write (    6, 2020) tmpname
               write (ludmp, 2020) tmpname
             endif
           else
             if (nchart .le. 32) then
               write (    6, 2030) itmpxs, tmpname
               write (ludmp, 2030) itmpxs, tmpname
             else
               write (    6, 2040) itmpxs, tmpname
               write (ludmp, 2040) itmpxs, tmpname
             endif
           endif
           nldmpt = nldmpt + 2
           go to 190
         else
           iold  = 1
           nlold = 0
           lfold = nloldt + 1
           llold = nloldt + ilmax
           call rfile ( luold, oldname, -1, lfold, llold, 0, leofo )
         endif
       endif
c
       if (itmp .gt. nltmp) then
         if (leoft) then
           ioldxs = nlold - iold + 1
50         continue
           if (.not. leofo) then
             nlold = 0
             lfold = nloldt + 1
             llold = nloldt + ilmax
             call rfile ( luold, oldname, -1, lfold, llold, 0, leofo )
             ioldxs = ioldxs + nlold
             go to 50
           endif
           if (ioldxs .eq. 1) then
             if (ncharo .le. 32) then
               write (    6, 2010) oldname
               write (ludmp, 2010) oldname
             else
               write (    6, 2020) oldname
               write (ludmp, 2020) oldname
             endif
           else
             if (ncharo .le. 32) then
               write (    6, 2030) ioldxs, oldname
               write (ludmp, 2030) ioldxs, oldname
             else
               write (    6, 2040) ioldxs, oldname
               write (ludmp, 2040) ioldxs, oldname
             endif
           endif
           nldmpt = nldmpt + 2
           go to 190
         else
           itmp  = 1
           nltmp = 0
           lftmp = nltmpt + 1
           lltmp = nltmpt + ilmax
           call rfile ( lutmp, tmpname, -2, lftmp, lltmp, 0, leoft )
         endif
       endif
60     continue
c
c      "lold" and "ltmp" are the lines being compared in the two files.
c
       lold = oldfile(iold)
       if (lold .eq. blank128) then
         iold  = iold  + 1
         ioldt = ioldt + 1
         go to 30
       endif
       ltmp = tmpfile(itmp)
       if (ltmp .eq. blank128) then
         itmp  = itmp  + 1
         itmpt = itmpt + 1
         go to 30
       endif
c
c      If continuation characters are not to be compared, blank out the
c  sixth column in each line.
c
       if (ignore(1) .eq. 1) then
         char1 = lold(1:1)
         char2 = ltmp(1:1)
         if ( (char1 .ne. 'c') .and. (char1 .ne. 'C') .and.
     1        (char1 .ne. '*') ) lold(6:6) = ' '
         if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1        (char2 .ne. '*') ) ltmp(6:6) = ' '
       endif
c
c      If differences in the blanking are not to be reported, then
c  squeeze the blanks out of each line.  Care is taken to consider the
c  line as two segments, namely columns 1:5 and columns 7:72 (except
c  when the line is a comment or an EDITOR command).
c
       if (ignore(2) .eq. 1) then
c
c  First do the line from "oldfile" ("lold").
c
         line  = blank128
         jchar = 0
         char2 = lold(1:1)
         do 70 j=1,nchar
           if (j .eq. 6) then
             if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1            (char2 .ne. '*') ) then
               jchar = 6
               line(6:6) = lold(6:6)
               go to 70
             endif
           endif
           char1 = lold(j:j)
           if (char1 .eq. ' ') go to 70
           jchar = jchar + 1
           line(jchar:jchar) = lold(j:j)
70       continue
         lold  = line
c
c  Then do the line from "tmpfile" ("ltmp").
c
         line  = blank128
         jchar = 0
         char2 = ltmp(1:1)
         do 80 j=1,nchar
           if (j .eq. 6) then
             if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1            (char2 .ne. '*') ) then
               jchar = 6
               line(6:6) = ltmp(6:6)
               go to 80
             endif
           endif
           char1 = ltmp(j:j)
           if (char1 .eq. ' ') go to 80
           jchar = jchar + 1
           line(jchar:jchar) = ltmp(j:j)
80       continue
         ltmp = line
       endif
c
c  If comment statements are to be ignored and a comment statement is
c  encountered, go on to the next line in the file.
c
       if (ignore(3) .eq. 1) then
         char1 = lold(1:1)
         if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') ) then
           iold  = iold  + 1
           ioldt = ioldt + 1
         endif
         char2 = ltmp(1:1)
         if ( (char2 .eq. 'c') .or. (char2 .eq. 'C') ) then
           itmp  = itmp  + 1
           itmpt = itmpt + 1
         endif
         if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') .or.
     1        (char2 .eq. 'c') .or. (char2 .eq. 'C') ) go to 30
       endif
c
c      If the two lines are identical, report that the files are once
c  again identical (if the previous lines considered were different,
c  i.e., isent = 1) and go on to the next line in each file.
c
       if (lold .eq. ltmp) then
         if (isent .eq. 1) then
           write (    6, 2100) ioldt, itmpt
           write (ludmp, 2100) ioldt, itmpt
           nldmpt = nldmpt + 1
           isent  = 0
         endif
         go to 20
       endif
c
c      The two lines are not identical.
c
       if (isent .eq. 0) then
c
c      Case:  The previous lines compared were identical.  Determine
c  at which column the difference begins ("jold" and "jtmp").  Note that
c  if blanks are not being considered, "jold" and "jtmp" need to be
c  adjusted for the number of blanks that were removed from each line.
c
         iold1  = iold
         ioldt1 = ioldt
         iold2  = iold
         ioldt2 = ioldt
         itmp1  = itmp
         itmpt1 = itmpt
         itmp2  = itmp
         itmpt2 = itmpt
         do 90 j=1,nchar
           char1 = lold(j:j)
           char2 = ltmp(j:j)
           if (char1 .ne. char2) go to 100
90       continue
100      continue
         jold = j
         jtmp = j
         if (ignore(2) .eq. 1) then
c
c  Adjust "jold".
c
           do 110 j=nchar,7,-1
             char1 = lold(j:j)
             jtot = j
             if (char1 .ne. ' ') go to 120
110        continue
120        continue
           lold  = oldfile(iold)
           char2 = lold(1:1)
           jchar = 0
           jblnk = 0
           do 130 j=1,nchar
             if (j .eq. 6) then
               if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1              (char2 .ne. '*') ) then
                 jblnk = 0
                 jchar = 6
                 if (jold .eq. 6) go to 140
                 go to 130
               endif
             endif
             char1 = lold(j:j)
             if (char1 .eq. ' ') jblnk = jblnk + 1
             if (char1 .ne. ' ') jchar = jchar + 1
             if ( (jchar .eq. jold) .or. (jchar .eq. jtot) ) then
               jold = jold + jblnk
               go to 140
             endif
130        continue
140        continue
c
c  Adjust "jtmp".
c
           do 150 j=nchar,7,-1
             char1 = ltmp(j:j)
             jtot = j
             if (char1 .ne. ' ') go to 160
150        continue
160        continue
           ltmp  = tmpfile(itmp)
           char2 = ltmp(1:1)
           jchar = 0
           jblnk = 0
           do 170 j=1,nchar
             if (j .eq. 6) then
               if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1              (char2 .ne. '*') ) then
                 jblnk = 0
                 jchar = 6
                 if (jold .eq. 6) go to 180
                 go to 170
               endif
             endif
             char1 = ltmp(j:j)
             if (char1 .eq. ' ') jblnk = jblnk + 1
             if (char1 .ne. ' ') jchar = jchar + 1
             if ( (jchar .eq. jtmp) .or. (jchar .eq. jtot) ) then
               jtmp = jtmp + jblnk
               go to 180
             endif
170        continue
180        continue
         endif
c
c  If this is the first difference found, create the column headings.
c
         if (idiff .eq. 0) then
           if ( (ncharo .le. 25) .and. (nchart .le. 25) ) then
             write (    6, 2050) oldname, tmpname
             write (ludmp, 2050) oldname, tmpname
           endif
           if ( (ncharo .le. 25) .and. (nchart .gt. 25) ) then
             write (    6, 2060) oldname, tmpname
             write (ludmp, 2060) oldname, tmpname
           endif
           if ( (ncharo .gt. 25) .and. (nchart .le. 25) ) then
             write (    6, 2070) oldname, tmpname
             write (ludmp, 2070) oldname, tmpname
           endif
           if ( (ncharo .gt. 25) .and. (nchart .gt. 25) ) then
             write (    6, 2080) oldname, tmpname
             write (ludmp, 2080) oldname, tmpname
           endif
           write (    6, 2090)
           write (ludmp, 2090)
           nldmpt = nldmpt + 2
         endif
c
c  Augment the number of differences found.  If this exceeds the user-
c  supplied maximum number to be reported, give a message indicating so
c  and return to EDITOR.
c
         idiff = idiff + 1
         if (idiff .gt. ndiff) then
           write (    6, 2110) ndiff
           write (ludmp, 2110) ndiff
           nldmpt = nldmpt + 1
           return
         endif
c
c  Store portion of each line where difference was found
c
         j1   = 1
         jbeg = jold - 10
         if (jbeg .lt. 1) then
           j1   = 2 - jbeg
           jbeg = 1
         endif
         j2   = 22
         jend = jold + 11
         if (jend .gt. nchar) then
           j2   = 22 - jend + nchar
           jend = nchar
         endif
         ophrase = blank22
         ophrase(j1:j2) = oldfile(iold)(jbeg:jend)
c
         j1   = 1
         jbeg = jtmp - 10
         if (jbeg .lt. 1) then
           j1   = 2 - jbeg
           jbeg = 1
         endif
         j2   = 22
         jend = jtmp + 11
         if (jend .gt. nchar) then
           j2   = 22 - jend + nchar
           jend = nchar
         endif
         tphrase = blank22
         tphrase(j1:j2) = tmpfile(itmp)(jbeg:jend)
c
c  Report line number and context where difference was found.
c
         write (    6, 2120) idiff, ioldt, ophrase, itmpt, tphrase
         write (ludmp, 2120) idiff, ioldt, ophrase, itmpt, tphrase
         nldmpt = nldmpt + 1
       endif
c
c      Case:  Previous lines compared could have been different or
c  identical.  Set "isent" to 1 to indicate that the current lines are
c  different.  This will cause execution to skip the previous case if
c  the next lines compared are different as well.  The algorithm for
c  augmenting "iold" and "itmp" is designed to find as quickly as
c  possible, and without ambiguity, where the two files match again.
c
       isent = 1
       if ( (itmp .eq. nltmp) .and. (leoft) .and.
     1      (iold .eq. nlold) .and. (leofo) ) go to 190
       if ( (itmp .eq. nltmp) .and. (leoft) ) iflag = 1
       if ( (iold .eq. nlold) .and. (leofo) ) iflag = 0
c
       if (iflag .eq. 0) then
         itmp  = itmp  + 1
         itmpt = itmpt + 1
       endif
       if (itmp .gt. itmp2) then
         if (itmp .gt. nltmp) then
           itmp  = itmp - itmp1 + 1
           itmp1 = 1
           nltmp = 0
           lftmp = itmpt1
           lltmp = lftmp + ilmax - 1
           call rfile ( lutmp, tmpname, -2, lftmp, lltmp, 0, leoft )
         endif
         iflag  = 1
         itmp2  = itmp
         itmpt2 = itmpt
         iold   = iold1
         ioldt  = ioldt1
         go to 60
       endif
c
       if (iflag .eq. 1) then
         iold  = iold  + 1
         ioldt = ioldt + 1
       endif
       if (iold  .gt. iold2) then
         if (iold .gt. nlold) then
           iold  = iold - iold1 + 1
           iold1 = 1
           nlold = 0
           lfold = ioldt1
           llold = lfold + ilmax - 1
           call rfile ( luold, oldname, -1, lfold, llold, 0, leofo )
         endif
         iflag  = 0
         iold2  = iold
         iold2t = ioldt
         itmp   = itmp1
         itmpt  = itmpt1
         go to 60
       endif
       go to 60
c
190    continue
c
c      Comparison is finished.  Report that files were identical, or the
c  number of differences found.  Return to EDITOR.
c
       if ( (iold  .gt. nlold) .and. (leofo) .and.
     1      (itmp  .gt. nltmp) .and. (leoft) .and.
     2      (idiff .eq. 0    ) ) then
         if ( (ncharo .le. 16) .and. (nchart .le. 16) ) then
           write (    6, 2130) oldname, tmpname
           write (ludmp, 2130) oldname, tmpname
         endif
         if ( (ncharo .le. 16) .and. (nchart .gt. 16) ) then
           write (    6, 2140) oldname, tmpname
           write (ludmp, 2140) oldname, tmpname
         endif
         if ( (ncharo .gt. 16) .and. (nchart .le. 16) ) then
           write (    6, 2150) oldname, tmpname
           write (ludmp, 2150) oldname, tmpname
         endif
         if ( (ncharo .gt. 16) .and. (nchart .gt. 16) ) then
           write (    6, 2160) oldname, tmpname
           write (ludmp, 2160) oldname, tmpname
         endif
         nldmpt = nldmpt + 1
       endif
       if (idiff .gt. 0) then
         write (    6, 2170) idiff
         write (ludmp, 2170) idiff
         nldmpt = nldmpt + 2
       endif
       write (6, 2180)
       go to 920
c
c-----------------------------------------------------------------------
c  ICOMPAR = 2 :  Report discrepencies between the two declaration lists
c-----------------------------------------------------------------------
c
c  NOTE:  It is assumed that all the declarations will be found in the
c  first portion of the input files.  Therefore, no subsequent calls to
c  RFILE are made.
c
200    continue
c
c      First, obtain a list of variables declared in the two files.
c  When "ipass" = 1 (2), variable list for "oldfile" ("tmpfile") is
c  created.
c
       ipass = 1
210    continue
       nrel = 0
       nint = 0
       nchr = 0
       nlog = 0
       npar = 0
       ncom = 0
       neqv = 0
       ndat = 0
       nxtr = 0
       nsav = 0
       if (ipass .eq. 1) imax = nlold
       if (ipass .eq. 2) imax = nltmp
       do 360 i=1,imax
         if (ipass .eq. 1) line = oldfile(i)
         if (ipass .eq. 2) line = tmpfile(i)
         if ( (line(1:6) .ne. '      ') .or. (line .eq. blank128) )
     1     go to 360
         jbeg = 7
         jend = nchar
         next = 0
         call getwrd ( i, ipass, next, jbeg, jend, jran, ' */(,', word )
         call capitals ( word )
c
c  Variable declaration statements may include length specifiers (eg.,
c  character*16, real*4, etc.)  Store the length specifier for later
c  use.
c
         word4 = '    '
         if (ipass .eq. 1) ltmp = oldfile(i+next)
         if (ipass .eq. 2) ltmp = tmpfile(i+next)
         if (ltmp(jend+1:jend+1) .eq. '*') then
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, ipass, next, jbeg, jend, jran, ' ', tmpwrd )
           word4 = tmpwrd(1:4)
         endif
c
c  If one of the characters in "word" is a "/", reset "word" to only
c  those characters before the "/", and adjust "jend".  This is in case
c  a "common" keyword is butt up against the opening "/" of the common
c  block name.
c
         do 220 j=1,16
           char1 = word(j:j)
           if (char1 .eq. '/') then
             tmpwrd = blank16
             tmpwrd(1:j-1) = word(1:j-1)
             word = tmpwrd
             jran = j - 1
             jend = jbeg + jran - 1
             go to 230
           endif
220      continue
230      continue
c
c  Determine if first word in line is a declaration keyword.
c
         match = 0
         do 240 iwrd=1,18
           if (word .eq. keywrd(iwrd)) go to 250
240      continue
         iwrd  = 0
250      continue
         if ( (iwrd .ge.  1) .and. (iwrd .le.  9) ) match = iwrd
         if ( (iwrd .ge. 10) .and. (iwrd .le. 14) ) match = 10
         if   (iwrd .eq. 15)                        match = 11
         if   (iwrd .eq. 16)                        match = 12
         if   (iwrd .eq. 17)                        match = 13
         if   (iwrd .eq. 18)                        match = 14
         if (match .eq. 0) go to 370
c
c  Remove all blanks from this and all continuation lines except for
c  the blank immediately following the present "word".
c
         j1    = jend + 2
         j2    = nchar
         iline = i
         ltmp  = blank128
         ltmp(1:jend) = line(1:jend)
260      continue
         k = j1 - 1
         do 270 j=j1,j2
           char1 = line(j:j)
           if (char1 .ne. ' ') then
             k = k + 1
             ltmp(k:k) = line(j:j)
           endif
270      continue
280      continue
         if (ipass .eq. 1) then
           oldfile(iline) = ltmp
           iline = iline + 1
           if (iline .gt. nlold) go to 290
           char1 = oldfile(iline)(1:1)
           char2 = oldfile(iline)(6:6)
         endif
         if (ipass .eq. 2) then
           tmpfile(iline) = ltmp
           iline = iline + 1
           if (iline .gt. nltmp) go to 290
           char1 = tmpfile(iline)(1:1)
           char2 = tmpfile(iline)(6:6)
         endif
         if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') .or.
     1        (char1 .eq. '*') ) then
           if (ipass .eq. 1) ltmp = oldfile(iline)
           if (ipass .eq. 2) ltmp = tmpfile(iline)
           go to 280
         endif
         if (char2 .ne. ' ') then
           j1 = 7
           if (ipass .eq. 1) line = oldfile(iline)
           if (ipass .eq. 2) line = tmpfile(iline)
           ltmp = blank128
           ltmp(1:6) = line(1:6)
           go to 260
         endif
290      continue
         if (ipass .eq. 1) line = oldfile(i)
         if (ipass .eq. 2) line = tmpfile(i)
c
c  Multiple "goto" statement for the various types of declarations.
c
         go to ( 300, 300, 300, 300, 340, 360, 300, 320, 300, 360
     1         , 350, 351, 300, 360 ) match
c
300      continue
c
c  Declaration type is one of "real", "integer", "logical", "character",
c  "dimension", "parameter", or "external".  Each variable found in the
c  list is stored in one of the arrays "rvar", "ivar", "lvar",
c  "cvar", "parm", or "xtrn".  The length of the character variable
c  is stored as a prefix to the variable name.  For variables declared
c  with "dimension", those starting with the letters "i" through "n"
c  are treated as though they were declared with "integer", the rest as
c  though they were declared with "real".  Note that any "implicit"
c  statements are ignored in this version.
c
         jbeg = jend + 1
         jend = 0
         call getwrd ( i, ipass, next, jbeg, jend, jran, ' ,()=.'
     1               , word )
         if (word .eq. blank16) go to 360
         word32      = blank32
         word32(1:4) = word4
         if (match .eq. 9) go to 310
         jopen = jend + 1
         iopen = i + next
         call list ( i, i, ipass, jopen, jclose, iopen, iclose )
         if (jclose .gt. 0) then
           jend = jclose
           jran = jend - jbeg + 1
           if (jran .gt. 27) then
             jran = 27
             jend = jbeg + 26
           endif
           next = iclose - i
         endif
         if (ipass .eq. 1) line = oldfile(i+next)
         if (ipass .eq. 2) line = tmpfile(i+next)
         word32(6:jran+5) = line(jbeg:jend)
c
c  Case:  declaration type is "real".
c
         if (match .eq. 1) then
           nrel = nrel + 1
           if (nrel .gt. ivmax) then
             write (    6, 2190) ivmax
             write (ludmp, 2190) ivmax
             nldmpt = nldmpt + 2
             stop
           endif
           rvar (nrel, ipass) = word32
         endif
c
c  Case:  declaration type is "integer".
c
         if (match .eq. 2) then
           nint = nint + 1
           if (nint .gt. ivmax) then
             write (    6, 2200) ivmax
             write (ludmp, 2200) ivmax
             nldmpt = nldmpt + 2
             stop
           endif
           ivar (nint, ipass) = word32
         endif
c
c  Case:  declaration type is "logical".
c
         if (match .eq. 3) then
           nlog = nlog + 1
           if (nlog .gt. ivmax) then
             write (    6, 2210) ivmax
             write (ludmp, 2210) ivmax
             nldmpt = nldmpt + 2
             stop
           endif
           lvar (nlog, ipass) = word32
         endif
c
c  Case:  declaration type is "character".
c
         if (match .eq. 4) then
           nchr = nchr + 1
           if (nchr .gt. ivmax) then
             write (    6, 2220) ivmax
             write (ludmp, 2220) ivmax
             nldmpt = nldmpt + 2
             stop
           endif
           cvar (nchr, ipass) = word32
         endif
c
c  Case:  declaration type is "dimension".
c
         if (match .eq. 7) then
           char1 = word32(6:6)
           if ( (char1 .ge. 'i') .and. (char1 .le. 'n') ) then
             nint = nint + 1
             if (nint .gt. ivmax) then
               write (    6, 2200) ivmax
               write (ludmp, 2200) ivmax
               nldmpt = nldmpt + 2
               stop
             endif
             ivar (nint, ipass) = word32
           else
             nrel = nrel + 1
             if (nrel .gt. ivmax) then
               write (    6, 2190) ivmax
               write (ludmp, 2190) ivmax
               nldmpt = nldmpt + 2
               stop
             endif
             rvar (nrel, ipass) = word32
           endif
         endif
c
c  Case:  declaration type is "external".
c
         if (match .eq. 13) then
           nxtr = nxtr + 1
           if (nxtr .gt. ivmax) then
             write (    6, 2230) ivmax
             write (ludmp, 2230) ivmax
             nldmpt = nldmpt + 2
             stop
           endif
           xtrn (nxtr, ipass) = word32
         endif
         go to 300
c
c  Case:  declaration type is "parameter".
c
310      continue
         word32(6:6) = '('
         jstart = 7
         jstop  = jran + 6
         word32(jstart:jstop) = word(1:jran)
         jstop = jstop + 1
         word32(jstop:jstop) = '='
         jbeg = jend + 1
         jend = 0
         call getwrd ( i, ipass, next, jbeg, jend, jran, ' ,()='
     1               , word )
         jstart = jstop + 1
         jstop  = jstop + jran
         word32(jstart:jstop) = word(1:jran)
         jstop = jstop + 1
         word32(jstop:jstop) = ')'
         npar = npar + 1
         if (npar .gt. ivmax) then
           write (    6, 2240) ivmax
           write (ludmp, 2240) ivmax
           nldmpt = nldmpt + 2
           stop
         endif
         parm(npar,ipass) = word32
         go to 300
c
c  Declaration type is "common".  Each variable in a common list causes
c  an entry to be made into the array "comm", which includes the common
c  block name, and the variable name.
c
320      continue
         jbeg = jend + 1
         jend = 0
         call getwrd ( i, ipass, next, jbeg, jend, jran, ' ,()', word )
         if (word .eq. blank16) go to 360
         if (word(1:1) .eq. '/') then
           do 330 j=2,16
             char1 = word(j:j)
             if (char1 .eq. '/') jran = j
330        continue
           jend = jbeg + jran - 1
           comnam = blank16
           comnam(1:jran) = word(1:jran)
           go to 320
         else
           word32 = blank32
           word32(1:16) = comnam
           jopen = jend + 1
           iopen = i + next
           call list ( i, i, ipass, jopen, jclose, iopen, iclose )
           if (jclose .gt. 0) then
             jend = jclose
             next = iclose - i
           endif
           if (ipass .eq. 1) line = oldfile(i+next)
           if (ipass .eq. 2) line = tmpfile(i+next)
           jran = jend - jbeg + 1
           if (jran .gt. 21) then
             jran = 21
             jend = jbeg + 20
           endif
           word32(12:jran+11) = line(jbeg:jend)
           ncom = ncom + 1
           if (ncom .gt. ivmax) then
             write (    6, 2250) ivmax
             write (ludmp, 2250) ivmax
             nldmpt = nldmpt + 2
             stop
           endif
           comm (ncom, ipass) = word32
           go to 320
         endif
c
c  Declaration type is "equivalence".  Each equivalence unit (enclosed
c  by parentheses) is added to the array "eqvl".
c
340      continue
         jopen = jend + 1
         iopen = i + next
         call list ( i, i, ipass, jopen, jclose, iopen, iclose )
         if (jclose .eq. 0) go to 360
         jran = jclose - jopen + 1
         if (jran .gt. 32) then
           jran   = 32
           jclose = jopen + 31
         endif
         next = iclose - i
         if (ipass .eq. 1) line = oldfile(i+next)
         if (ipass .eq. 2) line = tmpfile(i+next)
         word32 = blank32
         word32(1:jran) = line(jopen:jclose)
         neqv = neqv + 1
         if (neqv .gt. ivmax) then
           write (    6, 2260) ivmax
           write (ludmp, 2260) ivmax
           nldmpt = nldmpt + 2
           stop
         endif
         eqvl (neqv, ipass) = word32
         jbeg = jclose + 1
         jend = 0
         call getwrd ( i, ipass, next, jbeg, jend, jran, ' ,()', word )
         jbeg = jbeg - 1
         call getchr ( line, jbeg, char1, 2 )
         jend = jbeg - 1
         go to 340
c
c  A "data" statement.
c
350      continue
         ndat = ndat + 1
         if (ndat .gt. ivmax) then
           write (    6, 2270) ivmax
           write (ludmp, 2270) ivmax
           nldmpt = nldmpt + 2
           stop
         endif
         data (ndat, ipass) = word32
         go to 360
c
c  A "save" statement.
c
351      continue
         nsav = nsav + 1
         if (nsav .gt. ivmax) then
           write (    6, 2271) ivmax
           write (ludmp, 2271) ivmax
           nldmpt = nldmpt + 2
           stop
         endif
         save (nsav, ipass) = word32
         go to 360
c
c  An "implicit", "program", "subroutine", "function", "blockdata",
c  "block", or "options" statement are skipped over.
c
360    continue
c
c  Any other type of statement causes the comparison to end.
c
370    continue
       if (ipass .eq. 1) then
         nrel1 = nrel
         nint1 = nint
         nlog1 = nlog
         nchr1 = nchr
         npar1 = npar
         ncom1 = ncom
         neqv1 = neqv
         nxtr1 = nxtr
         ndat1 = ndat
         nsav1 = nsav
         ipass = 2
         go to 210
       else
         nrel2 = nrel
         nint2 = nint
         nlog2 = nlog
         nchr2 = nchr
         npar2 = npar
         ncom2 = ncom
         neqv2 = neqv
         nxtr2 = nxtr
         ndat2 = ndat
         nsav2 = nsav
       endif
c
c      Second, compare the corresponding lists from each file, and
c  record any discrepencies found.
c
c  Record "real" declarations in "tmpfile" not found in "oldfile".
c
       nrdis1 = 0
       do 390 i=1,nrel2
         do 380 j=1,nrel1
           if (rvar(j,1) .eq. rvar(i,2)) go to 390
380      continue
         nrdis1 = nrdis1 + 1
         rvar(nrdis1,3) = rvar(i,2)
390    continue
c
c  Record "integer" declarations in "tmpfile" not found in "oldfile".
c
       nidis1 = 0
       do 410 i=1,nint2
         do 400 j=1,nint1
           if (ivar(j,1) .eq. ivar(i,2)) go to 410
400      continue
         nidis1 = nidis1 + 1
         ivar(nidis1,3) = ivar(i,2)
410    continue
c
c  Record "logical" declarations in "tmpfile" not found in "oldfile".
c
       nldis1 = 0
       do 430 i=1,nlog2
         do 420 j=1,nlog1
           if (lvar(j,1) .eq. lvar(i,2)) go to 430
420      continue
         nldis1 = nldis1 + 1
         lvar(nldis1,3) = lvar(i,2)
430    continue
c
c  Record "character" declarations in "tmpfile" not found in "oldfile".
c
       ncdis1 = 0
       do 450 i=1,nchr2
         do 440 j=1,nchr1
           if (cvar(j,1) .eq. cvar(i,2)) go to 450
440      continue
         ncdis1 = ncdis1 + 1
         cvar(ncdis1,3) = cvar(i,2)
450    continue
c
c  Record "external" declarations in "tmpfile" not found in "oldfile".
c
       nxdis1 = 0
       do 470 i=1,nxtr2
         do 460 j=1,nxtr1
           if (xtrn(j,1) .eq. xtrn(i,2)) go to 470
460      continue
         nxdis1 = nxdis1 + 1
         xtrn(nxdis1,3) = xtrn(i,2)
470    continue
c
c  Record "parameter" declarations in "tmpfile" not found in "oldfile".
c
       npdis1 = 0
       do 490 i=1,npar2
         do 480 j=1,npar1
           if (parm(j,1) .eq. parm(i,2)) go to 490
480      continue
         npdis1 = npdis1 + 1
         parm(npdis1,3) = parm(i,2)
490    continue
c
c  Record "common block" declarations in "tmpfile" not found in
c  "oldfile".
c
       nbdis1 = 0
       do 510 i=1,ncom2
         do 500 j=1,ncom1
           if (comm(j,1) .eq. comm(i,2)) go to 510
500      continue
         nbdis1 = nbdis1 + 1
         comm(nbdis1,3) = comm(i,2)
510    continue
c
c  Record "equivalence" declarations in "tmpfile" not found in
c  "oldfile".
c
       nedis1 = 0
       do 530 i=1,neqv2
         do 520 j=1,neqv1
           if (eqvl(j,1) .eq. eqvl(i,2)) go to 530
520      continue
         nedis1 = nedis1 + 1
         eqvl(nedis1,3) = eqvl(i,2)
530    continue
c
c  Record "data" statements in "tmpfile" not found in "oldfile".
c
       nddis1 = 0
       do 550 i=1,ndat2
         do 540 j=1,ndat1
           if (data(j,1) .eq. data(i,2)) go to 550
540      continue
         nddis1 = nddis1 + 1
         data(nddis1,3) = data(i,2)
550    continue
c
c  Record "save" statements in "tmpfile" not found in "oldfile".
c
       nsdis1 = 0
       do 551 i=1,nsav2
         do 541 j=1,nsav1
           if (save(j,1) .eq. save(i,2)) go to 551
541      continue
         nsdis1 = nsdis1 + 1
         save(nsdis1,3) = save(i,2)
551    continue
c
c  Record "real" declarations in "oldfile" not found in "tmpfile".
c
       nrdis2 = 0
       do 570 i=1,nrel1
         do 560 j=1,nrel2
           if (rvar(j,2) .eq. rvar(i,1)) go to 570
560      continue
         nrdis2 = nrdis2 + 1
         rvar(nrdis2,4) = rvar(i,1)
570    continue
c
c  Record "integer" declarations in "oldfile" not found in "tmpfile".
c
       nidis2 = 0
       do 590 i=1,nint1
         do 580 j=1,nint2
           if (ivar(j,2) .eq. ivar(i,1)) go to 590
580      continue
         nidis2 = nidis2 + 1
         ivar(nidis2,4) = ivar(i,1)
590    continue
c
c  Record "logical" declarations in "oldfile" not found in "tmpfile".
c
       nldis2 = 0
       do 610 i=1,nlog1
         do 600 j=1,nlog2
           if (lvar(j,2) .eq. lvar(i,1)) go to 610
600      continue
         nldis2 = nldis2 + 1
         lvar(nldis2,4) = lvar(i,1)
610    continue
c
c  Record "character" declarations in "oldfile" not found in "tmpfile".
c
       ncdis2 = 0
       do 630 i=1,nchr1
         do 620 j=1,nchr2
           if (cvar(j,2) .eq. cvar(i,1)) go to 630
620      continue
         ncdis2 = ncdis2 + 1
         cvar(ncdis2,4) = cvar(i,1)
630    continue
c
c  Record "external" declarations in "oldfile" not found in "tmpfile".
c
       nxdis2 = 0
       do 650 i=1,nxtr1
         do 640 j=1,nxtr2
           if (xtrn(j,2) .eq. xtrn(i,1)) go to 650
640      continue
         nxdis2 = nxdis2 + 1
         xtrn(nxdis2,4) = xtrn(i,1)
650    continue
c
c  Record "parameter" declarations in "oldfile" not found in "tmpfile".
c
       npdis2 = 0
       do 670 i=1,npar1
         do 660 j=1,npar2
           if (parm(j,2) .eq. parm(i,1)) go to 670
660      continue
         npdis2 = npdis2 + 1
         parm(npdis2,4) = parm(i,1)
670    continue
c
c  Record "common block" declarations in "oldfile" not found in
c  "tmpfile".
c
       nbdis2 = 0
       do 690 i=1,ncom1
         do 680 j=1,ncom2
           if (comm(j,2) .eq. comm(i,1)) go to 690
680      continue
         nbdis2 = nbdis2 + 1
         comm(nbdis2,4) = comm(i,1)
690    continue
c
c  Record "equivalence" declarations in "oldfile" not found in
c  "tmpfile".
c
       nedis2 = 0
       do 710 i=1,neqv1
         do 700 j=1,neqv2
           if (eqvl(j,2) .eq. eqvl(i,1)) go to 710
700      continue
         nedis2 = nedis2 + 1
         eqvl(nedis2,4) = eqvl(i,1)
710    continue
c
c  Record "data" statements in "oldfile" not found in "tmpfile".
c
       nddis2 = 0
       do 730 i=1,ndat1
         do 720 j=1,ndat2
           if (data(j,2) .eq. data(i,1)) go to 730
720      continue
         nddis2 = nddis2 + 1
         data(nddis2,4) = data(i,1)
730    continue
c
c  Record "save" statements in "oldfile" not found in "tmpfile".
c
       nsdis2 = 0
       do 731 i=1,nsav1
         do 721 j=1,nsav2
           if (save(j,2) .eq. save(i,1)) go to 731
721      continue
         nsdis2 = nsdis2 + 1
         save(nsdis2,4) = save(i,1)
731    continue
c
c      Report discrepencies to both units 6 (crt) and ludmp ("output").
c
       ntot1 = nrdis1 + nidis1 + nldis1 + ncdis1 + npdis1 + nbdis1
     1       + nedis1 + nxdis1 + nddis1 + nsdis1
       ntot2 = nrdis2 + nidis2 + nldis2 + ncdis2 + npdis2 + nbdis2
     1       + nedis2 + nxdis2 + nddis2 + nsdis2
       ntot  = ntot1  + ntot2
       write (6, 2180)
       if (ntot .eq. 0) then
         if ( (ncharo .le. 16) .and. (nchart .le. 16) ) then
           write (    6, 2280) oldname, tmpname
           write (ludmp, 2280) oldname, tmpname
         endif
         if ( (ncharo .le. 16) .and. (nchart .gt. 16) ) then
           write (    6, 2290) oldname, tmpname
           write (ludmp, 2290) oldname, tmpname
         endif
         if ( (ncharo .gt. 16) .and. (nchart .le. 16) ) then
           write (    6, 2300) oldname, tmpname
           write (ludmp, 2300) oldname, tmpname
         endif
         if ( (ncharo .gt. 16) .and. (nchart .gt. 16) ) then
           write (    6, 2310) oldname, tmpname
           write (ludmp, 2310) oldname, tmpname
         endif
         nldmpt = nldmpt + 3
         return
       endif
c
c  Declarations in "tmpfile" not found in "oldfile".
c
       if (ntot1 .gt. 0) then
         if (ncharo .le. 16) then
           write (    6, 2320) oldname
           write (ludmp, 2320) oldname
         else
           write (    6, 2330) oldname
           write (ludmp, 2330) oldname
         endif
         nldmpt = nldmpt + 1
       endif
c
       do 740 i=1,nrdis1
         write (    6, 2340) rvar(i,3)
         write (ludmp, 2340) rvar(i,3)
740    continue
c
       do 750 i=1,nidis1
         write (    6, 2350) ivar(i,3)
         write (ludmp, 2350) ivar(i,3)
750    continue
c
       do 760 i=1,nldis1
         write (    6, 2360) lvar(i,3)
         write (ludmp, 2360) lvar(i,3)
760    continue
c
       do 770 i=1,ncdis1
         write (    6, 2370) cvar(i,3)
         write (ludmp, 2370) cvar(i,3)
770    continue
c
       do 780 i=1,nxdis1
         write (    6, 2380) xtrn(i,3)
         write (ludmp, 2380) xtrn(i,3)
780    continue
c
       do 790 i=1,npdis1
         write (    6, 2390) parm(i,3)
         write (ludmp, 2390) parm(i,3)
790    continue
c
       do 800 i=1,nbdis1
         write (    6, 2400) comm(i,3)
         write (ludmp, 2400) comm(i,3)
800    continue
c
       do 810 i=1,nedis1
         write (    6, 2410) eqvl(i,3)
         write (ludmp, 2410) eqvl(i,3)
810    continue
c
       do 820 i=1,nddis1
         write (    6, 2420) data(i,3)
         write (ludmp, 2420) data(i,3)
820    continue
c
       do 821 i=1,nsdis1
         write (    6, 2421) save(i,3)
         write (ludmp, 2421) save(i,3)
821    continue
c
       if (ntot1 .gt. 0) then
         write (    6, 2180)
         write (ludmp, 2180)
         nldmpt = nldmpt + ntot1 + 1
       endif
c
c  Declarations in "oldfile" not found in "tmpfile".
c
       if (ntot2 .gt. 0) then
         if (nchart .le. 16) then
           write (    6, 2320) tmpname
           write (ludmp, 2320) tmpname
         else
           write (    6, 2330) tmpname
           write (ludmp, 2330) tmpname
         endif
         nldmpt = nldmpt + 1
       endif
c
       do 830 i=1,nrdis2
         write (    6, 2340) rvar(i,4)
         write (ludmp, 2340) rvar(i,4)
830    continue
c
       do 840 i=1,nidis2
         write (    6, 2350) ivar(i,4)
         write (ludmp, 2350) ivar(i,4)
840    continue
c
       do 850 i=1,nldis2
         write (    6, 2360) lvar(i,4)
         write (ludmp, 2360) lvar(i,4)
850    continue
c
       do 860 i=1,ncdis2
         write (    6, 2370) cvar(i,4)
         write (ludmp, 2370) cvar(i,4)
860    continue
c
       do 870 i=1,nxdis2
         write (    6, 2380) xtrn(i,4)
         write (ludmp, 2380) xtrn(i,4)
870    continue
c
       do 880 i=1,npdis2
         write (    6, 2390) parm(i,4)
         write (ludmp, 2390) parm(i,4)
880    continue
c
       do 890 i=1,nbdis2
         write (    6, 2400) comm(i,4)
         write (ludmp, 2400) comm(i,4)
890    continue
c
       do 900 i=1,nedis2
         write (    6, 2410) eqvl(i,4)
         write (ludmp, 2410) eqvl(i,4)
900    continue
c
       do 910 i=1,nddis2
         write (    6, 2420) data(i,4)
         write (ludmp, 2420) data(i,4)
910    continue
c
       do 911 i=1,nsdis2
         write (    6, 2421) save(i,4)
         write (ludmp, 2421) save(i,4)
911    continue
c
       if (ntot2 .gt. 0) then
         write (    6, 2180)
         write (ludmp, 2180)
         nldmpt = nldmpt + ntot2 + 1
       endif
c
       go to 920
c
c      Close files, and return to calling routine.
c
920    continue
       call cfile ( luold, oldname, 0 )
       call cfile ( lutmp, tmpname, 0 )
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('COMPARE : An extra line was found in file "',a16,'"')
2020   format('COMPARE : An extra line was found in file "',a14,'...')
2030   format('COMPARE : An extra ',i6,' lines were found in file "'
     1       ,a16,'"')
2040   format('COMPARE : An extra ',i6,' lines were found in file "'
     1       ,a14,'...')
2050   format('COMPARE : diff',8x,'"',a26,'"  "',a26,'"')
2060   format('COMPARE : diff',8x,'"',a26,'"  "',a24,'...')
2070   format('COMPARE : diff',8x,'"',a24,'...  "',a26,'"')
2080   format('COMPARE : diff',8x,'"',a24,'...  "',a24,'...')
2090   format('COMPARE : ',12x,'line',10x,'context',9x,'line',10x
     1       ,'context',/
     2       ,'COMPARE : ----------------------------------------'
     3       ,'------------------------------')
2100   format('COMPARE : ',3x,' same @ ',i6,11x,'^',12x,i6,11x,'^')
2110   format('COMPARE : Number of differences exceeds ',i4
     1       ,'.  Execution terminated.')
2120   format('COMPARE : ',i3,' diff @ ',i6,1x,a22,1x,i6,1x,a22)
2130   format('COMPARE : Files "',a16,'" and "',a16,'" match exactly.')
2140   format('COMPARE : Files "',a16,'" and "',a14,'... match '
     1       ,'exactly.')
2150   format('COMPARE : Files "',a14,'... and "',a16,'" match '
     1       ,'exactly.')
2160   format('COMPARE : Files "',a14,'... and "',a14,'... match '
     1       ,'exactly.')
2170   format('COMPARE :',/
     1       ,'COMPARE : Number of differences reported = ',i4)
2180   format('COMPARE :')
2190   format('COMPARE : Number of real variables exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2200   format('COMPARE : Number of integer variables exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2210   format('COMPARE : Number of logical variables exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2220   format('COMPARE : Number of character variables exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2230   format('COMPARE : Number of externals declared exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2240   format('COMPARE : Number of parameters exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2250   format('COMPARE : Number of variables in common exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2260   format('COMPARE : Number of equivalences exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2270   format('COMPARE : Number of data assignments exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2271   format('COMPARE : Number of save assignments exceeded ',i4
     1       ,'.  Increase parameter k9.',/
     2       ,'COMPARE : ABORTS!')
2280   format('COMPARE : Declaration lists of files "',a16,'" and "'
     1       ,a16,'"',/
     2       ,'COMPARE : match exactly.',/
     3       ,'COMPARE :')
2290   format('COMPARE : Declaration lists of files "',a16,'" and "'
     1       ,a14,'...',/
     2       ,'COMPARE : match exactly.',/
     3       ,'COMPARE :')
2300   format('COMPARE : Declaration lists of files "',a14,'... and "'
     1       ,a16,'"',/
     2       ,'COMPARE : match exactly.',/
     3       ,'COMPARE :')
2310   format('COMPARE : Declaration lists of files "',a14,'... and "'
     1       ,a14,'...',/
     2       ,'COMPARE : match exactly.',/
     3       ,'COMPARE :')
2320   format('COMPARE : The following declarations were not found in '
     1       ,'file "',a16,'"')
2330   format('COMPARE : The following declarations were not found in '
     1       ,'file "',a14,'...')
2340   format('COMPARE :     real     ',a32)
2350   format('COMPARE :     integer  ',a32)
2360   format('COMPARE :     logical  ',a32)
2370   format('COMPARE :     character',a32)
2380   format('COMPARE :     external ',a32)
2390   format('COMPARE :     parameter',a32)
2400   format('COMPARE :     common        ',a32)
2410   format('COMPARE :     equivalence   ',a32)
2420   format('COMPARE :     data          ',a32)
2421   format('COMPARE :     save          ',a32)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               C O M P A R E               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                C O N C A T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine concat
c
c    dac:editor.concat <--------- concatenates files in a directory tree
c                                                             july, 1989
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 7 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine concatentes files with a common extension
c  found in a specified directory, or its subdirectories.  It is the
c  practical inverse of the subroutine SPLIT.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    CFILE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*80  infile  , command , line
       integer       j       , nform   , istat
c
c      External statements
c
       integer       ixeqos
       external      ixeqos  , ofile   , cfile
c
c-----------------------------------------------------------------------
c
c      Open output disc file.
c
       call ofile ( lunew, newname, 'unknown ' )
c
c      Open disc file "oldname" if one was specified, and copy its
c  contents to "newname".
c
       if (oldname .ne. blank64) then
         call ofile ( luold, oldname, 'old     ' )
         nlold = 1
10       continue
         read  (luold, 1010, end=20, err=90) line
         write (lunew, 2010) line
         nlold = nlold  + 1
         go to 10
20       continue
         nlnewt = nlold
         call cfile ( luold, oldname, 0 )
       endif
c
c      Default for the extension is '.src'.  Determine the number of
c  characters in the extension.
c
       if (ext .eq. '        ') ext = '.src    '
       do 30 j=1,8
         char1 = ext(j:j)
         if (char1 .eq. ' ') go to 40
         nform = j
30     continue
40     continue
c
c      Scan directory "branch" for files with extension "ext" by
c  executing appropriate system calls.
c
       istat = ixeqos ( 'rm dump' )
       if (nform .eq. 1) write (command, 2020) branch, ext
       if (nform .eq. 2) write (command, 2030) branch, ext
       if (nform .eq. 3) write (command, 2040) branch, ext
       if (nform .eq. 4) write (command, 2050) branch, ext
       if (nform .eq. 5) write (command, 2060) branch, ext
       if (nform .eq. 6) write (command, 2070) branch, ext
       if (nform .eq. 7) write (command, 2080) branch, ext
       if (nform .eq. 8) write (command, 2090) branch, ext
       istat = ixeqos ( command )
c
c  From DAC, 3/11: Commented out are lines that have been useful in
c  other OS/compilers.  I still need to test this with the various
c  compilers edit22 is supposed to support.
c
       open ( lutmp, file='dump', status='old' )
ccc  1             , fileopt='buffer=1024000' )
ccc    open ( lutmp, file='dump', status='old', blocksize=1024000 )
50     continue
       read ( lutmp, 1010, end=80 ) infile
       if (infile .eq. ' ') go to 80
       if (ibanner .eq. 1) write (    6, 2100) infile
       if (idump   .eq. 1) write (ludmp, 2100) infile
c
c      Copy disc file "infile" to disc file "newname".
c
       open ( luold, file=infile, status='old' )
ccc  1             , fileopt='buffer=1024000' )
ccc    open ( luold, file=infile, status='old', blocksize=1024000 )
       nlold = 1
60     continue
       read  (luold, 1010, end=70, err=100) line
       write (lunew,                  2010) line
       nlold  = nlold  + 1
       go to 60
70     continue
       nlnewt = nlnewt + nlold
       call cfile ( luold, oldname, 0 )
       go to 50
c
c      All disc files in directory have been copied to "newname".
c
80     continue
       call cfile ( lunew, newname, nlnewt )
       return
c
c      Problem reading line "nlold" in file "oldname".  ABORTS!
c
90     continue
       if (ncharo .le. 32) write (6, 2110) nlold, oldname
       if (ncharo .gt. 32) write (6, 2120) nlold, oldname
       write (6, 2130)
       stop
c
c      Problem reading line "nlold" in file "infile".  ABORTS!
c
100    continue
       if (ncharo .le. 32) write (6, 2110) nlold, infile
       if (ncharo .gt. 32) write (6, 2120) nlold, infile
       write (6, 2130)
       stop
c
c-----------------------------------------------------------------------
c----------------------- Read format statements ------------------------
c-----------------------------------------------------------------------
c
1010   format(a80)
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(a80)
2020   format('find ',a32,' -name ''*',a1,''' -print > dump')
2030   format('find ',a32,' -name ''*',a2,''' -print > dump')
2040   format('find ',a32,' -name ''*',a3,''' -print > dump')
2050   format('find ',a32,' -name ''*',a4,''' -print > dump')
2060   format('find ',a32,' -name ''*',a5,''' -print > dump')
2070   format('find ',a32,' -name ''*',a6,''' -print > dump')
2080   format('find ',a32,' -name ''*',a7,''' -print > dump')
2090   format('find ',a32,' -name ''*',a8,''' -print > dump')
2100   format('CONCAT  : Reading file ',a57)
2110   format('CONCAT  : Problem reading line ',i6,' in file "',a32
     1       ,'"')
2120   format('CONCAT  : Problem reading line ',i6,' in file "',a30
     1       ,'...')
2130   format('CONCAT  : ABORTS!')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                C O N C A T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 M E R G E                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine merge
c
c    dac:editor.merge <------------- merges change deck with source code
c                                                         february, 1989
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 3 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c
c  PURPOSE:  This subroutine merges the specified change deck (chgname)
c  with the specified source code (oldname), in a manner similar to the
c  way HISTORAN handled such merges.  Only the change deck will be
c  scanned for MERGE commands.  MERGE commands should not be put in the
c  original source code.
c
c      The following MERGE commands are currently recognised.  Allowed
c  abbreviations are included parenthetically.
c
c  *ident,FILENAME (*id)
c      identifies the change deck.  In HISTORAN, this had to be the
c      first line in the change deck.  In MERGE, the *ident command
c      is inert.
c
c  *read FILENAME (*r)
c      statement is replaced with specified file.
c
c  *delete DKNAM.m,n (*d)
c      deletes lines m through n in specified deck (ordinary or common)
c      of file "oldname" and inserts the following lines up to but not
c      including the next occurance of *read, *delete, *replace, *insert
c      or *end.
c
c  *replace DKNAM.m,n (*rp)
c      synonymous with *delete (unrecognised by HISTORAN).
c
c  *insert DKNAM.m (*i)
c      inserts the following lines up to but not including the next
c      occurance of *read, *delete, *replace, *insert, or *end after
c      line m in the specified deck (ordinary or common) in the file
c      "oldfile".
c
c  *end (*e)
c      if necessary, can be used to mark the end of text to be inserted
c      after a *delete, *replace, or *insert command (unrecognised by
c      HISTORAN).  Lines falling between an *end statement and the next
c      occurance of a *delete, *replace or *insert command will be put
c      at the beginning of the MERGEd file.
c
c      MERGE commands use commas, periods and blanks interchangeably.
c  In HISTORAN, the specified punctuation must be observed.  All lines
c  which are not associated with a *delete, *replace, or an *insert
c  (including other EDITOR commands not carried out by MERGE) are put
c  at the beginning of the MERGEd disc file "newfile".
c
c      If "inum" = 1, NUMBER is called and a disc file is created with
c  all the lines NUMBERed (using "inumber" = 3).  MERGE identifies the
c  lines it has inserted by placing an asterisk in column 74.  NUMBER
c  then capitalises the group name in columns 104 through 111 and the
c  deck name in columns 114 through 121 in these lines.  The NUMBERed
c  disc file is called OLDNAME.n.
c
c      If "ipre" = 1, the MERGEd file will also be PRECOMpiled, ready
c  for the fortran compiler.  The PRECOMpiled disc file is called
c  OLDNAME.f.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    RFILE
c    CFILE
c    GETWRD
c    ERRSET
c    OVERFLOW
c    ERRWRT
c    COLLECT
c    MRGNMBR
c    CTOI
c    WFILE
c    NUMBER
c    PRECOM
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   char1
       character*16  word    , wrd1    , wrd2    , wrd3    , subnam
       character*64  readname, mchgname
       character*128 line
       integer       i       , lfirst  , llast   , nround  , nread
     1             , jbeg    , jend    , jran    , next    , j1
     2             , j2      , jbegold , nldiff  , itmp    , k
     3             , match   , idk     , ideckb  , idecke  , ideckr
     4             , ideckr0 , icd     , ibeg    , iend    , isub
     5             , imax    , icount  , iline   , iadd    , ibit
     6             , imin    , i1      , i2      , ierr    , ncharm
     7             , nlines  , ncharr
c
       character*16  keywrd  (  20)
c
c      External statements
c
       external      ofile   , rfile   , cfile   , getwrd  , errset
     1             , overflow, errwrt  , collect , mrgnmbr , ctoi
     2             , wfile   , number  , precom
c
c      Data statements.
c
       data          keywrd
     1             / 'ident           ', 'id              '
     2             , 'read            ', 'r               '
     3             , 'delete          ', 'd               '
     4             , 'replace         ', 'rp              '
     5             , 'insert          ', 'i               '
     6             , 'end             ', 'e               '
     7             , 'error           ', '                '
     8             , '                ', '                '
     9             , '                ', '                '
     1             , '                ', '                ' /
c
c-----------------------------------------------------------------------
c
c      Initialise error variables.
c
       do 10 i=1,iemax
         ierr2 (i) = 0
         lnerr2(i) = 0
10     continue
       nerr2 = 0
c
c      Open disc files.
c
       call ofile ( luold, oldname, 'old     ' )
       call ofile ( lutmp, chgname, 'old     ' )
       call ofile ( lunew, newname, 'unknown ' )
c
c      Read all of the change deck from the disc file "chgname" to the
c  text file "tmpfile", then close "chgname".
c
       lfirst = 1
       llast  = 0
       nltmp  = 0
       leof   = .false.
       call rfile ( lutmp, chgname, -2, lfirst, llast, 0, leof )
       call cfile ( lutmp, chgname, 0 )
c
c      Substitute all *read's in the change deck for the named file.
c
       nlnew  = 0
       nround = 0
20     continue
       nread  = 0
       nround = nround + 1
       do 60 i=1,nltmp
         if ( (tmpfile(i  )(1:1) .eq. '*') .and.
     1        (tmpfile(i+1)(1:6) .ne. '*error') ) then
           jbeg = 2
           jend = 9
           next = 0
           call getwrd ( i, 2, next, jbeg, jend, jran, ' ,.', word )
           if ( (word .eq. keywrd(3)) .or. (word .eq. keywrd(4)) ) then
c
c  A *read statement has been found.  Check to make sure that "nround"
c  does not exceed 10.  If it does, issue an error message, and ignore
c  the *read.  If it doesn't, read the specified filename.
c
             if (nround .gt. 10) then
               call errset ( nlnew+1, 48, 2 )
               go to 50
             endif
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 2, next, jbeg, jend, jran, ' ,', subnam )
             if (subnam .eq. blank16) then
               call errset ( nlnew+1, 21, 2 )
               go to 50
             endif
             readname = blank64
             j1 = 1
             j2 = jran
30           continue
             readname(j1:j2) = subnam(1:jran)
             if (j2 .ge. 64) go to 40
c
c  If subnam(16:16) is not a blank, then all the filename may not have
c  been read yet.  In this case, continue reading.
c
             if (jran .eq. 16) then
               jbeg    = jend + 1
               jbegold = jbeg
               jend    = nchar
               call getwrd ( i, 2, next, jbeg, jend, jran, ' ', subnam )
               if (jbegold .eq. jbeg) then
                 j1 = j2 + 1
                 j2 = j2 + jran
                 if (j2 .gt. 64) then
                   j2   = 64
                   jran = j2   - j1   + 1
                   jend = jbeg + jran - 1
                 endif
                 go to 30
               endif
             endif
c
c  Open the file "readname", load it into "newfile", then close it.
c
40           continue
             call ofile ( luchg, readname, 'old     ' )
             lfirst = 1
             llast  = 0
             leof   = .false.
             call rfile ( luchg, readname, -4, lfirst, llast, 0, leof )
             call cfile ( luchg, readname, 0 )
             go to 60
           endif
         endif
c
c      Anything else other than a *read statement is just copied to
c  "newfile".  The only *read statements copied to "newfile" are those
c  with errors.
c
50       continue
         nlnew = nlnew + 1
         if (nlnew .gt. ilmax) call overflow ( 4, 1 )
         newfile(nlnew) = tmpfile(i)
         if (nerr2 .ne. 0) call errwrt ( nlnew, 4, 2, nlnew )
60     continue
c
c      Copy "newfile" back to "tmpfile", put an "*" in column 74, and
c  then empty "newfile".  Check for *read commands that may have been
c  embedded in the disc file "readname".
c
       do 70 i=1,nlnew
         tmpfile(i) = newfile(i)
         if (tmpfile(i)(1:1) .eq. '*') then
           jbeg = 2
           jend = 9
           next = 0
           call getwrd ( i, 2, next, jbeg, jend, jran, ' ,.', word )
           if ( (word .eq. keywrd( 3)) .or. (word .eq. keywrd( 4)) )
     1       nread = nread + 1
           if (word .eq. keywrd(13)) go to 70
         endif
         tmpfile(i)(74:74) = '*'
         newfile(i) = blank128
70     continue
       nltmp  = nlnew
       nltmpt = nlnew
       nlnew  = 0
       nlnewt = 0
       nread  = nread - nerror2
c
c      If "nread" > 0, search through "tmpfile" again for *read's.
c
       if ( (nread .gt. 0) .and. (nround .le. 10) ) go to 20
c
c      Call COLLECT to obtain a list of decks and their positions in
c  the source code (assumed to be in the disc file "oldname").
c
       call collect
c
c      Store "idkbeg", "idkend", "icdbeg", and "icdend" to the arrays
c  "idksta", "idkfin", "icdsta", and "icdfin".  The former arrays are
c  never altered, and are permanent markers for the decks in the disc
c  file.  The latter arrays are altered as changes are made to the
c  source code, and are used as markers for the decks in the text file.
c
       do 80 i=1,ndk
         idksta(i) = idkbeg(i)
         idkfin(i) = idkend(i)
80     continue
       do 90 i=1,ncd
         icdsta(i) = icdbeg(i)
         icdfin(i) = icdend(i)
90     continue
c
c      Read the next portion of the disc file "oldname" into the text
c  file "oldfile".
c
       nldiff = 0
       lfirst = 1
       leof   = lreadall
100    continue
       if (.not. leof) then
         nlold = 0
         call rfile ( luold, oldname, 1, lfirst, llast, 0, leof )
         nldiff = nloldt - nlold
       endif
c
c      Copy contents of "oldfile" to "newfile", just in case no changes
c  are made.
c
       do 110 i=1,nlold
         newfile(i) = oldfile(i)
110    continue
       nlnew = nlold
c
c      Call MRGNMBR to label the lines in "oldfile" with line numbers
c  so that *delete's and *insert's may be done.
c
       call mrgnmbr
c
c      Apply MERGE commands in change deck to "oldfile".
c
       itmp = 0
120    continue
       itmp = itmp + 1
       if (itmp .gt. nltmp) go to 330
       char1 = tmpfile(itmp)(1:1)
       if (char1 .ne. '*') go to 120
c
c      Determine which MERGE command has been found.
c
       next = 0
       jbeg = 2
       jend = 9
       call getwrd ( itmp, 2, next, jbeg, jend, jran, ' ,.', wrd1 )
       do 130 k=1,20
         if ( (wrd1 .ne. blank16) .and. (wrd1 .eq. keywrd(k)) )
     1     go to 140
130    continue
140    continue
       match = 1
       if ( (k .eq.  5) .or. (k .eq.  6) .or.
     1      (k .eq.  7) .or. (k .eq.  8) ) match = 2
       if ( (k .eq.  9) .or. (k .eq. 10) ) match = 3
       if ( (k .eq. 11) .or. (k .eq. 12) ) match = 4
       if ( (k .eq.  1) .or. (k .eq.  2) ) match = 5
       go to (120, 150, 150, 150, 150) match
c
150    continue
       tmpfile(itmp)(74:74) = ' '
       if ( (match .eq. 4) .or. (match .eq. 5) ) go to 120
c
c      Determine deck name and range of lines that are to be modified.
c
       jbeg = jend + 1
       jend = nchar
       next = 0
       call getwrd ( itmp, 2, next, jbeg, jend, jran, ' ,.', subnam )
       if (subnam .eq. blank16) then
         if (lfirst .eq. 1) call errset ( itmp, 21, 2 )
         go to 120
       endif
       do 160 idk=1,ndk
         if (subnam .eq. dknam(idk)) then
           if ( (nloldt .lt. idkbeg(idk)) .or.
     1          (lfirst .gt. idkend(idk)) ) go to 120
           ideckb  = idksta(idk)
           idecke  = idkfin(idk)
           ideckr  = idkran(idk)
           ideckr0 = idkend(idk) - idkbeg(idk) + 1
           go to 180
         endif
160    continue
       do 170 icd=1,ncd
         if (subnam .eq. cdnam(icd)) then
           if ( (nloldt .lt. icdbeg(icd)) .or.
     1          (lfirst .gt. icdend(icd)) ) go to 120
           ideckb  = icdsta(icd)
           idecke  = icdfin(icd)
           ideckr  = icdran(icd)
           ideckr0 = icdend(icd) - icdbeg(icd) + 1
           go to 180
         endif
170    continue
c
c      The only way for execution to reach this point, is if "subnam" is
c  not found in either of the lists "dknam" or "cdnam".  Issue an error
c  message.
c
       call errset ( itmp, 22, 2 )
       go to 120
180    continue
       jbeg = jend + 1
       jend = nchar
       next = 0
       call getwrd ( itmp, 2, next, jbeg, jend, jran, ' ,.', wrd1 )
       if (wrd1 .eq. blank16) then
         call errset ( itmp, 23, 2 )
         go to 120
       endif
       jbeg = jend + 1
       jend = nchar
       next = 0
       call getwrd ( itmp, 2, next, jbeg, jend, jran, ' ,.', wrd2 )
       if ( (wrd2 .eq. blank16) .or. (match .eq. 3) ) wrd2 = wrd1
c
c      Make sure that the range of lines make sense (end comes after
c  beginning) and that the first line comes before the end of the deck
c  ("ideckr0").  If the last line specified is greater than "ideckr0",
c  set "iend" = "ideckr0".
c
       call ctoi ( itmp, wrd1, ibeg )
       if (ibeg .eq. -1) go to 120
       call ctoi ( itmp, wrd2, iend )
       if (iend .eq. -1) go to 120
       if (iend .lt. ibeg) then
         call errset ( itmp, 24, 2 )
         go to 120
       endif
       if (ideckr0 .lt. ibeg) then
         if (match .eq. 3) then
           ibeg = ideckr0
         else
           call errset ( itmp, 25, 2 )
           go to 120
         endif
       endif
       if (ideckr0 .lt. iend) iend = ideckr0
c
c      "isub" is the number of lines that will be removed.
c      "imax" is the last line from "oldfile" to be copied to "newfile"
c  before new lines are added to "newfile" from "tmpfile".
c
       if (match .eq. 2) then
         isub = iend - ibeg + 1
         imax = ideckb - 1 - nldiff
       else
         isub = 0
         imax = ideckb - nldiff
       endif
       do 190 i=1,imax
         newfile(i) = oldfile(i)
190    continue
       if (match .eq. 2) icount = 0
       if (match .eq. 3) icount = 1
200    continue
       wrd3 = blank16
       if (match .eq. 2) wrd3(1:5) = oldfile(imax+1)(76:80)
       if (match .eq. 3) wrd3(1:5) = oldfile(imax  )(76:80)
       iline = 0
       if (wrd3 .ne. blank16) call ctoi ( itmp, wrd3, iline )
       if (iline .eq. -1) go to 120
       if (iline .eq. ibeg) go to 210
       icount = icount + 1
       if (icount .gt. ideckr) then
         call errset ( itmp, 26, 2 )
         go to 120
       endif
       imax = imax + 1
       newfile(imax) = oldfile(imax)
       go to 200
210    continue
c
c      Read next line in change deck, and see if it is a MERGE command.
c  If it is a *delete, *replace, *insert, or *end, write all the lines
c  in "oldfile" that come after "iend" to "newfile", then overwrite
c  "oldfile" with "newfile", then finally update the values of "idksta"
c  and "idkfin".
c      If the next line is not one of the above MERGE commands, then
c  the line is inserted into "newfile" (unless it is an *ident command,
c  in which case the line is skipped).
c      "iadd" is the number of lines added to "newfile".
c
       nlnew = imax
       iadd  = 0
220    continue
       if (itmp .eq. nltmp) then
         icount = icount - 1
         ibit = 0
         word = keywrd(11)
         go to 230
       endif
       itmp = itmp + 1
       char1 = tmpfile(itmp)(1:1)
       if (char1 .ne. '*') go to 310
       jbeg = 2
       jend = 9
       next = 0
       call getwrd ( itmp, 2, next, jbeg, jend, jran, ' ,.', word )
       if ( (word .eq. keywrd( 1)) .or. (word .eq. keywrd( 2)) .or.
     1      (word(1:1) .eq. '*') ) go to 320
       ibit = 1
230    continue
       if ( (word .eq. keywrd( 5)) .or. (word .eq. keywrd( 6)) .or.
     1      (word .eq. keywrd( 7)) .or. (word .eq. keywrd( 8)) .or.
     2      (word .eq. keywrd( 9)) .or. (word .eq. keywrd(10)) .or.
     3      (word .eq. keywrd(11)) .or. (word .eq. keywrd(12)) ) then
c
c  Note from DAC: 30/9/07:  Replaced
c
c        imin = imax
c
c  with the following two lines.
c
         if (match .eq. 2) imin = imax + 1
         if (match .eq. 3) imin = imax
240      continue
         wrd3 = blank16
         wrd3(1:5) = oldfile(imin)(76:80)
         imin = imin + 1
         iline = 0
         if (wrd3 .ne. blank16) call ctoi ( itmp, wrd3, iline )
         if (iline .eq. -1) go to 120
         if (iline .eq. iend) go to 250
         icount = icount + 1
         if (icount .gt. ideckr) then
           call errset ( itmp, 26, 2 )
           go to 120
         endif
         go to 240
250      continue
         if (imin .le. nlold) then
           do 260 i=imin,nlold
             nlnew = nlnew + 1
             if (nlnew .gt. ilmax) call overflow ( 4, 2 )
             newfile(nlnew) = oldfile(i)
260        continue
         endif
         do 270 i=1,nlnew
           oldfile(i) = newfile(i)
270      continue
         nlold = nlnew
         if (nlold .lt. ilmax) then
           do 280 i=nlold+1,ilmax
             oldfile(i) = blank128
280        continue
         endif
         do 290 i=1,ndk
           if ( (idksta(i) .gt. idecke) .and.
     1          (idkbeg(i) .le. nloldt) )
     2       idksta(i) = idksta(i) + iadd - isub
           if ( (idkfin(i) .gt. ideckb) .and.
     1          (idkend(i) .le. nloldt) )
     2       idkfin(i) = idkfin(i) + iadd - isub
           idkran(i) = idkfin(i) - idksta(i) + 1
290      continue
         do 300 i=1,ncd
           if ( (icdsta(i) .gt. idecke) .and.
     1          (icdbeg(i) .le. nloldt) )
     2       icdsta(i) = icdsta(i) + iadd - isub
           if ( (icdfin(i) .gt. ideckb) .and.
     1          (icdend(i) .le. nloldt) )
     2       icdfin(i) = icdfin(i) + iadd - isub
           icdran(i) = icdfin(i) - icdsta(i) + 1
300      continue
         itmp = itmp - ibit
         go to 120
       endif
310    continue
       nlnew = nlnew + 1
       if (nlnew .gt. ilmax) call overflow ( 4, 2 )
       iadd = iadd + 1
       newfile(nlnew) = tmpfile(itmp)
320    continue
       if (tmpfile(itmp)(1:6) .ne. '*error') tmpfile(itmp)(74:74) = ' '
       if (itmp .eq. nltmp) then
         icount = icount - 1
         ibit = 0
         word = keywrd(11)
         go to 230
       endif
       go to 220
c
c      Finished inserting changes into "oldfile".  Blank out columns
c  75-128 in "newfile" if an * is found in column 74.   Otherwise, blank
c  out columns 73-128.  Then write the contents of "newfile" to disc.
c
330    continue
       do 340 i=1,nlnew
         if (newfile(i)(1:6) .eq. '*error') go to 340
         line = blank128
         if (newfile(i)(74:74) .eq. '*') then
           line(1:74) = newfile(i)(1:74)
         else
           line(1:72) = newfile(i)(1:72)
         endif
         newfile(i) = line
340    continue
       call wfile ( lunew, 4 )
c
c      If the end of file has not been reached in the disc file
c  "oldname", read the next portion into "oldfile".  Otherwise, close
c  disc file "oldname".
c
       if (.not. leof) then
         lfirst = nloldt + 1
         go to 100
       endif
       call cfile ( luold, oldname, 0 )
c
c      All changes have been inserted into the disc file "oldname" and
c  written to "newname".  Now, deal with errors found in the change deck
c  ("ierr2" and "lnerr2").
c
       if (nerr2 .gt. 0) then
c
c      First, eliminate any duplicate errors found in the change deck
c  (same values of "ierr2" and "lnerr2").
c
         if (nerr2 .gt. 1) then
           do 360 i1=1,nerr2-1
             if (ierr2(i1) .ne. 0) then
               do 350 i2=i1+1,nerr2
                 if ( ( ierr2(i1) .eq.  ierr2(i2)) .and.
     1                (lnerr2(i1) .eq. lnerr2(i2)) ) ierr2(i2) = 0
350            continue
             endif
360        continue
           ierr = 2
370        continue
           if (ierr2(ierr) .eq. 0) then
             do 380 i1=ierr,nerr2-1
               ierr2 (i1) = ierr2 (i1+1)
               lnerr2(i1) = lnerr2(i1+1)
380          continue
             ierr2 (nerr2) = 0
             lnerr2(nerr2) = 0
             nerr2   = nerr2   - 1
             nerror2 = nerror2 - 1
           else
             ierr = ierr + 1
           endif
           if (ierr .le. nerr2) go to 370
         endif
c
c  Then, insert any errors found in the change deck into "tmpfile".
c
         nlold = 0
         do 390 i=1,nltmp
           nlold = nlold + 1
           oldfile(nlold) = tmpfile(i)
           if (nerr2 .gt. 0) call errwrt ( i, 1, 2, nlold )
390      continue
         do 400 i=1,nlold
           tmpfile(i) = oldfile(i)
400      continue
         nltmp = nlold
       endif
c
c      Write "mchgname" to disc.  If errors were discovered in the
c  change deck, issue appropriate message to the crt.
c
       mchgname = blank64
       i = min0 ( ncharc + 1, 63 )
       mchgname(1:i-1) = chgname(1:i-1)
       mchgname(i:i+1) = '.m'
       ncharm = min0 ( ncharc + 2, 64 )
       call ofile ( luchg, mchgname, 'unknown ' )
       call wfile ( luchg, 2 )
       if (nerror2 .gt. 0) then
         if ( (inum .eq. 0) .and. (ipre .eq. 0) )
     1     write (6, 2010) nerror2
         if (inum .gt. 0) write (6, 2020) nerror2
         if (ipre .gt. 0) write (6, 2030) nerror2
         if (ncharm .le. 17) write (6, 2040) mchgname
         if (ncharm .gt. 17) write (6, 2050) mchgname
       endif
       call cfile ( luchg, mchgname, nltmp )
c
c       Return to EDITOR if no NUMBERed or PRECOMpiled files are
c  desired, or if there were any errors detected in the change deck.
c
       if ( ( (inum .eq. 0) .and. (ipre .eq. 0) ) .or.
     1      (nerror2 .gt. 0) ) then
         call cfile ( lunew, newname, nlnewt )
         return
       endif
c
c      If "ipre" = 1, write all *define and *alias commands in "tmpfile"
c  that still have an * in column 74 to "newfile".  Then, write
c  "newfile" to the disc file "newname".
c
       nlines = 0
       if (ipre .eq. 1) then
         do 410 i=1,nltmp
           if (tmpfile(i)(74:74) .eq. '*') then
             word = blank16
             word(1:3) = tmpfile(i)(1:3)
             if ( (word .eq. '*de             ') .or.
     1            (word .eq. '*al             ') ) then
               nlnew  = nlnew  + 1
               if (nlnew .gt. ilmax) call overflow ( 4, 2 )
               newfile(nlnew ) = tmpfile(i)
               nlines = nlines + 1
               tmpfile(nlines) = tmpfile(i)
             endif
           endif
410      continue
         nltmp = nlines
         if (nltmp .gt. 0) then
           call wfile ( lunew, 2 )
           nlnewt = nlnewt + nltmp
         endif
       endif
c
c      Close disc file "newname".
c
       call cfile ( lunew, newname, nlnewt )
c
c      Set "readname", which is used to determine the name of the next
c  file written to disc.
c
       readname = oldname
       ncharr   = ncharo
c
c      If "lreadall" = .true., copy "newfile" back to "oldfile".
c
       if (lreadall) then
         do 420 i=1,nlnewt
           oldfile(i) = newfile(i)
420      continue
         nlold  = nlnewt
         nloldt = nlnewt
       endif
       oldname = newname
c
c      Call NUMBER if "inum" > 0.
c
       if (inum .gt. 0) then
         newname = blank64
         i = min0 ( ncharr + 1, 63 )
         newname(1:i-1) = readname(1:i-1)
         newname(i:i+1) = '.n'
         ncharn  = min0 ( ncharr + 2, 64 )
         inumber = 3
         itable  = 1
         ixclude = 1
         nlnewt  = 0
         call number
       endif
c
c      Call PRECOM if "ipre" > 0.
c
       if (ipre .gt. 0) then
         newname = blank64
         i = min0 ( ncharr + 1, 63 )
         newname(1:i-1) = readname(1:i-1)
         newname(i:i+1) = '.f'
         ncharn = min0 ( ncharr + 2, 64 )
         nlnewt  = 0
         do 430 ierr=1,nerror1
           lnerr1(ierr) = 0
           ierr1 (ierr) = 0
430      continue
         nerr1   = 0
         nerror1 = 0
         call precom
       endif
c
c      Return to EDITOR.
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('MERGE   : ',i4,' errors detected in the change deck.')
2020   format('MERGE   : ',i4,' errors detected in the change deck.  '
     1       ,'No NUMBERed file written.')
2030   format('MERGE   : ',i4,' errors detected in the change deck.  '
     1       ,'No PRECOMpiled file written.')
2040   format('MERGE   : Scan file "',a17,'" (columns 16-20) for '
     1       ,'pattern: **** ERROR.')
2050   format('MERGE   : Scan file "',a14,'..." (columns 16-20) for '
     1       ,'pattern: **** ERROR.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 M E R G E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                N U M B E R                \\\\\\\\\\
c
c=======================================================================
c
       subroutine number
c
c    dac:editor.number <---------- inserts line numbers in a source code
c                                                         november, 1988
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 1 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1: September 1989 by David Clarke; Reworked to allow
c                partial reads of input file.
c
c  PURPOSE:  This subroutine numbers the lines in a source code in one
c  of three ways.
c
c  If "inumber" = 1, line numbers are inserted in columns 1 through 6
c  and again in column 84 through 89.  The numbers correspond to the
c  line numbers used by FRED, for example.  The line itself is put in
c  columns 11 through 82.  Each line is numbered sequentially, including
c  comments, continuation lines, and EDITOR (HISTORAN) commands.
c
c  If "inumber" = 2, FRED type line numbering is inserted in columns 1
c  through 6 and again in columns 84 through 89.  In addition, the
c  statement number (to which CTSS CFT compiler errors refer) is put in
c  columns 91 through 95, the number of lines since the last "program",
c  "subroutine, "function", or "blockdata" statement is put in columns
c  97 through 101, and the subprogram name in put in columns 104 through
c  111.  The line itself is put in columns 11 through 82.
c
c  If "inumber" = 3, FRED type line numbering is inserted in columns 1
c  through 6 and again in columns 84 through 89.  In addition, the
c  statement number (to which CTSS CFT compiler errors refer) is put in
c  columns 91 through 95, the number of lines since the last "*deck",
c  "*dk", "*cdeck", or "*cd" statement (to which EDITOR and HISTORAN
c  commands refer) is put in columns 97 through 101, the name of the
c  current "*group" or "*gp" is put in columns 104 through 111, and the
c  name of the deck is put in columns 114 through 121.  If NUMBER has
c  been called by MERGE, then the deck and group names are capitalised
c  for statements that have been inserted by MERGE, so that these lines
c  may be distinguished from the original lines in the source code.  The
c  statement number will be included only if the surrounding EDITOR
c  "*if " tests are satisfied.  The line itself is put in columns 11
c  through 82.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    RFILE
c    COLLECT
c    CDECKS
c    ALIASES
c    ITOC
c    GETWRD
c    INOREX
c    CAPITALS
c    HEADER
c    CFILE
c    WFILE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   char1   , char2
       character*16  word    , wrd1    , wrd2    , subnam    , ucsnam
     1             , subname , grpnam  , ucgnam  , grpname
       character*128 line
       integer       ilx     , nlx     , isub    , ixeq    , lfirst
     1             , llast   , i       , iline   , jbeg    , jend
     2             , next    , jran    , iwrd    , match   , icd
     3             , ndkncd  , idk     , ibegj   , j
c
       logical       lxeq    (  13)
       character*16  keywrd  (  15)
       character*16  clist1  (2*k4), clist2  (2*k4), clist3  (2*k4)
     1             , clist4  (2*k4)
       integer       ilist1  (2*k4), ilist2  (2*k4)
c
c      External statements
c
       external      ofile   , rfile   , collect , cdecks  , aliases
     1             , itoc    , getwrd  , inorex  , capitals, header
     2             , cfile   , wfile
c
c      Data statements.
c
       data          keywrd
     1   / 'PROGRAM         ', 'SUBROUTINE      ', 'FUNCTION        '
     2   , 'BLOCKDATA       ', 'BLOCK           ', 'group           '
     3   , 'gp              ', 'deck            ', 'dk              '
     4   , 'cdeck           ', 'cd              ', 'REAL            '
     5   , 'INTEGER         ', 'LOGICAL         ', 'CHARACTER       ' /
c
c-----------------------------------------------------------------------
c
c      Open disc files "oldname" and "newname".
c
       call ofile ( luold, oldname, 'old     ' )
       call ofile ( lunew, newname, 'unknown ' )
c
c      Initialise temporaries.
c
       do 10 ilx=1,13
         lxeq(ilx) = .true.
10     continue
       nlx    = 2
       isub   = 0
       ixeq   = 0
       subnam = blank16
       ucsnam = blank16
       grpnam = blank16
       ucgnam = blank16
c
       lfirst = 1
       llast  = 0
       nlold  = 0
       if (inumber .eq. 1) then
         call rfile ( luold, oldname, -1, lfirst, llast, 0, leof )
       else
         call collect
         call cdecks
       endif
       leof   = lreadall
c
c      If "inumber" is 1, then RFILE has already read the entire disc
c  file into "oldfile", and there is no need to read it again.
c      If "inumber" = 2 or 3, and "leof" = .true., then the entire  disc
c  file fits into the text array "oldfile", and there is no need to
c  read it again.
c      If "inumber" = 2 or 3, and "leof" = .false., the entire disc file
c  could not fit into "oldfile, and so it is necessary to read the disc
c  file into "oldfile" again, from the beginning, in portions determined
c  by "idkend" and "icdend".
c
20     continue
       if ( (inumber .ne. 1) .and. (.not. leof) ) then
         nlold  = 0
         call rfile ( luold, oldname, 1, lfirst, llast, 0, leof )
       endif
c
c      Copy "oldfile" to "tmpfile".
c
       do 30 i=1,nlold
         tmpfile(i) = oldfile(i)
30     continue
       nltmp = nlold
c
c      If "inumber" = 3, substitute all aliases.
c
       if ( (inumber .eq. 3) .and. (nalias .ne. 0) ) call aliases ( 1 )
c
c      Number the lines in the file.
c
       nlnew = 0
       do 120 i=1,nltmp
         line        = blank128
         line(11:82) = tmpfile(i)(1:72)
         iline       = i + lfirst - 1
         call itoc ( iline, word, 2 )
         line( 1: 6) = word(11:16)
         line(84:89) = word(11:16)
         if (inumber .eq. 1) go to 110
c
c      Case:  "inumber" = 2.
c
         if (inumber .eq. 2) then
           isub = isub + 1
           if (line(11:16) .eq. '      ') then
             jbeg = 7
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' *', word )
             call capitals ( word )
c
c      Reset subroutine numbers ("isub" and "ixeq") if a "subroutine"
c  or a "program" statement is encountered.  Call to GETWRD gets name
c  of subroutine.
c
             do 40 iwrd=1,15
               if (word .eq. keywrd(iwrd)) go to 50
40           continue
50           continue
             match = 1
             if ( (iwrd .ge.  1) .and. (iwrd .le.  4) ) match = 2
             if   (iwrd .eq.  5)                        match = 3
             if ( (iwrd .ge. 12) .and. (iwrd .le. 15) ) match = 4
c
             go to ( 80, 60, 60, 60 ) match
c
60           continue
             isub = 1
             ixeq = 0
             if (line(jend+11:jend+11) .eq. '*') then
               jbeg = jend + 1
               jend = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
             endif
70           continue
             jbeg = jend + 1
             jend = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' (', subnam )
             if (match .eq. 3) then
               match = 2
               go to 70
             endif
             if (match .eq. 4) then
               call capitals ( subnam )
               if (subnam .eq. keywrd(3)) then
                 match = 2
                 go to 70
               endif
             endif
c
80           continue
           endif
         endif
c
c      Case:  "inumber" = 3.
c
         if (inumber .eq. 3) then
           lxeq(1) = .true.
           isub    = isub + 1
           if (line(11:11) .eq. '*') then
             call inorex ( i, 1, 3, nlx, lxeq )
             jbeg = 2
             jend = 6
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', word )
c
c      Reset "subnam" and "ucsnam" to blank if an EDITOR *group or *gp
c  command is encountered.  Call to GETWRD gets name of group.
c
             if ( (word.eq.keywrd(6)) .or. (word.eq.keywrd(7)) ) then
               subnam = blank16
               ucsnam = blank16
               jbeg   = jend + 1
               jend   = nchar
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.'
     1                     , grpnam )
               ucgnam = grpnam
               call capitals ( ucgnam )
             endif
c
c      Reset deck numbers ("isub" and "ixeq") if an EDITOR *deck, *dk,
c  *cdeck, or a *cd command is encountered.  Call to GETWRD gets name
c  of deck.
c
             if ( (word.eq.keywrd( 8)) .or. (word.eq.keywrd( 9)) .or.
     1            (word.eq.keywrd(10)) .or. (word.eq.keywrd(11)) ) then
               isub = 1
               ixeq = 0
               jbeg = jend + 1
               jend = nchar
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.'
     1                     , subnam )
               ucsnam = subnam
               call capitals ( ucsnam )
             endif
c
c      If an EDITOR *call or *ca command is encountered, "ixeq" is
c  increased by the number of statements in the common deck being
c  called, provided the EDITOR conditionals surrounding the *call
c  statement are satisfied.
c
             if ( (word(1:2) .eq. 'ca')       .and. (lxeq( 3)) .and.
     1            (lxeq( 4)) .and. (lxeq( 5)) .and. (lxeq( 6)) .and.
     2            (lxeq( 7)) .and. (lxeq( 8)) .and. (lxeq( 9)) .and.
     3            (lxeq(10)) .and. (lxeq(11)) .and. (lxeq(12)) ) then
               jbeg = jend + 1
               jend = nchar
               next = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', word )
               do 90 icd=1,ncd
                 if (word .eq. cdnam(icd)) then
                   ixeq = ixeq + icdxeq(icd)
                   go to 100
                 endif
90             continue
100            continue
             endif
           endif
         endif
c
c      Case:  "inumber" = 2 or 3.
c
         char1 = line(11:11)
         char2 = line(16:16)
         if ( (lxeq( 1)) .and. (lxeq( 2)) .and. (lxeq( 3)) .and.
     1        (lxeq( 4)) .and. (lxeq( 5)) .and. (lxeq( 6)) .and.
     2        (lxeq( 7)) .and. (lxeq( 8)) .and. (lxeq( 9)) .and.
     3        (lxeq(10)) .and. (lxeq(11)) .and. (lxeq(12)) ) then
           if ( (char1 .ne. 'c') .and. (char1 .ne. 'C') .and.
     1          (char1 .ne. '*') .and. (char2 .eq. ' ') ) then
             ixeq = ixeq + 1
             call itoc ( ixeq, word, 2 )
             line(91:95) = word(12:16)
           endif
         endif
         call itoc ( isub, word, 2 )
         if ( (inumber .eq. 3) .and. (subnam .eq. blank16) )
     1     word = blank16
         line(97:101) = word(12:16)
         if (inumber .eq. 2) then
           line(104:111) = subnam(1:8)
         else
           char1 = oldfile(i)(74:74)
           if (char1 .eq. '*') then
             line(104:111) = ucgnam(1:8)
             line(114:121) = ucsnam(1:8)
           else
             line(104:111) = grpnam(1:8)
             line(114:121) = subnam(1:8)
           endif
         endif
110      continue
c
c      Case:  "inumber" = 1, 2, or 3.
c
         nlnew = nlnew + 1
         newfile(nlnew) = line
120    continue
c
c      Copy "tmpfile" back to "oldfile".
c
       do 130 i=1,nltmp
         oldfile(i) = tmpfile(i)
130    continue
c
c      Write header to outfile only if this is the first portion of the
c  file being read ("lfirst" = 1)).
c
       if (lfirst .eq. 1) call header ( lunew )
c
c      Write a table of contents if "itable" = 1, "inumber" = 2 or 3,
c  and this is the first portion of the file being read ("lfirst" = 1)).
c
       if ( (lfirst  .eq. 1) .and. (itable .eq. 1) .and.
     1      (inumber .ne. 1) ) then
c
c      Copy ordinary and common deck names, along with their groups
c  and beginning lines, to "clist*" and "ilist*".  Put an '*' before
c  each common deck name.
c
         ndkncd = ndk + ncd
         do 140 i=1,ndk
           idk = i
           clist1(i) = dknam (idk)
           clist2(i) = dknam (idk)
           clist3(i) = dkgrp (idk)
           clist4(i) = dkgrp (idk)
           ilist1(i) = idkbeg(idk)
           ilist2(i) = idkbeg(idk)
140      continue
         do 150 i=ndk+1,ndkncd
           icd = i - ndk
           clist1(i)(1:1) = '*'
           clist1(i)(2:9) = cdnam (icd)(1:8)
           clist2(i) = clist1(i)
           clist3(i) = cdgrp (icd)
           clist4(i) = cdgrp (icd)
           ilist1(i) = icdbeg(icd)
           ilist2(i) = icdbeg(icd)
150      continue
c
c      Rearrange "clist1" (the deck names) alphabetically.
c
         do 170 i=1,ndkncd-1
           do 160 j=1,ndkncd-1
             if (clist1(j) .gt. clist1(j+1)) then
               subname     = clist1(j  )
               grpname     = clist3(j  )
               ibegj       = ilist1(j  )
               clist1(j  ) = clist1(j+1)
               clist3(j  ) = clist3(j+1)
               ilist1(j  ) = ilist1(j+1)
               clist1(j+1) = subname
               clist3(j+1) = grpname
               ilist1(j+1) = ibegj
             endif
160        continue
170      continue
c
c      Rearrange "ilist1" (the line numbers of the first line in each
c  deck) sequentially.
c
         do 190 i=1,ndkncd-1
           do 180 j=1,ndkncd-1
             if (ilist2(j) .gt. ilist2(j+1)) then
               subname     = clist2(j  )
               grpname     = clist4(j  )
               ibegj       = ilist2(j  )
               clist2(j  ) = clist2(j+1)
               clist4(j  ) = clist4(j+1)
               ilist2(j  ) = ilist2(j+1)
               clist2(j+1) = subname
               clist4(j+1) = grpname
               ilist2(j+1) = ibegj
             endif
180        continue
190      continue
c
c      Create table of contents.
c
         write (lunew, 2010)
         do 200 i=1,ndkncd
           call itoc ( ilist1(i), wrd1, 2 )
           call itoc ( ilist2(i), wrd2, 2 )
           call capitals ( clist3(i) )
           call capitals ( clist4(i) )
           write (lunew, 2020) clist3(i), clist1(i), wrd1(9:16)
     1                       , clist4(i), clist2(i), wrd2(9:16)
200      continue
         write (lunew, 2030)
         nlnewt = nlnewt + 7 + ndkncd
       endif
c
c      Write contents of "newfile" to disc.
c
       call wfile ( lunew, 4 )
c
c      If end of file has not been reached (leof = .false.), read the ne
c  portion of the disc file.
c
       if (.not. leof) then
         lfirst = nloldt + 1
         go to 20
       endif
c
c      Message to terminal.
c
       if (ibanner .eq. 1) then
         if (ncharn .le. 16) write (6, 2040) newname, nloldt
         if (ncharn .gt. 16) write (6, 2050) newname, nloldt
       endif
c
c      Close files, and return to calling routine.
c
       call cfile ( luold, oldname,      0 )
       call cfile ( lunew, newname, nlnewt )
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(/,24x,'T A B L E   O F   C O N T E N T S'
     1       ,/,14x,'Group Names capitalised, Common Decks prefaced '
     2       ,'by *',/)
2020   format(7x,a8,2x,a8,4x,a8,6x,a8,2x,a8,4x,a8)
2030   format(/)
2040   format('NUMBER  : Lines NUMBERed in file "',a16,'" = ',i6,'.')
2050   format('NUMBER  : Lines NUMBERed in file "',a14,'... = ',i6,'.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                N U M B E R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                P R E C O M                \\\\\\\\\\
c
c=======================================================================
c
       subroutine precom
c
c    dac:editor.precom <-------------------- precompiler for source code
c                                                         november, 1988
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 4 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c    modified 2: July 2004, by David Clarke; generalised makefile to
c                allow special routines to be compiled with different
c                compiler options.
c    modified 3: March, 2011 by DAC; removed OS macros.
c
c  PURPOSE:  This subroutine executes all the EDITOR commands inserted
c  in the source code, and prepares the source code for compilation by
c  the compiler.  The following EDITOR commands are recognised (and are
c  not copied over to the precompiled source code):
c
c  1.  *call x            is replaced by the common deck "x" defined
c                         elsewhere in the listing.
c  2.  *define x,y,z      turns on switches "x", "y" and "z".  comma's
c                         are optional.
c  3.  *if define x       includes the following text if the switch "x"
c                         is on.
c  4.  *if -define x      includes the following text if the switch "x"
c                         is off.
c  5.  *if define x.and.y includes the following text if both switches
c                         "x" and "y" are on.
c  6.  *if define x.or.y  includes the following text if either switch
c                         "x" or "y" are on.
c  7.  *alias x y         all occurances of "x" are replaced with "y".
c  8.  *if alias x.eq.y   includes the following text if "x" is an alias
c                         for "y".
c  9.  *if alias x.ne.y   includes the following text if "x"is not an
c                         alias for "y".
c  10. *else              includes the following text if the previous
c                         "if" test is false.
c  11. *endif             ends an "if" or an "if-else" construct.
c  12. **                 what follows is treated like a comment.
c
c  All EDITOR sentinels (*) must be placed in column 1, or the command
c  is not recognised.  There should be no blanks between the sentinel
c  and the first word of the command.  Commas and blanks may be used
c  interchangeably.  The following abbreviations are recognised:
c
c  *ca  = *call     *def = *define   *al  = *alias    *el  = *else
c  *ei  = *endif
c
c  After all the common deck insertions have been completed, the
c  common decks themselves are deleted.
c
c  If desired ("inmlst" = 1), NMLST can be called to substitute all
c  namelists and their associated reads, writes, and prints for calls
c  to NLSDACxx subroutines found in the library "namelist.lib".
c
c  If desired ("iutask" = 1, 2), PARALLEL can be called to insert Cray
c  (1) or OpenMP (2) microtasking directives before nested do-loop
c  constructs.  Negative values will relax the requirment that loops be
c  nested, though this feature has been known to cause parallel runs to
c  differ from serial runs, and should be considered experimental.  See
c  subroutine PARALLEL for further discussion of this feature.
c
c  If desired ("iupdate" = 1), UPDATE can be called to store all decks
c  on disc in separate files.  This will be done only if there isn't
c  already an identical copy on disc.  When "iupdate" = 1, a makefile
c  can be created if "makename" is not blank.  PRECOM opens, starts,
c  finishes, and closes the makefile, while UPDATE creates the list of
c  object files.  The following attributes of the makefile can be
c  specified by the user:
c
c  1. compiler         ("compiler", char*16 , default: gfortran)
c  2. compiler options ("coptions", char*128, default: none)
c                      ("speccopt", char*128, default: none)
c  3. executable name  ("xeq"     , char*64 , default: "oldname".x)
c  4. directory        ("branch"  , char*32 , default: none)
c  5. loader           ("loader"  , char*16 , default: segldr, fc)
c  6. loader options   ("loptions", char*128, default: '-o $(EXE)')
c  7. libraries        ("libs"    , char*512, default: none)
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    COLLECT
c    CDECKS
c    STRLEN
c    RFILE
c    ALIASES
c    COPY
c    GETWRD
c    OVERFLOW
c    ERRSET
c    ERRWRT
c    NMLST
c    PARALLEL
c    WFILE
c    UPDATE
c    CFILE
c    DUMP
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   tab
       character*16  word    , subnam
       character*64  makefile
       integer       i       , j       , jcomp   , jload   , jxeq
     1             , jcopt   , jspcopt , jlopt   , jlibs   , nlw
     2             , lfirst  , llast   , jbeg    , jend    , jran
     3             , next    , icd     , ibeg    , iend    , iline
     4             , nerror
c
       character*16  keywrd  (   2)
c
c      External statements
c
       integer       strlen
       external      ofile   , collect , cdecks  , strlen  , rfile
     1             , aliases , copy    , getwrd  , overflow, errset
     2             , errwrt  , nmlst   , parallel, wfile   , update
     3             , cfile   , dump
c
c      Data statements
c
       data          keywrd
     1            / 'ca              ', 'call            ' /
c
c-----------------------------------------------------------------------
c
c      Initialise error variables.
c
       do 10 i=1,iemax
         lnerr2(i) = 0
         ierr2 (i) = 0
10     continue
       nerr2 = 0
c
c      Open disc files "oldname" and "newname".
c
       call ofile ( luold, oldname, 'old     ' )
       call ofile ( lunew, newname, 'unknown ' )
c
c      Collect a list of switches, aliases, decknames, and beginning
c  and ending line numbers of each deck from the disc file "oldname".
c
       call collect
       leof = lreadall
c
c      Create a text file "cdkfile" containing all the common decks.
c
       call cdecks
c
c      Start creating the makefile, if none has been started and one is
c  desired.
c
       if ( (iupdate .eq. 1) .and. (makename .ne. blank16) ) then
c
         if (xeq .eq. blank64) then
           xeq = oldname
           xeq(ncharo+1:ncharo+2) = '.x'
         endif
         makefile       = blank64
         makefile(1:16) = makename
         call ofile ( lumak, makefile, 'unknown ' )
c
c      Determine the lengths of all the character strings to be written
c  to the makefile.
c
         jcomp   = strlen ( compiler )
         jload   = strlen ( loader   )
         jxeq    = strlen ( xeq      )
         jcopt   = strlen ( coptions )
         jspcopt = strlen ( speccopt )
         jlopt   = strlen ( loptions )
         jlibs   = strlen ( libs     )
c
c      Write the first seven lines of the makefile.
c
         write (lumak, 2010) compiler(1:jcomp)
         write (lumak, 2030) 'COPT1', coptions(1:jcopt)
         write (lumak, 2030) 'COPT2', speccopt(1:jspcopt)
         if (compiler(1:4) .eq. 'cf77') then
           write (lumak, 2040) 'COPT1', coptions(1:jcopt)
           write (lumak, 2040) 'COPT2', speccopt(1:jspcopt)
         endif
         write (lumak, 2070) xeq     (1:jxeq  )
         write (lumak, 2080) branch  (1:ncharb)
c
       endif
c
       nlw    = 2
       lfirst = 1
60     continue
c
c      If either "leof" is false, or COLLECT found errors in the disc
c  file (nerr1 > 0), read the next portion of the disc file "oldname"
c  into the text file "oldfile".  Insert any errors from error array
c  "ierr1" found by COLLECT.
c
       if ( (.not. leof) .or. (nerr1 .gt. 0) ) then
         nlold  = 0
         call rfile ( luold, oldname, 1, lfirst, llast, 1, leof )
       endif
c
c      Make the alias substitutions.
c
       if (nalias .ne. 0) call aliases ( 1 )
c
c      Copy the source code from "oldfile" to "newfile" provided any
c  EDITOR conditionals that may be surrounding the source code are
c  satisfied.
c
       call copy ( 1, 2, nlw )
c
c      Copy "newfile" back to "oldfile".
c
       do 70 i=1,nlnew
         oldfile(i) = newfile(i)
70     continue
       nlold = nlnew
       nlnew = 0
c
c      Substitute EDITOR *call statements for the called common deck.
c
       do 100 i=1,nlold
         if (oldfile(i)(1:1) .eq. '*') then
           jbeg = 2
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', word )
           if ( (word .eq. keywrd(1)) .or. (word .eq. keywrd(2)) ) then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', subnam )
             do 90 icd=1,ncd
               if (subnam .eq. cdnam(icd)) then
c
c      The "common deck" called by the *call statement has been matched
c  with one of the known "common decks".  Insert the "common deck" into
c  "newfile", except the first line which is the *cdeck label.
c
                 ibeg = icdsta(icd) + 1
                 iend = icdfin(icd)
                 do 80 iline=ibeg,iend
                   nlnew = nlnew + 1
                   if (nlnew .gt. ilmax) call overflow ( 4, 3 )
                   newfile(nlnew) = cdkfile(iline)
                   if (newfile(nlnew)(1:6) .eq. '*error')
     1               nerror2 = nerror2 + 1
80               continue
                 go to 100
               endif
90           continue
c
c      The only way for execution to reach this point is if a *call has
c  been made to a "common deck" not found in the array "cdnam".  Issue
c  the appropriate error message.
c
             call errset ( i, 34, 2 )
           endif
         endif
c
c      Copy current line in "oldfile", along with any error messages to
c  "newfile".  This is not done if the line is a valid EDITOR *call
c  statement.
c
         nlnew = nlnew + 1
         if (nlnew .gt. ilmax) call overflow ( 4, 3 )
         newfile(nlnew) = oldfile(i)
         if (nerr2 .ne. 0) call errwrt ( i, 4, 2, nlnew )
100    continue
c
c      The text file "oldfile" has been PRECOMpiled, and the results
c  have been stored in the text file "newfile".  If "inmlst" > 0,  call
c  NMLST to replace occurances of NAMELIST and their associated READ's,
c  WRITE's, and PRINT's with calls to subroutines found in the library
c  NAMELIST.LIB.
c
       if (inmlst .gt. 0) call nmlst
c
c      If there are no errors, and iutask .ne. 0, call PARALLEL to
c  insert microtasking directives into the source code.
c
       nerror = nerror1 + nerror2
       if ( (nerror .eq. 0) .and. (iutask .ne. 0) ) call parallel
c
c      If there are no errors, and "iupdate" = 1, call UPDATE to split
c  all modules into separate files, and write to disc only those modules
c  that are different from the copy currently on disc.  If there are
c  errors, or "iupdate" = 0, write contents of "newfile" to disc file
c  "newname".
c
       nerror = nerror1 + nerror2
       if ( (nerror .eq. 0) .and. (iupdate .eq. 1) ) then
         call update ( leof )
       else
         call wfile ( lunew, 4 )
       endif
c
c      If end of file for disc file "oldname" has not been found, read
c  next portion of "oldname" into "oldfile".
c
       if (.not. leof) then
         nlold  = 0
         lfirst = nloldt + 1
         go to 60
       endif
c
c      End of file for "oldname" has been reached.  Finish up makefile,
c  if one was desired.
c
       if ( (iupdate .eq. 1) .and. (makename .ne. blank16) ) then
         write (lumak, 2090) loader  (1:jload)
         write (lumak, 2110) loptions(1:jlopt)
         write (lumak, 2120) libs    (1:jlibs)
         tab = char(9)
         write (lumak, 2130) tab
         if (nobj2 .gt. 0) then
           write (lumak, 2140) tab
           write (lumak, 2160) tab
           nlmakt = nlmakt + 14
         else
           write (lumak, 2180) tab
           nlmakt = nlmakt + 12
         endif
         call cfile ( lumak, makefile, nlmakt )
       endif
c
c      Inform user if errors were detected by either PRECOM or NMLST.
c
       if (nerror .gt. 0) then
         write (6, 2190) nerror
         if (iupdate .gt.  0) write (6, 2200)
         if (ncharn  .le. 17) write (6, 2210) newname
         if (ncharn  .gt. 17) write (6, 2220) newname
       endif
c
c      Close disc files "oldname" and "newname".
c
       call cfile ( luold, oldname,      0 )
       call cfile ( lunew, newname, nlnewt )
c
c      Write the dump file.
c
       if (idump .eq. 1) call dump
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('COMP     = ',a)
2030   format(a,'    = -c -o $*.o ',a)
2040   format(a,'    = -Wf"-l $*.l -b $*.o" ',a)
2070   format('EXE      = ',a)
2080   format('DIR      = ',a)
2090   format('LOAD     = ',a)
2110   format('LOPT     = -o $(EXE) ',a)
2120   format('LIBS     = ',a)
2130   format('all: $(EXE)',/
     1       ,'$(OBJ1): %.o : %.f',/,a1,'$(COMP) $(COPT1) $*.f')
2140   format('$(OBJ2): %.o : %.f',/,a1,'$(COMP) $(COPT2) $*.f')
2160   format('$(EXE): $(OBJ1) $(OBJ2)',/,a1
     1       ,'$(LOAD) $(LOPT) $(OBJ1) $(OBJ2) $(LIBS)')
2180   format('$(EXE): $(OBJ1)',/,a1,'$(LOAD) $(LOPT) $(OBJ1) $(LIBS)')
2190   format('PRECOM  : ',i4,' errors detected in the PRECOMpiled '
     1       ,'file.')
2200   format('PRECOM  : Updating of module files is incomplete.')
2210   format('PRECOM  : Scan file "',a17,'" (columns 16-20) for '
     1       ,'pattern: **** ERROR.')
2220   format('PRECOM  : Scan file "',a14,'..." (columns 16-20) for '
     1       ,'pattern: **** ERROR.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                P R E C O M                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 S P L I T                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine split
c
c    dac:editor.split <----------------- splits up a file into its decks
c                                                             july, 1989
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 6 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c
c  PURPOSE:  This subroutine splits the input file into separate files
c  for each deck.  If EDITOR *dk or *cd statements define the decks,
c  the files will be split by decks.  If there are no EDITOR *dk or *cd
c  statements, the files will be split according to module statements
c  ("program", "subroutine", "function", "blockdata").  Each file is
c  written to the subdirectory "branch".
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS
c    OFILE
c    COLLECT
c    RFILE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   char1
       character*16  filename
       character*64  infile
       integer       cdordk  , lfirst  , llast   , nmax    , n
     1             , i       , imin    , imax    , j
c
c      External statements
c
       external      ofile   , collect , rfile
c
c-----------------------------------------------------------------------
c
c      Open disc file "oldname".
c
       call ofile ( luold, oldname, 'old     ' )
c
c      Collect limits and names of each deck.
c
       call collect
c
c      Read next portion of "oldname" into "oldfile".
c
       lfirst = 1
       leof   = lreadall
10     continue
       if (.not. leof) then
         nlold = 0
         call rfile ( luold, oldname, 1, lfirst, llast, 0, leof )
       endif
c
c      Write each deck to a separate file on disc.  When cdordk = 1 (2),
c  "common" ("ordinary") decks are written to disc.
c
       cdordk = 1
20     continue
       if (ext .eq. '        ') ext = '.src    '
       if (cdordk .eq. 1) nmax = ncd
       if (cdordk .eq. 2) nmax = ndk
       do 60 n=1,nmax
c
c      Establish limits of deck, and determine if the deck is in the
c  current portion of the disc file "oldname" stored in "oldfile".
c
         if (cdordk .eq. 1) then
           imin = icdbeg(n)
           imax = icdend(n)
         endif
         if (cdordk .eq. 2) then
           imin = idkbeg(n)
           imax = idkend(n)
         endif
         if ( (imin .lt. lfirst) .or. (imin .gt. nloldt) ) go to 60
c
c  Create "filename" for the common deck by appending "ext" after the
c  name of the deck.
c
         filename = blank16
         do 30 j=1,9
           if (cdordk .eq. 1) char1 = cdnam(n)(j:j)
           if (cdordk .eq. 2) char1 = dknam(n)(j:j)
           if (char1 .eq. ' ') go to 40
30       continue
40       continue
         if (cdordk .eq. 1) filename(1:j-1) = cdnam(n)(1:j-1)
         if (cdordk .eq. 2) filename(1:j-1) = dknam(n)(1:j-1)
         filename(j:j+7) = ext
c
c  Write deck to file "filename" in directory "branch" on disc.
c
         infile                     = blank64
         infile(       1:       32) = branch
         infile(ncharb+1:ncharb+16) = filename
         if (ibanner .eq. 1) write (    6, 2010) infile
         if (idump   .eq. 1) write (ludmp, 2010) infile
c
c  From DAC, 3/11: Commented out are lines that have been useful in
c  other OS/compilers.  I still need to test this with the various
c  compilers edit22 is supposed to support.
c
         open ( lunew, file=infile, status='unknown' )
ccc  1               , fileopt='buffer=1024000' )
ccc      open ( lunew, file=infile, status='unknown'
ccc  1        , blocksize=1024000 )
c
c      Changes made by DAC October 2007:  adjustments made to imin and
c  imax necessary to resume reading oldfile at the correct place.  This
c  may be an issue in other "jobs" as well?
c
         imin = imin - lfirst + 1
         imax = imax - lfirst + 1
         do 50 i=imin,imax
           write (lunew, 2020) oldfile(i)
50       continue
         close ( lunew )
c
c  Go on to next deck.
c
60     continue
       if (cdordk .eq. 1) then
         cdordk = 2
         go to 20
       endif
c
c      If end of file has been reached in "oldname", return to EDITOR.
c  Otherwise, read next portion of "oldname" into "oldfile".
c
       if (leof) goto 999
       lfirst = nloldt + 1
       go to 10
c
999    continue
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('SPLIT   : Creating new file ',a52)
2020   format(a80)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 S P L I T                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                T A R G E T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine target
c
c    dac:editor.target <----------------------------- resequence targets
c                                                          october, 1988
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 2 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1: February 1991 by David Clarke; Reworked to allow
c                partial reads of input file.
c    modified 2: October 2003 by Alexander Men'shchikov; corrected
c                conversions of DO-ENDDO loops to targeted loops.
c
c  PURPOSE:  This subroutine resequences all targets, including those
c  statements with integers in the first five columns and UNIX MPPL
c  "enddo"'s.  It associates each target with an origin, which include
c  "do" (FORTRAN and MPPL), "goto" (or "go to", both ordinary and
c  computed), arithmetic "if", "read" (and "decode"), and "write" (and
c  "encode").  The program is capable of identifying other origins in a
c  "read" statement other than the origin for the format statement (eg.
c  "err=100", "end=200"), and it treats these as "goto" statements.  The
c  program can identify origins embedded in "open" statements (eg.
c  "err=100", "end=200") and treats these as "goto" statements.
c  Finally, the program will find origins at the end of "if" statements.
c  The origins and targets are matched, and the targets are resequenced
c  according to origin type.  The default is to have "do" and "goto"
c  targets range between 10 and 990, "read" targets range between 1010
c  and 1990, and "write" targets range between 2010 and 2990, with each
c  targets incrementing by 10.
c      The program will apply a uniform indentation scheme, if desired,
c  so that do loops are indented by two columns.  "if then - else -
c  endif" structures are also recognised, and indented accordingly.
c  If the source code is indented, then all "do" and "goto" targets are
c  forced to end on a "continue" statement.  Nested "do" loops are not
c  permitted to end on the same continuation statement.  Thus,
c  additional "continue" statements are inserted where needed.
c      The program searches for targets and origins in the input source
c  code one subroutine at a time.  Thus, the first pass (search for
c  targets) and the second pass (rewriting the source code) are done
c  for every subroutine encountered.  The end of a subroutine is
c  identified by an "end" statement, which the program can distinguish
c  from "end if"'s and "end do"'s.
c      Finally, TARGET will resequence the source code alphabetically
c  according to both group name and deck name, if desired.
c
c  WARNINGS:
c
c  1. TARGET will break up a line into two lines if indentation or
c  replacing an origin causes the line to exceed 72 characters.  The
c  break is done right at the 73rd character, and may result in a word
c  being divided in two.  This may or may not cause a problem during
c  compilation.  EDITOR uses a '&' as the continuation character, so
c  one can do a global search for a '&' in column 6 and make any
c  adjustment that may be necessary.
c
c  2.  Although some care has been taken to allow the same target to
c  be used in mutually exclusive segments of coding (as defined by the
c  EDITOR *if define and *if alias commands), it is still advisable,
c  wherever possible, not to use the same targets anywhere at all.
c  Even if EDITOR is able to keep straight all the possible regions
c  of coding that are mutually exclusive, it will possibly screw up
c  the indentation, and the ordering of the targets will not always
c  be sequential.  If it is necessary to use the same target in
c  mutually exclusive portions of coding, make the *if def - *el -
c  *ei structures simple.  Avoid nesting, and complicated logical
c  expressions using .and. and .or..  Ignoring this advise will only
c  tempt fate, and the logic of the code could be compromised.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    RFILE
c    GETWRD
c    ADDELT
c    ITOC
c    ERRSET
c    LIST
c    GETCHR
c    DUMP
c    ERRMSG
c    COLLECT
c    CFILE
c    WFILE
c    CAPITALS
c    OVERFLOW
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   char1
       character*2   char2
       character*3   char3
       character*16  word    , oldword , wrd1    , wrd2    , wrd3
     1             , wrd4    , subnam  , subnm1  , subnm2  , newsw
     2             , frstwrd , subname , grpnam
       character*32  word32
       character*128 line    , tmpline
       integer       i       , j       , nerrt   , ind0    , indinc
     1             , lfirst  , llast   , nlines  , jbeg    , jend
     2             , jran    , next    , nif     , nsw     , nal1
     3             , nal2    , imin    , idef    , ndef    , isw
     4             , iswold  , ial1    , ial2    , match   , iwrd
     5             , k       , jopen   , jclose  , iopen   , iclose
     6             , idummy  , i1      , i2      , iadd    , kmin
     7             , l       , lnerr1j , ierr1j  , itrg    , iorg
     8             , ndo     , nre     , nwr     , incnew  , index
     9             , ndomax  , nremax  , nwrmax  , ido     , ire
       integer       iwr     , itype   , ierr    , jdiff   , itt
     1             , iot     , j1      , j2      , j3      , j4
     2             , j5      , j6      , j7      , j8      , icont
     3             , int1    , idk     , icd     , ndeck   , lmin
     4             , lstrtj  , lfnshj  , ideck   , ifirst  , j0
     5             , igp     , no1     , no2
c
       character*16  keywrd  (  20), keywrd2 (  10), edcmd   (  20)
       character*32  fulnam  (2*k4)
       integer       lstrt   (2*k4), lfnsh   (2*k4)
       integer       incalt  (   4), ind1    (  10)
c
       integer       indsw   (  10,  10), oorg(1000), ttrg(1000)
c
       common / ccom001  /
     1               frstwrd , subname
c
c      External statements
c
       external      ofile   , rfile   , getwrd  , addelt  , itoc
     1             , errset  , list    , getchr  , dump    , errmsg
     2             , collect , cfile   , wfile   , capitals, overflow
c
c      Data statements.  PRINT is not supported?.. (A.M.)
c
       data          keywrd
     1   / 'DO              ', 'GOTO            ', 'GO              '
     2   , 'READ            ', 'WRITE           ', 'OPEN            '
     3   , 'IF              ', 'END             ', 'THEN            '
     4   , 'ELSE            ', 'ENCODE          ', 'DECODE          '
     5   , '                ', '                ', '                '
     6   , '                ', '                ', 'ENDIF           '
     7   , 'ENDDO           ', 'ERR             ' /
       data          keywrd2
     1   / 'PROGRAM         ', 'SUBROUTINE      ', 'FUNCTION        '
     2   , 'BLOCKDATA       ', 'BLOCK           ', 'END             '
     3   , 'REAL            ', 'INTEGER         ', 'LOGICAL         '
     4   , 'CHARACTER       ' /
       data          edcmd
     1   / '*if             ', '*el             ', '*else           '
     2   , '*ei             ', '*endif          ', 'def             '
     3   , 'define          ', '-def            ', '-define         '
     4   , 'al              ', 'alias           ', '                '
     5   , '                ', '                ', '                '
     6   , '.not.           ', '.and.           ', '.or.            '
     7   , '.eq.            ', '.ne.            ' /
       data          incalt   / 1, 2, 5, 10 /
c
c-----------------------------------------------------------------------
c
       nerrt  = 0
       ind0   = indent
       indinc = 2
c
c      Open disc file "oldname".
c
       call ofile ( luold, oldname, 'old     ' )
c
c      Collect all deck names and the line numbers where they begin and
c  end.
c
       call collect
       leof = lreadall
c
c      If "ialpha" = 1 and "lreadall" = .false., then the retargeted
c  file will have to be stored in a temporary disc file which will be
c  read when it is time to alphabetise the file.  Thus, store the
c  desired value of "newname" in "tmpname", and then reset "newname".
c
       if ( (ialpha .eq. 1) .and. (.not. lreadall) ) then
         tmpname = newname
         newname = 'target.tmp'
       endif
c
c      Open disc file "newname".
c
       call ofile ( lunew, newname, 'unknown ' )
c
       lfirst = 1
10     continue
       if (.not. leof) then
         nlold  = 0
         call rfile ( luold, oldname, 1, lfirst, llast, 0, leof )
       endif
       nlines = 0
       nlnew  = 0
c
15     continue
c
c      Reset variables.
c
       do 20 i=1,2*ismax
         fulnam(i) = blank32
         lstrt (i) = 0
         lfnsh (i) = 0
20     continue
       do 25 i=1,itmax
         lntarg(i) = 0
         iorig (i) = 0
         ittype(i) = 0
         mtarg (i) = 0
         targ  (i) = blank16
25     continue
       do 35 i=1,idmax
         envir1(i) = 'tf'
         swtch2(i) = blank16
         do 30 j=1,itmax
           envir2(j,i) = 'tf'
30       continue
35     continue
       do 40 i=1,iamax
         alias1(i) = blank16
         alias2(i) = blank16
40     continue
       do 45 i=1,iomax
         lnorig(i) = 0
         itarg (i) = 0
         jstrt (i) = 0
         jfnsh (i) = 0
         iotype(i) = 0
         orig  (i) = blank16
45     continue
       do 50 i=1,iemax
         ierr1 (i) = 0
         lnerr1(i) = 0
50     continue
       indent  = ind0 - 1
       do 55 i=1,10
         ind1(i) = indent
55     continue
       next    = 0
       ntarg   = 0
       norig   = 0
       nerr1   = 0
       nif     = 0
       nsw     = 0
       nal1    = 0
       nal2    = 0
       imin    = nlines + 1
 
       no1 = 1
       no2 = 0
c
c      The first pass.
c
       do 200 i=imin,nlold
         line   = oldfile(i)
         nlines = nlines + 1
         char1  = line(1:1)
c
c      If line is a comment, skip immediately on to next line.
c
         if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') ) go to 200
c
c      If line is an EDITOR command, then mutually exclusive sections
c  of coding need to be identified for proper retargeting.
c
         if (char1 .eq. '*') then
           jbeg = 1
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', wrd1 )
c
c      Peel off last character if it is an integer between 0 and 9
c  (this allows HISTORAN *if0, etc. commands to be interpreted).
c
           char1 = wrd1(jran:jran)
           if ( (char1 .ge. '0') .and. (char1 .le. '9') ) then
             wrd2 = wrd1
             wrd1 = blank16
             wrd1(1:jran-1) = wrd2(1:jran-1)
           endif
           if (wrd1 .eq. edcmd(1)) then
c
c      An *if statement.
c
             nif  = min0 ( 10, nif + 1 )
             do 60 idef=1,10
               indsw (nif, idef) = 0
60           continue
             ndef = 0
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', wrd2 )
             if ( (wrd2 .eq. edcmd(6)) .or. (wrd2 .eq. edcmd(7)) .or.
     1            (wrd2 .eq. edcmd(8)) .or. (wrd2 .eq. edcmd(9)) ) then
c
c      An *if define or an *if -define statement.
c
               if ( (wrd2.eq.edcmd(6)) .or. (wrd2.eq.edcmd(7)) ) then
                 char2 = 'tt'
               else
                 char2 = 'ff'
               endif
               wrd4  = blank16
               newsw = blank16
65             continue
               jbeg = jend + 1
               jend = nchar
               next = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', wrd3 )
               if (wrd3 .eq. blank16) go to 200
               if (wrd3 .eq. edcmd(16)) then
                 if ( (wrd2.eq.edcmd(6)) .or. (wrd2.eq.edcmd(7)) ) then
                   char2 = 'ff'
                 else
                   char2 = 'tt'
                 endif
                 go to 65
               endif
               call addelt ( wrd3, swtch2, isw, nsw )
               ndef = ndef + 1
               indsw (nif, ndef) = isw
               if (wrd4 .eq. edcmd(18)) then
                 envir1(isw) = 'tf'
                 call itoc ( isw, word, 1 )
                 if (isw .gt. iswold) then
                   newsw(6:8) = word(1:3)
                 else
                   newsw(1:3) = word(1:3)
                 endif
                 call addelt ( newsw, swtch2, isw, nsw )
                 ndef = ndef + 1
                 indsw (nif, ndef) = isw
               endif
               envir1(isw) = char2
               jbeg = jend + 1
               jend = nchar
               next = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', wrd4 )
               if (wrd4 .eq. edcmd(18)) then
                 iswold = isw
                 envir1(isw) = 'tf'
                 call itoc ( isw, word, 1 )
                 newsw(1:3) = word(1:3)
                 newsw(4:5) = 'or'
                 newsw(6:8) = word(1:3)
                 go to 65
               endif
               if (wrd4 .eq. edcmd(17)) go to 65
               go to 200
             endif
             if ( (wrd2 .eq. edcmd(9)) .or. (wrd2 .eq. edcmd(10)) ) then
c
c      An *if alias statement.
c
               jbeg = jend + 1
               jend = nchar
               next = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.'
     1                     , subnm1 )
               if (subnm1 .eq. blank16) go to 200
               call addelt ( subnm1, alias1, ial1, nal1 )
               call itoc ( ial1, wrd3, 1 )
               jbeg = jend + 1
               jend = nchar
               next = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', word )
               if ( (word .ne. edcmd(19)) .and. (word .ne. edcmd(20)) )
     1           go to 200
               if (word .eq. edcmd(19)) then
                 char2 = 'tt'
               else
                 char2 = 'ff'
               endif
               jbeg = jend + 1
               jend = nchar
               next = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.'
     1                     , subnm2 )
               if (subnm2 .eq. blank16) go to 200
               call addelt ( subnm2, alias2, ial2, nal2 )
               call itoc ( ial2, wrd4, 1 )
               newsw = blank16
               if (ial2 .gt. ial1) then
                 newsw(1:3) = wrd3(1:3)
                 newsw(6:8) = wrd4(1:3)
               else
                 newsw(6:8) = wrd3(1:3)
                 newsw(1:3) = wrd4(1:3)
               endif
               newsw(4:5) = 'eq'
               call addelt ( newsw, swtch2, isw, nsw )
               envir1 (isw) = char2
               ndef = ndef + 1
               indsw (nif, ndef) = isw
               go to 200
             endif
             go to 200
           endif
           if ( (wrd1 .eq. edcmd(2)) .or. (wrd1 .eq. edcmd(3)) ) then
c
c      An *else statement.  All values of "envir1" that were set by the
c  previous *if define or *if alias (indices of affected values of
c  "envir1" are stored in "indsw (nif, idef=1,ndef)") are reversed.
c  Thus, "tt" -> "ff", "ff" -> "tt", and "tf" -> "tf".
c
             do 70 idef=1,ndef
               isw   = indsw (nif, idef)
               char2 = envir1(isw)
               if (char2 .eq. 'tt') envir1 (isw) = 'ff'
               if (char2 .eq. 'ff') envir1 (isw) = 'tt'
70           continue
             go to 200
           endif
           if ( (wrd1 .eq. edcmd(4)) .or. (wrd1 .eq. edcmd(5)) ) then
c
c      An *endif statement.  All values of "envir1" that were set by
c  the previous *if define or *if alias are reset to "tf".
c
             if (nif .gt. 0) then
               do 75 idef=1,ndef
                 isw = indsw (nif, idef)
                 envir1(isw) = 'tf'
75             continue
               nif = max0 ( 1, nif - 1 )
             endif
             go to 200
           endif
           if (wrd1(1:1) .eq. '*') then
c
c      An EDITOR comment line has been found.  Go on to next line.
c
             go to 200
           endif
c
         endif
c
c      If line is a continuation line, it has already been scanned.
c  Go on to next line.
c
         char1  = line(6:6)
         if (char1 .ne. ' ') go to 200
c
c      For purposes of the dump file, retain current subroutine or
c  program name.
c
         next = 0
         jbeg = 7
         jend = nchar
         call getwrd ( i, 1, next, jbeg, jend, jran, ' *', word )
         call capitals ( word )
         match = 1
         do 80 iwrd=1,10
           if (word .eq. keywrd2(iwrd)) go to 85
80       continue
85       continue
         if ( (iwrd .ge.  1) .and. (iwrd .le.  4) ) match = 2
         if   (iwrd .eq.  5)                        match = 3
         if ( (iwrd .ge.  7) .and. (iwrd .le. 10) ) match = 4
c
         go to (100, 90, 90, 90) match
c
90       continue
         if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
         endif
95       continue
         jbeg = jend + 1
         jend = 0
         call getwrd ( i, 1, next, jbeg, jend, jran, ' (', word )
         if (match .eq. 2) then
           subname = word
           go to 200
         endif
         if (match .eq. 3) then
           match = 2
           go to 95
         endif
         if (match .eq. 4) then
           call capitals ( word )
           if (word .eq. keywrd2(3)) then
             match = 2
             go to 95
           endif
         endif
c
100      continue
c
c      Determine if line is a target.  If so, store line number (lntarg)
c  and target number (targ).
c
         if (line(1:5) .eq. '     ') go to 110
         next = 0
         jbeg = 1
         jend = 5
         call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
         char1 = word(1:1)
         if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) then
           call errset ( i+next, 35, 1 )
           if (nerr1 .ge. iemax) go to 205
           go to 200
         endif
         ntarg = ntarg + 1
         if (ntarg .gt. itmax) then
           call errset ( i+next, 36, 1 )
           go to 205
         endif
         targ  (ntarg) = word
         lntarg(ntarg) = i
         do 105 isw=1,idmax
           envir2 (ntarg, isw) = envir1 (isw)
105      continue
110      continue
c
c      If "do-enddo's" are to be replaced by "targeted do's", determine
c  if statement is an "enddo" or an "end do".  If so, store line number
c  in "lntarg" and the enddo target label in "targ".
c
         if (irepl .eq. 0) go to 115
         next = 0
         jbeg = 7
         jend = nchar
         call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
         call capitals ( word )
         if ( (word .ne. keywrd(8)) .and. (word .ne. keywrd(19)) )
     1     go to 115
         if (word .eq. keywrd(8)) then
           next = 0
           jbeg = jend + 1
           jend = nchar
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           call capitals ( word )
           if (word .ne. keywrd(1)) go to 115
         endif
         ntarg = ntarg + 1
         if (ntarg .gt. itmax) then
           call errset ( i+next, 36, 1 )
           go to 205
         endif
         next = 0
         jbeg = jend + 1
         jend = 0
         call getwrd ( i, 1, next, jbeg, jend, jran, ' (=', word )
         targ  (ntarg) = word
         ittype(ntarg) = 19
         lntarg(ntarg) = i
c
c      Changes by A.M. (October 2003).
c      DO-ENDDO pairs were not identified correctly.
c      Find the origin that is the closest to the target just found:
c
         if (norig .ge. no1) then
           do j=no1,norig
             if (lnorig(j) .lt. lntarg(ntarg)) no2 = j
           enddo
           no1 = no2 + 1
         endif
         do j=no2,1,-1
           if (orig(j) .ne. '        ' .and. iotype(j) .eq. 1) then
             oorg(j    ) = lnorig(j)
             ttrg(ntarg) = lnorig(j)
             no2 = j - 1
             goto 114
           endif
         enddo
114      continue
c
c      End of changes by A.M.
c
115      continue
c
c      If indentation is to be imposed, determine if target is an
c  "endif".
c
         if (ind0 .eq. 0) go to 120
         next = 0
         jbeg = 7
         jend = 0
         call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
         call capitals ( word )
         if ( (word .ne. keywrd(8)) .and. (word .ne. keywrd(18)) )
     1     go to 120
         if (word .eq. keywrd(8)) then
           next = 0
           jbeg = jend + 1
           jend = nchar
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           call capitals ( word )
           if (word .ne. keywrd(7)) go to 120
           jbeg = jend + 1
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           if (word .ne. blank16) then
             call errset ( i+next, 37, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
         endif
         ntarg = ntarg + 1
         if (ntarg .gt. itmax) then
           call errset ( i+next, 36, 1 )
           go to 205
         endif
         ittype(ntarg) = 18
         lntarg(ntarg) = i
120      continue
c
c      Determine if statement on line is an origin for a target.  If so,
c  store the type of origin (iotype), the line number (lnorig), the
c  origin number (orig), and the beginning (jstrt) and ending (jfnsh)
c  positions of the origin label in the line.
c
         next = 0
         jbeg = 7
         jend = nchar
         call getwrd ( i, 1, next, jbeg, jend, jran, ' (', word )
125      continue
         call capitals ( word )
         match = 0
         do 130 k=1,20
           if ( (word .ne. blank16) .and. (word .eq. keywrd(k)) )
     1       match = k
130      continue
         if (match .eq. 11) match = 5
         if (match .eq. 12) match = 4
         go to (135, 150, 150, 160, 160, 170, 180, 190, 195, 195) match
         go to 200
c
c      Origin is a "do" statement.
c
135      continue
         jbeg = jend + 1
         jend = 0
         call getwrd ( i, 1, next, jbeg, jend, jran, ' =(', word )
         if (word .eq. blank16) then
           call errset ( i+next, 38, 1 )
           if (nerr1 .ge. iemax) go to 205
           go to 200
         endif
         if (irepl .eq. 1) go to 140
         char1 = word(1:1)
         if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) then
           call errset ( i+next, 38, 1 )
           if (nerr1 .ge. iemax) go to 205
           go to 200
         endif
140      continue
         norig = norig + 1
         if (norig .gt. iomax) then
           call errset ( i+next, 39, 1 )
           go to 205
         endif
         lnorig(norig) = i + next
         orig  (norig) = word
         iotype(norig) = match
         jstrt (norig) = jbeg
         jfnsh (norig) = jend
         do 145 isw=1,idmax
           envir3 (norig, isw) = envir1 (isw)
145      continue
         go to 200
c
c      Origin is a "goto" or a "go to" statement.
c
150      continue
         if (match .eq. 3) then
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' (', word )
           call capitals ( word )
           if (word .ne. 'TO              ') then
             call errset ( i+next, 37, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
         endif
         jopen = jend + 1
         iopen = i + next
         call list ( i, i, 1, jopen, jclose, iopen, iclose )
         if (nerr1 .ge. iemax) go to 205
         ifirst = 1
         if (jclose .gt. 0) then
           next = iopen - i
155        continue
           jbeg = jend + 1
           jend = 0
           if (next .eq. iclose-i) jend = jclose
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()', word )
           if (word .eq. blank16) then
             if (ifirst .eq. 1) call errset ( i+next, 37, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
           ifirst = 0
           char1 = word(1:1)
           if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) then
             call errset ( i+next, 38, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
           norig = norig + 1
           if (norig .gt. iomax) then
             call errset ( i+next, 39, 1 )
             go to 205
           endif
           lnorig(norig) = i + next
           orig  (norig) = word
           iotype(norig) = match
           jstrt (norig) = jbeg
           jfnsh (norig) = jend
           go to 155
         else
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           char1 = word(1:1)
           if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) then
             call errset ( i+next, 38, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
           norig = norig + 1
           if (norig .gt. iomax) then
             call errset ( i+next, 39, 1 )
             go to 205
           endif
           lnorig(norig) = i + next
           orig  (norig) = word
           iotype(norig) = match
           jstrt (norig) = jbeg
           jfnsh (norig) = jend
         endif
         go to 200
c
c      Origin is either a "read" or a "write" statement.  The now
c  obsolete "decode" and "encode" statements are treated as "read"
c  and "write" statements respectively.
c
160      continue
         jopen = jend + 1
         iopen = i + next
         call list ( i, i, 1, jopen, jclose, iopen, iclose )
         if (nerr1 .ge. iemax) go to 205
         if (jclose .gt. 0) then
           next = iopen - i
           jbeg = jend + 1
           jend = 0
           if (next .eq. iclose-i) jend = jclose
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()=', word )
           if (word .eq. blank16) then
             call errset ( i+next, 37, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
165        continue
           jbeg = jend + 1
           call getchr ( line, jbeg, char1, 1 )
           if (char1 .eq. '(') then
             iopen = i + next
             call list ( i, i, 1, jbeg, jend, iopen, idummy)
           endif
           jbeg = jend + 1
           jend = 0
           if (next .eq. iclose-i) jend = jclose
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()=', word )
           if (word .eq. blank16) go to 200
           call capitals ( word )
           char1 = word(1:1)
           if (char1 .eq. '*') go to 200
           oldword = blank16
           if ( (word .eq. keywrd(8)) .or. (word .eq. keywrd(20)) ) then
             oldword = word
             jbeg = jend + 1
             jend = 0
             if (next .eq. iclose-i) jend = jclose
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,)=', word )
             char1 = word(1:1)
             if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) then
               call errset ( i+next, 38, 1 )
               if (nerr1 .ge. iemax) go to 205
               go to 200
             endif
           endif
           if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) go to 200
           norig = norig + 1
           if (norig .gt. iomax) then
             call errset ( i+next, 39, 1 )
             go to 205
           endif
           lnorig(norig) = i + next
           orig  (norig) = word
           iotype(norig) = match
           if (oldword .eq. keywrd( 8)) iotype(norig) =  8
           if (oldword .eq. keywrd(20)) iotype(norig) = 20
           jstrt (norig) = jbeg
           jfnsh (norig) = jend
           go to 165
         else
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,(=.', word )
           if (word .eq. blank16) then
             call errset ( i+next, 37, 1 )
             if (nerr1 .ge. iemax) go to 205
           endif
           go to 200
         endif
c
c      An origin may be embedded in an "open" statement.
c
170      continue
         jopen = jend + 1
         iopen = i + next
         call list ( i, i, 1, jopen, jclose, iopen, iclose )
         if (nerr1 .ge. iemax) go to 205
         ifirst = 1
         if (jclose .gt. 0) then
           next = iopen - i
175        continue
           jbeg = jend + 1
           jend = 0
           if (next .eq. iclose-i) jend = jclose
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()=', word )
           if (word .eq. blank16) then
             if (ifirst .eq. 1) call errset ( i+next, 37, 1 )
             if (nerr1 .ge. iemax) go to 205
             go to 200
           endif
           call capitals ( word )
           ifirst = 0
           if ( (word .eq. keywrd(8)) .or. (word .eq. keywrd(20)) ) then
             oldword = word
             jbeg = jend + 1
             jend = 0
             if (next .eq. iclose-i) jend = jclose
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,)=', word )
             char1 = word(1:1)
             if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) then
               call errset ( i+next, 38, 1 )
               if (nerr1 .ge. iemax) go to 205
               go to 200
             endif
             norig = norig + 1
             if (norig .gt. iomax) then
               call errset ( i+next, 39, 1 )
               go to 205
             endif
             lnorig(norig) = i + next
             orig  (norig) = word
             if (oldword .eq. keywrd( 8)) iotype(norig) =  8
             if (oldword .eq. keywrd(20)) iotype(norig) = 20
             jstrt (norig) = jbeg
             jfnsh (norig) = jend
           endif
           go to 175
         else
           call errset ( i+next, 37, 1 )
           if (nerr1 .ge. iemax) go to 205
           go to 200
         endif
c
c      An origin may be embedded in an "if" statement (ie, either as an
c  "arithmetic if" or part of a "logical if").
c
180      continue
         jopen = jend + 1
         iopen = i + next
         call list ( i, i, 1, jopen, jclose, iopen, iclose )
         if (nerr1 .ge. iemax) go to 205
         if (jclose .eq. 0) go to 200
         next = iclose - i
         jbeg = jclose + 1
         jend = 0
         call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()', word )
         char1 = word(1:1)
         if ( (char1 .ge. '0') .and. (char1 .le. '9') ) then
185        continue
           norig = norig + 1
           if (norig .gt. iomax) then
             call errset ( i+next, 39, 1 )
             go to 205
           endif
           lnorig(norig) = i + next
           orig  (norig) = word
           iotype(norig) = 2
           jstrt (norig) = jbeg
           jfnsh (norig) = jend
           jbeg          = jend + 1
           jend          = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()', word )
           if (word .eq. blank16) go to 200
           go to 185
         else
           go to 125
         endif
c
c      An "end" statement has been encountered.
c
190      continue
         jbeg = jend + 1
         jend = nchar
         call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
         if (word .eq. blank16) go to 205
         go to 200
c
c      An "if-then" or an "else" statement has been encountered.
c
195      continue
         if (ind0 .eq. 0) go to 200
         norig = norig + 1
         if (norig .gt. iomax) then
           call errset ( i+next, 39, 1 )
           go to 205
         endif
         lnorig(norig) = i + next
         iotype(norig) = match
c
200    continue
205    continue
c
c      If desired, diagnostic dumps are printed in "output".
c
       if (idump .eq. 1) then
         frstwrd = 'ORIGINAL        '
         call dump
       endif
c
c      Link matching targets with "mtarg".
c
       do 220 i=1,ntarg-1
         char1 = targ(i)(1:1)
         if ( (char1 .ge. '0') .and. (char1 .le. '9') ) then
           do 210 j=i+1,ntarg
             if (targ(i) .eq. targ(j)) then
               mtarg(i) = j
               go to 215
             endif
210        continue
215        continue
         endif
220    continue
c
c      Issue error messages for repeated targets that are not mutually
c  excluded by EDITOR *if def or *if al statements and are not MPPL
c  "enddo"'s.
c
       do 250 i=1,ntarg-1
         j = mtarg(i)
         if (j .ne. 0) then
           i1 = i
225        continue
           i2 = mtarg(i1)
230        continue
           if (i2 .ne. 0) then
             do 235 isw=1,idmax
               if ( (envir2(i1,isw)(1:1).ne.envir2(i2,isw)(1:1)) .and.
     1              (envir2(i1,isw)(2:2).ne.envir2(i2,isw)(2:2)) )
     2           go to 245
235          continue
             mtarg(i) = 0
             call errset ( lntarg(i), 40, 1 )
240          continue
             call errset ( lntarg(j), 40, 1 )
             k = mtarg(j)
             if (k .eq. 0) go to 250
             mtarg(j) = 0
             j = k
             go to 240
245          continue
             i2 = mtarg(i2)
             go to 230
           else
             i1 = mtarg(i1)
             if (i1 .ne. 0) go to 225
           endif
         endif
250    continue
c
c      Match origin list with target list.
c
       do 265 i=1,norig
         if ( (iotype(i) .eq. 9) .or. (iotype(i) .eq. 10) ) go to 265
         char1 = orig(i)(1:1)
 
         if ( (char1 .ge. '0') .and. (char1 .le. '9') ) then
           do 255 j=1,ntarg
             if ( (targ(j) .eq. orig(i)) .and. (mtarg(j) .eq. 0) ) then
               itarg(i) = j
               if (iorig(j) .ne. 0) then
                 if (iotype(iorig(j)) .eq. 1) go to 265
               endif
               iorig(j) = i
               go to 265
             endif
255        continue
           call errset ( lnorig(i), 41, 1 )
           if (nerr1 .ge. iemax) go to 300
         else
           do 260 j=1,ntarg
             if (lntarg(j) .gt. lnorig(i)) then
c
c       Change by A.M. (October 2003):
ccc               if ( (targ(j) .eq. orig(i)) .and.
               if ( (ttrg(j) .eq. oorg(i)) .and.
     1              (mtarg(j) .eq. 0) ) then
 
                 itarg(i) = j
                 if (iorig(j) .ne. 0) then
                   call errset ( lnorig(iorig(j)), 42, 1 )
                   if (nerr1 .ge. iemax) go to 300
                 endif
                 iorig(j) = i
                 go to 265
               endif
             endif
260        continue
         endif
265    continue
c
c      Set "iorig" for repeated targets ("mtarg" .ne. 0).
c
       do 270 i=ntarg-1,1,-1
         j = mtarg(i)
         if (j .ne. 0) iorig(i) = iorig(j)
270    continue
c
c      If uniform identation is to be imposed, then it is necessary to
c  have no nested do-loops with just one target.  Identify these, and
c  adjust the target lists.
c
       if (ind0 .eq. 0) go to 300
       do 295 i=norig,2,-1
         char1 = orig(i)(1:1)
         if ( (char1 .lt. '0') .or. (char1 .gt. '9') ) go to 295
         iadd = 0
         if ( (iotype(i) .eq. 1) .and.
     1        (lntarg(itarg(i)) .gt. lnorig(i)) ) then
           do 290 j=i-1,1,-1
             if ( (iotype(j) .eq. 1) .and.
     1            (itarg(j) .eq. itarg(i)) .and.
     2            (lntarg(itarg(j)) .gt. lnorig(j)) ) then
               do 275 isw=1,idmax
                 if ( (envir3(i,isw)(1:1) .ne. envir3(j,isw)(1:1)) .and.
     1                (envir3(i,isw)(2:2) .ne. envir3(j,isw)(2:2)) )
     2              go to 290
275            continue
               ntarg = ntarg + 1
               if (ntarg .gt. itmax) then
                 call errset ( lntarg(itarg(i)), 36, 1 )
                 go to 300
               endif
               iadd = iadd + 1
               kmin = itarg(i) + iadd
               do 285 k=ntarg-1,kmin,-1
                 lntarg(k+1) = lntarg(k)
                 ittype(k+1) = ittype(k)
                 targ  (k+1) = targ  (k)
                 iorig (k+1) = iorig (k)
                 do 280 l=1,norig
                   if (itarg(l) .eq. k) itarg(l) = k + 1
280              continue
285            continue
               lntarg(kmin) = lntarg(kmin-1)
               ittype(kmin) = ittype(kmin-1)
               targ  (kmin) = targ  (kmin-1)
               itarg (j   ) = itarg (j     ) + iadd
               iorig (itarg(j)) = j
             endif
290        continue
         endif
295    continue
300    continue
c
c      Reorder the error messages so that they are sequential according
c  to line number.
c
       do 310 i=1,nerr1-1
         do 305 j=1,nerr1-1
           if (lnerr1(j) .gt. lnerr1(j+1)) then
             lnerr1j     = lnerr1(j  )
             ierr1j      = ierr1 (j  )
             lnerr1(j  ) = lnerr1(j+1)
             ierr1 (j  ) = ierr1 (j+1)
             lnerr1(j+1) = lnerr1j
             ierr1 (j+1) = ierr1j
           endif
305      continue
310    continue
c
c      Flag target and origin line numbers if they are also an error
c  line number.
c
       itrg = 1
       iorg = 1
       do 325 i=1,nerr1
315      continue
         if (lntarg(itrg) .le. lnerr1(i)) then
           if ( (lntarg(itrg) .eq. lnerr1(i)) .and.
     1          (lntarg(itrg) .gt. 0) ) lntarg(itrg) = - lntarg(itrg)
           itrg = itrg + 1
           go to 315
         endif
320      continue
         if (lnorig(iorg) .le. lnerr1(i)) then
           if ( (lnorig(iorg) .eq. lnerr1(i)) .and.
     1          (lnorig(iorg) .gt. 0) ) lnorig(iorg) = - lnorig(iorg)
           iorg = iorg + 1
           go to 320
         endif
325    continue
c
       if (nerr1 .ge. iemax) go to 395
c
c      Determine if the user specified value of "inc" is too large
c  for the number of targets that need to be resequenced.
c
       ndo = 0
       nre = 0
       nwr = 0
       do 330 i=1,ntarg
         if ( (lntarg(i) .lt. 0) .or. (ittype(i) .eq. 18) .or.
     1        (mtarg (i) .ne. 0) ) go to 330
         if (iotype(iorig(i)) .le. 3 ) ndo = ndo + 1
         if (iotype(iorig(i)) .eq. 4 ) nre = nre + 1
         if (iotype(iorig(i)) .eq. 5 ) nwr = nwr + 1
330    continue
       incnew = inc
       index  = 5
335    continue
       ndomax = 1 + ifix ( float(ienddo - ibegdo) / float(incnew) )
       if (ndo .gt. ndomax) then
         index  = index - 1
         if (index .lt. 1) then
           call errset ( lntarg(i), 43, 1 )
           go to 385
         endif
         incnew = incalt(index)
         go to 335
       endif
340    continue
       nremax = 1 + ifix ( float(iendre - ibegre) / float(incnew) )
       if (nre .gt. nremax) then
         index  = index - 1
         if (index .lt. 1) then
           call errset ( lntarg(i), 44, 1 )
           go to 385
         endif
         incnew = incalt(index)
         go to 340
       endif
345    continue
       nwrmax = 1 + ifix ( float(iendwr - ibegwr) / float(incnew) )
       if (nwr .gt. nwrmax) then
         index  = index - 1
         if (index .lt. 1) then
           call errset ( lntarg(i), 45, 1 )
           go to 385
         endif
         incnew = incalt(index)
         go to 345
       endif
       if (inc .ne. incnew) write (6, 2010) subname, inc, incnew
c
c      Resequence target labels.  If there is an error associated with
c  the target, if the target is a FORTRAN "endif", or if "mtarg(i)"
c  .ne. 0 (the first n-1 of n repeated targets in mutually exclusive
c  segments of coding), do not resequence the target.
c
       ido = ibegdo
       ire = ibegre
       iwr = ibegwr
       do 375 i=1,ntarg
         if ( (lntarg(i) .lt. 0) .or. (ittype(i) .eq. 18) .or.
     1        (mtarg (i) .ne. 0) ) go to 375
         itype = 2
         if (iotype(iorig(i)) .eq. 1 ) itype = 1
         if (iotype(iorig(i)) .eq. 4 ) itype = 3
         if (iotype(iorig(i)) .eq. 5 ) itype = 4
         go to (350, 355, 360, 365) itype
c
c      "do" label.
c
350      continue
         char1 = targ(i)(1:1)
         if ( (char1 .ge. '0') .and. (char1 .le. '9') )
     1     ittype(i) = 1
         call itoc ( ido, word, 1 )
         ido = ido + incnew
         go to 370
c
c      "go to" label.
c
355      continue
         call itoc ( ido, word, 1 )
         ido = ido + incnew
         go to 370
c
c      "read" label.
c
360      continue
         call itoc ( ire, word, 1 )
         ire = ire + incnew
         go to 370
c
c      "write" label.
c
365      continue
         call itoc ( iwr, word, 1 )
         iwr = iwr + incnew
c
370      continue
         targ(i) = word
375    continue
c
c      Set the first n-1 occurances of an n-times repeated target to
c  the value of the nth occurance of the target, which was resequenced
c  above.
c
       do 380 i=ntarg-1,1,-1
         j = mtarg(i)
         if (j .ne. 0) then
           word      = targ  (j)
           targ  (i) = word
           ittype(i) = ittype(j)
         endif
380    continue
385    continue
c
c      Reassign origin labels.
c
       do 390 i=1,norig
         if ( (lnorig(i) .lt. 0) .or. (iotype(i) .eq. 9) .or.
     1        (iotype(i) .eq. 10) ) go to 390
         orig(i) = targ(itarg(i))
390    continue
395    continue
c
c      Reorder the error messages so that they are sequential according
c  to line number.
c
       do 405 i=1,nerr1-1
         do 400 j=1,nerr1-1
           if (lnerr1(j) .gt. lnerr1(j+1)) then
             lnerr1j     = lnerr1(j  )
             ierr1j      = ierr1 (j  )
             lnerr1(j  ) = lnerr1(j+1)
             ierr1 (j  ) = ierr1 (j+1)
             lnerr1(j+1) = lnerr1j
             ierr1 (j+1) = ierr1j
           endif
400      continue
405    continue
c
c      Second Pass.  Replace old origin and target labels with new
c  labels.
c
       iorg   = 1
       itrg   = 1
       ierr   = 1
       jdiff  = 0
       nif    = 0
       do 460 i=imin,nlines
         line = oldfile(i)
c
c      Deal with target lines.
c
         if (lntarg(itrg) .eq. i) then
           line(1:5) = targ(itrg)(1:5)
c
c      MPPL "enddo i" is replaced with a "continue".
c
           if (ittype(itrg) .eq. 19) then
             line       = blank128
             line(1: 5) = targ(itrg)(1:5)
             line(7:14) = 'continue'
             oldfile(i) = line
           endif
c
c      If uniform indentation is to be imposed, make sure that "go to"
c  and "do" targets land on "continue" statements, and that nested
c  "do loops" have as many targets as origins.  Indent the targets
c  accordingly.
c
           if (ind0 .eq. 0) go to 420
           itt  = ittype(itrg)
           iot  = iotype(iorig(itrg))
           if ( (iot .eq. 4) .or. (iot .eq. 5) ) go to 420
           jbeg = 7
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           call capitals ( word )
           if (word .ne. 'CONTINUE        ') then
             tmpline = blank128
             if (iot .eq. 1) then
               j1 = jbeg
               j2 = indent + 7
               j3 = min0 ( nchar, nchar - j2 + j1 )
               j4 = min0 ( nchar, nchar - j1 + j2 )
               tmpline(j2:j4) = line(j1:j3)
               nlnew = nlnew + 1
               if (nlnew .ge. ilmax) call overflow ( 4, 8 )
               newfile(nlnew) = tmpline
               do 410 j=7,icmax
                 line(j:j) = ' '
410            continue
               line(7:14) = 'continue'
             endif
             if ( (iot .eq. 2) .or. (iot .eq. 3) .or. (iot .eq. 8) .or.
     1            (iot .eq. 20) ) then
               tmpline(1:5) = line(1:5)
               tmpline(indent+7:indent+14) = 'continue'
               line(1:5) = '     '
               nlnew = nlnew + 1
               if (nlnew .ge. ilmax) call overflow ( 4, 8 )
               newfile(nlnew) = tmpline
             endif
           endif
           if (iot .eq. 1) then
415          continue
             if ( (lntarg(itrg+1) .eq. lntarg(itrg)) .and.
     1            (itrg .lt. ntarg) ) then
               tmpline = blank128
               indent  = max0 ( ind0 - 1, indent - indinc )
               tmpline(1:5) = targ(itrg)(1:5)
               tmpline(indent+7:indent+14) = 'continue'
               nlnew = nlnew + 1
               if (nlnew .ge. ilmax) call overflow ( 4, 8 )
               newfile(nlnew) = tmpline
               itrg = itrg + 1
               line(1:5) = targ(itrg)(1:5)
               go to 415
             endif
           endif
           if ( (itt .eq. 1 ) .or. (itt .eq. 18) .or.
     1          (itt .eq. 19) ) then
             indent = max0 ( ind0 - 1, indent - indinc )
           endif
420        continue
           itrg = itrg + 1
         endif
         if (lntarg(itrg) .eq. -i) itrg = itrg + 1
c
c      Deal with origin statements.  Origins such as "then" and "else"
c  have no numerical targets, and are used only for indentation
c  purposes.
c
         j0 = 0
         iot = iotype(iorg)
425      continue
 
         if ( (lnorig(iorg) .eq. i) .and. (iot .ne. 9) .and.
     1        (iot .ne. 10) ) then
           j1 = jstrt(iorg) + j0
           do 430 j=j1,icmax
             line(j:j) = ' '
430        continue
           line(j1:j1+7) = orig(iorg)(1:8)
           do 435 j=1,8
             if (orig(iorg)(j:j) .eq. ' ') go to 440
             j2 = j1 + j
435        continue
440        continue
           char1 = oldfile(i)(jstrt(iorg):jstrt(iorg))
           if ( (char1 .ge. '0') .and. (char1 .le. '9') ) then
             j3 = jfnsh(iorg) + 1
           else
             j3 = jstrt(iorg) - 1
           endif
           j4 = min0 ( icmax, icmax - j3 + j2 )
           j5 = min0 ( icmax, icmax - j2 + j3 )
           line(j2:j4) = oldfile(i)(j3:j5)
           j0 = j2 - j3
           iorg = iorg + 1
           go to 425
         endif
c
c      If no indentation is to be imposed, and the substitutions made
c  "line" longer than "nchar" characters (usually 72), then "line"
c  is broken up into two lines.  If ind0 .ne. 0, "line" will be divided
c  into two lines when indentation is imposed.
c
         if (ind0 .eq. 0) then
           j6 = icmax
           call getchr ( line, j6, char1, 2 )
           if (j6 .gt. nchar) then
             tmpline(1:nchar) = line(1:nchar)
             nlnew = nlnew + 1
             if (nlnew .ge. ilmax) call overflow ( 4, 8 )
             newfile(nlnew) = tmpline
             j7 = 7
             call getchr ( line, j7, char1, 1 )
             tmpline = blank128
             tmpline(6:6) = '&'
             j8 = j6 - nchar - 1 + j7
             tmpline(j7:j8) = line(nchar+1:j6)
             line = tmpline
           endif
         endif
         if (lnorig(iorg) .eq. -i) then
           iorg = iorg + 1
           go to 425
         endif
         if ( (lnorig(iorg) .eq. i) .and. (iot .eq. 9) )
     1     iorg = iorg + 1
         if ( (lnorig(iorg) .eq. i) .and. (iot .eq. 10) ) then
           if (ind0 .gt. 0) indent = max0 ( ind0 - 1, indent - indinc )
           iorg = iorg + 1
         endif
c
c      Resequence continuation characters
c
         char1 = oldfile(i)(1:1)
         if (ireseq .eq. 1) then
           if ( (oldfile(i)(6:6) .ne. ' ') .and.
     1          (oldfile(i)(1:5) .eq. '     ') ) then
             icont = icont + 1
             int1  = 10 * ifix (float(icont)/10. + 0.01)
             if (icont .eq. int1) icont = icont + 1
             call itoc ( icont, word, 2 )
             line(6:6) = word(16:16)
           else
             if ( (char1 .ne. 'c') .and. (char1 .ne. 'C') .and.
     1            (char1 .ne. '*') ) icont = 0
           endif
         endif
c
c      Indent line.
c
         if ( (lntarg(itrg-1) .eq. -i) .or.
     1        (lnorig(iorg-1) .eq. -i) ) go to 445
         if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') .or.
     1        (ind0  .eq.   0) ) go to 445
         if (char1 .eq. '*') then
           char3 = oldfile(i)(1:3)
           if (char3 .eq. '*if') then
             nif       = min0 ( 10, nif + 1 )
             ind1(nif) = indent
           endif
           if (char3 .eq. '*el') indent = ind1(nif)
           if ( (char3 .eq. '*en') .or. (char3 .eq. '*ei') )
     1       nif = max0 (  1, nif - 1 )
           go to 445
         endif
         tmpline = blank128
         tmpline(1:6) = line(1:6)
         j1 = 7
         call getchr ( line, j1, char1, 1 )
         if (char1 .eq. ' ') j1 = 7
         char1 = oldfile(i)(6:6)
         if (char1 .ne. ' ') then
           j2 = j1 + jdiff
         else
           j2 = indent + 7
           jdiff = j2 - j1
         endif
         j3 = min0 ( icmax, icmax - j2 + j1 )
         j4 = min0 ( icmax, icmax - j1 + j2 )
         tmpline(j2:j4) = line(j1:j3)
         line = tmpline
         j5   = icmax
         call getchr ( line, j5, char1, 2 )
         if (j5 .gt. nchar) then
           tmpline = blank128
           tmpline(1:nchar) = line(1:nchar)
           nlnew = nlnew + 1
           if (nlnew .ge. ilmax) call overflow ( 4, 8 )
           newfile(nlnew) = tmpline
           tmpline = blank128
           tmpline(6:6) = '&'
           j6 = j5 - nchar - 1 + j2
           tmpline(j2:j6) = line(nchar+1:j5)
           line = tmpline
         endif
445      continue
c
c      Store line to "newfile".
c
         nlnew = nlnew + 1
         if (nlnew .ge. ilmax) call overflow ( 4, 8 )
         newfile(nlnew) = line
c
c      Adjust "indent" if ind0 > 1, and if line is an origin for a
c  "do loop" or an "if then".
c
         if ( (lntarg(itrg-1) .eq. -i) .or.
     1        (lnorig(iorg-1) .eq. -i) ) go to 450
         if (ind0 .eq. 0) go to 450
         if ( (lnorig(iorg-1) .eq. i) .and. (iorg .gt. 1) ) then
           if ( (iot .eq. 1) .or. (iot .eq. 9) .or. (iot .eq. 10) )
     1       indent = indent + indinc
         endif
450      continue
c
c      Issue error messages.
c
         if (lnerr1(ierr) .eq. i) then
           call errmsg ( nlnew, 4, ierr1(ierr) )
           if (nlnew .ge. ilmax) call overflow ( 4, 8 )
           ierr = ierr + 1
           go to 450
         endif
c
460    continue
c
c      If desired, diagnostic dumps are printed in "output".
c
       if (idump .eq. 1) then
         frstwrd = 'UPDATED         '
         call dump
       endif
c
c      Go back to pass 1 for next subroutine.
c
       nerrt = nerrt + nerr1
       if ( (nlines .lt. nlold) .and. (nlnew .lt. ilmax) ) go to 15
c
c      If end of file has not been reached (leof = .false.), write
c  contents of "newfile" to disc, and then read the next portion of the
c  input disc file.
c
       if (.not. lreadall) then
         call wfile ( lunew, 4 )
         if (.not. leof) then
           lfirst = nloldt + 1
           go to 10
         endif
       endif
c
c      End of file has been reached.
c
c      If desired, rearrange the decks alphabetically.  There are
c  several ways to override complete alphabetisation.  By specifying
c  groups as well as decks, decks are arranged alphabetically within
c  each group, while the groups themselves are arranged alphabetically.
c  This prevents related decks from being scattered about in the file.
c  All decks declared before the first group are considered to be
c  "ungrouped", and will be put at the beginning of the file.  The user
c  can also specify four decks to be specifically placed at or near the
c  beginning of the file, regardless of where they ought to go
c  alphabetically.
c
c      dknam1    will be ungrouped if it is grouped, and placed at the
c                very beginning of the file (= "first" in namelist)
c      dknam2    will be ungrouped if it is grouped, and placed right
c                after dknam1 (= "secnd" in namelist)
c      dknam3    is a common deck, and will be the first common deck
c                to appear in its group (after dknam1 and dknam2
c                if it is ungrouped, = "firstcd" in namelist).
c      dknam4    is an ordinary deck, and will be the first ordinary
c                deck to appear in its group (after dknam1 and dknam2
c                if it is ungrouped, = "firstdk" in namelist).
c
c  Note that within each group, common decks will be placed before
c  ordinary decks.
c
       if (ialpha .eq. 1) then
c
c      If "lreadall" = .true., then write "newfile" to "oldfile".
c  Otherwise, close units "luold" and "lunew", reset "oldname" and
c  "newname", and re-open units "luold" and "lunew".
c
         if (lreadall) then
           do 470 i=1,nlnew
             oldfile(i) = newfile(i)
470        continue
           nlold  = nlnew
           nloldt = nlnew
         else
           call cfile ( luold, oldname,      0 )
           call cfile ( lunew, newname, nlnewt )
           oldname = newname
           call ofile ( luold, oldname, 'old     ' )
           newname = tmpname
           nlnewt  = 0
           call ofile ( lunew, newname, 'unknown ' )
         endif
c
c      Call COLLECT again to update the new beginning and ending lines
c  of each deck (they could have been shifted by retargeting).
c
         call collect
c
c      Create "fulnam", consisting of group name concatenated with
c  deck name.  Prefix the deck name with a special character if the
c  deck to to be placed out of alphabetical order (dknam1, etc.)
c
c  First, the ordinary decks.
c
         do 475 idk=1,ndk
           i = idk
           subnam = dknam(idk)
           if ( (subnam .eq. dknam1) .or. (subnam .eq. dknam2) )
     1       dkgrp(idk) = blank16
           char1 = ')'
           if (subnam .eq. dknam1) char1 = ' '
           if (subnam .eq. dknam2) char1 = '$'
           if (subnam .eq. dknam4) char1 = '*'
           if (char1 .ne. ')') then
             subnam = blank16
             subnam(1:1) = char1
             subnam(2:9) = dknam(idk)(1:8)
           endif
           fulnam(i)( 1:16) = dkgrp (idk)
           fulnam(i)(17:32) = subnam
           lstrt (i)        = idkbeg(idk)
           lfnsh (i)        = idkend(idk)
475      continue
c
c  Then, the common decks.
c
         do 480 icd=1,ncd
           i = icd + ndk
           subnam = cdnam(icd)
           if ( (subnam .eq. dknam1) .or. (subnam .eq. dknam2) )
     1       cdgrp(icd) = blank16
           char1 = ')'
           if (subnam .eq. dknam1) char1 = ' '
           if (subnam .eq. dknam2) char1 = '$'
           if (subnam .eq. dknam3) char1 = '('
           subnam = blank16
           subnam(1:1) = char1
           subnam(2:9) = cdnam(icd)(1:8)
           fulnam(i)( 1:16) = cdgrp(icd)
           fulnam(i)(17:32) = subnam
           lstrt (i)        = icdbeg(icd)
           lfnsh (i)        = icdend(icd)
480      continue
         ndeck = ncd + ndk
c
c      Take care of any lines that may be before the first *dk, *cd, or
c  *gp statement.
c
         lmin = 999999
         do 485 i=1,ndeck
           lmin = min0 ( lmin, lstrt(i) )
485      continue
         do 490 i=1,ngp
           lmin = min0 ( lmin, igpbeg(i) )
490      continue
         if ( (lmin .ne. 1) .or. (ndeck .eq. 0) ) then
           ndeck = ndeck + 1
           if (ndeck .gt. 2*ismax) then
             ndeck = 2 * ismax
             call errmsg ( nlnew, 4, 46 )
             go to 495
           endif
           fulnam(ndeck) = blank32
           lstrt (ndeck) = 1
           lfnsh (ndeck) = lmin - 1
           if (ndeck .eq. 1) lfnsh(1) = nlnew
         endif
495      continue
c
c      Rearrange "fulnam" alphabetically.  Rearrange "lstrt" and "lfnsh"
c  as well.
c
         do 505 i=1,ndeck-1
           do 500 j=1,ndeck-1
             if (fulnam(j) .gt. fulnam(j+1)) then
               word32      = fulnam(j  )
               lstrtj      = lstrt (j  )
               lfnshj      = lfnsh (j  )
               fulnam(j  ) = fulnam(j+1)
               lstrt (j  ) = lstrt (j+1)
               lfnsh (j  ) = lfnsh (j+1)
               fulnam(j+1) = word32
               lstrt (j+1) = lstrtj
               lfnsh (j+1) = lfnshj
             endif
500        continue
505      continue
c
c      Rearrange decks alphabetically.
c
         nlnew  = 0
         nlines = 0
         grpnam = blank16
         do 525 ideck=1,ndeck
           if (grpnam .ne. fulnam(ideck)(1:16)) then
             grpnam = fulnam(ideck)(1:16)
             do 515 igp=1,ngp
               if ( (grpnam      .eq. gpnam(igp)) .and.
     1              (igpran(igp) .gt. 0) ) then
                 if (lreadall) then
                   do 510 i=igpbeg(igp),igpend(igp)
                     nlnew = nlnew + 1
                     newfile(nlnew) = oldfile(i)
510                continue
                 else
                   nlnew = 0
                   call rfile ( luold, oldname, -4, igpbeg(igp)
     1                        , igpend(igp), 0, leof )
                   call wfile ( lunew, 4 )
                   nlnewt = nlnewt - nlnew
                   nlines = nlines + nlnew
                 endif
               endif
515          continue
           endif
           if (lreadall) then
             do 520 i=lstrt(ideck),lfnsh(ideck)
               nlnew = nlnew + 1
               newfile(nlnew) = oldfile(i)
520          continue
           else
             nlnew = 0
             call rfile ( luold, oldname, -4, lstrt(ideck), lfnsh(ideck)
     1                  , 0, leof )
             call wfile ( lunew, 4 )
             nlnewt = nlnewt - nlnew
             nlines = nlines + nlnew
           endif
525      continue
         if (.not. lreadall) nlnewt = nlines
c
       endif
       if (lreadall) call wfile ( lunew, 4 )
c
c      Closing messages.
c
       if (nerrt .gt. 0) then
         write (6, 2015) nerrt
         if (ncharn .le. 17) write (6, 2020) newname
         if (ncharn .gt. 17) write (6, 2025) newname
       endif
c
c      Close files, and return to EDITOR.
c
       call cfile ( luold, oldname,      0 )
       call cfile ( lunew, newname, nlnewt )
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('TARGET  : **** WARNING **** Increment for deck: '
     1       ,a8,' reduced from ',i2,' to ',i2,'.')
2015   format('TARGET  : ',i4,' errors detected in the reTARGETed '
     1       ,'file.')
2020   format('TARGET  : Scan file "',a17,'" (columns 16-20) for '
     1       ,'pattern: **** ERROR.')
2025   format('TARGET  : Scan file "',a14,'..." (columns 16-20) for '
     1       ,'pattern: **** ERROR.')
c
       end
c
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                T A R G E T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  T E S T                  \\\\\\\\\\
c
c=======================================================================
c
       subroutine test
c
c    dac:editor.test <------------------------------------- testing mode
c                                                        september, 1989
c
c>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> JOB = 10 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine can be used to test various aspects of
c  EDITOR.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    OFILE
c    CFILE
c    COLLECT
c    CDECKS
c    RFILE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       integer       i       , i1      , i2      , icoll   , ifile
     1             , lfirst  , llast
c
c      External statements
c
       external      ofile   , cfile   , collect , cdecks  , rfile
c
c-----------------------------------------------------------------------
c
       call ofile (luold, oldname, 'old     ')
       leof  = .false.
       icoll = 0
10     continue
       write (6, 2010) nloldt
2010   format(' nloldt = ',i6,'.  Enter ifile, lfirst, llast')
       read (5, *) ifile, lfirst, llast
       if (ifile  .eq. 0) then
         call cfile (luold, oldname, 0)
         goto 999
       endif
       if ( (ifile .gt. 0) .and. (icoll .eq. 0) ) then
         call collect
         leof = lreadall
         call cdecks
         do 20 i=1,ncd
           write(6,2020) cdnam(i),icdbeg(i),icdend(i),icdsta(i)
     1                  ,icdfin(i), icdxeq(i)
2020       format('cdnam= ',a8,' cdbeg=',i6,' cdend=',i6,' cdsta=',i6
     1           ,' cdfin=',i6,' cdxeq=',i6)
20       continue
         icoll = 1
       endif
       if ( (ifile .gt. 0) .and. (leof) ) go to 30
       nlold = 0
       call rfile ( luold, oldname, ifile, lfirst, llast, 1, leof )
30     continue
       write(6,2030) nloldt, nlold, oldname
2030   format(' nloldt=',i6,', nlold=',i6,'.  Enter desired range of '
     1       ,'file ',a16)
       read (6, *) i1,i2
       if (i1 .eq. 0) go to 40
       write (6, 2040) (oldfile(i), i=i1,i2)
2040   format(a80)
       go to 30
40     continue
       write(6,2050) nlcdkt, nlcdk
2050   format(' nlcdkt=',i6,', nlcdk=',i6,'.  Enter desired range of '
     1       ,'file cdkfile')
       read (6, *) i1,i2
       if (i1 .eq. 0) go to 10
       write (6, 2040) (cdkfile(i), i=i1,i2)
       go to 40
999    continue
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  T E S T                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                A D D E L T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine addelt ( word, vector, index, nmax )
c
c    dac:editor.addelt <------------------------- adds element to vector
c                                                         december, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  If the character string "word" is not already an element of
c  the character string array "vector", this subroutine will add it to
c  the array, increment "nmax" by 1, and return "index" = "nmax".  If
c  "word" is already an element of "vector", "word" is not added to
c  "vector", "nmax" is not incremented by 1, and "index" is returned
c  as the index of "word" in "vector".
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*16  word
       integer       i       , nmax    , index
c
       character*16  vector  ( 1)
c
c-----------------------------------------------------------------------
c
       do 10 i=1,idmax
         if (i .gt. nmax) go to 20
         if (word .eq. vector(i)) then
           index = i
           return
         endif
10     continue
20     continue
       nmax  = min0 ( idmax, nmax + 1 )
       index = nmax
       vector(nmax) = word
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                A D D E L T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               A L I A S E S               \\\\\\\\\\
c
c=======================================================================
c
       subroutine aliases ( ifile )
c
c    dac:editor.aliases <------------------ performs alias substitutions
c                                                         february, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine substitutes all occurances of the alias1's
c  for alias2's in "oldfile", except for those found in comment
c  statements.  Aliases found in "dknam" are also substituted.
c
c  INPUT VARIABLES:
c    ifile       =1 => substitute aliases in text file "oldfile"
c                =2 => substitute aliases in text file "tmpfile"
c                =3 => substitute aliases in text file "cdkfile"
c                =4 => substitute aliases in text file "newfile"
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    GETWRD
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*16  word
       character*128 line    , tmpline
       integer       ifile
       integer       i       , j       , j1      , j2      , j3
     1             , j4      , jbeg    , jend    , jran    , next
     2             , ial     , nlxxx
c
c      External statements
c
       external      getwrd
c
c-----------------------------------------------------------------------
c
       if (ifile .eq. 1) nlxxx  = nlold
       if (ifile .eq. 2) nlxxx  = nltmp
       if (ifile .eq. 3) nlxxx  = nlcdk
       if (ifile .eq. 4) nlxxx  = nlnew
c
       do 50 i=1,nlxxx
         if (ifile .eq. 1) line = oldfile(i)
         if (ifile .eq. 2) line = tmpfile(i)
         if (ifile .eq. 3) line = cdkfile(i)
         if (ifile .eq. 4) line = newfile(i)
         if ( (line(1:1) .eq.      'c') .or.
     1        (line(1:1) .eq.      'C') .or.
     2        (line(1:2) .eq.     '**') .or.
     3        (line(1:6) .eq. '*error') ) go to 50
         jend = 0
10       continue
         jbeg = jend + 1
         jend = nchar
         next = 0
         call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,()=.'
     1               , word )
         if (word .eq. blank16) go to 50
         do 30 ial=1,nalias
           if (word .eq. alias1(ial)) then
             ialias(ial) = ialias(ial) + 1
             j1   = jend + 1
             jend = jbeg + jranal(ial) - 1
             j2   = jend + 1
             j3   = min0 ( nchar, nchar - j2 + j1 )
             j4   = min0 ( nchar, nchar - j1 + j2 )
             tmpline     = line
             line(j2:j4) = tmpline(j1:j3)
             if (j4 .lt. nchar) then
               do 20 j=j4+1,nchar
                 line(j:j) = ' '
20             continue
             endif
             line(jbeg:jend) = alias2(ial)(1:jranal(ial))
             if (ifile .eq. 1) oldfile(i) = line
             if (ifile .eq. 2) tmpfile(i) = line
             if (ifile .eq. 3) cdkfile(i) = line
             if (ifile .eq. 4) newfile(i) = line
             go to 40
           endif
30       continue
40       continue
         go to 10
50     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               A L I A S E S               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              C A P I T A L S              \\\\\\\\\\
c
c=======================================================================
c
       subroutine capitals ( word )
c
c    dac:editor.capitals <--------------------------- capitalises "word"
c                                                         february, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine replaces all lower case characters in
c  "word" with the corresponding upper case character.
c
c  INPUT VARIABLES:
c    word        character*16 string to be converted to upper case.
c
c  OUTPUT VARIABLES:
c    word        character*16 string converted to upper case.
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    STRLEN
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*(*) word
       integer       nch     , i       , ich
c
       integer       strlen
       external      strlen
c
c-----------------------------------------------------------------------
c
       nch = strlen ( word )
       do 10 i=1,nch
         ich = ichar ( word(i:i) )
         if ( (ich .ge. 97) .and. (ich .le. 122) ) ich = ich - 32
         word(i:i) = char ( ich )
10     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              C A P I T A L S              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                C C L O C K                \\\\\\\\\\
c
c=======================================================================
c
       function cclock ()
c
c    dac:editor.cclock <-------------------- returns time from cpu clock
c    from dac:zeus3d.wclock                               february, 2011
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE: This function returns the current time (in seconds) from the
c  internal cpu clock of, presumably, the master node.  It is good for
c  keeping track of cpu time consumed in a single-thread application.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c    cclock      cpu clock time in seconds
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    compiler-specific cpu clock subroutines/functions
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       real          cclock  , rclock
       real          etime   , tdummy  (   2)
c
c-----------------------------------------------------------------------
c
c      Returns cpu time in seconds.
c
       cclock = 0.0
       cclock = etime ( tdummy )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                C C L O C K                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                C D E C K S                \\\\\\\\\\
c
c=======================================================================
c
       subroutine cdecks
c
c    dac:editor.cdecks <--------------- stores common decks in "cdkfile"
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine copies all the common decks from the disc
c  file "oldname" into the text file "cdkfile".  ALIAS and COPY are
c  called to free the common decks from EDITOR conditionals.  All EDITOR
c  *call statements are replaced with the called common deck.  The first
c  line number, last line number, and the number of executable
c  statements in each command deck are stored in "icdsta", "icdfin", and
c  "icdxeq" respectively.
c      CDECKS assumes that COLLECT has been called, and that the disc
c  file "oldname" is still open.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    RFILE
c    ALIASES
c    COPY
c    GETWRD
c    ERRSET
c    OVERFLOW
c    ERRWRT
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       character*1   char1   , char2
       character*16  word    , subnam
       integer       i       , icd     , lfirst  , llast   , nlw
     1             , nround  , ncall   , jbeg    , jend    , jran
     2             , next    , ibeg    , iend    , iline   , nlines
c
c      External statements
c
       external      rfile   , aliases , copy    , getwrd  , errset
     1             , overflow, errwrt
c
c-----------------------------------------------------------------------
c
c      Initialise error variables
c
       do 10 i=1,iemax
         ierr2 (i) = 0
         lnerr2(i) = 0
10     continue
       nerr2 = 0
c
c      Copy command decks from disc file "oldname" to text array
c  "cdkfile".
c
       nlcdk  = 0
       leof   = .false.
       nlines = nloldt
       do 20 icd=1,ncd
         lfirst = icdbeg(icd)
         llast  = icdend(icd)
         call rfile ( luold, oldname, -3, lfirst, llast, 1, leof )
20     continue
       rewind ( luold )
       nloldt = nlines
c
c      Make the alias substitutions.
c
       if (nalias .ne. 0) call aliases ( 3 )
c
c      Copy the lines of "cdkfile" to "newfile" subject to the EDITOR
c  conditionals that may be surrounding the lines.
c
       nlw = 2
       call copy ( 3, 1, nlw )
c
c      Copy "newfile" to both "cdkfile" and "tmpfile".  "cdkfile" will
c  be updated as the EDITOR *call statements are carried out, whereas
c  "tmpfile" will be left alone.  In this way, the values of "icdsta"
c  and "icdfin" remain valid for "tmpfile".
c
       do 30 i=1,nlnew
         cdkfile(i) = newfile(i)
         tmpfile(i) = newfile(i)
30     continue
       nlcdk = nlnew
       nltmp = nlnew
c
c      Store the starting and finishing line of each common deck in
c  "cdkfile" in "icdsta" and "icdfin".
c
       icd         = 1
       icdsta(  1) = 1
       do 40 i=2,nlcdk
         if (cdkfile(i)(1:3) .eq. '*cd') then
           icdfin(icd) = i - 1
           icd         = icd + 1
           icdsta(icd) = i
         endif
40     continue
       icdfin(ncd) = nlcdk
c
c      Substitute EDITOR *call statements for the called common deck.
c
c  "nround"    the number of passes made through "cdkfile" in an effort
c              to replace nested *call statements (maximum = 10)
c  "ncall"     is the number of *call statements remaining after last
c              pass.  If "ncall" > 0, another round is needed.
c
       nround = 0
50     continue
       nround = nround + 1
       ncall  = 0
       nlnew  = 0
       do 90 i=1,nlcdk
         char1 = cdkfile(i)(1:1)
         if (char1 .eq. '*') then
           jbeg = 2
           jend = 9
           next = 0
           call getwrd ( i, 3, next, jbeg, jend, jran, ' ,.', word )
           if (word(1:2) .eq. 'ca') then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 3, next, jbeg, jend, jran, ' ,.', subnam )
             do 70 icd=1,ncd
               if (subnam .eq. cdnam(icd)) then
                 if (nround .gt. 10) then
                   call errset ( i, 1, 2 )
                   go to 80
                 endif
c
c      The "common deck" called by the *call statement has been matched
c  with one of the known "common decks".  Insert the "common deck" into
c  "newfile", except the first line which is the *cdeck label.  Count
c  any other *call's that may have been inserted with the "common deck".
c
                 ibeg = icdsta(icd) + 1
                 iend = icdfin(icd)
                 do 60 iline=ibeg,iend
                   nlnew = nlnew + 1
                   if (nlnew .gt. ilmax) call overflow ( 4, 7 )
                   newfile(nlnew) = tmpfile(iline)
                   if (newfile(nlnew)(1:3) .eq. '*ca')
     1               ncall   = ncall   + 1
60               continue
                 go to 90
               endif
70           continue
c
c      The only way for execution to reach this point is if a *call has
c  been made to a "common deck" not found in the array "cdnam".  Issue
c  the appropriate error message.
c
             if (cdkfile(i+1)(21:29) .ne. 'ERROR   2')
     1         call errset ( i, 2, 2 )
           endif
         endif
80       continue
c
c      Copy current line in "cdkfile", along with any error messages to
c  "newfile".  This is not done if the line is a valid EDITOR *call
c  statement.
c
         nlnew = nlnew + 1
         if (nlnew .gt. ilmax) call overflow ( 4, 7 )
         newfile(nlnew) = cdkfile(i)
         if (nerr2 .ne. 0) call errwrt ( i, 4, 2, nlnew )
90     continue
c
c      Update "cdkfile".
c
       do 100 i=1,nlnew
         cdkfile(i) = newfile(i)
100    continue
       nlcdk = nlnew
c
c      If "ncall" .ne. 0, go through "cdkfile" again.
c
       if (ncall .ne. 0) go to 50
c
c      Update "icdsta" and "icdfin", and determine "icdxeq".
c
       icd         = 1
       icdsta(  1) = 1
       do 110 i=2,nlcdk
         if (cdkfile(i)(1:3) .eq. '*cd') then
           icdfin(icd) = i - 1
           icd         = icd + 1
           icdsta(icd) = i
         endif
         char1 = cdkfile(i)(1:1)
         char2 = cdkfile(i)(6:6)
         jbeg  = 1
         jend  = nchar
         next  = 0
         call getwrd ( i, 3, next, jbeg, jend, jran, ' ,()=.', word )
         if ( (char1 .ne. '*') .and. (char1 .ne. 'c') .and.
     1        (char1 .ne. 'C') .and. (char2 .eq. ' ') .and.
     2        (word  .ne. blank16) ) icdxeq(icd) = icdxeq(icd) + 1
110    continue
       icdfin(ncd) = nlcdk
c
c      Reset "nerror2" (since common decks are not copied to PRECOMpiled
c  file, unless by a *ca command, in which case, any errors that are
c  copied will cause "nerror2" to be incremented by 1.
c
       nerror2 = 0
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                C D E C K S                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               C O L L E C T               \\\\\\\\\\
c
c=======================================================================
c
       subroutine collect
c
c    dac:editor.collect <----- collects aliases, switches and deck names
c                                                         february, 1989
c
c    written by: David Clarke
c    modified 1: September 1989 by David Clarke; Reworked to allow
c                partial reads of input file.
c    modified 2: March, 2011 by DAC; allowed for switches to be case
c                insensitive.
c
c  PURPOSE:  This subroutine first determines how the source code in the
c  disc file assigned to "luold" has been modularised.  If an EDITOR
c  *group, *gp, *deck, *dk, *cdeck, or *cd is encountered before the
c  first module (program, subroutine, function, or blockdata) statement,
c  then it will be assumed that the source code is modularised by
c  EDITOR decks.  On the other hand, if a subprogram statement is found
c  first, then it will be assumed that the source code is modularised
c  by ordinary FORTRAN subprogram statements, and that EDITOR decks are
c  not used.
c      COLLECT assumes that the file "oldname" on "luold" has already
c  been opened.
c
c  FOR SOURCE CODE MODULARISED BY EDITOR DECKS:
c
c      The subroutine collects the names of the common decks ("cdnam"),
c  the ordinary decks ("dknam"), their associated groups ("cdgrp" and
c  "dkgrp"), along with the beginning and ending lines of each deck
c  ("icdbeg", "idkbeg", and "icdend", "idkend") and each group "leader
c  text" ("igpbeg" and "igpend").  Group "leader text" is defined to be
c  any text (usually comments) which may lie between but not including
c  the *gp statement and the next *dk or *cd statement.
c      This subroutine will also collect all the switches and aliases
c  that may be defined throughout the source code.  The common arrays
c  "swtch1", "alias1", and "alias2" are used to store the switches and
c  aliases.
c
c  FOR SOURCE CODE MODULARISED BY SUBPOGRAM NAMES ONLY:
c
c      This subroutine collects the list of module names ("dknam") found
c  in PROGRAM, SUBROUTINE, FUNCTION, and BLOCKDATA statements, along
c  with the line numbers where each module begins ("idkbeg") and ends
c  ("idkend").  "idkbeg" is set to the line number of the PROGRAM,
c  SUBROUTINE, FUNCTION, or BLOCKDATA statement.  Except for the last
c  module, "idkend(i)" is set to "idkbeg(i+1)" - 1.  For the last
c  module, "idkend" is set to the line number of the last line in the
c  disc file.  Any lines found before the first PROGRAM, SUBROUTINE,
c  FUNCTION, or BLOCKDATA statement are considered a separate module,
c  and given a blank "dknam".
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    RFILE
c    GETWRD
c    ERRSET
c    CAPITALS
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof
       integer       cddkgp
       character*16  word    , ucword  , subnm1  , subnm2  , grpnam
       character*128 line
       integer       i       , iflag   , lfirst  , llast   , itot
     1             , jbeg    , jend    , jran    , next    , iwrd
     2             , match   , igp
c
       character*16  keywrd  (  25)
c
c      External statements.
c
       external      rfile   , getwrd  , errset  , capitals
c
c      Data statements.
c
       data          keywrd
     1   / 'define          ', 'def             ', 'alias           '
     2   , 'al              ', 'cdeck           ', 'cd              '
     3   , 'deck            ', 'dk              ', 'group           '
     4   , 'gp              ', 'PROGRAM         ', 'SUBROUTINE      '
     5   , 'FUNCTION        ', 'BLOCKDATA       ', 'BLOCK           '
     6   , 'REAL            ', 'INTEGER         ', 'LOGICAL         '
     7   , 'CHARACTER       ', 'DATA            ', 'EXTERNAL        '
     8   , 'COMMON          ', 'DIMENSION       ', 'EQUIVALENCE     '
     9   , 'SAVE            ' /
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       do 10 i=1,iemax
         ierr1 (i) = 0
         lnerr1(i) = 0
10     continue
       nerr1   = 0
c
       do 20 i=1,ismax
         idkbeg(i) = 0
         idkend(i) = 0
         dknam (i) = blank16
         dkgrp (i) = blank16
         icdbeg(i) = 0
         icdend(i) = 0
         cdnam (i) = blank16
         cdgrp (i) = blank16
         igpbeg(i) = 0
         igpend(i) = 0
         gpnam (i) = blank16
20     continue
       ncd    = 0
       ndk    = 0
       ngp    = 0
       grpnam = blank16
c
       do 30 i=1,idmax
         swtch1(i) = blank16
30     continue
       nswitch = 0
c
       do 40 i=1,iamax
         ialias(i) = 0
         jranal(i) = 0
         alias1(i) = blank16
         alias2(i) = blank16
40     continue
       nalias  = 0
c
       cddkgp  = 0
       iflag   = 0
       leof    = lreadall
c
c      If "lreadall" is true, assume that all of the desired disc file
c  is contained by the text file "oldfile".  If "lreadall" is false,
c  then it will be necessary to read "oldname" in pieces.
c
       if (.not. lreadall) nloldt  = 0
50     continue
c
c      If "leof" is false, read the next "ilmax" lines from the disc
c  file "oldname" assigned to "luold" into the file "oldfile".
c
       if (.not. leof) then
         nlold   = 0
         lfirst  = nloldt + 1
         llast   = nloldt + ilmax
         call rfile ( luold, oldname, -1, lfirst, llast, 0, leof )
       endif
c
c      ENTERING MAIN LOOP . . . .
c
       do 160 i=1,nlold
         itot = i + nloldt - nlold
         line = oldfile(i)
c
c      First, determine how the disc file is modularised:
c  "iflag" = 0  =>  as yet undetermined, but assume EDITOR decks
c  "iflag" = 1  =>  EDITOR decks
c  "iflag" = 2  =>  subprogram statements
c
         if (iflag .eq. 0) then
           jbeg = 1
           if (line(1:2) .eq. '**') go to 160
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.*', word )
           ucword = word
           call capitals ( ucword )
           do 60 iwrd=1,25
             if (  word .eq. keywrd(iwrd) ) go to 70
             if (ucword .eq. keywrd(iwrd) ) go to 70
60         continue
70         continue
           if ( (iwrd .ge.  5) .and. (iwrd .le. 10) ) iflag = 1
           if ( (iwrd .ge. 11) .and. (iwrd .le. 25) ) iflag = 2
         endif
         if (iflag .eq. 2) go to 110
c
c      Even if "iflag" is still 0, assume that the source code is
c  modularised by EDITOR decks.  Collect a list of switches, aliases,
c  decknames and groupnames.  In addition, store the line number of the
c  beginning and ending of each deck and the number of executable
c  statements in each common deck.
c
         if (line(1:1) .eq. '*') then
           jbeg = 2
           jend = 9
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', word )
c
c      Collect defined switches.
c
           if ( (word .eq. keywrd(1)) .or. (word .eq. keywrd(2)) ) then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', subnm1 )
             if (subnm1 .eq. blank16) then
               call errset ( itot, 3, 1 )
               go to 160
             endif
80           continue
             nswitch = nswitch + 1
             if (nswitch .gt. idmax) then
               nswitch = idmax
               call errset ( itot, 4, 1 )
               go to 160
             endif
             if (swcase .eq. 0) call capitals ( subnm1 )
             swtch1(nswitch) = subnm1
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', subnm1 )
             if (subnm1 .eq. blank16) go to 90
             go to 80
           endif
90         continue
c
c      Collect aliases.
c
           if ( (word .eq. keywrd(3)) .or. (word .eq. keywrd(4)) ) then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', subnm1 )
             if (subnm1 .eq. blank16) then
               call errset ( itot, 3, 1 )
               go to 160
             endif
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ', subnm2 )
             if (subnm2 .eq. blank16) then
               call errset ( itot, 3, 1 )
               go to 160
             endif
             nalias = nalias + 1
             if (nalias .gt. iamax) then
               nalias = iamax
               call errset ( itot, 5, 1 )
               go to 160
             endif
             alias1(nalias) = subnm1
             alias2(nalias) = subnm2
             jranal(nalias) = jran
           endif
c
c      Common decks are identified by setting the flag "cddkgp" to 1.
c  When a *cdeck is encountered, store the deck name (cdnam(ncd)) and
c  the beginning line of the common deck (icdbeg(ncd)).
c
           if ( (word .eq. keywrd(5)) .or. (word .eq. keywrd(6)) ) then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', subnm1 )
             if (subnm1 .eq. blank16) then
               call errset ( itot, 3, 1 )
               go to 160
             endif
             ncd  = ncd + 1
             if (ncd .gt. ismax) then
               ncd = ismax
               call errset ( itot, 6, 1 )
               go to 160
             endif
             cddkgp      = 1
             cdnam (ncd) = subnm1
             cdgrp (ncd) = grpnam
             icdbeg(ncd) = itot
           endif
c
c      Ordinary decks are identified by setting the flag "cddkgp" to 2.
c  When a *deck is encountered, store the deck name (dknam(ndk)) and
c  the beginning line of the deck (idkbeg(ndk)).
c
           if ( (word .eq. keywrd(7)) .or. (word .eq. keywrd(8)) ) then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', subnm1 )
             if (subnm1 .eq. blank16) then
               call errset ( itot, 3, 1 )
               go to 160
             endif
             ndk  = ndk + 1
             if (ndk .gt. ismax) then
               ndk = ismax
               call errset ( itot, 6, 1 )
               go to 160
             endif
             cddkgp      = 2
             dknam (ndk) = subnm1
             dkgrp (ndk) = grpnam
             idkbeg(ndk) = itot
           endif
c
c      *group statements and any text between *group statements and the
c  next *gp, *dk, or *cd statement will not be included in any of the
c  decks identified in the source code.  Thus, it is necessary to keep
c  track of this text separately.  Since it is possible to have many
c  *group statements with the same group name scattered throughout the
c  source code, the beginning line of this text will include the *group
c  statement itself only if this is the first time a *group statement
c  with a particular group name is encountered.  This aids TARGET in
c  alphabetising the source.
c      Group text is identified by setting the flag "cddkgp" to 3.  When
c  a group is encountered, store the group name (gpnam(ngp)) and the
c  first line of the group text (igpbeg(ngp)).  Note that the group name
c  is read directly into "grpnam", which is used to set "dkgrp" and
c  "cdgrp".
c
           if ( (word .eq. keywrd(9)) .or. (word .eq. keywrd(10)) ) then
             jbeg = jend + 1
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', grpnam )
             ngp  = ngp + 1
             if (ngp .gt. ismax) then
               ngp = ismax
               call errset ( itot, 6, 1 )
               go to 160
             endif
             cddkgp      = 3
             gpnam (ngp) = grpnam
             igpbeg(ngp) = itot
             if (ngp .gt. 1) then
               do 100 igp=1,ngp-1
                 if (grpnam .eq. gpnam(igp)) igpbeg(ngp) = itot + 1
100            continue
             endif
           endif
c
         endif
c
c      Update "icdend", "idkend", or "igpend" depending on "cddkgp".
c
         if (cddkgp .eq. 1) icdend(ncd) = itot
         if (cddkgp .eq. 2) idkend(ndk) = itot
         if (cddkgp .eq. 3) igpend(ngp) = itot
         go to 160
c
110      continue
c
c      A subprogram statement or a declarative (real, common, etc) was
c  detected before an EDITOR deck statement.  Assume, therefore, that
c  the source code is modularised by subprogram statements only, and
c  that the subprogram names and their limits are all that must be
c  collected.
c
         if ( (itot .gt. 1) .and. (ndk .eq. 0) ) then
           ndk       = 1
           dknam (1) = blank16
           idkbeg(1) = 1
           idkend(1) = itot - 1
         endif
         if (line(1:6) .eq. '      ') then
           jbeg  = 7
           jend  = nchar
           next  = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' (*/', word )
           call capitals ( word )
           match = 1
           do 120 iwrd=1,25
             if (word .eq. keywrd(iwrd)) go to 130
120        continue
130        continue
           if ( (iwrd .ge. 11) .and. (iwrd .le. 14) ) match = 2
           if   (iwrd .eq. 15)                        match = 3
           if ( (iwrd .ge. 16) .and. (iwrd .le. 19) ) match = 4
c
           if (match .gt. 1) then
             if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
               jbeg = jend + 1
               jend = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ', subnm1 )
             endif
140          continue
             jbeg = jend  + 1
             jend = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' (', subnm1 )
             if (subnm1 .eq. blank16) then
               call errset ( itot, 3, 1 )
               go to 150
             endif
             if (match .eq. 3) then
               match = 2
               go to 140
             endif
             if (match .eq. 4) then
               call capitals ( subnm1 )
               if (subnm1 .eq. keywrd(13)) then
                 match = 2
                 go to 140
               else
                 go to 150
               endif
             endif
             ndk  = ndk + 1
             if (ndk .gt. ismax) then
               ndk = ismax
               call errset ( itot, 6, 1 )
               go to 150
             endif
             dknam (ndk) = subnm1
             idkbeg(ndk) = itot
           endif
         endif
150      continue
         idkend(ndk) = itot
c
160    continue
c
c      . . . . EXITING MAIN LOOP
c
c      If all of the file has not been scanned yet ("leof" = .false.),
c  read the next portion of the disc file and continue COLLECTing.
c
       if (.not. leof) go to 50
c
c      Once all of the disc file has been scanned, set "nloldt" back to
c  zero if "lreadall" is still false, rewind unit "luold", set "idkran"
c  and "icdran", and return to the calling routine.
c
       if (.not. lreadall) nloldt = 0
       rewind ( luold )
       do 170 i=1,ndk
         idkran(i) = idkend(i) - idkbeg(i) + 1
170    continue
       do 180 i=1,ncd
         icdran(i) = icdend(i) - icdbeg(i) + 1
180    continue
       do 190 i=1,ngp
         igpran(i) = igpend(i) - igpbeg(i) + 1
190    continue
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               C O L L E C T               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  C O P Y                  \\\\\\\\\\
c
c=======================================================================
c
       subroutine copy ( ifile, level, nlw )
c
c    dac:editor.copy <--------- copies text file subject to conditionals
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine copies the text from the text file
c  specified by "ifile" to the text file "newfile" subject to any EDITOR
c  conditionals that may be surrounding the text.
c
c  INPUT VARIABLES:
c    ifile       specifies text file to be copied to "newfile".
c                =1 => copy from "oldfile"
c                =2 => copy from "tmpfile"
c                =3 => copy from "cdkfile"
c    level       =1 => copy all source code, including common decks,
c                      except those bounded by false EDITOR
c                      conditionals.  Do not copy EDITOR conditional
c                      statements themselves (*if, *else, *endif,
c                      *define, and *alias), unless statement contains a
c                      syntax error.  Do not copy EDITOR comments (**).
c                      EDITOR statements which are copied are *deck,
c                      *cdeck, *call, and *error.  Used by CDECKS.
c                =2 => same as 1, except in addition, do not copy common
c                      decks or EDITOR deck statements (*deck, *cdeck),
c                      unless the statement contains a syntax error.
c                      EDITOR statements which are copied are *call and
c                      *error.  Used by PRECOM.
c    nlw         total number of logical write flags ("lwrite") set.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    ERRSET
c    GETCHR
c    INOREX
c    ERRWRT
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1   , char2
       character*128 line
       integer       ifile   , level   , nlw
       integer       ilw     , nlxxx   , i       , jval
c
c      External statements
c
       external      errset  , getchr  , inorex  , errwrt
c
       logical       lcopy   (  13)
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       do 10 ilw=1,13
         lcopy(ilw) = .true.
10     continue
c
       if (ifile .eq. 1) nlxxx = nlold
       if (ifile .eq. 2) nlxxx = nltmp
       if (ifile .eq. 3) nlxxx = nlcdk
       nlnew = 0
c
c      Copy the lines of "xxxfile" to "newfile" subject to the EDITOR
c  conditionals that may be surrounding the lines.  The line under
c  consideration is copied if the logical variables "lcopy(i=1,12)" are
c  .true., or if "lcopy(13)" is .true..
c
       do 20 i=1,nlxxx
         lcopy(1) = .true.
         if (ifile .eq. 1) line = oldfile(i)
         if (ifile .eq. 2) line = tmpfile(i)
         if (ifile .eq. 3) line = cdkfile(i)
         char1 = line(1:1)
c
c      Check for incorrect syntax.
c
c  1.  First character in line must be a ' ', '*', 'c', 'C', or a digit.
c
         if (   (char1 .ne. ' ') .and. (char1 .ne. '*') .and.
     1          (char1 .ne. 'c') .and. (char1 .ne. 'C') .and.
     2        ( (char1 .lt. '0') .or.  (char1 .gt. '9') ) )
     3     call errset ( i, 7, 2 )
c
c  2.  The EDITOR '*' sentinel must be in column 1.
c
         if (char1 .eq. ' ') then
           jval = 2
           call getchr ( line, jval, char2, 1 )
           if ( (char2 .eq. '*') .and. (jval .le. 5) )
     1       call errset ( i, 8, 2 )
         endif
c
c  3.  When an EDITOR sentinel (*) is found in column 1, the EDITOR
c      command must start in column 2.  If it does, call INOREX to
c      update "lcopy".
c
         if (char1 .eq. '*') then
           char2 = line(2:2)
           if (char2 .eq. ' ') then
             call errset ( i, 9, 2 )
           else
             call inorex ( i, ifile, level, nlw, lcopy )
           endif
         endif
c
c      Copy the line.
c
         if ( ( (lcopy( 1)) .and. (lcopy( 2)) .and. (lcopy( 3)) .and.
     1          (lcopy( 4)) .and. (lcopy( 5)) .and. (lcopy( 6)) .and.
     2          (lcopy( 7)) .and. (lcopy( 8)) .and. (lcopy( 9)) .and.
     3          (lcopy(10)) .and. (lcopy(11)) .and. (lcopy(12)) ) .or.
     4        (lcopy(13)) ) then
           nlnew = nlnew + 1
           newfile(nlnew) = line
           if (nerr2 .gt. 0) call errwrt ( i, 4, 2, nlnew )
         endif
20     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  C O P Y                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  C T O I                  \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine ctoi ( iline, word, int )
c
c    dac:editor.ctoi <----------- translates character string to integer
c                                                         february, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine translates a character string to an
c  integer.
c
c  INPUT VARIABLES:
c    iline       current line number in text file (needed if error
c                message is set).
c    word        character string to be converted to an integer.
c
c  OUTPUT VARIABLES:
c    int         integer equivalent to "word".
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    ERRSET
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*1   char1
       character*16  word
       integer       iline   , int
       integer       i       , ichar   , ifact
c
       character*1   ch      (  10)
c
c      External statements
c
       external      errset
c
c      Data statements.
c
       data          ch
     1             / '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' /
c
c-----------------------------------------------------------------------
c
       ichar = 16
       ifact = 1
       int   = 0
10     continue
       char1 = word(ichar:ichar)
       if (char1 .ne. ' ') then
         do 20 i=1,10
           if (char1 .eq. ch(i)) go to 30
20       continue
c
c       One of the characters in "word" does not correspond to a digit.
c  Issue an error message.
c
         call errset ( iline, 10, 2 )
         int = - 1
         return
c
30       continue
         int   = int + ifact * (i - 1)
         ifact = ifact * 10
       endif
       ichar = ichar - 1
       if (ichar .gt. 0) go to 10
       if (int .eq. 0) int = 99999999
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  C T O I                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////               F I R S T C H               \\\\\\\\\\
c
c=======================================================================
c
       function firstch ( word )
c
c    dac:editor.firstch <----------- first non-blank character in "word"
c                                                            march, 2011
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This function returns the location of the first non-blank
c  character in the input character string "word".
c
c  INPUT VARIABLES:
c    word        input character string
c
c  OUTPUT VARIABLES:
c    firstch     integer location of first non-blank character
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*(*) word
       integer       firstch , imax    , i
c
c-----------------------------------------------------------------------
c
       imax = len ( word )
       do 10 i=1,imax
         if (word(i:i) .ne. ' ') go to 20
10     continue
20     continue
       firstch = 0
       if (i .le. imax) firstch = i
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////               F I R S T C H               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                G E T C H R                \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine getchr ( line, jval, char1, forl )
c
c    dac:editor.getchr <------ returns first or last non-blank character
c                                                         november, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine returns the first (last) non-blank
c  character at or after (before) the input position "jval" in "line".
c
c  INPUT VARIABLES:
c    line        current line of text file
c    jval        begin search for first (last) non-blank character at
c                column "jval".
c    forl        =1 => first non-blank character is sought
c                =2 => last  non-blank character is sought
c
c  OUTPUT VARIABLES:
c    jval        column number of first (last) non-blank character.
c    char1       first (last) non-blank character in "line".
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*128 line
       integer       forl    , j       , j1      , j2      , jval
c
c-----------------------------------------------------------------------
c
       if (forl .eq. 1) then
c
c      Determine "jval".  If there are no non-blank characters after
c  the input value of "jval", then "char1" is returned blank.
c
         j1 = jval
         if (j1 .eq. 0) j1 = 1
         j2 = icmax
         do 10 j=j1,j2
           jval = j
           char1 = line(j:j)
           if (char1 .ne. ' ') go to 20
10       continue
20       continue
       else
c
c      Determine "jval".  If there are no non-blank characters before
c  the input value of "jval", then "char1" is returned blank.
c
         j1 = jval
         if (j1 .eq. 0) j1 = icmax
         j2 = 1
         do 30 j=j1,j2,-1
           jval = j
           char1 = line(j:j)
           if (char1 .ne. ' ') go to 40
30       continue
40       continue
       endif
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                G E T C H R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                G E T W R D                \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine getwrd ( iline, ifile, next, jbeg, jend, jran, blanks
     1                   , word )
c
c    dac:editor.getwrd <------------------ returns next "word" in "line"
c                                                          october, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine returns the next "word" (character groups
c  separated by the characters listed in "blanks") between the input
c  positions of "jbeg" and "jend" on the line which is "next" lines
c  after line number "iline" in the text file specified by "ifile".  If
c  "jend" = 0, and the end of the line is reached before a new "word" is
c  found, then the next line is considered.  If it is a continuation
c  line (6th character is not a blank), then the next "word" is read.
c  If there is a period (.) on either side of a boolean "word" (and, or,
c  eq, ne, gt, ge, lt, le), then the periods are returned as part of the
c  word.
c
c  Note that "jbeg" and "jend" are determined in slightly different
c  ways.  "jbeg" always begins at the first non-blank character, even
c  if a blank is not one of the characters in "blanks".  However, "jend"
c  will not be set when the first blank is encountered if a blank is not
c  included in "blanks".  Thus, in the following statement
c
c       imax  j(j) = imax
c
c  "imax" is the first word if blanks=' ', whereas "imax  j" is the
c  first word if blanks='('.  Note that the subroutine SQUEEZE would
c  convert "imax  j" to "imaxj".
c
c  INPUT VARIABLES:
c    iline       line number of file.
c    ifile       =1 => read line from "oldfile".
c                =2 => read line from "tmpfile".
c                =3 => read line from "cdkfile".
c                =4 => read line from "newfile".
c    next        number of lines after line "iline" where search for
c                next "word" should begin.
c    jbeg        begin search for next "word" at column "jbeg".
c    jend        next "word" must end at or before column "jend".  If
c                jend = 0, search for next "word" may be continued on
c                next line.
c    blanks      character constant containing the characters to be
c                treated as word separators.
c
c  OUTPUT VARIABLES:
c    next        number of lines after current line in which "word" was
c                found.
c    jbeg        column number of beginning of next "word".
c    jend        column number of end of next "word".
c                jend .le. jbeg + 15.
c    jran        jend - jbeg + 1.
c    word        next "word" in "line".
c
c  LOCAL VARIABLES:
c    line        current line.
c    char1       current character.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char0   , char1   , char2   , char3   , char4
     1             , char5   , char6   , char7   , char8
       character*(*) blanks
       character*4   word4
       character*16  word
       character*128 line
       integer       iline   , ifile   , next    , jbeg    , jend
     1             , jran    , i       , j       , j1      , j2
     2             , iadd    , nline   , nch     , match   , jbegm1
     3             , jendp1
c
       character*16  keywrd  (  12)
c
c      Data statements.
c
       data          keywrd
     1             / 'and             ', 'or              '
     2             , 'eq              ', 'ne              '
     3             , 'gt              ', 'ge              '
     4             , 'lt              ', 'le              '
     5             , 'not             ', '                '
     6             , '                ', '                ' /
c
c-----------------------------------------------------------------------
c
       nch   = len ( blanks )
       match = min0 ( nch, 9 )
c
c      Get "line".
c
       if (ifile .eq. 1) line = oldfile(iline+next)
       if (ifile .eq. 2) line = tmpfile(iline+next)
       if (ifile .eq. 3) line = cdkfile(iline+next)
       if (ifile .eq. 4) line = newfile(iline+next)
c
c      Determine "jbeg".  Read next line(s) if necessary.
c
10     continue
       j1   = jbeg
       if (jbeg .eq. 0) j1 =  1
       j2   = jend
       if (jend .eq. 0) j2 = nchar
c
       go to ( 20, 40, 60, 80, 100, 120, 140, 160, 180 ) match
c
20     continue
       char1 = blanks(1:1)
       do 30 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq.   ' ') ) go to 30
         jbeg = j
         go to 240
30     continue
       go to 210
c
40     continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       do 50 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq.   ' ') ) go to 50
         jbeg = j
         go to 240
50     continue
       go to 210
c
60     continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       char3 = blanks(3:3)
       do 70 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq.   ' ') ) go to 70
         jbeg = j
         go to 240
70     continue
       go to 210
c
80     continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       char3 = blanks(3:3)
       char4 = blanks(4:4)
       do 90 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq.   ' ') ) go to 90
         jbeg = j
         go to 240
90     continue
       go to 210
c
100    continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       char3 = blanks(3:3)
       char4 = blanks(4:4)
       char5 = blanks(5:5)
       do 110 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq.   ' ') ) go to 110
         jbeg = j
         go to 240
110    continue
       go to 210
c
120    continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       char3 = blanks(3:3)
       char4 = blanks(4:4)
       char5 = blanks(5:5)
       char6 = blanks(6:6)
       do 130 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq. char6) .or.
     3        (char0 .eq.   ' ') ) go to 130
         jbeg = j
         go to 240
130    continue
       go to 210
c
140    continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       char3 = blanks(3:3)
       char4 = blanks(4:4)
       char5 = blanks(5:5)
       char6 = blanks(6:6)
       char7 = blanks(7:7)
       do 150 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq. char6) .or.
     3        (char0 .eq. char7) .or. (char0 .eq.   ' ') ) go to 150
         jbeg = j
         go to 240
150    continue
       go to 210
c
160    continue
       char1 = blanks(1:1)
       char2 = blanks(2:2)
       char3 = blanks(3:3)
       char4 = blanks(4:4)
       char5 = blanks(5:5)
       char6 = blanks(6:6)
       char7 = blanks(7:7)
       char8 = blanks(8:8)
       do 170 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq. char6) .or.
     3        (char0 .eq. char7) .or. (char0 .eq. char8) .or.
     4        (char0 .eq.   ' ') ) go to 170
         jbeg = j
         go to 240
170    continue
       go to 210
c
180    continue
       do 200 j=j1,j2
         char0 = line(j:j)
         do 190 i=1,nch
           if (char0 .eq. blanks(i:i)) go to 200
190      continue
         if (char0 .eq. ' ') go to 200
         jbeg = j
         go to 240
200    continue
       go to 210
c
210    continue
       if (jend .ne. 0) go to 230
c
c      The only way for execution to have reached this point is for the
c  end of the line to have been reached without finding another "word".
c  Thus, see if the "next" line is a continuation of the present line,
c  and if it is, resume search for the next "word".
c
       iadd  = 0
220    continue
       iadd  = iadd + 1
       next  = next + 1
       nline = iline + next
       if (ifile .eq. 1) then
         if (nline .gt. nlold) go to 230
         line = oldfile(nline)
       endif
       if (ifile .eq. 2) then
         if (nline .gt. nltmp) go to 230
         line = tmpfile(nline)
       endif
       if (ifile .eq. 3) then
         if (nline .gt. nlcdk) go to 230
         line = cdkfile(nline)
       endif
       if (ifile .eq. 4) then
         if (nline .gt. nlnew) go to 230
         line = newfile(nline)
       endif
       if (line .eq. blank128) go to 220
       word4 = line(1:4)
       if ( (word4 .ne. 'c** ') .and. (word4 .ne. 'C** ') ) then
         char0 = line(1:1)
         if ( (char0 .eq. 'c') .or. (char0 .eq. 'C') .or.
     1        (char0 .eq. '*') ) go to 220
       endif
       char0 = line(6:6)
       if (char0 .ne. ' ') then
         jbeg = 7
         go to 10
       endif
       next = next - iadd
230    continue
       jend = jbeg
       word = blank16
       return
c
c      "jbeg" has been determined.  Now find "jend", which cannot be
c  greater than "jbeg + 15" or the input value of "jend".
c
240    continue
       j1   = jbeg + 1
       j2   = min0 ( nchar, jbeg + 15 )
       if ( (jend .ne. 0) .and. (j2 .gt. jend) ) j2 = jend
       jend = jbeg
c
       go to ( 250, 270, 290, 310, 330, 350, 370, 390, 410 ) match
c
250    continue
       do 260 j=j1,j2
         char0 = line(j:j)
         if (char0 .eq. char1) go to 440
         jend = j
260    continue
       go to 440
c
270    continue
       do 280 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) ) go to 440
         jend = j
280    continue
       go to 440
c
290    continue
       do 300 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) ) go to 440
         jend = j
300    continue
       go to 440
c
310    continue
       do 320 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) ) go to 440
         jend = j
320    continue
       go to 440
c
330    continue
       do 340 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) ) go to 440
         jend = j
340    continue
       go to 440
c
350    continue
       do 360 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq. char6) ) go to 440
         jend = j
360    continue
       go to 440
c
370    continue
       do 380 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq. char6) .or.
     3        (char0 .eq. char7) ) go to 440
         jend = j
380    continue
       go to 440
c
390    continue
       do 400 j=j1,j2
         char0 = line(j:j)
         if ( (char0 .eq. char1) .or. (char0 .eq. char2) .or.
     1        (char0 .eq. char3) .or. (char0 .eq. char4) .or.
     2        (char0 .eq. char5) .or. (char0 .eq. char6) .or.
     3        (char0 .eq. char7) .or. (char0 .eq. char8) ) go to 440
         jend = j
400    continue
       go to 440
c
410    continue
       do 430 j=j1,j2
         char0 = line(j:j)
         do 420 i=1,nch
           if (char0 .eq. blanks(i:i)) go to 440
420      continue
         jend = j
430    continue
       go to 440
c
440    continue
       jran = jend - jbeg + 1
       word = blank16
       word(1:jran) = line(jbeg:jend)
       jbegm1 = jbeg - 1
       jendp1 = jend + 1
       if ( (jbegm1 .ge. 1) .and. (jendp1 .le. nchar) ) then
         if ( (line(jbegm1:jbegm1) .eq. '.') .and.
     1        (line(jendp1:jendp1) .eq. '.') ) then
           do 450 i=1,12
             if (keywrd(i) .eq. blank16) return
             if (word .eq. keywrd(i)) go to 460
450        continue
           return
460        continue
           jbeg = jbegm1
           jend = jendp1
           jran = jend - jbeg + 1
           word = blank16
           word(1:jran) = line(jbeg:jend)
         endif
       endif
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                G E T W R D                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                I N O R E X                \\\\\\\\\\
c
c=======================================================================
c
       subroutine inorex ( i, ifile, level, nlf, lflag )
c
c    dac:editor.inorex <--------------- includes or excludes source code
c                                                         february, 1989
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c
c  PURPOSE:  In both COPY and NUMBER, it is necessary to know whether
c  the EDITOR conditionals include or exclude any section of the source
c  code.  Code that may be excluded by the EDITOR conditionals will not
c  be copied to "newfile" by COPY, and will not be labeled with
c  executable statement numbers by NUMBER.
c      When an EDITOR command is encountered by COPY or NUMBER (the
c  EDITOR * sentinel is found in column 1), this subroutine is called
c  and updates one element of the array "lflag".  If any one element of
c  "lflag" is ".false.", then the current line in the source code is
c  excluded by the calling routine.
c
c  NOTE:  This subroutine assumes that all alias substitutions have
c         already been performed.
c
c  INPUT VARIABLES:
c    i           current line number in "xxxfile".
c    ifile       =1 => "xxxfile" is "oldfile"
c                =2 => "xxxfile" is "tmpfile"
c                =3 => "xxxfile" is "cdkfile"
c    level       =1 => Exclude all source code bounded by false EDITOR
c                      conditionals.  Exclude EDITOR conditional
c                      statements (*if, *else, *endif, *define, and
c                      *alias), unless statement contains syntax errors.
c                      Exclude EDITOR comments (**).  Used by COPY when
c                      called from CDECKS.
c                =2 => In addition to level 1, exclude common decks and
c                      EDITOR module statements (*deck, *cdeck, *group),
c                      unless statement contains syntax errors.  Used
c                      by COPY when called by PRECOM.
c                =3 => Exclude all source code bounded by false EDITOR
c                      conditionals.  Exclude all EDITOR statements
c                      whether they have syntax errors or not.  Used by
c                      NUMBER.
c    nlf         number of flags already set (maximum = 12).
c    lflag       existing list of logical flags.
c
c  OUTPUT VARIABLES:
c    lflag       updated list of logical flags.
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    GETWRD
c    ERRSET
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       ltemp
       character*1   char1
       character*16  wrd1    , wrd2    , subnm1  , subnm2
       character*128 line
       integer       i       , ifile   , level   , nlf
       integer       next    , jbeg    , jend    , jran    , match
     1             , k       , icomp   , isw     , ilw     , ierr
c
       logical       lflag   (  13)
       character*16  keywrd  (  28)
c
c       External statements
c
       external      getwrd  , errset
c
c      Data statements.
c
       data          keywrd
     1             / 'define          ', 'def             '
     2             , '-define         ', '-def            '
     3             , 'alias           ', 'al              '
     4             , 'if              ', 'else            '
     5             , 'el              ', 'endif           '
     6             , 'ei              ', 'cdeck           '
     7             , 'cd              ', 'deck            '
     8             , 'dk              ', 'call            '
     9             , 'ca              ', 'group           '
     1             , 'gp              ', 'error           '
     2             , '                ', '                '
     3             , '                ', '.not.           '
     4             , '.and.           ', '.or.            '
     5             , '.eq.            ', '.ne.            ' /
c
c-----------------------------------------------------------------------
c
c  FOR level 1:
c
c  - "lflag(1)" is set to .false. if the line is an EDITOR command other
c        than *deck, *cdeck, *group, *call, or *error.
c
c  - "lflag(2)" is always .true..
c
c  FOR level 2:
c
c  - "lflag(1)" is set to .false. if the line is an EDITOR command other
c        than *call, or *error.
c
c  - "lflag(2)" is .true. if the line belongs to an ordinary deck and
c        .false. if it belongs to a common deck.
c
c  FOR level 3:
c
c  - "lflag(1)" is set to .false. for all EDITOR commands.
c
c  - "lflag(2)" is always .true..
c
c  FOR all levels:
c
c  - "lflag(i=3,12)" allow the line to be buried in as many as 10
c        nested EDITOR conditionals based on whether a switch is
c        defined, or on how an alias is defined.
c
c  - "lflag(13)" is .true. only if the line contains a detected error.
c
       lflag( 1) = .false.
       lflag(13) = .false.
       if ( (level .eq. 1) .or. (level .eq. 3) ) lflag(2) = .true.
       if (ifile .eq. 1) line = oldfile(i)
       if (ifile .eq. 2) line = tmpfile(i)
       if (ifile .eq. 3) line = cdkfile(i)
c
c      Ignore EDITOR comments.  The *$ and c$ are fossils of Sasha's
c  attempt account for watcom Fortran, which has since been expunged.
c
       if (line(1:2) .eq. '**') go to 140
       if ( (line(1:2) .eq. '*$') .or. (line(1:2) .eq. 'c$') ) go to 140
c
c      Determine which EDITOR command has been found.
c
       next = 0
       jbeg = 2
       jend = 9
       call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', wrd1 )
c
c      Peel off last character if it is an integer between 0 and 9
c  (this allows HISTORAN *if0, etc. commands to be interpreted).
c
       char1 = wrd1(jran:jran)
       if ( (char1 .ge. '0') .and. (char1 .le. '9') ) then
         wrd2 = wrd1
         wrd1 = blank16
         wrd1(1:jran-1) = wrd2(1:jran-1)
       endif
       match = 0
       do 10 k=1,28
         if ( (wrd1 .ne. blank16) .and. (wrd1 .eq. keywrd(k)) ) go to 20
10     continue
       go to 30
20     continue
       if   (k .le.  6)                    match = 1
       if   (k .eq.  7)                    match = 2
       if ( (k .eq.  8) .or. (k .eq.  9) ) match = 3
       if ( (k .eq. 10) .or. (k .eq. 11) ) match = 4
       if ( (k .eq. 12) .or. (k .eq. 13) .or.
     1      (k .eq. 14) .or. (k .eq. 15) ) match = 5
       if ( (k .eq. 16) .or. (k .eq. 17) .or.
     1      (k .eq. 20)                  ) match = 6
       if ( (k .eq. 18) .or. (k .eq. 19) ) match = 7
       go to (140, 40, 80, 90, 100, 120, 130) match
c
c      Unrecognised EDITOR command.  Issue error message.
c
30     continue
       call errset ( i, 13, 2 )
       go to 140
c
c      An *if statement.
c
40     continue
       nlf = nlf + 1
       if (nlf .gt. 12) then
         nlf = 12
         call errset ( i, 14, 2 )
         go to 140
       endif
       jbeg = jend + 1
       jend = nchar
       next = 0
       call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', wrd1 )
       if (wrd1 .eq. blank16) then
         call errset ( i, 15, 2 )
         go to 140
       endif
       if ( (wrd1 .eq. keywrd(1)) .or. (wrd1 .eq. keywrd(2)) .or.
     1      (wrd1 .eq. keywrd(3)) .or. (wrd1 .eq. keywrd(4)) ) then
c
c      An *if define or an *if -define statement.
c
         lflag(nlf) = .false.
         icomp = 1
50       continue
         jbeg = jend + 1
         jend = nchar
         next = 0
         call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', subnm1 )
         if (subnm1 .eq. blank16) then
           call errset ( i, 15, 2 )
           lflag(nlf) = .true.
           go to 140
         endif
         if (subnm1 .eq. keywrd(24)) then
           wrd2 = wrd1
           if ( (wrd2 .eq. keywrd(1)) .or. (wrd2 .eq. keywrd(2)) )
     1       wrd1 = keywrd(3)
           if ( (wrd2 .eq. keywrd(3)) .or. (wrd2 .eq. keywrd(4)) )
     1       wrd1 = keywrd(1)
           go to 50
         endif
         if (icomp .eq. 1) then
           do 60 isw=1,nswitch
             if (subnm1 .eq. swtch1(isw)) lflag(nlf) = .true.
60         continue
         endif
         jbeg = jend + 1
         jend = nchar
         next = 0
         call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', wrd2 )
         if (wrd2 .eq. blank16) go to 70
         if (wrd2 .eq. keywrd(25)) then
           if (lflag(nlf)) then
             lflag(nlf) = .false.
             icomp = 1
           else
             icomp = 0
           endif
           go to 50
         endif
         if (wrd2 .eq. keywrd(26)) then
           if (lflag(nlf)) then
             icomp = 0
           else
             icomp = 1
           endif
           go to 50
         endif
c
c      The only way for execution to reach this point is if the next
c  word was not Boolean .and. or Boolean .or..  Issue error message.
c
         call errset ( i, 16, 2 )
         lflag(nlf) = .true.
         go to 140
c
c      If the EDITOR command was *if -define, reverse the truth value
c  of "lflag(nlf)".
c
70       continue
         if ( (wrd1 .eq. keywrd(3)) .or. (wrd1 .eq. keywrd(4)) ) then
           if (      lflag(nlf)) ltemp = .false.
           if (.not. lflag(nlf)) ltemp = .true.
           lflag(nlf) = ltemp
         endif
         go to 140
       endif
c
c      An *if alias statement.
c
       if ( (wrd1 .eq. keywrd(5)) .or. (wrd1 .eq. keywrd(6)) ) then
         jbeg = jend + 1
         jend = nchar
         next = 0
         call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', subnm1 )
         if (subnm1 .eq. blank16) then
           call errset ( i, 15, 2 )
           lflag(nlf) = .true.
           go to 140
         endif
         jbeg = jend + 1
         jend = nchar
         next = 0
         call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', wrd2 )
         if ( (wrd2 .ne. keywrd(27)) .and. (wrd2 .ne. keywrd(28)) ) then
           call errset ( i, 17, 2 )
           lflag(nlf) = .true.
           go to 140
         endif
         jbeg = jend + 1
         jend = nchar
         next = 0
         call getwrd ( i, ifile, next, jbeg, jend, jran, ' ,.', subnm2 )
         if (subnm2 .eq. blank16) then
           call errset ( i, 15, 2 )
           lflag(nlf) = .true.
           go to 140
         endif
         if ( (wrd2 .eq. keywrd(27)) .and. (subnm1 .ne. subnm2) )
     1     lflag(nlf) = .false.
         if ( (wrd2 .eq. keywrd(28)) .and. (subnm1 .eq. subnm2) )
     1     lflag(nlf) = .false.
         go to 140
       endif
c
c      The only way for execution to arrive here is if the *if was
c  was followed by something other than a "define" or an "alias".
c  Issue an error message.
c
       call errset ( i, 13, 2 )
       go to 140
c
c      An *else statement.  An "else" reverses the truth of lflag(nlf).
c
80     continue
       if (      lflag(nlf)) ltemp = .false.
       if (.not. lflag(nlf)) ltemp = .true.
       lflag(nlf) = ltemp
       go to 140
c
c      An *endif statement.  An "endif" sets lflag(nlf) back to .true..
c
90     continue
       lflag(nlf) = .true.
c
c      If nlf .lt. 3, then too many *endif's have been found.
c
       if (nlf .lt. 3) then
         call errset ( i, 18, 2 )
         go to 140
       endif
       nlf = nlf - 1
       go to 140
c
c      A "common deck" or an ordinary "deck".
c
100    continue
       if (level .eq. 1) lflag(1) = .true.
c
c      If nlf .gt. 2, then too few *endif's have been found in the
c  previous deck.  Issue an error message.
c
       if (nlf .gt. 2) call errset ( i, 19, 2 )
       do 110 ilw=3,12
         lflag(ilw) = .true.
110    continue
       nlf  = 2
       if (level .eq. 2) then
         if (wrd1(1:1) .eq. 'c') lflag(2) = .false.
         if (wrd1(1:1) .eq. 'd') lflag(2) = .true.
       endif
       go to 140
c
c      A "call" or "error" statement.
c
120    continue
       if ( (level .eq. 1) .or. (level .eq. 2) ) lflag(1) = .true.
       go to 140
c
c      A "group" statement.
c
130    continue
       if (level .eq. 1) lflag(1) = .true.
       go to 140
c
c      Check for any errors associated with this EDITOR statement.
c
140    continue
       if (level .eq. 3) return
       wrd1 = blank16
       if (ifile .eq. 1) wrd1(1:5) = oldfile(i+1)(1:5)
       if (ifile .eq. 2) wrd1(1:5) = tmpfile(i+1)(1:5)
       if (ifile .eq. 3) wrd1(1:5) = cdkfile(i+1)(1:5)
       if (wrd1(1:5) .eq. '*erro') then
         lflag(13) = .true.
         return
       endif
       do 150 ierr=1,nerr2
         if (lnerr2(ierr) .eq. i) then
           lflag(13) = .true.
           return
         endif
150    continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                I N O R E X                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  I T O C                  \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine itoc ( int, word, lorr )
c
c    dac:editor.itoc <----------- translates integer to character string
c                                                             july, 1987
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine translates an integer into a character
c  string, which can be either left- ot right-justified.
c
c  INPUT VARIABLES:
c    int         integer to be converted to a character string.
c    lorr        = 1  =>  left-justified.
c                = 2  =>  right-justified.
c
c  OUTPUT VARIABLES:
c    word        character*16 string
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*16  word    , blank16
       integer       int     , lorr
       integer       ilog    , j       , jbeg    , jend    , jj
       real          x       , xlog    , x1
c
       character*1   ch      (  10)
c
c      Data statements.
c
       data          ch
     1             / '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' /
       data          blank16  / '                ' /
c
c-----------------------------------------------------------------------
c
       x    = float(int)
       xlog = alog10(x)
       ilog = ifix (xlog + .000001)
c
c    "jbeg" and "jend" for right justified character string.
c
       if (lorr .eq. 2) then
         jbeg = 16 - ilog
         jend = 16
c
c    "jbeg" and "jend" for left justified character string.
c
       else
         jbeg = 1
         jend = 1 + ilog
       endif
c
       if (jbeg .lt.  1) go to 20
       if (jend .gt. 16) go to 20
       word = blank16
       do 10 j=jbeg,jend
         x1   = x / 10**ilog
         jj   = ifix ( x1 + .000001 )
         word(j:j) = ch(jj+1)
         x    = x - float(jj) * 10**ilog
         ilog = ilog - 1
10     continue
       return
c
20     continue
       word = '****************'
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  I T O C                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                I X E Q O S                \\\\\\\\\\
c
c=======================================================================
c
       function ixeqos ( command )
c
c    dac:editor.ixeqos <------------------------ issues a system command
c                                                            march, 2011
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This function issues a unix command via the compiler-
c  dependent system call.
c
c  INPUT VARIABLES:
c    command     character string containing command to be issued.
c
c  OUTPUT VARIABLES:
c    ixeqos      status code
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    compiler-specific system-call function
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*(*) command
       integer       ixeqos  , system
c
c-----------------------------------------------------------------------
c
       ixeqos = system ( command )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                I X E Q O S                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                S T R L E N                \\\\\\\\\\
c
c=======================================================================
c
       function strlen ( word )
c
c    dac:editor.strlen <--------------------- length of character string
c                                                         february, 1992
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE: This function returns the number of characters in the
c  character string "word".  Note that PSPLOT has a function LENSTR with
c  essentially the same purpose.
c
c  INPUT VARIABLES:
c    word        input character*(*) string
c
c  OUTPUT VARIABLES:
c    strlen      number of characters up to and including the last
c                non-blank character in "word"
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*(*) word
       integer       strlen  , i       , imax
c
c-----------------------------------------------------------------------
c
       imax   = len ( word )
       strlen = 0
       do 10 i=1,imax
         if (word(i:i) .ne. ' ') strlen = i
10     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                S T R L E N                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  L I S T                  \\\\\\\\\\
c
c=======================================================================
c
       subroutine list ( iline, lnbad, ifile, jopen, jclose
     1                 , iopen, iclose )
c
c    dac:editor.list <--------------- determines range of parameter list
c                                                          october, 1988
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine returns the positions of the beginning and
c  end of a parameter list that is enclosed in parentheses which starts
c  after the input position "jopen" on the current line of the text file
c  specified by "ifile".  The first opening parenthesis is at the output
c  position "jopen" on line "iopen" while the final closing parenthesis
c  is at position "jclose" on line "iclose".
c
c  INPUT VARIABLES:
c    iline       line number of file.
c    lnbad       line number to use if an error is detected.
c    ifile       =1 => read "line" from "oldfile".
c                =2 => read "line" from "tmpfile".
c                =3 => read "line" from "cdkfile".
c                =4 => read "line" from "newfile".
c    jopen       column after which search for opening parenthesis is
c                begun
c
c  OUTPUT VARIABLES:
c    jopen       opening parenthesis is located at column "jopen" on
c    iopen       line "iopen".
c    jclose      closing parenthesis is located at column "jclose" on
c    iclose      line "iclose".  "jclose" is set to zero if there is no
c                parameter list.
c
c  LOCAL VARIABLES:
c    char1       current character (character*1)
c    word        current word (character*16)
c    line        current line (character*128)
c
c  EXTERNALS:
c    ERRSET
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*16  word
       character*128 line
       integer       iline   , lnbad   , ifile   , jopen   , jclose
     1             , iopen   , iclose  , ierr
       integer       j       , j1      , j2      , nparen  , nquote
     1             , ndblqt  , int1    , int2    , iadd
c
c      External statements
c
       external      errset
c
c-----------------------------------------------------------------------
c
       if (ifile .eq. 1) line = oldfile(iopen)
       if (ifile .eq. 2) line = tmpfile(iopen)
       if (ifile .eq. 3) line = cdkfile(iopen)
       if (ifile .eq. 4) line = newfile(iopen)
10     continue
       j1 = jopen
       j2 = nchar
       do 20 j=j1,j2
         jopen = j
         char1 = line(j:j)
         if (char1 .eq. '(') go to 40
         if ( (char1 .ne. ' ') .and. (char1 .ne. '(') ) go to 30
20     continue
c
c      The only way for execution to come here is if all characters
c  after the input position of "jopen" are blanks.  In this case, the
c  next line is read, and if it is a continuation line, the search for
c  a "(" is resumed.
c
       iopen = iopen + 1
       if (ifile .eq. 1) line = oldfile(iopen)
       if (ifile .eq. 2) line = tmpfile(iopen)
       if (ifile .eq. 3) line = cdkfile(iopen)
       if (ifile .eq. 4) line = newfile(iopen)
       word = blank16
       word(1:5) = line(1:5)
       char1 = line(6:6)
       if ( (char1 .ne. ' ') .and. (word .eq. blank16) ) then
         jopen = 7
         go to 10
       endif
       iopen = iopen - 1
c
c      There is no parameter list.  Return execution to calling program.
c
30     continue
       jclose = 0
       return
c
c      "jopen" has been established.  Now find the end of the parameter
c  list by counting parentheses.  For each "(", add 1 to "nparen".  For
c  each ")", subtract 1 from "nparen".  Do not count any "(" or ")" that
c  lie inside quotation marks (' or ").  When "nparen = 0", the end of
c  the list has been found.
c
40     continue
       iclose = iopen
       nparen = 0
       nquote = 0
       ndblqt = 0
       j1     = jopen
       j2     = nchar
50     continue
       do 60 j=j1,j2
         jclose = j
         char1  = line(j:j)
         int1   = 2 * ifix ( float(nquote) / 2.0 + 0.1 )
         int2   = 2 * ifix ( float(ndblqt) / 2.0 + 0.1 )
         iadd   = 1
         if ( (int1 .ne. nquote) .or. (int2 .ne. ndblqt) ) iadd = 0
         if (char1 .eq. '(') nparen = nparen + iadd
         if (char1 .eq. ')') nparen = nparen - iadd
         if ( (char1 .eq. '''') .and. (int2 .eq. ndblqt) )
     1     nquote = nquote + 1
         if ( (char1 .eq. '"') .and. (int1 .eq. nquote) )
     1     ndblqt = ndblqt + 1
         if (nparen .eq. 0) go to 70
60     continue
c
c      The only way for execution to come here is if the end of the line
c  has been found without finding the end of the parameter list.  Thus,
c  read the next line, and if it is a continuation line, resume the
c  search.
c
       iclose = iclose + 1
       if (ifile .eq. 1) line = oldfile(iclose)
       if (ifile .eq. 2) line = tmpfile(iclose)
       if (ifile .eq. 3) line = cdkfile(iclose)
       if (ifile .eq. 4) line = newfile(iclose)
       word = blank16
       word(1:5) = line(1:5)
       char1 = line(6:6)
       if ( (char1 .ne. ' ') .and. (word .eq. blank16) ) then
         j1 = 7
         go to 50
       endif
       iclose = iclose - 1
c
c      Parentheses in parameter list are unbalanced.  Issue an error
c  code.
c
       ierr = 2
       if (job .eq. 2) ierr = 1
       if (lnbad .gt. 0) call errset ( lnbad, 20, ierr )
       jclose = 0
c
c      Return execution to calling program.
c
70     continue
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  L I S T                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               M R G N M B R               \\\\\\\\\\
c
c=======================================================================
c
       subroutine mrgnmbr
c
c    dac:editor.mrgnmbr <---------------- inserts line numbers for MERGE
c                                                        september, 1989
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE:  This subroutine numbers the lines in the text file
c  "oldfile" so that MERGE can insert the changes at the desired lines.
c  Columns 1-72 are reserved for the line itself, while the number of
c  lines since the last *dk or *cd is put in columns 76-80.  This
c  subroutine assumes that COLLECT has already been called.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    GETWRD
c    ITOC
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*16  word
       character*128 line
       integer       i       , isub    , jbeg    , jend    , jran
     1             , next
c
       character*16  keywrd  (4)
c
c      External statements
c
       external      getwrd  , itoc
c
c      Data statements
c
       data          keywrd
     1             / 'dk              ', 'deck            '
     2             , 'cd              ', 'cdeck           ' /
c
c-----------------------------------------------------------------------
c
c      Number the lines presently in "oldfile".
c
       isub = 0
       do 10 i=1,nlold
         line        = blank128
         line( 1:72) = oldfile(i)(1:72)
         isub        = isub + 1
         if (line(1:1) .eq. '*') then
           jbeg = 2
           jend = 6
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,.', word )
c
c      Reset deck number ("isub") if an EDITOR *deck, *dk, *cdeck, or
c  a *cd command is encountered.
c
           if ( (word .eq. keywrd(1)) .or. (word .eq. keywrd(2)) .or.
     1          (word .eq. keywrd(3)) .or. (word .eq. keywrd(4)) )
     2       isub = 1
         endif
         call itoc ( isub, word, 2 )
         line(76:80) = word(12:16)
         oldfile(i)  = line
10     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               M R G N M B R               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////                N M L S T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine nmlst
c
c    dac:editor.nmlst <------------------ replaces CTSS NAMELIST fortran
c                                                              may, 1989
c
c    written by: David Clarke
c    modified 1: October 1989 by David Clarke; Reworked to allow partial
c                reads of input file.
c    modified 2: February 1991 by David Clarke; enabled PRINT and WRITE
c                statements.
c
c  PURPOSE:  Yet another obnoxious "feature" of CFT77 is its incredibly
c  stupid excuse for NAMELIST.  With this compiler, one cannot have
c  comments, define character constants, nor define vectors and arrays
c  easily.  This subroutine scans the source code in "oldfile" for
c  occurances of NAMELIST and the accompanying READ's and WRITE's.  When
c  a NAMELIST is found, it is replaced with calls to various subroutines
c  found in the library NAMELIST.LIB, which must be linked to the object
c  file after compilation.  Similarly, the accompanying READ is replaced
c  with calls to subroutines found in the same library.  For every
c  variable declared in the NAMELIST, this subroutine will insert a
c  little more than two lines of FORTRAN.
c      There are several considerations that must be met when using
c  EDITOR NAMELIST.  In the source code itself, there must be no
c  variable with the name "namelist".  Second, the subroutines in
c  NAMELIST.LIB are all named NLSDACxx, where xx ranges from 01 to 24.
c  Consequently, no user supplied subroutines should use these names.
c  Third, the READ statement must appear after the defining NAMELIST
c  and before the next NAMELIST.  It may appear an arbitrary number of
c  times, so long as they are all positioned accordingly.
c      The NAMELIST statements are "interpreted" by passing the source
c  code through the PRECOMpiler ("job" = 4) with the option "inmlst"
c  set to some integer greater than 0.  The value of the integer will
c  determine the maximum number of assignments that will be permitted
c  per NAMELIST in the input deck (note that this could be substantially
c  more than the number of variables declared in the NAMELIST itself if
c  many portions of arrays are to be set to different values).  Setting
c  "inmlst" to 1 invokes the default (1000), which should allow plenty
c  of assignments for most applications.  Setting "inmlst" to 0 turns
c  the NAMELIST feature of EDITOR off, appropriate for operating systems
c  (such as CTSS) with sensible NAMELIST's.
c      The use of the EDITOR NAMELIST should then be transparent to
c  those who used NAMELIST under CTSS CFT.  In the source code itself,
c  the same syntax is used.  Variables of all attributes (character,
c  integer, real, and logical) and three different dimensions (scalar,
c  vector, and 2-D array) can be assigned.  For example, there are
c  three ways to specify vector(10) in an input deck:
c
c  1.  vector(1)=5*1.0, vector(6)=3*2.0, vector(9)=2*3.0
c  2.  vector(1:5)=1.0, vector(6:8)=2.0, vector(9:10)=3.0
c  3.  vector = 1.0, 1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 3.0
c
c  Note that the "(1)" in the first specification in the first method
c  is optional.  2-D arrays may be specified in an analogous way to the
c  second method for vectors.
c
c      array(1: 5,1: 5) = 1.0, array(1: 5,6:10) = 2.0,
c      array(6:10,1: 5) = 3.0, array(6:10,6:10) = 4.0
c
c  Character strings can be specified in the input deck by surrounding
c  the text in single quotes (eg, 'editor') or double quotes (eg,
c  "editor").  Hollerith format is NOT supported.  Legal logical values
c  are .true. and .false..  There are a multitude of readable error
c  messages that appear on the crt should a deviation from the rules
c  be detected.  Execution of the program terminates at the first
c  NAMELIST error found, so it may take several starts before all the
c  errors in the user-supplied input deck are found.
c      The input deck for the NAMELIST is the same as for CTSS.  Data
c  for each NAMELIST must begin with a $ sentinel in column 2, followed
c  by the name of the namelist itself.  The variable assignments follow,
c  each separated from the next by a comma, and can extend to as many
c  lines as needed.  A $ sentinel must follow the last assignment, and
c  must appear at or before column 72.  Only as many as "inmlst"
c  assignments may be made per namelist.  Statements can be "commented
c  out" by flagging the line with a "c" in column 1.  The order in which
c  the NAMELIST data appear in the input deck should be the same as the
c  order in which the READ's are encountered in the source code.  Data
c  that are out of order will not be read.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    GETWRD
c    OVERFLOW
c    ERRSET
c    GETCHR
c    LIST
c    ERRWRT
c    CAPITALS
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1   , char2
       character*2   word2
       character*4   word4
       character*8   word8   , lunit
       character*16  word    , tmpwrd  , namenl
       character*128 line
       integer       i       , ndeck   , jbeg    , jend    , next
     1             , jran    , iwrd    , ideck   , ibeg    , iline
     2             , ifpend  , iend    , nltot   , nlist   , lnbad
     3             , insert  , k       , ierr    , i1      , i2
     4             , match   , ilist   , jopen   , jclose  , iopen
     5             , iclose
c
       character*16  keywrd  (  20)
       character*32  nmlist  (  k9)
c
c      External statements
c
       external      getwrd  , overflow, errset  , getchr  , list
     1             , errwrt  , capitals
c
c      Data Statements
c
       data          keywrd
     1   / 'PROGRAM         ', 'SUBROUTINE      ', 'FUNCTION        '
     2   , 'IMPLICIT        ', 'PARAMETER       ', 'DIMENSION       '
     3   , 'REAL            ', 'INTEGER         ', 'LOGICAL         '
     4   , 'CHARACTER       ', 'COMMON          ', 'EQUIVALENCE     '
     5   , 'EXTERNAL        ', 'DATA            ', 'SAVE            '
     6   , 'NAMELIST        ', 'IF              ', 'READ            '
     7   , 'PRINT           ', 'WRITE           ' /
c
c-----------------------------------------------------------------------
c
c      Copy contents of "newfile" to "oldfile".
c
       do 10 i=1,nlnew
         oldfile(i) = newfile(i)
10     continue
       nlold = nlnew
c
c      Gather module limits and store them in "idksta" and "idkfin".
c
       ndeck = 0
       do 50 i=1,nlold
         if (oldfile(i)(1:6) .eq. '      ') then
           jbeg = 7
           jend = nchar
           next = 0
20         continue
           call getwrd ( i, 1, next, jbeg, jend, jran, ' *(', word )
           call capitals ( word )
           do 30 iwrd=1,10
             if (word .eq. keywrd(iwrd)) go to 40
30         continue
40         continue
           if ( (iwrd .ge. 1) .and. (iwrd .le. 3) ) then
             ndeck = ndeck + 1
             idksta(ndeck) = i
           endif
           if ( (iwrd .ge. 7) .and. (iwrd .le. 10) ) then
             if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
               jbeg = jend + 1
               jend = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
             endif
             jbeg = jend + 1
             jend = 0
             go to 20
           endif
         endif
         if ( (i .eq. 1) .and. (ndeck .eq. 0) ) then
           ndeck     = 1
           idksta(1) = 1
         endif
         idkfin(ndeck) = i
50     continue
c
c      Initialise variables.
c
       do 60 i=1,iemax
         lnerr2(i) = 0
         ierr2 (i) = 0
60     continue
       nerr2  = 0
       ideck  = 1
       ibeg   = idksta(1)
       iline  = 1
       nlnew  = 0
       namenl = blank16
c
c      Scan "oldfile" for occurances of NAMELIST and associated READ's,
c  PRINT's and WRITE's.
c
c      ENTERING MAIN LOOP . . . .
c
70     continue
c
       ifpend = 0
       if (iline .eq. idkfin(ideck) ) then
         iend  = iline
         nltot = nlnew + iend - ibeg + 1
         if (nltot .gt. ilmax) call overflow ( 4, 4 )
         do 80 i=ibeg,iend
           nlnew = nlnew + 1
           newfile(nlnew) = oldfile(i)
80       continue
         ideck  = ideck + 1
         if (ideck .gt. ndeck) go to 270
         iline  = iline + 1
         ibeg   = idksta(ideck)
         namenl = blank16
         go to 70
       endif
       if (oldfile(iline)(1:6) .ne. '      ') go to 260
       jbeg = 7
       jend = nchar
       next = 0
       call getwrd ( iline, 1, next, jbeg, jend, jran, ' *(/', word )
       call capitals ( word )
       if (word .eq. keywrd(16)) then
c
c      A NAMELIST statement has been encountered.  First determine the
c  name of the NAMELIST (which must be enclosed by forward slash (/)
c  delimiters), and store it in "namenl".
c
         nlist = 0
         jbeg  = jend + 1
         jend  = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ', word )
         char1 = word(1:1)
         if (char1 .ne. '/') then
c
c      ERROR:  missing opening delimiter /
c
           lnbad = nlnew + iline + next - ibeg + 1
           call errset ( lnbad, 27, 2 )
           go to 260
         endif
         jbeg   = jbeg + 1
         jend   = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ', word )
         char1  = word(jran:jran)
         if (char1 .eq. '/') then
           word(jran:jran) = ' '
           jran = jran - 1
           jend = jend - 1
         endif
         namenl = word
         jbeg   = jend + 1
         jend   = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ', word )
         char1  = word(1:1)
         if (char1 .ne. '/') then
c
c      ERROR:  missing closing delimiter /
c
           lnbad = nlnew + iline + next - ibeg + 1
           call errset ( lnbad, 28, 2 )
           go to 260
         endif
         jend = jbeg
c
c      Next, store the list of variables in the character*32 vector
c  "namelist".
c
90       continue
         jbeg  = jend + 1
         jend  = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ,', word )
         if (word .eq. blank16) go to 100
         nlist = nlist + 1
         if (nlist .gt. ivmax) then
c
c      ERROR:  too many variables listed.  Increase "k9" ("ivmax").
c
           nlist = ivmax
           lnbad = nlnew + iline + next - ibeg + 1
           call errset ( lnbad, 29, 2 )
         endif
         if (nlist .gt. inmlst) then
c
c      ERROR:  too many variables listed.  Increase "inmlst".
c
           nlist = inmlst
           lnbad = nlnew + iline + next - ibeg + 1
           call errset ( lnbad, 30, 2 )
         endif
         nmlist(nlist) = blank32
         nmlist(nlist)(1:16) = word
         go to 90
100      continue
         if (nlist .eq. 0) then
c
c      ERROR:  No variables specified in NAMELIST.
c
           lnbad = nlnew + iline + next - ibeg + 1
           call errset ( lnbad, 31, 2 )
           go to 260
         endif
         iend  = iline - 1
         iline = iline + next + 1
c
c      Find the last line in the opening declarations.  The declaration
c  for "namelist" will be put after this line.
c
         if (ibeg .eq. idksta(ideck)) then
           insert = ibeg
           do 120 i=ibeg,iend
             char1 = oldfile(i)(1:1)
             if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') .or.
     1            (char1 .eq. '*') ) go to 120
             char1 = oldfile(i)(6:6)
             if (char1 .ne. ' ') then
               insert = i
               go to 120
             endif
             jbeg = 7
             jend = nchar
             next = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' (*/', word )
             call capitals ( word )
             do 110 k=1,13
               if ( (word .eq. keywrd(k)) .or.
     1              (word .eq. blank16  ) ) then
                 insert = i
                 go to 120
               endif
110          continue
             go to 130
120        continue
         endif
130      continue
c
c      Copy "oldfile" from one line after last line copied to one line
c  before occurance of NAMELIST to "newfile".  Insert declaration of
c  "namelist" and external statements after line "insert" if "ibeg" =
c  "idksta(ideck)".
c
         nltot = nlnew + iend - ibeg + 1
         if (nltot .gt. ilmax) call overflow ( 4, 4 )
         do 150 i=ibeg,iend
           nlnew = nlnew + 1
           newfile(nlnew) = oldfile(i)
           if ( (ibeg .eq. idksta(ideck)) .and. (i .eq. insert) ) then
             nltot = nltot + 6
             if (nltot .gt. ilmax) call overflow ( 4, 4 )
             line  = blank128
             write (line, 2010) inmlst
             nlnew = nlnew + 1
             newfile(nlnew) = line
             write (line, 2020)
             nlnew = nlnew + 1
             newfile(nlnew) = line
             write (line, 2030)
             nlnew = nlnew + 1
             newfile(nlnew) = line
             write (line, 2040)
             nlnew = nlnew + 1
             newfile(nlnew) = line
             write (line, 2050)
             nlnew = nlnew + 1
             newfile(nlnew) = line
             write (line, 2060)
             nlnew = nlnew + 1
             newfile(nlnew) = line
             do 140 ierr=1,nerr2
               if (lnerr2(ierr) .ge. nlnew)
     1           lnerr2(ierr) = lnerr2(ierr) + 6
140          continue
           endif
150      continue
         ibeg = iline
c
c      Scan declarations at beginning of module for attributes and
c  dimensions of variables in "namelist".
c
         i1 = idksta(ideck) + 1
         i2 = iend
         do 200 i=i1,i2
           if (oldfile(i)(1:6) .ne. '      ') go to 200
           jbeg = 7
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' *', word )
           if (word .eq. blank16) go to 200
           call capitals ( word )
           if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
             jbeg = jend + 1
             jend = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ', tmpwrd )
           endif
c
c  First, the attributes (c, i, r, or l) ...
c
           match = 1
           do 160 iwrd=1,15
             if (word .eq. keywrd(iwrd)) go to 170
160        continue
170        continue
           if   (iwrd .le.  5)                        match = 2
           if ( (iwrd .ge. 12) .and. (iwrd .le. 15) ) match = 2
           if ( (iwrd .eq.  6) .or.  (iwrd .eq. 11) ) match = 3
           if   (iwrd .eq.  7)                        match = 4
           if   (iwrd .eq.  8)                        match = 5
           if   (iwrd .eq.  9)                        match = 6
           if   (iwrd .eq. 10)                        match = 7
           go to (210, 200, 180, 180, 180, 180, 180) match
180        continue
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()=', word )
           if (word .eq. blank16) go to 200
           do 190 ilist=1,nlist
             if (word .eq. nmlist(ilist)(1:16)) then
               if (nmlist(ilist)(30:30) .ne. ' ') go to 180
               if (match .eq. 4) char1 = 'r'
               if (match .eq. 5) char1 = 'i'
               if (match .eq. 6) char1 = 'l'
               if (match .eq. 7) char1 = 'c'
               if (match .eq. 3) then
                 char2 = word(1:1)
                 if ( (char2 .ge. 'a') .and. (char2 .le. 'h') )
     1             char1 = 'r'
                 if ( (char2 .ge. 'A') .and. (char2 .le. 'H') )
     1             char1 = 'r'
                 if ( (char2 .ge. 'i') .and. (char2 .le. 'n') )
     1             char1 = 'i'
                 if ( (char2 .ge. 'I') .and. (char2 .le. 'N') )
     1             char1 = 'i'
                 if ( (char2 .ge. 'o') .and. (char2 .le. 'z') )
     1             char1 = 'r'
                 if ( (char2 .ge. 'O') .and. (char2 .le. 'Z') )
     1             char1 = 'r'
               endif
               nmlist(ilist)(30:30) = char1
c
c  Then, the dimension (s, v, or a) ...
c
               jbeg = jend + 1
               call getchr ( oldfile(i+next), jbeg, char1, 1 )
               if ( (char1 .eq. ',') .or. (char1 .eq. ' ') .or.
     1              (jbeg .gt. nchar) ) then
                 nmlist(ilist)(32:32) = 's'
                 if (jbeg .gt. nchar) jbeg = nchar
                 go to 180
               endif
               if (char1 .eq. '(') then
                 jbeg = jbeg + 1
                 jend = 0
                 call getwrd ( i, 1, next, jbeg, jend, jran, ' ,()'
     1                       , word )
                 nmlist(ilist)(25:28) = word(1:4)
                 jbeg = jend + 1
                 call getchr ( oldfile(i+next), jbeg, char1, 1 )
                 jend = jbeg
                 if (char1 .eq. ')') then
                   nmlist(ilist)(32:32) = 'v'
                   go to 180
                 endif
                 if (char1 .eq. ',') then
                   nmlist(ilist)(32:32) = 'a'
                   go to 180
                 endif
               endif
c
c      ERROR:  unrecognised syntax
c
               lnbad = nlnew - i2 + i
               call errset ( lnbad, 32, 2 )
               go to 200
             endif
190        continue
           go to 180
200      continue
210      continue
c
c      For variables in the namelist not found in the declarations,
c  assign integer (i) to those beginning with letters i to n, and real
c  (r) to all others.  Assign scalar (s) dimension to all undeclared
c  variables.
c
         do 220 ilist=1,nlist
           if (nmlist(ilist)(29:32) .eq. '    ') then
             char2 = nmlist(ilist)(1:1)
             if ( (char2 .ge. 'a') .and. (char2 .le. 'h') ) char1 = 'r'
             if ( (char2 .ge. 'A') .and. (char2 .le. 'H') ) char1 = 'r'
             if ( (char2 .ge. 'i') .and. (char2 .le. 'n') ) char1 = 'i'
             if ( (char2 .ge. 'I') .and. (char2 .le. 'N') ) char1 = 'i'
             if ( (char2 .ge. 'o') .and. (char2 .le. 'z') ) char1 = 'r'
             if ( (char2 .ge. 'O') .and. (char2 .le. 'Z') ) char1 = 'r'
             nmlist(ilist)(30:30) = char1
             nmlist(ilist)(32:32) = 's'
           endif
220      continue
c
c      Replace NAMELIST statement with "namelist" assignments.
c
         nltot = nlnew + nlist + 1
         if (nltot .gt. ilmax) call overflow ( 4, 4 )
         line  = blank128
         write (line, 2070) inmlst
         nlnew = nlnew + 1
         newfile(nlnew) = line
         do 230 ilist=1,nlist
           line  = blank128
           write (line, 2080) ilist, nmlist(ilist)
           nlnew = nlnew + 1
           newfile(nlnew) = line
230      continue
         go to 70
       endif
c
       if (namenl .eq. blank16) go to 260
       if (word .eq. keywrd(17)) then
c
c      An IF statement has been encountered.  See if there is a READ
c  statement buried in it.
c
         ifpend = 1
         jopen  = jend + 1
         iopen  = iline
         lnbad  = nlnew + iline - ibeg + 1
         call list ( iline, lnbad, 1, jopen, jclose, iopen, iclose )
         if (jclose .eq. 0) go to 260
         next = iclose - iline
         jbeg = jclose + 1
         jend = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' (', word )
         call capitals ( word )
       endif
c
       match = 0
       if (word .eq. keywrd(18)) match = 1
       if (word .eq. keywrd(19)) match = 2
       if (word .eq .keywrd(20)) match = 2
       if (match .ne. 0) then
c
c      A READ, PRINT, or WRITE statement has been found.  See if the
c  statement corresponds to the last NAMELIST (named "namenl").
c
         jbeg = jend + 1
         jend = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ,()', word )
         lunit = word(1:8)
         jbeg = jend + 1
         jend = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ,()', word )
         if (word .eq. namenl) then
c
c      The i/o statement corresponds to the most recent NAMELIST call.
c  First, copy those lines in "oldfile" after the last line copied and
c  before this i/o statement to "newfile".  Then, in the case of a READ
c  statement ("match" = 1), replace the READ statement with calls to
c  subroutines in NAMELIST.LIB to fill the variables with their assigned
c  values.  In the case of a PRINT or WRITE statement ("match = 2),
c  replace it with a call to NLSDAC24 which sends output to the
c  specified unit.
c
           iend  = iline - 1
           nltot = nlnew + iend - ibeg + 1
           if (nltot .gt. ilmax) call overflow ( 4, 4 )
           do 240 i=ibeg,iend
             nlnew = nlnew + 1
             newfile(nlnew) = oldfile(i)
240        continue
           if (ifpend .eq. 1) then
             line                    = blank128
             line(       1:jclose  ) = oldfile(iline)(1:jclose)
             line(jclose+2:jclose+5) = 'then'
             nlnew = nlnew + 1
             if (nlnew .gt. ilmax) call overflow ( 4, 4 )
             newfile(nlnew) = line
           endif
           if (match .eq. 2) then
             word8 = namenl(1:8)
             line  = blank128
             write (line, 2090) lunit, word8, inmlst
             nlnew = nlnew + 1
             newfile(nlnew) = line
           endif
           iline = iline + next
           ibeg  = iline + 1
           if (match .eq. 1) then
             nltot = nlnew + nlist + 1
             if (nltot .gt. ilmax) call overflow ( 4, 4 )
             word8 = namenl(1:8)
             line  = blank128
             write (line, 2100) lunit, word8, inmlst, nlist
             nlnew = nlnew + 1
             newfile(nlnew) = line
             do 250 ilist=1,nlist
               word2 = '  '
               word4 = nmlist(ilist)(29:32)
               if (word4 .eq. ' c s') word2 = '03'
               if (word4 .eq. ' i s') word2 = '04'
               if (word4 .eq. ' r s') word2 = '05'
               if (word4 .eq. ' l s') word2 = '06'
               if (word4 .eq. ' c v') word2 = '07'
               if (word4 .eq. ' i v') word2 = '08'
               if (word4 .eq. ' r v') word2 = '09'
               if (word4 .eq. ' l v') word2 = '10'
               if (word4 .eq. ' c a') word2 = '11'
               if (word4 .eq. ' i a') word2 = '12'
               if (word4 .eq. ' r a') word2 = '13'
               if (word4 .eq. ' l a') word2 = '14'
               word8 = nmlist(ilist)(1:8)
               word4 = nmlist(ilist)(25:28)
               line  = blank128
               if (nmlist(ilist)(32:32) .eq. 'a') then
                 write (line, 2110) word2, word8, word8, inmlst, word4
               else
                 write (line, 2120) word2, word8, word8, inmlst
               endif
               nlnew = nlnew + 1
               newfile(nlnew) = line
               if (word2 .eq. '  ') then
c
c      ERROR:  Suffix for "nlsdac" (word2) is blank!  Check declarations
c
                 call errset ( nlnew, 33, 2 )
               endif
250          continue
           endif
           if (ifpend .eq. 1) then
             line       = blank128
             line(8:12) = 'endif'
             nlnew = nlnew + 1
             if (nlnew .gt. ilmax) call overflow ( 4, 4 )
             newfile(nlnew) = line
           endif
         endif
       endif
260    continue
       iline = iline + 1
       go to 70
c
c      . . . . EXITING MAIN LOOP
c
270    continue
c
c      Insert any error messages into "newfile", then return to calling
c  routine.
c
       if (nerr2 .gt. 0) then
         do 280 i=1,nlnew
           oldfile(i) = newfile(i)
280      continue
         nlold = nlnew
         nlnew = 0
         do 290 i=1,nlold
           nlnew = nlnew + 1
           if (nlnew .gt. ilmax) call overflow ( 4, 4 )
           newfile(nlnew) = oldfile(i)
           if (nerr2 .gt. 0) call errwrt ( i, 4, 2, nlnew )
290      continue
       endif
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(7x,'character*32  namelist (   2,',i4,')')
2020   format('       external      nlsdac01, nlsdac02, nlsdac03, '
     1       ,'nlsdac04, nlsdac05')
2030   format('     1             , nlsdac06, nlsdac07, nlsdac08, '
     1       ,'nlsdac09, nlsdac10')
2040   format('     2             , nlsdac11, nlsdac12, nlsdac13, '
     1       ,'nlsdac14, nlsdac15')
2050   format('     3             , nlsdac16, nlsdac17, nlsdac18, '
     1       ,'nlsdac19, nlsdac20')
2060   format('     4             , nlsdac21, nlsdac22, nlsdac23, '
     1       ,'nlsdac24          ')
2070   format(7x,'call nlsdac01 ( namelist, ',i4,' )')
2080   format(7x,'namelist (1,',i4,') = ''',a32,'''')
2090   format(7x,'call nlsdac24 ( ',a8,', ''',a8,''', namelist, ',i4
     1       ,' )')
2100   format(7x,'call nlsdac02 ( ',a8,', ''',a8,''', namelist, ',i4
     1       ,', ',i4,' )')
2110   format(7x,'call nlsdac',a2,' ( ',a8,', ''',a8,''', namelist, '
     1       ,i4,', ',a4,' )')
2120   format(7x,'call nlsdac',a2,' ( ',a8,', ''',a8,''', namelist, '
     1       ,i4,' )')
c
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////                N M L S T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              P A R A L L E L              \\\\\\\\\\
c
c=======================================================================
c
       subroutine parallel
c
c    dac:editor.parallel <----------------- parallelises nested do-loops
c                                                            march, 1992
c
c    written by: David Clarke
c    modified 1: June, 2000 by David Clarke; allowed CMIC$ commands to
c                be inserted for all operating systems.
c    modified 2: 2006 by Jon Ramsey; added OpenMP commands.
c    modified 3: June, 2009 by DAC; generalised to allow keywords (such
c                as "do" and "if") to be variables.
c    modified 4: June, 2009 by DAC and long overdue; added c*shared and
c                c*private commands
c
c  NOTE (6/09): dzeus36 includes IRIX parallel directives that include
c  complex*16 variables.  EDITOR needs to be updated for complex and
c  complex*16 variables.  Further, we may want iutask=3 to be the
c  doacross parallelisation commands:
c
c  c$doacross   local   ( k, j, i),
c  c$&          share   ( x, n3, n2, n1, d, is, js, ks )
c
c  PURPOSE:  This subroutine performs an optional pass through the code
c  during the precompilation process to insert Cray CMIC$ or OpenMP
c  C$OMP statements at the beginning of *targetted* do-loops (e.g.,
c  do n i=i1,i2, and not do-enddo structures.  Note that TARGET can be
c  instructed to replace do-enddo structures with targetted do-loops),
c  effectively parallelising the code at the do-loop level.  NB: Both
c  SGI and SUN operating systems can interpret Cray CMIC$ directives.
c
c  Nested do-loops are detected and *declared* variables (15 characters
c  or less; the 16th character is used as a control character) are
c  scoped with the following simplified rules:
c
c      indexed by outer loop index      |
c      OR                               |  ==>  SHARED
c      variable is referenced only      |
c
c      not indexed by outer loop index  |
c      AND                              |  ==>  PRIVATE
c      variable is assigned a value     |
c
c  Words found in the loop that are not in the declaration list are
c  assumed to be either constants or references to intrinsic functions
c  (SQRT, AMAX1, etc.) and are not scoped.  If one of the words found is
c  in fact an undeclared scalar (hence, IMPLICIT was not set to NONE),
c  then they will probably be scoped properly by virtue of "autoscope"
c  in the cmic$ [default[none] in the c$omp] commands inserted into the
c  source code.
c
c  External functions whose attribute is declared (REAL, INTEGER, etc.)
c  will be scoped unless they are also listed in an EXTERNAL statement.
c  This should be done since external functions should not be scoped.
c  Parameters are not scoped.
c
c  Fundamental to the usability of this option is the assumption that
c  the code is bug-free and written without undue complexities.  Using
c  arrays or aliases for the outer do-loop index will inhibit proper
c  scoping.  For example, in the following segment of code,
c
c  001         do 20 j=jmin,jmax
c  002           jp1 = j + 1
c  003           do 10 i=imin,imax
c  004             q1(i,j  ) = ...
c  005             q2(i,j+1) = ...
c  006             q3(i,jp1) = ...
c  007  10       continue
c  008  20     continue
c
c  "q1" and "q2" would be scoped as shared since these are indexed
c  explicitly by the outer do-loop index "j".  However, the routine is
c  not smart enough to realise that "jp1" is really an alias for "j+1",
c  and so it would scope q3 (undesirably) as private.
c
c  EDITOR offers three ways to correct improperly scoped variables.
c
c  1.  EDITOR will not attempt to autoscope any do-loop already scoped;
c  i.e., with cmic$ (c$omp) directives immediately preceding it.
c
c  2.  As of June/09, one can "force-scope" variables with the c*shared
c  and c*private commands.  Thus,
c
c  001  c*shared(q3)
c  002         do 20 j=jmin,jmax
c  003           jp1 = j + 1
c  004           do 10 i=imin,imax
c  005             q1(i,j  ) = ...
c  006             q2(i,j+1) = ...
c  007             q3(i,jp1) = ...
c  008  10       continue
c  009  20     continue
c
c  forces q3 to be listed as a shared variable, overriding the
c  autoscoper for q3 only.  Similarly,
c
c       c*private(jp1)
c
c  forces jp1 to be scoped as private.  In this case, EDITOR does not
c  need to be told how to scope jp1, though adding the statement does no
c  harm.  The full syntax is:
c
c       c*shared ( var1, var2, ..., varn )
c
c  with the leading 'c' in column 1 and spaces optional.  The open and
c  close parentheses must appear on the same line; there is no mechanism
c  for "continuation statements".  However, as many c*shared or
c  c*private statements as desired may appear immediately before the
c  do-loop (i.e., no FORTRAN including comments between the first
c  c*shared/private command and the top of the do-loop, except any lines
c  excluded by EDITOR *if def, *endif statements).
c
c  WARNING: If the user errs in scoping the variables, EDITOR will
c  blindly scope them as requested without issuing any error messages.
c
c  3.  The third method is somewhat obviated by the introduction of the
c  shared/private commands, but remains in EDITOR for compatibility.
c  One could make use of the compiler-ignored but EDITOR-read comment
c  lines, the first three characters of which are 'c**' or 'C**'.  Thus,
c  if the previous example were rewritten as:
c
c  001  c*ipdep
c  002         do 20 j=jmin,jmax
c  003           jp1 = j + 1
c  004           do 10 i=imin,imax
c  005             q1(i,j  ) = ...
c  006             q2(i,j+1) = ...
c  007  c**        q3(i,j  ) = 0.0
c  008             q3(i,jp1) = ...
c  009  10       continue
c  010  20     continue
c
c  then the compiler would, of course, ignore line 007, but EDITOR would
c  "see" it during the parallelisation step.  Because dummy line 007
c  indexes "q3" with the outer do-loop index directly, it would now be
c  scoped properly as shared.  Line 008 would not affect this scoping.
c  Note the addition of the "c*ipdep" which instructs EDITOR to ignore
c  parallel dependencies (discussed below).  This is because lines 007
c  and 008 together would, technically, constitute a dependency and
c  inhibit parallelisation.  Of course, since line 007 is only a
c  comment, no dependency can actually exist.  Thus, the instruction to
c  ignore parallel dependencies is also needed in this example.
c
c  If there are any do-loops in the code that the user does not wish to
c  be rendered parallel by this routine, the statement
c
c  c*nopar
c
c  beginning in column 1 should be placed immediately preceding the
c  outermost "do" statement.
c
c  There are several things which will inhibit parallelisation.  A
c  "dependency" is when an apparently shared variable (i.e., referenced
c  the first time it appears) is later determined to be private.  e.g.,
c
c  001         do 20 j=jmin,jmax
c  002           do 10 i=imin,imax
c  003             q1   = d(i)
c  004             d(i) = ...
c  005             ...
c  006  10       continue
c  007  20     continue
c
c  A "reduction" is when an apparently private variable (i.e., assigned
c  and is not indexed with the outer do-loop index) is assigned, in
c  part, to itself the first time it is assigned a value.  e.g.,
c
c  001         do 20 j=jmin,jmax
c  002           do 10 i=imin,imax
c  003             d(i) = d(i) + ...
c  004             ...
c  005  10       continue
c  006  20     continue
c
c  Either of these structures will prevent parallel directives from
c  being issued by this routine and will generate a dependency report at
c  the end of the do-loop.  If a detected dependency and/or a reduction
c  is immaterial, then EDITOR may be instructed to ignore the dependency
c  and/or reduction by inserting one of the following statements
c  beginning in column 1 immediately preceding the outermost "do"
c  statement:
c
c  c*ipdep                ! ignore parallel dependencies
c  c*ipred                ! ignore parallel reductions
c  c*ipdepipred           ! ignore parallel dependencies and reductions
c  c*ipredipdep           ! same as above
c
c  A common type of dependency that is *not* detected by this routine
c  is in the following example:
c
c  001         do 20 j=jmin,jmax
c  002           do 10 i=imin,imax
c  003             d(i,j) = d(i,j+1)
c  004             ...
c  005  10       continue
c  006  20     continue
c
c  In this example, cpu2 may fill d(i,j=2) with d(i,j=3) before cpu1 has
c  a chance to fill d(i,j=1) with d(i,j=2).  Thus, serial and parallel
c  versions of the code would yield different results.  This routine
c  makes no attempt to unravel whether statements such as 003 above
c  constitute a dependency or whether it is a valid reassignment of a
c  shared variable.  EDITOR will assume that no dependency exists and
c  proceed with parallisation.  If the loop should not be parallelised,
c  a "c*nopar" statement should be inserted before the outermost "do"
c  statement.
c
c  By their nature, character and I/O operations within a do-loop will
c  prevent parallelisation.  GOTO statements within a do-loop will not
c  inhibit parallelisation, but no effort is made to determine if the
c  GOTO statement takes execution outside the outer do-loop.  If it
c  does, a parallel code will generally yield different results than a
c  serial code.
c
c  Although much more sophisticated than this auto-scoper will ever be,
c  FPP (Cray auto-tasker, c. 1990) is known to make mistakes and/or
c  omissions when scoping even ideal do-loop structures.  Thus, this
c  routine is designed to scope the variables in an ideal do-loop
c  structure more consistently than FPP.  Because this routine only
c  works with nested do-loop structures, other intrinsically parallel
c  regions of a code will go undetected.  FPP might also be able to
c  render any reduction loops parallel.  Thus, FPP might still be used
c  after EDITOR has rendered the loops parallel.
c
c  This routine will insert the set of statements
c
c  cmic$ do all private (...)     c$omp parallel do private (...)
c  cmic$1       shared  (...)     c$omp1            shared  (...)
c  cmic$1       autoscope         c$omp1            default ( none )
c
c  in front of the outermost loop of every nested do-loop structure it
c  encounters if that do-loop structure doesn't have a "c*nopar" or a
c  "cmic$/c$omp" (i.e., the do-loop has already been scoped) immediately
c  before it and if there are no obvious reasons why the loop is not
c  parallelisable.
c
c  NOTE, Feb 2008 by DAC:  The autotasker was originally designed for
c  Cray FPP which assumed vectorisation on the inner loop.  Thus, if
c  there were only one loop, no parallelisation was to be done since it
c  and vectorisation are mutually exclusive operations.  For iutask=2
c  (OpenMP), no assumption of vectorisation is made and thus, in
c  principle, single loops may be parallelised too.  This can be done by
c  setting iutask =-2 (and iutask =-1 for FPP if there is no
c  vectorisation), though this has been known to be over agressive in
c  parallelising some loops, and should be used with extreme caution.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    STRLEN
c    GETWRD
c    CAPITALS
c    LIST
c    OVERFLOW
c    ERRSET
c    ERRWRT
c    SQUEEZE
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       character*1   char1
       character*4   word4
       character*16  word    , wrdtrg  , wrdind  , wrd2    , wrd3
     1             , vlhs
       character*128 line
       integer       i       , i1      , i2      , iopen   , iclose
     1             , ibeg    , iend    , j       , jopen   , jclose
     2             , j1      , j2      , jbeg    , jend    , jendold
     3             , jran    , next    , nextold , ndeck   , iwrd
     4             , ideck   , iline   , nline   , ipar    , ndep
     5             , lpend   , nest    , npriv   , npact   , nshar
     6             , nsact   , nltot   , lnbad   , nch     , match
     7             , k       , io      , ichv    , ipdep   , ipred
     8             , doloop
c
       logical       pvalid  (  k9), svalid  (  k9)
       character*16  pvrble  (  k9), svrble  (  k9), dvrble  (  k9)
       character*16  keywrd  (  25)
c
c      External statements
c
       integer       strlen
       external      strlen  , getwrd  , capitals, list    , overflow
     1             , errset  , errwrt  , squeeze
c
c      Data Statements
c
       data          keywrd
     1   / 'PROGRAM         ', 'SUBROUTINE      ', 'FUNCTION        '
     2   , 'IMPLICIT        ', 'PARAMETER       ', 'DIMENSION       '
     3   , 'REAL            ', 'INTEGER         ', 'LOGICAL         '
     4   , 'CHARACTER       ', 'COMMON          ', 'EXTERNAL        '
     5   , 'EQUIVALENCE     ', 'DATA            ', 'SAVE            '
     6   , 'DO              ', 'WHILE           ', 'IF              '
     7   , 'GO              ', 'GOTO            ', 'READ            '
     8   , 'WRITE           ', 'PRINT           ', 'OPEN            '
     9   , 'CLOSE           ' /
c
c-----------------------------------------------------------------------
c
c      Copy contents of "newfile" to "oldfile".
c
       do 10 i=1,nlnew
         oldfile(i) = newfile(i)
10     continue
       nlold = nlnew
c
c      Gather module limits and store them in "idksta" and "idkfin".
c
       ndeck = 0
       do 50 i=1,nlold
         if (oldfile(i)(1:6) .eq. '      ') then
           jbeg = 7
           jend = nchar
           next = 0
20         continue
           call getwrd ( i, 1, next, jbeg, jend, jran, ' *(', word )
           call capitals ( word )
           do 30 iwrd=1,10
             if (word .eq. keywrd(iwrd)) go to 40
30         continue
40         continue
           if ( (iwrd .ge. 1) .and. (iwrd .le. 3) ) then
             ndeck = ndeck + 1
             idksta(ndeck) = i
           endif
           if ( (iwrd .ge. 7) .and. (iwrd .le. 10) ) then
             if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
               jbeg = jend + 1
               jend = 0
               call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
             endif
             jbeg = jend + 1
             jend = 0
             go to 20
           endif
         endif
         if ( (i .eq. 1) .and. (ndeck .eq. 0) ) then
           ndeck     = 1
           idksta(1) = 1
         endif
         idkfin(ndeck) = i
50     continue
c
c      Initialise variables.
c
       do 60 i=1,ivmax
         svrble(i) = blank16
         svalid(i) = .false.
         pvrble(i) = blank16
         pvalid(i) = .false.
60     continue
       do 70 i=1,iemax
         lnerr2(i) = 0
         ierr2 (i) = 0
70     continue
       nerr2 = 0
       ideck = 1
       iline = 1
       nlnew = 0
       ipar  = 1
       nest  = 0
       if (iutask .lt. 0) nest = 1
       ndep  = 0
       io    = 0
       ichv  = 0
       ipdep = 0
       ipred = 0
       vlhs  = blank16
c
c-----------------------------------------------------------------------
c      ENTERING MAIN LOOP . . . .
c-----------------------------------------------------------------------
c
80     continue
c
       if (iline .gt. idkfin(ideck)) ideck = ideck + 1
       nline = iline
       if (oldfile(iline)(1:6) .ne. '      ') go to 480
c
c      Scan "oldfile" for beginning of a do-loop.  If one is found,
c  analyse the loop.  Otherwise, copy the line to "newfile".
c
       doloop = 0
       jbeg   = 7
       jend   = nchar
       next   = 0
       call getwrd   ( iline, 1, next, jbeg, jend, jran, ' ', word )
       call capitals ( word )
c
c      Changes 06/09: Guard against "do" being a variable on the LHS of
c  an assignment statement.  Note that EDITOR will scope the syntax:
c
c      do i = 2
c
c  incorrectly as the beginning of a do-loop, and not as an assignment
c  statement setting variable doi to 2.  On the other hand:
c
c      doi = 2
c
c  poses no problem for EDITOR.  For the most part, EDITOR can handle
c  embedded blanks in variable names, but there are times like this
c  where such manoeuvres will cause problems.
c
       if (word .eq. keywrd(16)) then
         j1    = jend + 1
         j2    = 0
         call getwrd ( iline, 1, next, j1, j2, jran, ' ', wrd2 )
         char1 = wrd2(1:1)
         if ( (char1 .ne. '=') .and. (char1 .ne. '(') ) doloop = 1
       endif
c
       if (doloop .eq. 1) then
c
c      A do-loop has been encountered.  Note that only "targetted" do-
c  loops (do n i-i1,i2) and not do-enddo constructs can be handled by
c  this routine.
c
c  Determine if this loop has already been scoped (previous line begins
c  with a "cmic$/c$omp") or if the user has turned parallisation off for
c  this loop (previous line begins with "c*nopar"), or if any variables
c  are forced-scoped (previous line begins with "c*shared/c*private").
c
c  "ipar" is the sentinel indicating if this loop is to be parallelised.
c
c  "ipdep" is the switch indicating whether parallel dependencies should
c  be ignored.
c
c  "ipred" is the switch indicating whether parallel reductions should
c  be ignored.
c
c  "io"   is the sentinel indicating if I/O is performed in this loop.
c
c  "ichv" is the sentinel indicating if there are any character
c  variables in this loop.
c
c  "ndep" is the running total of possible variable-related dependencies
c  found in the loop.
c
c  "nest" is set to 1 if nested loops are subsequently found.  Only
c  nested loops are parallelised.
c
c  "npriv" and "nshar" are respectively the running total of candidate
c  private and shared variables found in the loop.
c
         nline = max0 ( 1, iline - 1 )
         word  = oldfile(nline)(1:16)
         call capitals ( word )
         ipar  = 1
         if (word(1: 5) .eq. 'CMIC$'       ) ipar  = 0
         if (word(1: 5) .eq. 'C$OMP'       ) ipar  = 0
         if (word(1: 7) .eq. 'C*NOPAR'     ) ipar  = 0
         ipdep = 0
         if (word(1: 7) .eq. 'C*IPDEP'     ) ipdep = 1
         if (word(1:12) .eq. 'C*IPREDIPDEP') ipdep = 1
         ipred = 0
         if (word(1: 7) .eq. 'C*IPRED'     ) ipred = 1
         if (word(1:12) .eq. 'C*IPDEPIPRED') ipred = 1
c
c      June/09: added c*shared and c*private commands.  Note that a
c  variable forced-scoped as shared needs to be flagged as such (done by
c  setting the 16th character to !) lest a dependency be declared should
c  the variable be autoscoped later as private.  Conversely, a variable
c  forced-scoped as private need not be flagged as such since a variable
c  tagged as private remains private even if later scoped as shared.
c
         nshar = 0
         npriv = 0
c
81       continue
         if (word(1:8) .eq. 'C*SHARED') then
           j2 = 8
82         continue
           j1 = j2 + 1
           j2 = nchar
           call getwrd ( nline, 1, next, j1, j2, jran, ' (,)', wrd2 )
           if (wrd2 .ne. blank16) then
             nshar                = min0 ( nshar + 1, ivmax )
             svrble(nshar)        = wrd2
             svrble(nshar)(16:16) = '!'
             go to 82
           endif
         endif
c
         if (word(1:9) .eq. 'C*PRIVATE') then
           j2 = 9
83         continue
           j1 = j2 + 1
           j2 = nchar
           call getwrd ( nline, 1, next, j1, j2, jran, ' (,)', wrd2 )
           if (wrd2 .ne. blank16) then
             npriv         = min0 ( npriv + 1, ivmax )
             pvrble(npriv) = wrd2
             go to 83
           endif
         endif
c
         if ( (word(1:8).eq.'C*SHARED' ) .or.
     1        (word(1:9).eq.'C*PRIVATE') ) then
           nline = nline - 1
           if (nline .gt. 0) then
             word = oldfile(nline)(1:16)
             call capitals ( word )
             if ( (word(1:8).eq.'C*SHARED' ) .or.
     1            (word(1:9).eq.'C*PRIVATE') ) go to 81
           endif
         endif
c
         io    = 0
         ichv  = 0
         ndep  = 0
         nest  = 0
         if (iutask .lt. 0) nest = 1
c
c  "wrdtrg" is the character representation of the numerical target for
c  the loop.  If "wrdtrg" .eq. "WHILE", then this is a "do while"
c  construct, and is not parallelisable by this routine.
c
c  "wrdind" is the index of the outer do-loop.
c
c  "lpend" is the sentinel which is set to 1 when the end of the loop is
c  encountered.
c
         jbeg  = jend + 1
         jend  = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, ' ', wrdtrg )
         call capitals ( wrdtrg )
         if (wrdtrg .eq. keywrd(17)) go to 480
         jbeg  = jend + 1
         jend  = 0
         call getwrd ( iline, 1, next, jbeg, jend, jran, '=', wrdind )
         call squeeze ( wrdind )
         lpend = 0
         nline = iline - 1
c
c      Scan subsequent lines for variable names, beginning of nested
c  do-loops, and do-loop closing statements.  "vlhs" is set to the
c  variable on the left-hand-side of the expression on the current line
c  only if the variable is being added to the list "pvrble".  Otherwise
c  it is blank.
c
90       continue
         vlhs  = blank16
         if (lpend .eq. 1) go to 280
         if (nline .ge. nlold) go to 480
         nline = nline + 1
         char1 = oldfile(nline)(6:6)
         if (char1 .ne. ' ') go to 90
         word4 = oldfile(nline)(1:4)
         if ( (word4 .ne. 'c** ') .and. (word4 .ne. 'C** ') ) then
           char1 = oldfile(nline)(1:1)
           if ( (char1 .eq. 'c') .or. (char1 .eq. 'C') .or.
     1          (char1 .eq. '*') ) go to 90
         endif
c
c      Check if the next line closes the opening do-loop.  If it does,
c  set the end-loop sentinel.
c
         jbeg  = 1
         jend  = 5
         next  = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' ', word )
         if (word .eq. wrdtrg) lpend = 1
c
c      If parallelisation is not desired for this loop, read the next
c  line.
c
         if ( (ipar .eq. 0) .or.
     1        ( (io .eq. 1) .and. (nest .eq. 1) ) ) go to 90
c
c      For parallelisation, scan the current statement for variables.
c  Note that at this point in the algorithm, it is the first word on
c  line "oldfile(nline)" that is being read.  Entry point to read
c  subsequent words on the same line is statement 130 below.
c
         jbeg = 7
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' (),=+-*/.'
     1               , word )
         if (word .eq. blank16) go to 90
         call capitals ( word )
c
c      Changes 06/09: Guard against keywords being a variable on the LHS
c  of an assignment statement.
c
         j1 = jend + 1
         j2 = 0
         call getwrd ( nline, 1, next, j1, j2, jran, ' ', wrd2 )
         if (wrd2(1:1) .eq. '=') go to 120
         if (wrd2(1:1) .eq. '(') then
c
c      Determine if the open-parenthesis indicates an argument list of a
c  variable.  If so, there should be an '=' immediately after the list
c  in which case this is an assignment statement.
c
           jopen = j1
           iopen = nline + next
           lnbad = nlnew + nline + next - iline + 1
           call list ( nline, lnbad, 1, jopen, jclose, iopen, iclose )
           j1    = jclose
           j2    = 0
           call getwrd ( iclose, 1, next, j1, j2, jran, ' ', wrd2 )
           if (wrd2(1:1) .eq. '=') go to 120
         endif
c
         match = 1
         do 100 iwrd=1,25
           if (word .eq. keywrd(iwrd)) go to 110
100      continue
110      continue
         if   (iwrd .eq. 16)                        match = 2
         if   (iwrd .eq. 18)                        match = 3
         if ( (iwrd .ge. 19) .and. (iwrd .le. 20) ) match = 4
         if ( (iwrd .ge. 21) .and. (iwrd .le. 25) ) match = 5
         go to ( 120, 230, 240, 260, 270 ) match
c
c-----------------------------------------------------------------------
c
120      continue
         jend = jbeg - 1
130      continue
c
c      A variable may have been found.  Locate its bounds without a
c  blank delimiter.  Numerical constants are skipped over.
c
         jbeg = jend + 1
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, '(),=+-*/.'
     1               , word )
         if (word .eq. blank16) go to 90
         call squeeze ( word )
         if ( (word(1:1) .ge. '0') .and. (word(1:1) .le. '9') )
     1     go to 130
         jendold = jend
         nextold = next
c
c  1.  Determine if the variable has an argument list.  If it doesn't,
c      scope it.
c
         jbeg = jend + 1
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' ', wrd2 )
         if (wrd2(1:1) .ne. '(') go to 160
c
c  2.  Determine the extent of the argument list.
c
         jopen = jbeg
         iopen = nline + next
         lnbad = nlnew + nline + next - iline + 1
         call list ( nline, lnbad, 1, jopen, jclose, iopen, iclose )
c
c  3.  Scan the list for the outermost do-loop index ("wrdind").
c
140      continue
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, '(),+-*/'
     1               , wrd2 )
         call squeeze ( wrd2 )
c
c      a) If the end of the parameter list has been passed and "wrdind"
c         has still not been found in the argument list, scope the
c         variable.
c
         if ( ( (jend .gt. jclose) .and. (nline+next .eq. iclose) ) .or.
     1        (wrd2 .eq. blank16) ) then
           jend = jclose
           next = iclose - nline
           go to 150
         endif
c
c      b) If a variable in the parameter list itself has a parameter
c         list, it and its parameter list are passed over (on the
c         assumption that arrays are not used for do-loop indices).
c
         jbeg = jend + 1
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' ', wrd3 )
         if (wrd3(1:1) .eq. '(') then
           j1    = jbeg
           i1    = nline + next
           lnbad = nlnew + nline + next - iline + 1
           call list ( nline, lnbad, 1, j1, j2, i1, i2 )
           jbeg  = j2 + 1
           next  = i2 - nline
           go to 140
         endif
c
c      c) "wrdind" has been found in the argument list.  The variable is
c         shared.
c
         if (wrd2 .eq. wrdind) then
           jend = jclose
           next = iclose - nline
           go to 160
         endif
c
c      d) "wrdind" has not been found yet, and the argument list has not
c         been exhausted.  Continue reading the argument list.
c
         go to 140
c
c  4.  Scope the variable if a dependency or a reduction hasn't already
c      been associated with it.  A variable is considered private if it
c      ever appears left of an equals sign.  Otherwise it is shared.
c
150      continue
         jbeg = jend + 1
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' ', wrd2 )
160      continue
         jend = jendold
         next = nextold
         do 170 i=1,ndep
           if (word(1:15) .eq. dvrble(i)(1:15)) go to 130
170      continue
         if (wrd2(1:1) .eq. '=') then
c
c      Private variable?  If the variable has already been scoped as
c  "shared", then a dependency has been found.  In this case, remove the
c  variable name from the list "svrble" and add it to the the list
c  "dvrble".  Otherwise, add the variable to the list "pvrble" if it is
c  not already there and if it is not "forced-scoped" as shared (set by
c  c*shared).  Note that the 16th character of a forced-scoped shared
c  variable is an '!'.
c
           do 190 i=1,nshar
             if (word .eq. svrble(i)) then
               if (ipdep .eq. 0) then
                 nshar = nshar - 1
                 do 180 j=i,nshar
                   svrble(j) = svrble(j+1)
180              continue
                 ndep = min0 ( ivmax, ndep + 1 )
                 dvrble(ndep)( 1:15) = word( 1:15)
                 dvrble(ndep)(16:16) = 'd'
               endif
               go to 130
             endif
190        continue
           do 200 i=1,npriv
             if (word .eq. pvrble(i)) go to 130
200        continue
           do 201 i=1,nshar
             if ( ( svrble(i)(1 :15) .eq. word(1:15) ) .and.
     1            ( svrble(i)(16:16) .eq. '!'        ) ) go to 130
201        continue
           npriv = npriv + 1
           if (npriv .gt. ivmax) then
c
c      ERROR:  too many variables listed.  Increase "k9" ("ivmax").
c
             lnbad = nlnew + nline + next - iline + 1
             call errset ( lnbad, 47, 2 )
             go to 480
           endif
           pvrble(npriv) = word
           vlhs          = word
c
         else
c
c      Shared variable?  If the variable is the same as "vlhs", then
c  this is a reduction.  In this case, remove the variable name from the
c  list "pvrble" (it is the most recent entry) and add it to the list
c  "dvrble".  Otherwise, add the variable to the list "svrble" if it is
c  not already there and if it is not already in "pvrble".
c
           if ( (word .eq. vlhs) .and. (ipred .eq. 0) ) then
             pvrble(npriv) = blank16
             npriv = npriv - 1
             ndep  = min0 ( ivmax, ndep + 1 )
             dvrble(ndep)( 1:15) = word( 1:15)
             dvrble(ndep)(16:16) = 'r'
             go to 130
           endif
           do 210 i=1,nshar
             if (   svrble(i)        .eq. word       )   go to 130
             if ( ( svrble(i)(1 :15) .eq. word(1:15) ) .and.
     1            ( svrble(i)(16:16) .eq. '!'        ) ) go to 130
210        continue
           do 220 i=1,npriv
             if (pvrble(i) .eq. word) go to 130
220        continue
           nshar = nshar + 1
           if (nshar .gt. ivmax) then
c
c      ERROR:  too many variables listed.  Increase "k9" ("ivmax").
c
             lnbad = nlnew + nline + next - iline + 1
             call errset ( lnbad, 47, 2 )
             go to 480
           endif
           svrble(nshar) = word
c
         endif
         go to 130
c
c-----------------------------------------------------------------------
c
230      continue
c
c      Another do-loop has been opened.  Set "nest" to 1 to indicate
c  that there are nested loops, pass over the target, and resume
c  scanning line for variables.
c
         if (nline .gt. iline) nest = 1
         jbeg = jend + 1
         jend = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' ', word )
         go to 130
c
c-----------------------------------------------------------------------
c
240      continue
c
c      An "if" statement has been encountered.  First determine if there
c  is an I/O statement beyond the parentheses.  If so, abort parallel-
c  isation of loop.  If not, continue to scan the statement for possible
c  variables.
c
         jopen   = jend + 1
         iopen   = nline + next
         lnbad   = nlnew + nline + next - iline + 1
         call list ( nline, lnbad, 1, jopen, jclose, iopen, iclose )
         nextold = next
         jendold = jend
         next    = iclose - nline
         jbeg    = jclose + 1
         jend    = 0
         call getwrd ( nline, 1, next, jbeg, jend, jran, ' (', word )
         call capitals ( word )
         do 250 iwrd=21,25
           if (word .eq. keywrd(iwrd)) go to 270
250      continue
         next = nextold
         jend = jendold
         go to 130
c
c-----------------------------------------------------------------------
c
260      continue
c
c      An "go to" statement has been encountered.  Scan it for possible
c  variables.  A "go to" statement is assumed *not* to take execution
c  outside the loop.  If it does, the parallel code will, in general,
c  yield different results from the serial code.
c
         go to 130
c
c-----------------------------------------------------------------------
c
270      continue
c
c      I/O statements have been encountered.  These prevent the loop
c  from being parallelised.
c
         io = 1
         go to 90
c
c-----------------------------------------------------------------------
c
c      Generate parallelisation directives (cmic$/c$omp statements).
c
280      continue
         if ( (ipar .eq. 0) .or. (nest .eq. 0) .or. (ndep .gt. 0) .or.
     1        (io   .eq. 1) ) go to 480
c
c      Scan declarations at beginning of module to make sure variables
c  in "pvrble" and "svrble" are declared.  "Validate" declared variables
c  by setting "pvalid" or "svalid" to .true..
c
c  "npact" is a running total of the "actual" private variables found.
c  "nsact" is a running total of the "actual" shared  variables found.
c
         npact = 0
         nsact = 0
         if ( (npriv .eq. 0) .and. (nshar .eq. 0) ) go to 450
         do 290 i=1,npriv
           pvalid(i) = .false.
290      continue
         do 300 i=1,nshar
           svalid(i) = .false.
300      continue
         i1 = idksta(ideck) + 1
         i2 = idkfin(ideck)
         do 440 i=i1,i2
           if (oldfile(i)(1:6) .ne. '      ') go to 440
           jbeg = 7
           jend = nchar
           next = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' *', word )
           if (word .eq. blank16) go to 440
           call capitals ( word )
           match = 1
           do 310 iwrd=1,15
             if (word .eq. keywrd(iwrd)) go to 320
310        continue
320        continue
           if   (iwrd .le.  4)                        match = 2
           if ( (iwrd .ge. 13) .and. (iwrd .le. 15) ) match = 2
           if ( (iwrd .ge.  6) .and. (iwrd .le. 11) ) match = 3
           if ( (iwrd .eq.  5) .or.  (iwrd .eq. 12) ) match = 4
           go to ( 450, 440, 330, 390 ) match
c
330        continue
c
c      A declarative statement has been found (DIMENSION, REAL, INTEGER,
c  LOGICAL, CHARACTER, COMMON).  Scan the statement for variables and
c  determine if they are in either list "pvrble" and "svrble".
c
           if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
             jbeg = jend + 1
             jend = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           endif
340        continue
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ',()', word )
           if (word .eq. blank16) go to 440
           call squeeze ( word )
c
c      If a variable listed in "pvrble" or "svrble" is a character
c  string, abort attempt to parallelise loop.
c
           if (iwrd .eq. 10) then
c
             do 350 j=1,npriv
               if (word(1:15) .eq. pvrble(j)(1:15)) then
                 ichv = 1
                 go to 480
               endif
350          continue
             do 360 j=1,nshar
               if (word(1:15) .eq. svrble(j)(1:15)) then
                 ichv = 1
                 go to 480
               endif
360          continue
c
           else
c
c      If the variable is not a character string, determine the extent
c  of the argument list, if any.  Reset pointer "jend" to end of
c  parameter list if one is found.
c
             jendold = jend
             nextold = next
             jbeg    = jend + 1
             jend    = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ', wrd2 )
             if (wrd2(1:1) .eq. '(') then
               jopen = jbeg
               iopen = i + next
               call list ( i, -1, 1, jopen, jclose, iopen, iclose )
               jend = jclose
               next = iclose - i
             else
               jend = jendold
               next = nextold
             endif
c
c      Finish scoping the variables.
c
             do 370 j=1,npriv
               if ( ( word(1:15) .eq. pvrble(j)(1:15) ) .and.
     1              ( .not. pvalid(j) ) ) then
                 pvalid(j) = .true.
                 npact     = npact + 1
               endif
370          continue
             do 380 j=1,nshar
               if ( ( word(1:15) .eq. svrble(j)(1:15) ) .and.
     1              ( .not. svalid(j) ) ) then
                 svalid(j) = .true.
                 nsact     = nsact + 1
               endif
380          continue
c
           endif
           go to 340
c
390        continue
c
c      An EXTERNAL or PARAMETER statement has been found.  Delete all
c  variables from the lists "svrble" and "pvrble" found to be external
c  functions or parameters.
c
           jbeg = jend + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ',=()', word )
           if (word .eq. blank16) go to 440
           do 410 j=1,npriv
             if ( word(1:15) .eq. pvrble(j)(1:15) ) then
               if ( pvalid(j) ) npact = npact - 1
               npriv = npriv - 1
               do 400 k=j,npriv
                 pvrble(k) = pvrble(k+1)
                 pvalid(k) = pvalid(k+1)
400            continue
             endif
410        continue
           do 430 j=1,nshar
             if ( word(1:15) .eq. svrble(j)(1:15) ) then
               if ( svalid(j) ) nsact = nsact - 1
               nshar = nshar - 1
               do 420 k=j,nshar
                 svrble(k) = svrble(k+1)
                 svalid(k) = svalid(k+1)
420            continue
             endif
430        continue
           go to 390
c
440      continue
450      continue
c
c      Variables have been scoped.  Generate cmic$ (Cray) or c$omp
c  (OpenMP) statements and write them to "newfile" immediately before
c  the outer do-loop.
c
         line = blank128
         if (abs(iutask) .eq. 1) line(1:12) = 'cmic$ do all'
         if (abs(iutask) .eq. 2) line(1:17) = 'c$omp parallel do'
c
c  Case:  No private variables and no shared variables were collected.
c
c  Issue a "cmic$ do all autoscope"        (Cray)
c     or a "c$omp parallel do default ( )" (OpenMP) command.
c
c  From DAC, 6/11: The logic on F90 used to be required by F77 under
c  SOLARIS; unknown whether it's still relevant to Sun's f90 -f77.
c
         if ( (npact .eq. 0) .and. (nsact .eq. 0) ) then
           if (abs(iutask) .eq. 1) line(14:22) = 'autoscope'
           if (abs(iutask) .eq. 2) line(19:34) = 'default (__auto)'
           nltot = nlnew + 1
           if (nltot .gt. ilmax) call overflow ( 4, 9 )
           nlnew = nlnew + 1
           newfile(nlnew) = line
         endif
c
c  Case:  Private variables were collected.
c
c  Issue command to list private variables.  If there are more variables
c  than can be fit on one line, copy the line to "newfile" and continue
c  on the next line.
c
         if (npact .ne. 0) then
           line(19:28) = 'private ( '
           iend        = 28
           do 460 i=1,npriv
             if (pvalid(i)) then
               nch  = strlen ( pvrble(i)(1:15) )
               ibeg = iend + 1
               iend = iend + nch + 2
               if (iend .gt. 72) then
                 nltot = nlnew + 1
                 if (nltot .gt. ilmax) call overflow ( 4, 9 )
                 nlnew = nlnew + 1
                 newfile(nlnew) = line
                 line           = blank128
                 if (abs(iutask) .eq. 1) line(1:6) = 'cmic$1'
                 if (abs(iutask) .eq. 2) line(1:6) = 'c$omp1'
                 ibeg  = 29
                 iend  = 30 + nch
               endif
               line(ibeg:iend-2) = pvrble(i)(1:nch)
               line(iend-1:iend) = ', '
             endif
460        continue
           line(iend-1:iend) = ' )'
           nltot = nlnew + 1
           if (nltot .gt. ilmax) call overflow ( 4, 9 )
           nlnew = nlnew + 1
           newfile(nlnew) = line
           if (nsact .ne. 0) then
             line = blank128
             if (abs(iutask) .eq. 1) line(1:6) = 'cmic$1'
             if (abs(iutask) .eq. 2) line(1:6) = 'c$omp1'
           endif
         endif
c
c  Case:  Shared variables were collected.
c
c  Issue command to list shared variables.  If there are more variables
c  than can be fit on one line, copy the line to "newfile" and continue
c  on the next line.
c
         if (nsact .ne. 0) then
           line(19:28) = 'shared  ( '
           iend        = 28
           do 470 i=1,nshar
             if (svalid(i)) then
               nch  = strlen ( svrble(i)(1:15) )
               ibeg = iend + 1
               iend = iend + nch + 2
               if (iend .gt. 72) then
                 nltot = nlnew + 1
                 if (nltot .gt. ilmax) call overflow ( 4, 9 )
                 nlnew = nlnew + 1
                 newfile(nlnew) = line
                 line  = blank128
                 if (abs(iutask) .eq. 1) line(1:6) = 'cmic$1'
                 if (abs(iutask) .eq. 2) line(1:6) = 'c$omp1'
                 ibeg  = 29
                 iend  = 30 + nch
               endif
               line(ibeg:iend-2) = svrble(i)(1:nch)
               line(iend-1:iend) = ', '
             endif
470        continue
           line(iend-1:iend) = ' )'
           nltot = nlnew + 1
           if (nltot .gt. ilmax) call overflow ( 4, 9 )
           nlnew = nlnew + 1
           newfile(nlnew) = line
         endif
c
c  Case:  Either private or shared variables collected.
c
c  Issue a "cmic$1       autoscope"           (Cray) or
c          "c$omp1            default ( )"    (OpenMP) command.
c
c  From DAC, 6/11: The logic on F90 used to be required by F77 under
c  SOLARIS; unknown whether it's still relevant to Sun's f90 -f77.
c
         if ( (npact .ne. 0) .or. (nsact .ne. 0) ) then
           line       = blank128
           if (abs(iutask) .eq. 1 )
     1       line(1:22) = 'cmic$1       autoscope'
           if (abs(iutask) .eq. 2 )
     1       line(1:34) = 'c$omp1            default (__auto)'
           nltot = nlnew + 1
           if (nltot .gt. ilmax) call overflow ( 4, 9 )
           nlnew = nlnew + 1
           newfile(nlnew) = line
         endif
         go to 480
c
c      "cmic$/c$omp" statements have been inserted.
c
       endif
480    continue
c
c      Write scanned lines ("iline" through "nline") to "newfile".
c
       nltot = nlnew + nline - iline + 1
       if (nltot .gt. ilmax) call overflow ( 4, 9 )
       do 490 i=iline,nline
         nlnew = nlnew + 1
         newfile(nlnew) = oldfile(i)
490    continue
c
c      If dependencies were found, list the variables after the loop.
c
       if (ipar*nest*ndep .ge. 1) then
         nltot = nlnew + 6 + ndep
         if (nltot .gt. ilmax) call overflow ( 4, 9 )
         line = blank128
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         if (abs(iutask) .eq. 1) write (line, 2020) wrdtrg(1:5)
         if (abs(iutask) .eq. 2) write (line, 2021) wrdtrg(1:5)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2030)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2040)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         do 500 i=1,ndep
           word = blank16
           if (dvrble(i)(16:16) .eq. 'd') word = '(dependency)    '
           if (dvrble(i)(16:16) .eq. 'r') word = '(reduction)     '
           write (line, 2050) dvrble(i)(1:15), word
           nlnew = nlnew + 1
           newfile(nlnew) = line
500      continue
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         ndep = 0
       endif
c
c      If the loop was not parallelised because of I/O, report it after
c  the loop.
c
       if (ipar*nest*io .eq. 1) then
         nltot = nlnew + 5
         if (nltot .gt. ilmax) call overflow ( 4, 9 )
         line = blank128
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         if (abs(iutask) .eq. 1) write (line, 2020) wrdtrg(1:5)
         if (abs(iutask) .eq. 2) write (line, 2021) wrdtrg(1:5)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2060)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         io = 0
       endif
c
c      If the loop was not parallelised because of character operations,
c  report it after the loop.
c
       if (ipar*nest*ichv .eq. 1) then
         nltot = nlnew + 5
         if (nltot .gt. ilmax) call overflow ( 4, 9 )
         line = blank128
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         if (abs(iutask) .eq. 1) write (line, 2020) wrdtrg(1:5)
         if (abs(iutask) .eq. 2) write (line, 2021) wrdtrg(1:5)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2070)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         write (line, 2010)
         nlnew = nlnew + 1
         newfile(nlnew) = line
         ichv = 0
       endif
c
c      Read next line in "oldfile" if it exists.
c
       iline = nline + 1
       if (iline .le. nlold) go to 80
c
c-----------------------------------------------------------------------
c      . . . . EXITING MAIN LOOP
c-----------------------------------------------------------------------
c
c      Insert any error messages into "newfile".
c
       if (nerr2 .gt. 0) then
         do 510 i=1,nlnew
           oldfile(i) = newfile(i)
510      continue
         nlold = nlnew
         nlnew = 0
         do 520 i=1,nlold
           nlnew = nlnew + 1
           if (nlnew .gt. ilmax) call overflow ( 4, 9 )
           newfile(nlnew) = oldfile(i)
           if (nerr2 .gt. 0) call errwrt ( i, 4, 2, nlnew )
520      continue
       endif
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('c**************************************************'
     1       ,'*********************')
2020   format('c*********** EDITOR NO-CMIC$-DIRECTIVE REPORT FOR LOOP '
     1       ,a5,' ***********')
2021   format('c*********** EDITOR NO-C$OMP-DIRECTIVE REPORT FOR LOOP '
     1       ,a5,' ***********')
2030   format('c** No parallel directives issued because the following '
     1       ,'variable(s)   **')
2040   format('c** was/were found to generate dependencies or '
     1       ,'reductions:',12x,'**')
2050   format('c**',17x,a15,1x,a16,18x,'**')
2060   format('c** I/O prevented parallel directives from being '
     1       ,'issued.              **')
2070   format('c** Char. operations prevented parallel directives '
     1       ,'from being issued. **')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              P A R A L L E L              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               S Q U E E Z E               \\\\\\\\\\
c
c=======================================================================
c
       subroutine squeeze ( word )
c
c    dac:editor.squeeze <--------------- squeezes out blanks from "word"
c                                                            march, 1992
c
c    written by: David Clarke
c    modified 1: March, 2011 by DAC; generalised for word of arbitrary
c                length
c
c  PURPOSE:  This subroutine removes all blanks from the interior of a
c  word.
c
c  INPUT VARIABLES:
c    word        character string to be squeezed.
c
c  OUTPUT VARIABLES:
c    word        character string expunged of blanks.
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*(*) word
       integer       imax    , i       , ii
c
c-----------------------------------------------------------------------
c
       imax = len ( word )
       ii   = 0
       do 10 i=1,imax
         if (word(i:i) .ne. ' ') then
           ii = ii + 1
           word(ii:ii) = word(i:i)
         endif
10     continue
       word(ii+1:imax) = ' '
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               S Q U E E Z E               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                U P D A T E                \\\\\\\\\\
c
c=======================================================================
c
       subroutine update ( leof )
c
c    dac:editor.update <--------------- updates subroutine files on disc
c                                                              may, 1989
c
c    written by: David Clarke
c    modified 1: September 1989, by David Clarke:  Reworked so that
c                ISHELL is no longer needed.
c    modified 2: May 2001, by David Clarke: Fixed problem with
c                generating makefile should the last buffer contain no
c                subprograms.
c    modified 3: July 2004, by David Clarke; generalised makefile to
c                allow special routines to be compiled with different
c                compiler options.
c
c  PURPOSE:  This subroutine has been completely revamped from the
c  version in EDITOR1.5, because the previous version was terribly slow.
c  It made frequent use of the "ishell" feature, which allows UNICOS
c  commands to be executed within a FORTRAN program.  Unfortunately, as
c  with many other UNICOS features, "ishell" is not all that useful,
c  since calling it momentarily doubles the size of the executable,
c  bringing the machine to its knees.
c      This subroutine UPDATEs the disc files containing the individual
c  subprograms according to the changes made to the "master" file,
c  which contains all the PRECOMpiled subprograms.  Rather than using
c  "ishell", UPDATE now uses the "err" option in the "open" statement
c  to indicate if the file is not found in the directory "branch".
c  Thus, the only limitation of this version over version 1.5 is all
c  files must exist directly in directory "branch", and not in some
c  subdirectory of "branch".
c      If no file containing the subroutine is found in the directory
c  "branch", one is written.  If a file does exist in "branch", it is
c  compared to the current version.  If the two copies differ, the old
c  version is overwritten.  If the files are identical, no file is
c  written to disc.  In this way, the creation date of files containing
c  uneditted subroutines will not be affected, and MAKE will not
c  recompile them.
c      UPDATE will create an object file list for the makefile while it
c  is updating the modules.  PRECOM opens and closes the makefile, and
c  writes the rest of the makefile to disc.
c
c  INPUT VARIABLES:
c      LEOF      logical variable to indicate if the end of file has
c                been reached in the input disc file "oldname".  This
c                is needed in making the object list for the makefile.
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    GETWRD
c    RFILE
c    WFILE
c    CAPITALS
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
c-----------------------------------------------------------------------
c----------------------------- Parameters ------------------------------
c-----------------------------------------------------------------------
       integer       k1      , k2      , k3      , k4      , k5
     1             , k6      , k7      , k8      , k9
       real          tiny    , huge
c
       parameter     ( k1=1000, k2=50000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
       parameter     ( tiny=1.0e-32, huge = 1.0e32 )
c
c-----------------------------------------------------------------------
c--------------------------- Root Variables ----------------------------
c-----------------------------------------------------------------------
       logical       lreadall
       character*8   ext     , blank8  , chtime
       character*16  dknam1  , dknam2  , dknam3  , dknam4  , blank16
     1             , makename, compiler, loader  , chdate
       character*32  branch  , blank32
       character*64  oldname , tmpname , chgname , newname , xeq
     1             , blank64
       character*128 coptions, loptions, blank128, speccopt
       character*512 libs
       integer       indent  , ireseq  , idump   , irepl   , ibegdo
     1             , ienddo  , ibegre  , iendre  , ibegwr  , iendwr
     2             , inc     , nerr1   , nerr2   , nerror1 , nerror2
     3             , ntarg   , norig   , ialpha  , inumber , nlold
     4             , nloldt  , nltmp   , nltmpt  , nlcdk   , nlcdkt
     5             , nlnew   , nlnewt  , nldmpt  , nlmakt  , iemax
     6             , ilmax   , iomax   , ismax   , itmax   , icmax
     7             , idmax   , iamax   , ivmax   , nchar   , nalias
     8             , nswitch , ndk     , ncd     , ngp     , job
     9             , ibanner , itable  , ixclude , inum    , ipre
     1             , inmlst  , icompar , ndiff   , ncharn  , ncharo
     2             , nchart  , ncharc  , ncharb  , ludmp   , luold
     3             , lutmp   , lunew   , luchg   , luout   , lumak
     4             , lunml   , lulp    , iupdate , iutask  , nobj2
     5             , swcase
       real          safety
c
       character*2   envir1  (  k7)
       character*16  orig    (  k3)
       character*16  cdnam   (  k4), dknam   (  k4), gpnam   (  k4)
     1             , cdgrp   (  k4), dkgrp   (  k4), specdk  (  k4)
       character*16  targ    (  k5)
       character*16  swtch1  (  k7), swtch2  (  k7)
       character*16  alias1  (  k8), alias2  (  k8)
       character*128 oldfile (  k2), tmpfile (  k2), cdkfile (  k2)
     1             , newfile (  k2)
       integer       lnerr1  (  k1), ierr1   (  k1)
     1             , lnerr2  (  k1), ierr2   (  k1)
       integer       lnorig  (  k3), itarg   (  k3), iotype  (  k3)
     1             , jstrt   (  k3), jfnsh   (  k3)
       integer       idkbeg  (  k4), idkend  (  k4), idkran  (  k4)
     1             , idksta  (  k4), idkfin  (  k4), idkxeq  (  k4)
     2             , icdbeg  (  k4), icdend  (  k4), icdran  (  k4)
     3             , icdsta  (  k4), icdfin  (  k4), icdxeq  (  k4)
     4             , igpbeg  (  k4), igpend  (  k4), igpran  (  k4)
       integer       lntarg  (  k5), iorig   (  k5), ittype  (  k5)
     1             , mtarg   (  k5)
       integer       ialias  (  k8), jranal  (  k8)
       integer       ignore  (  10)
c
       character*2   envir2  (  k5,  k7), envir3  (  k3,  k7)
c
c-----------------------------------------------------------------------
c----------------------- Equivalence statements ------------------------
c-----------------------------------------------------------------------
       character*8   c8      (  20)
       character*16  c16     (  20)
       character*32  c32     (  20)
       character*64  c64     (  20)
       character*128 c128    (  20)
       integer       i8      ( 100)
       real          r8      (  20)
c
       character*16  carr4   (  k4,   6), carr7   (  k7,   2)
     1             , carr8   (  k8,   2)
       integer       iarr1   (  k1,   4), iarr3   (  k3,   5)
     1             , iarr4   (  k4,  15), iarr5   (  k5,   4)
c
       equivalence   (c8      ( 1), ext     ), (c8      ( 2), blank8  )
     1             , (c8      ( 3), chtime  )
       equivalence   (c16     ( 1), dknam1  ), (c16     ( 2), dknam2  )
     1             , (c16     ( 3), dknam3  ), (c16     ( 4), dknam4  )
     2             , (c16     ( 5), blank16 ), (c16     ( 6), makename)
     3             , (c16     ( 7), compiler), (c16     ( 8), loader  )
     4             , (c16     ( 9), chdate  )
       equivalence   (c32     ( 1), branch  ), (c32     ( 2), blank32 )
       equivalence   (c64     ( 1), oldname ), (c64     ( 2), tmpname )
     1             , (c64     ( 3), chgname ), (c64     ( 4), newname )
     2             , (c64     ( 5), xeq     ), (c64     ( 6), blank64 )
       equivalence   (c128    ( 1), coptions), (c128    ( 2), loptions)
     1             , (c128    ( 3), blank128), (c128    ( 4), speccopt)
       equivalence   (i8      ( 1), indent  ), (i8      ( 2), ireseq  )
     1             , (i8      ( 3), idump   ), (i8      ( 4), irepl   )
     2             , (i8      ( 5), ibegdo  ), (i8      ( 6), ienddo  )
     3             , (i8      ( 7), ibegre  ), (i8      ( 8), iendre  )
     4             , (i8      ( 9), ibegwr  ), (i8      (10), iendwr  )
     5             , (i8      (11), inc     ), (i8      (12), nerr1   )
     6             , (i8      (13), nerr2   ), (i8      (14), nerror1 )
     7             , (i8      (15), nerror2 ), (i8      (16), ntarg   )
     8             , (i8      (17), norig   ), (i8      (18), ialpha  )
     9             , (i8      (19), inumber ), (i8      (20), nlold   )
       equivalence   (i8      (21), nloldt  ), (i8      (22), nltmp   )
     1             , (i8      (23), nltmpt  ), (i8      (24), nlcdk   )
     2             , (i8      (25), nlcdkt  ), (i8      (26), nlnew   )
     3             , (i8      (27), nlnewt  ), (i8      (28), nldmpt  )
     4             , (i8      (29), nlmakt  ), (i8      (30), iemax   )
     5             , (i8      (31), ilmax   ), (i8      (32), iomax   )
     6             , (i8      (33), ismax   ), (i8      (34), itmax   )
     7             , (i8      (35), icmax   ), (i8      (36), idmax   )
     8             , (i8      (37), iamax   ), (i8      (38), ivmax   )
     9             , (i8      (39), nchar   ), (i8      (40), nalias  )
       equivalence   (i8      (41), nswitch ), (i8      (42), ndk     )
     1             , (i8      (43), ncd     ), (i8      (44), ngp     )
     2             , (i8      (45), job     ), (i8      (46), ibanner )
     3             , (i8      (47), itable  ), (i8      (48), ixclude )
     4             , (i8      (49), inum    ), (i8      (50), ipre    )
     5             , (i8      (51), inmlst  ), (i8      (52), icompar )
     6             , (i8      (53), ndiff   ), (i8      (54), ncharn  )
     7             , (i8      (55), ncharo  ), (i8      (56), nchart  )
     8             , (i8      (57), ncharc  ), (i8      (58), ncharb  )
     9             , (i8      (59), ludmp   ), (i8      (60), luold   )
       equivalence   (i8      (61), lutmp   ), (i8      (62), lunew   )
     1             , (i8      (63), luchg   ), (i8      (64), luout   )
     2             , (i8      (65), lumak   ), (i8      (66), lunml   )
     3             , (i8      (67), lulp    ), (i8      (68), iupdate )
     4             , (i8      (69), iutask  ), (i8      (70), nobj2   )
     5             , (i8      (71), swcase  )
       equivalence   (r8      ( 1), safety  )
c
       equivalence   (carr4 (1, 1), dknam   ), (carr4 (1, 2), dkgrp   )
     1             , (carr4 (1, 3), cdnam   ), (carr4 (1, 4), cdgrp   )
     2             , (carr4 (1, 5), gpnam   ), (carr4 (1, 6), specdk  )
       equivalence   (carr7 (1, 1), swtch1  ), (carr7 (1, 2), swtch2  )
       equivalence   (carr8 (1, 1), alias1  ), (carr8 (1, 2), alias2  )
       equivalence   (iarr1 (1, 1), lnerr1  ), (iarr1 (1, 2), ierr1   )
     1             , (iarr1 (1, 3), lnerr2  ), (iarr1 (1, 4), ierr2   )
       equivalence   (iarr3 (1, 1), lnorig  ), (iarr3 (1, 2), itarg   )
     1             , (iarr3 (1, 3), jstrt   ), (iarr3 (1, 4), jfnsh   )
     2             , (iarr3 (1, 5), iotype  )
       equivalence   (iarr4 (1, 1), idkbeg  ), (iarr4 (1, 2), idkend  )
     1             , (iarr4 (1, 3), idkran  ), (iarr4 (1, 4), idksta  )
     2             , (iarr4 (1, 5), idkfin  ), (iarr4 (1, 6), idkxeq  )
     3             , (iarr4 (1, 7), icdbeg  ), (iarr4 (1, 8), icdend  )
     4             , (iarr4 (1, 9), icdran  ), (iarr4 (1,10), icdsta  )
     5             , (iarr4 (1,11), icdfin  ), (iarr4 (1,12), icdxeq  )
     6             , (iarr4 (1,13), igpbeg  ), (iarr4 (1,14), igpend  )
     7             , (iarr4 (1,15), igpran  )
       equivalence   (iarr5 (1, 1), lntarg  ), (iarr5 (1, 2), iorig   )
     1             , (iarr5 (1, 3), ittype  ), (iarr5 (1, 4), mtarg   )
c
c-----------------------------------------------------------------------
c--------------------------- Common blocks -----------------------------
c-----------------------------------------------------------------------
       common / lcommon  /
     1               lreadall
       common / ccommon  /
     1               targ    , orig    , envir1  , envir2  , envir3
     2             , libs    , c8      , c16     , c32     , c64
     3             , c128    , carr4   , carr7   , carr8
       common / files    /
     1               oldfile , tmpfile , cdkfile , newfile
       common / icommon  /
     1               i8      , iarr1   , iarr3   , iarr4   , iarr5
     2             , jranal  , ialias  , ignore
       common / rcommon  /
     1               r8
c
c
       logical       leof    , ldum    , lobj1
       character*1   char1
       character*16  word    , filename
       character*64  infile
       integer       i       , j       , nlines  , ndeck   , jbeg
     1             , jend    , jran    , next    , match   , iwrd
     2             , ideck   , ncharf  , lftmp   , lltmp   , iopt
     3             , nobj1
c
       character*16  keywrd  (  11), decknam (  k4)
c
       equivalence   (dkgrp   ( 1), decknam ( 1))
c
c      External statements
c
       external      getwrd  , rfile   , wfile   , capitals
c
c      Data Statements
c
       data          keywrd
     1   / 'PROGRAM         ', 'SUBROUTINE      ', 'FUNCTION        '
     2   , 'BLOCKDATA       ', 'BLOCK           ', 'END             '
     3   , 'REAL            ', 'INTEGER         ', 'LOGICAL         '
     4   , 'CHARACTER       ', 'OPTIONS         ' /
c
c-----------------------------------------------------------------------
c
c      Copy contents of "newfile" to "oldfile".
c
       do 10 i=1,nlnew
         oldfile(i) = newfile(i)
10     continue
       nlold  = nlnew
       nlines = nlnewt
       nobj1  = max0 ( 0, ndk - nobj2 )
c
c      Gather module names and limits and store them in "decknam",
c  "idksta", and "idkfin".
c
       iopt  = 0
       ndeck = 0
11     continue
       do 70 i=1,nlold
         if (oldfile(i)(1:6) .eq. '      ') then
           jbeg  = 7
           jend  = nchar
           next  = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' *', word )
           call capitals ( word )
           match = 1
           do 20 iwrd=1,11
             if (word .eq. keywrd(iwrd)) go to 30
20         continue
30         continue
           if ( (iwrd .ge.  1) .and. (iwrd .le.  4) ) match = 2
           if   (iwrd .eq.  5)                        match = 3
           if   (iwrd .eq.  6)                        match = 4
           if ( (iwrd .ge.  7) .and. (iwrd .le. 10) ) match = 5
           if   (iwrd .eq. 11)                        match = 6
           go to (70, 40, 40, 40, 40, 60) match
c
40         continue
           if (oldfile(i+next)(jend+1:jend+1) .eq. '*') then
             jbeg = jend  + 1
             jend = 0
             call getwrd ( i, 1, next, jbeg, jend, jran, ' ', word )
           endif
50         continue
           jbeg = jend  + 1
           jend = 0
           call getwrd ( i, 1, next, jbeg, jend, jran, ' (', word )
           if (match .eq. 2) then
             if (iopt .eq. 0) then
               ndeck = ndeck + 1
               idksta (ndeck) = i
             endif
             decknam(ndeck) = word
             iopt = 0
             go to 70
           endif
           if (match .eq. 3) then
             match = 2
             go to 50
           endif
           if (match .eq. 4) then
             if ( (word .eq. blank16) .and. (ndeck .gt. 0) )
     1         idkfin (ndeck) = i
             go to 70
           endif
           if (match .eq. 5) then
             call capitals ( word )
             if (word .eq. keywrd(3)) then
               match = 2
               go to 50
             else
               go to 70
             endif
           endif
c
c      An OPTION statement has been found.  EDITOR assumes that the next
c  statement will be a subprogram statement.  If it isn't, this may or
c  may not have consequences during the subsequent precompilation, and
c  at any rate will cause the compiler to generate an error message upon
c  compilation.
c
60         continue
           if (iopt .eq. 1) go to 70
           iopt  = 1
           ndeck = ndeck + 1
           idksta (ndeck) = i
           go to 70
         endif
70     continue
c
c      Change made May 1, 2001!!
c
c      In the rare case where the text EDITOR has in its buffer
c  [newfile(1:nlnew)] contains the last line of the file (eof), but no
c  sub-programs (e.g., buffer contains only *dk zzzend in dzeus34), then
c  no subprogram is identified, and thus no additional statements are
c  added to the object list in the makefile.  Thus the last entry made
c  to the object list was generated from the last chunk of text EDITOR
c  digested, during which leof was false.  Thus, a backslash (\) was
c  appended to the last entry in the object list, which causes MAKE to
c  crash.
c      To solve this, if there are no subprograms in the current buffer,
c  and the current buffer contains the end of the file (leof = .true.),
c  then create a dummy subprogram (zzzend.f), and add that to the list
c  of object files with no backslash.
c
       if ( (ndeck .eq. 0) .and. (leof) ) then
         oldfile(nlold+1) = '       subroutine zzzend'
         oldfile(nlold+2) = '       return'
         oldfile(nlold+3) = '       end'
         nlold                  = nlold + 3
         go to 11
       endif
c
c      Default for the extension is '.f'.  If the first character of
c  the extension is not a period, put one at the beginning.
c
       if (ext .eq. '        ') ext = '.f      '
       if (ext(1:1) .ne. '.') then
         word(2:8) = ext(1:7)
         word(1:1) = '.'
         ext       = word(1:8)
       endif
c
c      Compare each module with the copy on disc (in directory "branch")
c  and UPDATE as necessary.
c
       do 140 ideck=1,ndeck
c
c      Determine number of characters in module name (.le. 8)
c
         do 80 j=1,8
           char1 = decknam(ideck)(j:j)
           if (char1 .ne. ' ') ncharf = j
80       continue
         filename = decknam(ideck)
c
c      If a makefile is desired, create object file list (for those
c  modules being compiled with compiler options coptions) and write to
c  unit "lumak".
c
         if (makename .ne. blank16) then
           lobj1 = .true.
           do 81 i=1,nobj2
             if (specdk(i) .eq. decknam(ideck)) lobj1 = .false.
81         continue
           if (lobj1) then
             filename(ncharf+1:ncharf+2) = '.o'
             if ( (ideck .eq. 1) .and. (nlmakt .eq. 0) ) then
               if (nobj1 .eq. 1) then
                 write (lumak, 2010) 'OBJ1', filename
               else
                 write (lumak, 2020) 'OBJ1', filename
               endif
             else
               if ( (ideck .eq. ndeck) .and. (leof) ) then
                 write (lumak, 2040) filename
               else
                 write (lumak, 2030) filename
               endif
             endif
             nlmakt = nlmakt + 1
           endif
         endif
c
c      Store module "ideck" in "newfile".
c
         nlnew = 0
         do 90 i=idksta(ideck),idkfin(ideck)
           nlnew = nlnew + 1
           newfile(nlnew) = oldfile(i)
90       continue
c
c      Create "filename" for module by appending the extension "ext"
c  after "filename".  Then, concatenate "branch" and "filename" to get
c  "infile".
c
         filename(ncharf+1:ncharf+ 8) = ext
         infile                       = blank64
         infile  (       1:       32) = branch
         infile  (ncharb+1:ncharb+16) = filename
c
c      Attempt to open "infile".
c
c  From DAC, 3/11: Commented out are lines that have been useful in
c  other OS/compilers.  I still need to test this with the various
c  compilers edit22 is supposed to support.
c
         open ( lutmp, file=infile, status='old', err=120 )
ccc  1               , fileopt='buffer=1024000' )
ccc      open ( lutmp, file=infile, status='old', err=120
ccc  1               , blocksize=1024000 )
c
c      The file "infile" exists on disc.  Read it into "tmpfile" and
c  compare it with "newfile".
c
         lftmp = 1
         lltmp = 0
         nltmp = 0
         call rfile ( lutmp, infile, -2, lftmp, lltmp, 0, ldum )
         close ( lutmp )
         if (nltmp .eq. nlnew) then
           do 100 i=1,nltmp
             if (newfile(i) .ne. tmpfile(i)) go to 110
100        continue
c
c      "newfile" and "tmpfile" match exactly.  Go on to the next module.
c
           go to 140
         endif
110      continue
c
c      "newfile" and "tmpfile" do not match.  Update the disc file.
c
         write (6, 2050) infile
         go to 130
c
c      "infile" does not exist.  Write "newfile" to disc in a file with
c  name "infile" opened on unit "lutmp".
c
120      continue
         write (6, 2060) infile
c
130      continue
c
c  From DAC, 3/11: Commented out are lines that have been useful in
c  other OS/compilers.  I still need to test this with the various
c  compilers edit22 is supposed to support.
c
         open  ( lutmp, file=infile, status='unknown' )
ccc     1                , fileopt='buffer=1024000' )
ccc      open  ( lutmp, file=infile, status='unknown'
ccc  1                , blocksize=1024000 )
         call wfile ( lutmp, 4 )
         close ( lutmp )
c
c      Go on to next module.
c
140    continue
c
c      If a makefile is desired, leof is .true. (all the source file has
c  now been updated) and special routines were flagged for special
c  compiler options, create a second object file list and write to unit
c  "lumak".
c
       if ( (makename .ne. blank16) .and. leof ) then
         do 160 ideck=1,nobj2
           ncharf = 0
           do 150 j=1,8
             char1 = specdk(ideck)(j:j)
             if (char1 .ne. ' ') ncharf = j
150        continue
           filename = specdk(ideck)
           filename(ncharf+1:ncharf+2) = '.o'
           if (ideck .eq. 1) then
             if (nobj2 .eq. 1) then
               write (lumak, 2010) 'OBJ2', filename
             else
               write (lumak, 2020) 'OBJ2', filename
             endif
           else
             if (ideck .eq. nobj2) then
               write (lumak, 2040) filename
             else
               write (lumak, 2030) filename
             endif
           endif
           nlmakt = nlmakt + 1
160      continue
       endif
c
c      All modules have been considered.  Return to PRECOM.
c
       nlnewt = nlines
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
c  From DAC, 6/11: The double backslashes \\ used to be required by F77
c  under SOLARIS; unknown whether it's still relevant to Sun's f90 -f77.
c
2010   format(a,'     = $(DIR)',a16)
2020   format(a,'     = $(DIR)',a16,' \\')
2030   format('           $(DIR)',a16,' \\')
2040   format('           $(DIR)',a16)
2050   format('UPDATE  : Updating old file "',a50,'"')
2060   format('UPDATE  : Creating new file "',a50,'"')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                U P D A T E                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                W C L O C K                \\\\\\\\\\
c
c=======================================================================
c
       function wclock ( msec, chtime, chdate, iform )
c
c    dac:editor.wclock <----------- returns number of wall clock seconds
c    from dac:zeus3d.wclock                               february, 2011
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE: This integer function returns the number of elapsed wall
c  clock seconds since the beginning of the year in which the job began,
c  taking into account passage over leap years, months of differing
c  lengths, etc.  For compilers that support DATE_AND_TIME, the argument
c  "msec" is number of elapsed milliseconds since the last full second.
c  Otherwise, "msec" is returned as zero.
c
c  This function is better than the intrinsic function TIME (available
c  on most platforms which returns the number of seconds elapsing since
c  Jan 1, 1970) as TIME does not give information on fractional seconds.
c
c  This function also returns the time (in "chtime") in format hh:mm:ss,
c  and the date (in "chdate") in one of four formats as specified by
c  "iform".
c
c  INPUT VARIABLES:
c    iform       =0 => "chtime" and "chdate" not returned
c                =1 => date returned as dd/mm/yy
c                =2 => date returned as dd/mm/yyyy
c                =3 => date returned as mm/dd/yy
c                =4 => date returned as MMMMMMMMM dd, yyyy
c
c  OUTPUT VARIABLES:
c    wclock      integer number of whole seconds since beginning of year
c                in which job began
c    msec        integer number of elapsed milliseconds since last whole
c                second ended
c    chtime      time returned as hh:mm:ss
c    chdate      date returned in format specified by "iform"
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    CTOI
c    STRLEN
c    compiler-specific wall clock subroutines/functions
c
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c------------------------ Implicit statements --------------------------
c-----------------------------------------------------------------------
       implicit      none
c
       character*(*) chtime  , chdate
       character*10  cmonth
       character*26  chstr
       integer       wclock  , msec    , iform   , year    , month
     1             , day     , hour    , minute  , second  , yrbeg
     2             , nleap   , leap    , ncht    , nchd    , nch
     3             , yr
c
       integer       values  (   8), days    (  12)
c
       data          year    , month   , day     , hour    , minute
     1             / 2000    , 1       , 1       , 0       , 0        /
       data          second  , yrbeg
     1             / 1       , 0        /
       data          days     /   0,  31,  59,  90, 120, 151
     1                        , 181, 212, 243, 273, 304, 334 /
       save          yrbeg
c
       integer       ctoi    , strlen
       external      ctoi    , strlen
c
c-----------------------------------------------------------------------
c
       msec   = 0
c
c  DATE_AND_TIME returns eight integers in "values", where:
c
c  values(1)   the year (e.g., 2011)
c  values(2)   the month of the year (1-12)
c  values(3)   the day of the month (1-31)
c  values(4)   the number of minutes from GMT (e.g., -240 for Halifax)
c  values(5)   the hour of the day (0-23)
c  values(6)   the minute of the hour (0-59)
c  values(7)   the second of the minute (0-59)
c  values(8)   the number of milliseconds of the second (0-999)
c
       call date_and_time ( values=values )
       year   = values(1)
       month  = values(2)
       day    = values(3)
       hour   = values(5)
       minute = values(6)
       second = values(7)
       msec   = values(8)
c
c----- Number of seconds since beginning of year in which job began ----
c
       if ( yrbeg .eq. 0 ) yrbeg = year
c
c      If the current year is a leap year, set "leap" to 1 if the month
c  is beyond February (month > 2).
c
       leap = 0
       if ( ( 4 * ( year/4 ) .eq. year ) .and. (month .gt. 2) ) leap = 1
c
c      For extreme jobs that take months, even years, we may need to
c  keep track of wall clock over one or more leap years.  "nleap" counts
c  all leap years between "yrbeg" and "year", including "yrbeg" but not
c  including "year", the latter being accounted for by "leap".
c
       nleap  = ( year - 1 ) / 4 - ( yrbeg - 1) / 4
       wclock = ( year - yrbeg ) * 31536000
     1        + ( nleap + days(month) + leap + day - 1 ) * 86400
     2        + hour * 3600 + minute * 60 + second
c
c----- Set "chtime" and "chdate" ---------------------------------------
c
       if ( (iform .lt. 1) .or. (iform .gt. 4) ) return
       ncht   = len ( chtime )
       nchd   = len ( chdate )
       chtime = ' '
       chdate = ' '
       write ( chstr, 2010 ) hour, minute, second
       nch          = min ( 8, ncht )
       chtime(1:nch) = chstr(1:nch)
       yr           = year - 100 * ( year/100 )
       if (iform .eq. 1) write ( chstr, 2020 ) day, month, yr
       if (iform .eq. 2) write ( chstr, 2030 ) day, month, year
       if (iform .eq. 3) write ( chstr, 2020 ) month, day, yr
       if (iform .eq. 4) then
         cmonth = ' '
         if (month .eq.  1) cmonth = 'January '
         if (month .eq.  2) cmonth = 'February '
         if (month .eq.  3) cmonth = 'March '
         if (month .eq.  4) cmonth = 'April '
         if (month .eq.  5) cmonth = 'May '
         if (month .eq.  6) cmonth = 'June '
         if (month .eq.  7) cmonth = 'July '
         if (month .eq.  8) cmonth = 'August '
         if (month .eq.  9) cmonth = 'September '
         if (month .eq. 10) cmonth = 'October '
         if (month .eq. 11) cmonth = 'November '
         if (month .eq. 12) cmonth = 'December '
         nch = strlen ( cmonth ) + 1
         if (day .lt. 10) write ( chstr, 2040 ) cmonth(1:nch), day, year
         if (day .ge. 10) write ( chstr, 2050 ) cmonth(1:nch), day, year
       endif
       nch           = min ( strlen ( chstr ), nchd )
       chdate(1:nch) = chstr(1:nch)
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(i2,':',i2.2,':',i2.2)
2020   format(i2,'/',i2.2,'/',i2.2)
2030   format(i2,'/',i2.2,'/',i4.4)
2040   format(a,i1,', ',i4)
2050   format(a,i2,', ',i4)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                W C L O C K                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 1             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac01 ( nmlst, nmax )
c
c    dac:namelist.nlsdac01 <----------------------- reset namelist array
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine initialises all the elements of the array
c  "nmlst" to 32 character blanks words.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*32  blank32
       integer       nmax    , i
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank32 /'                                '/
c
c-----------------------------------------------------------------------
c
       do 10 i=1,nmax
         nmlst(1,i) = blank32
         nmlst(2,i) = blank32
10     continue
c
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 1             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 2             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac02 ( nlunit, cname, nmlst, nmax, ival )
c
c    dac:namelist.nlsdac02 <----------------- reads input character data
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1: February, 1991 by David Clarke; Fixed various bugs
c                  discovered in the previous 20 months of use.
c                  Character strings of indefinite length can now be
c                  read.
c      Modified 2: January, 1993 by David Clarke; Generalised array
c                  reader so that ar(1,1) is understood as ar(1:1,1:1).
c
c  PURPOSE:  This subroutine reads the input decks originally designed
c  for CFT "namelist" (under CTSS), and stores the character
c  representations of the input data in "nmlst(n,2)".  Meanwhile,
c  "nmlst(n,1)" contains a list of the corresponding variable names,
c  which were set by the calling program.  Other subroutines (called by
c  the calling program) convert the character strings to the correct
c  attribute.
c
c  EXTERNALS:  NLSDAC15 - 23
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1   , char2   , char3
       character*8   cname   , word8
       character*32  blank32 , word32  , temp32
       character*72  line    , oldline
       integer       nlunit  , nmax    , ival    , nlist   , jbeg
     1             , jend    , jran    , jbegold , jendold , i
     2             , i1      , i2      , ilist   , ilisto  , match
     3             , iqte
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data blank32 /'                                '/
c
c      External statements
c
       external      nlsdac15, nlsdac16, nlsdac17, nlsdac18, nlsdac19
     1             , nlsdac20, nlsdac21, nlsdac22, nlsdac23
c
c-----------------------------------------------------------------------
c
c      Initialise parameters.  Note that all the second elements of the
c  array "nmlst" (nmlst(2,*)) and all but the first "ival" of the first
c  elements (nmlst(1,*)) are reset to 32 character blank words.  This is
c  to allow for the possibility that the READ statement appears in a
c  loop, in which case, most of "nmlst" must be reset.
c
       do 10 i=1,nmax
         nmlst(2,i) = blank32
10     continue
       if (ival .ge. nmax) return
       do 20 i=ival+1,nmax
         nmlst(1,i) = blank32
20     continue
       nlist = ival
       iqte  = 0
30     continue
c
c      Read line from input deck.
c
       read (nlunit, 1010, end=150, err=160) line
c
c      Error message if column 1 contains anything but a 'c', 'C', or a
c  blank.
c
       char2 = line(1:1)
       if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1      (char2 .ne. ' ') ) call nlsdac15 ( line, 1, 1 )
c
c      Error message if column 2 contains anything but a '$' or a blank
c  (unless column 1 contains a 'c' or a 'C').
c
       char3 = line(2:2)
       if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1      (char3 .ne. '$') .and. (char3 .ne. ' ') )
     2   call nlsdac15 ( line, 2, 2 )
c
c      If column 1 contains a 'c' or a 'C', the line is "commented out",
c  and is echoed on the terminal.
c
       if ( (char2 .eq. 'c') .or. (char2 .eq. 'C') ) then
         write (6, 2010) line
         go to 30
       endif
c
c      If column 2 contains a '$' sentinal, then a new namelist begins.
c  Determine if name of namelist matches "cname", and if it does, read
c  the contents of the namelist.  The next '$' sentinal will close the
c  namelist.
c
       if (char3 .eq. '$') then
         jbeg = 3
         call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
         if (char1 .eq. '$') go to 30
         call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte, word32 )
         word8 = word32(1:8)
         if (word8 .eq. cname) then
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           if (char1 .eq. '$') return
40         continue
           i1 = 0
           i2 = 0
c
c      Read the next specified variable.
c
           call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                   , word32 )
           do 50 i=1,nmax
             ilist  = i
             temp32 = blank32
             temp32(1:8) = nmlst(1,ilist)(1:8)
             if (temp32 .eq. blank32) go to 60
             if (temp32 .eq.  word32) then
               if (nmlst(2,ilist) .ne. blank32) then
                 temp32 = nmlst(1,ilist)
                 nlist  = nlist + 1
                 ilist  = nlist
                 nmlst(1,ilist)( 1: 8) = temp32( 1: 8)
                 nmlst(1,ilist)(25:32) = temp32(25:32)
               endif
               go to 70
             endif
50         continue
c
c      Error:  variable specified in input deck was not included in
c  "nmlst".
c
60         continue
           call nlsdac15 ( line, jbeg, 3 )
c
c      Specified variable found in "nmlst".  Read the next character.
c  If "char1" .ne. '(' or '=', issue error message.  If "char1" = '(', a
c  portion of an array will be set.  If "char1" = '=', the variable valu
c  will be read next.
c
70         continue
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           match = 1
           if (char1 .eq. '(') match = 2
           if (char1 .eq. '=') match = 3
           go to (80, 90, 130) match
c
c      Error: unexpected character.
c
80         continue
           call nlsdac15 ( line, jbeg, 4 )
c
c      Specify portion of vector or array to be set.  The limits are
c  stored in columns 10 through 28  of "nmlst(1,ilist)", and are
c  used by other subroutines to initiate the variable.
c
90         continue
           jbeg = jend + 1
           call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                   , word32 )
           call nlsdac18 ( line, jbeg, word32 )
           call nlsdac19 ( word32, i1 )
           i2 = i1
           nmlst(1,ilist)(9:12) = word32(1:4)
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           match = 1
           if (char1 .eq. ')') match = 2
           if (char1 .eq. ':') match = 3
           if (char1 .eq. ',') match = 4
           go to (80, 100, 110, 111) match
100        continue
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           if (char1 .ne. '=') go to 80
           go to 130
110        continue
           jbeg = jend + 1
           call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                   , word32 )
           call nlsdac18 ( line, jbeg, word32 )
           nmlst(1,ilist)(13:16) = word32(1:4)
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           match = 1
           if (char1 .eq. ')') match = 2
           if (char1 .eq. ',') match = 3
           go to (80, 100, 120) match
111        continue
           nmlst(1,ilist)(13:16) = word32(1:4)
120        continue
           jbeg = jend + 1
           call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                   , word32 )
           call nlsdac18 ( line, jbeg, word32 )
           nmlst(1,ilist)(17:20) = word32(1:4)
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           match = 1
           if (char1 .eq. ':') match = 2
           if (char1 .eq. ')') match = 3
           go to (80, 121, 122) match
121        continue
           jbeg = jend + 1
           call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                   , word32 )
           call nlsdac18 ( line, jbeg, word32 )
           nmlst(1,ilist)(21:24) = word32(1:4)
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           match = 1
           if (char1 .eq. ')') match = 2
           go to (80, 123) match
122        continue
           nmlst(1,ilist)(21:24) = word32(1:4)
123        continue
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           if (char1 .ne. '=') go to 80
c
c      Read the character representation of the variable value.
c
130        continue
           jbeg    = jend + 1
           call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                   , word32 )
           jbegold = jbeg
           jendold = jend
           oldline = line
           jbeg    = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           if (char1 .eq. '*') then
             char1 = nmlst(1,ilist)(32:32)
             if (char1 .ne. 'v') call nlsdac15 ( line, jbeg, 8 )
             if (i1 .eq. 0) i1 = 1
             call nlsdac18 ( line, jbeg, word32 )
             call nlsdac19 ( word32, i2 )
             i2 = i1 + i2 - 1
             call nlsdac20 ( i2, word32 )
             nmlst(1,ilist)(13:16) = word32(1:4)
             call nlsdac20 ( i1, word32 )
             nmlst(1,ilist)( 9:12) = word32(1:4)
             jbeg = jend + 1
             call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                     , word32 )
           else
             jbeg = jbegold
             jend = jendold
             if (line .ne. oldline) then
               backspace (nlunit)
               line = oldline
             endif
           endif
           ilisto = ilist
           char1  = nmlst(1,ilist)(30:30)
           if (char1 .eq. 'l') call nlsdac22 ( line, jbeg, word32 )
           if (char1 .eq. 'i') call nlsdac18 ( line, jbeg, word32 )
           if (char1 .eq. 'r') call nlsdac23 ( line, jbeg, word32 )
           if (char1 .eq. 'c') then
c
c      Single or double quotes must surround each character string.  If
c  a second quote is not found, it will be assumed that the character
c  variable is being assigned a string longer than 30 characters.  In
c  this case, multiple entries are made in "nmlst(1,ilist)" for the
c  character variable, with successive pieces of the assigned value
c  stored in "nmlst(2,ilist)".  Continuation characters (&) are appended
c  to each piece of the input character value to tell the subroutines
c  which set the values of character variables that each entry is to be
c  concatenated, rather than overwriting the previous entry.
c
             char1 = word32(1:1)
             if ( (char1 .ne. '"') .and. (char1 .ne. '''') )
     1         call nlsdac15 ( line, jbeg, 10 )
             temp32           = blank32
             temp32(1:jran-1) = word32(2:jran)
             word32           = temp32
             jran             = jran - 1
140          continue
             char1 = word32(jran:jran)
             if ( (char1 .ne. '"') .and. (char1 .ne. '''') ) then
               char1 = nmlst(1,ilist)(32:32)
               if ( (char1 .eq. 'v') .and. (i1 .eq. 0) ) then
                 nmlst(1,ilist)(9:9) = '1'
                 i1 = 1
               endif
               if (jran .le. 30) then
                 jbeg = - jend - 1
               endif
               if (jran .eq. 31) then
                 jran = 30
                 jbeg = - jend
               endif
               if (jran .eq. 32) then
                 jran = 30
                 jbeg = - jend + 1
               endif
               word32 (31:31) = char(jran)
               word32 (32:32) = '&'
               nmlst(2,ilist) = word32
               word32         = nmlst(1,ilist)
               nlist          = nlist + 1
               ilist          = nlist
               nmlst(1,ilist) = word32
               call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                       , word32 )
               go to 140
             endif
             temp32           = blank32
             temp32(1:jran-1) = word32(1:jran-1)
             word32           = temp32
           endif
           nmlst(2,ilist) = word32
           ilist          = ilisto
c
c      Make sure next character is a comma or a dollar sign.
c
           jbeg = jend + 1
           call nlsdac17 ( nlunit, line, jbeg, jend, char1 )
           if ( (char1 .ne. ',') .and. (char1 .ne. '$') ) go to 80
           jend = jbeg
c
c      If the variable is a vector, check to see if there are more data
c  (a propos for the syntax: iplot=1,1,1,2,0).
c
           if (nmlst(1,ilist)(32:32) .eq. 'v') then
             if (i1 .eq. 0) then
               nmlst(1,ilist)(9:9) = '1'
               i1 = 1
             endif
             if (i2 .eq. 0) i2 = i1
             if (char1 .eq. '$') return
             jbegold = jbeg
             jendold = jend
             oldline = line
             jbeg    = jend + 1
             call nlsdac16 ( nlunit, line, jbeg, jend, jran, iqte
     1                     , word32 )
             char2 = word32(1:1)
             jbeg  = jend + 1
             call nlsdac17 ( nlunit, line, jbeg, jend, char3 )
             if ( (char3 .eq. ',') .or. (char3 .eq. '$') .or.
     1            (char3 .eq. '*') .or. (char2 .eq. '"') .or.
     2            (char2 .eq. '''') ) then
               word32 = nmlst(1,ilist)
               nlist  = nlist + 1
               ilist  = nlist
               nmlst(1,ilist)( 1: 8) = word32( 1: 8)
               nmlst(1,ilist)(25:32) = word32(25:32)
               i1 = i2 + 1
               i2 = i1
               call nlsdac20 ( i1, word32 )
               nmlst(1,ilist)( 9:12) = word32(1:4)
             endif
             jbeg = jbegold
             jend = jendold
             if (line .ne. oldline) then
               backspace (nlunit)
               line = oldline
             endif
             if ( (char3 .eq. ',') .or. (char3 .eq. '$') .or.
     1            (char3 .eq. '*') .or. (char2 .eq. '"') .or.
     2            (char2 .eq. '''') ) go to 130
           endif
c
c     Go on to next variable in "line".
c
           if (char1 .eq. '$') return
           go to 40
         endif
       endif
c
c      No match for "cname" in current "line".  Read next "line".
c
       go to 30
c
c      Error:  "cname" does not exist, or was out of order and thus
c  skipped over.
c
150    continue
       call nlsdac15 ( cname, 0, 6 )
c
c      Error:  Problem reading input deck.
c
160    continue
       call nlsdac15 ( blank32, 0, 7 )
c
c-----------------------------------------------------------------------
c----------------------- Read format statements ------------------------
c-----------------------------------------------------------------------
c
1010   format(a72)
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(a72)
c
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 2             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 3             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac03 ( cscalar, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac03 <--------------------- fills character scalar
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1: February 1991, by David Clarke; rewritten to allow
c                  character strings to be specified in pieces.
c
c  PURPOSE:  This subroutine assigns the input value to a character
c  scalar.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  blank32 , word32
       character*(*) cscalar
       integer       nmax    , i       , ibeg    , mult    , lbeg
     1             , lend    , lran
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8   / '        ' /
       data          blank32  / '                                ' /
c
c-----------------------------------------------------------------------
c
       mult = 0
       ibeg = 1
       lbeg = 1
10     continue
c
c      Find next entry in "nmlst(1,*)" which matches the name of the
c  variable to be set ("cstring").
c
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. cstring) go to 30
         if (word8 .eq. blank8 ) return
20     continue
       return
30     continue
       word32 = nmlst(2,i)
c
c      If character string is longer than 30 characters (final character
c  is '&'), it has been stored in "nmlst" in pieces.  Thus, set the next
c  piece of "cscalar" to the contents of "nmlst(2,i)", and then go back
c  to read the next piece.
c
       if (word32(32:32) .eq. '&') then
         mult = 1
         lran = ichar ( word32(31:31) )
         lend = lbeg + lran - 1
         cscalar(lbeg:lend) = word32(1:lran)
         lbeg = lend + 1
         ibeg = i + 1
         go to 10
       endif
c
c      If the character string was stored in pieces, "mult" will have
c  been set to 1.  If final character is not a '&', then this is the
c  last piece to read in.  Do not include trailing blanks in "cscalar".
c
c      If "mult" is 0, then the character string is stored in its
c  entirety in "nmlst(2,i)".  Thus, set cscalar trivially.
c
       if (mult .eq. 1) then
         do 60 lran=31,1,-1
           if (word32(lran:lran) .ne. ' ') go to 70
60       continue
70       continue
         lend = lbeg + lran - 1
         cscalar(lbeg:lend) = word32(1:lran)
       else
c
c      See comments from DAC, Jan/08 and Apr/08 in NLSDAC07.
c
         if (word32 .ne. blank32) cscalar = word32
c        cscalar = word32
       endif
c
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 3             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 4             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac04 ( iscalar, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac04 <----------------------- fills integer scalar
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input value to an integer
c  scalar.
c
c  EXTERNALS:  NLSDAC19
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  blank32 , word32
       integer       iscalar , nmax    , i
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8   / '        ' /
       data          blank32  / '                                ' /
c
c      External statements
c
       external      nlsdac19
c
c-----------------------------------------------------------------------
c
       do 10 i=1,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. cstring) go to 20
         if (word8 .eq. blank8 ) return
10     continue
       return
20     continue
       word32 = nmlst(2,i)
       if (word32 .ne. blank32) call nlsdac19 ( word32, iscalar )
c
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 4             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 5             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac05 ( rscalar, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac05 <-------------------------- fills real scalar
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input value to a real scalar.
c
c  EXTERNALS:  NLSDAC21
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  blank32 , word32
       integer       nmax    , i
       real          rscalar
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8   / '        ' /
       data          blank32  / '                                ' /
c
c      External statements
c
       external      nlsdac21
c
c-----------------------------------------------------------------------
c
       do 10 i=1,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. cstring) go to 20
         if (word8 .eq. blank8 ) return
10     continue
       return
20     continue
       word32 = nmlst(2,i)
       if (word32 .ne. blank32) call nlsdac21 ( word32, rscalar )
c
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 5             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 6             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac06 ( lscalar, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac06 <----------------------- fills logical scalar
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input value to a logical
c  scalar.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       logical       lscalar
       character*8   cstring , word8   , blank8
       integer       nmax    , i
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8   / '        ' /
c
c-----------------------------------------------------------------------
c
       do 10 i=1,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. cstring) go to 20
         if (word8 .eq. blank8 ) return
10     continue
       return
20     continue
       word8 = nmlst(2,i)(1:8)
       if (word8 .eq. '.true.  ') lscalar = .true.
       if (word8 .eq. '.t.     ') lscalar = .true.
       if (word8 .eq. '.false. ') lscalar = .false.
       if (word8 .eq. '.f.     ') lscalar = .false.
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 6             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 7             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac07 ( cvector, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac07 <--------------------- fills character vector
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1: February 1991, by David Clarke; rewritten to allow
c                  character strings to be specified in pieces.
c
c  PURPOSE:  This subroutine assigns the input values to a character
c  vector.
c
c  EXTERNALS:  NLSDAC19
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*12  cstr12  , word12
       character*32  word32  , blank32
       integer       nmax    , mult    , i       , ibeg    , j
     1             , jbeg    , jend    , lbeg    , lend    , lran
c
       character*(*) cvector(*)
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8   / '        ' /
       data          blank32  / '                                ' /
c
c      External statements
c
       external      nlsdac19
c
c-----------------------------------------------------------------------
c
       ibeg  = 1
10     continue
       lbeg  = 1
       mult  = 0
c
c      Find next entry in "nmlst(1,*)" which matches the name of the
c  variable to be set ("cstring").
c
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. cstring) go to 30
         if (word8 .eq. blank8 ) go to 999
20     continue
30     continue
       cstr12 = nmlst(1,i)(1:12)
c
c      Set range of variable index (jbeg through jend) to be set to
c  what will be stored in "cvector(jbeg)".
c
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
c
c      Note from DAC, Apr/08: Added conditional go to 120 when jbeg = 0,
c  which will trip the `array bound checking' (-C) in loop 110 below.
c  If jbeg=0, the array isn't being set anyway, so skipping on to line
c  120 should be innocuous.
c
       if (word32 .eq. blank32) go to 120
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       if (word32 .eq. blank32) then
         jend = jbeg
       else
         call nlsdac19 ( word32, jend )
       endif
c
c      If character string is longer than 30 characters (final character
c  is '&'), it has been stored in "nmlst" in pieces.  Thus, set the next
c  piece of "cvector(jbeg)" to the contents of "nmlst(2,i)", and then
c  read the next piece.
c
40     continue
       word32 = nmlst(2,i)
       if (word32(32:32) .eq. '&') then
         mult = 1
         lran = ichar ( word32(31:31) )
         lend = lbeg + lran - 1
         cvector(jbeg)(lbeg:lend) = word32(1:lran)
         lbeg = lend + 1
         ibeg = i + 1
         do 70 i=ibeg,nmax
           word12 = nmlst(1,i)(1:12)
           if (word12 .eq. cstr12 ) go to 80
70       continue
80       continue
         go to 40
       endif
c
c      If the character string was stored in pieces, "mult" will have
c  been set to 1.  If final character is not a '&', then this is the
c  last piece to read in.  Do not include trailing blanks in
c  "cvector(jbeg)".
c
c      If "mult" is 0, then the character string is stored in its
c  entirety in "nmlst(2,i)".  Thus, set cvector(jbeg) trivially.
c
       if (mult .eq. 1) then
         do 90 lran=31,1,-1
           if (word32(lran:lran) .ne. ' ') go to 100
90       continue
100      continue
         lend = lbeg + lran - 1
         cvector(jbeg)(lbeg:lend) = word32(1:lran)
       else
c
c      Comment from DAC, Jan/08: the line commented out below prevented
c  character strings from being set to blanks in namelists, such as
c  p1ylab=' ' in namelist plt1con so that no y-label is put on the plot
c  (but annotations remain).  I cannot recall at all why "cvector" was
c  protected from being set to blank.
c
c      Answer Apr/08: It's to prevent defaults from being clobbered by
c  blanks if the namelist variable is not set.  The original intent of a
c  blank in "nmlst(2,i)" was to indicate that the variable given in
c  "nmlst(1,i)" is not being set, and therefore the default shouldn't
c  be overwritten with a blank.  This means character variables cannot
c  be set to a blank, which is a problem.
c
c      Comment from DAC, Apr/08: If the variable is not being set,
c  jbeg=0 and this portion of the routine is skipped.  Thus, if
c  execution gets here, the variable is to be set, and there is no
c  default value to protect.  Thus, the original first line is commented
c  out, and the second "unprotected" line is revealed.  This tact should
c  work in NLSDAC11 (character arrays) but won't for NLSDAC03 (character
c  scalars) since the latter have no "jbeg" to set.
c
c        if (word32 .ne. blank32) cvector(jbeg) = word32
         cvector(jbeg) = word32
       endif
c
c      Set desired range of "cvector" to the desired constant.
c
       do 110 j=jbeg,jend
         cvector(j) = cvector(jbeg)
110    continue
c
c      Search for next range of elements in "cvector" to be set.
c
120    continue
       ibeg = i + 1
       if (ibeg .gt. nmax) go to 999
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 7             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 8             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac08 ( ivector, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac08 <----------------------- fills integer vector
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input values to an integer
c  vector.
c
c  EXTERNALS:  NLSDAC19
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  word32  , blank32
       integer       nmax    , i       , ibeg    , j       , jbeg
     1             , jend    , ival
c
       integer       ivector (   *)
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8  / '        ' /
       data          blank32 / '                                ' /
c
c      External statements
c
       external      nlsdac19
c
c-----------------------------------------------------------------------
c
       ibeg = 1
10     continue
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. blank8) go to 999
         if (word8 .eq. cstring) go to 30
20     continue
30     continue
       word32 = nmlst(2,i)
       if (word32 .eq. blank32) go to 999
       ibeg = i + 1
       if (ibeg .gt. nmax+1) go to 999
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       if (word32 .eq. blank32) then
         jend = jbeg
       else
         call nlsdac19 ( word32, jend )
       endif
       call nlsdac19 ( nmlst(2,i), ival )
       do 40 j=jbeg,jend
         ivector(j) = ival
40     continue
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 8             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 0 9             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac09 ( rvector, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac09 <-------------------------- fills real vector
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input values to a real vector.
c
c  EXTERNALS:  NLSDAC19, NLSDAC21
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  word32  , blank32
       integer       nmax    , i       , ibeg    , j       , jbeg
     1             , jend
       real          rval
c
       real          rvector (   *)
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8  / '        ' /
       data          blank32 / '                                ' /
c
c      External statements
c
       external      nlsdac19, nlsdac21
c
c-----------------------------------------------------------------------
c
       ibeg = 1
10     continue
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. blank8) go to 999
         if (word8 .eq. cstring) go to 30
20     continue
30     continue
       word32 = nmlst(2,i)
       if (word32 .eq. blank32) go to 999
       ibeg = i + 1
       if (ibeg .gt. nmax+1) go to 999
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       if (word32 .eq. blank32) then
         jend = jbeg
       else
         call nlsdac19 ( word32, jend )
       endif
       call nlsdac21 ( nmlst(2,i), rval )
       do 40 j=jbeg,jend
         rvector(j) = rval
40     continue
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 0 9             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 1 0             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac10 ( lvector, cstring, nmlst, nmax )
c
c    dac:namelist.nlsdac10 <----------------------- fills logical vector
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input values to a logical
c  vector.
c
c  EXTERNALS:  NLSDAC19
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       logical       lval
       character*8   cstring , word8   , blank8
       character*32  word32  , blank32
       integer       nmax    , i       , ibeg    , j       , jbeg
     1             , jend
c
       logical       lvector (   *)
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8  / '        ' /
       data          blank32 / '                                ' /
c
c      External statements
c
       external      nlsdac19
c
c-----------------------------------------------------------------------
c
       ibeg = 1
10     continue
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. blank8) go to 999
         if (word8 .eq. cstring) go to 30
20     continue
30     continue
       word32 = nmlst(2,i)
       if (word32 .eq. blank32) go to 999
       ibeg = i + 1
       if (ibeg .gt. nmax+1) go to 999
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       if (word32 .eq. blank32) then
         jend = jbeg
       else
         call nlsdac19 ( word32, jend )
       endif
       word8 = nmlst(2,i)(1:8)
       if (word8 .eq. '.true.  ') lval = .true.
       if (word8 .eq. '.t.     ') lval = .true.
       if (word8 .eq. '.false. ') lval = .false.
       if (word8 .eq. '.f.     ') lval = .false.
       do 40 j=jbeg,jend
         lvector(j) = lval
40     continue
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 1 0             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 1 1             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac11 ( carray, cstring, nmlst, nmax, nx )
c
c    dac:namelist.nlsdac11 <------ fills two-dimensional character array
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1: February 1991, by David Clarke; rewritten to allow
c                  character strings to be specified in pieces.
c
c  PURPOSE:  This subroutine assigns the input values to a two-
c  dimensional character array.
c
c  EXTERNALS:  NLSDAC19
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*24  cstr24  , word24
       character*32  word32  , blank32
       integer       nmax    , nx      , mult    , i       , ibeg
     1             , j       , jbeg    , jend    , k       , kbeg
     2             , kend    , lbeg    , lend    , lran
c
       character*32  nmlst   (   2,   *)
       character*(*) carray  (  nx,   *)
c
c      Data statements
c
       data          blank8   / '        ' /
       data          blank32  / '                                ' /
c
c      External statements
c
       external      nlsdac19
c
c-----------------------------------------------------------------------
c
       ibeg  = 1
10     continue
       lbeg  = 1
       mult  = 0
c
c      Find next entry in "nmlst(1,*)" which matches the name of the
c  variable to be set ("cstring").
c
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. cstring) go to 30
         if (word8 .eq. blank8 ) go to 999
20     continue
30     continue
       cstr24 = nmlst(1,i)(1:24)
c
c      Set range of variable index (jbeg through jend; kbeg through
c  kend) to be set to what will be stored in "carray(jbeg,kbeg)".
c
c      See comments from DAC, Apr/08 in NLSDAC07.
c
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       if (word32 .eq. blank32) go to 130
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       call nlsdac19 ( word32, jend )
       word32(1:4) = nmlst(1,i)(17:20)
       if (word32 .eq. blank32) go to 130
       call nlsdac19 ( word32, kbeg )
       word32(1:4) = nmlst(1,i)(21:24)
       call nlsdac19 ( word32, kend )
c
c      If character string is longer than 30 characters (final character
c  is '&'), it has been stored in "nmlst" in pieces.  Thus, set the
c  next piece of "carray(jbeg,kbeg)" to the contents of "nmlst(2,i)",
c  and then read the next piece.
c
40     continue
       word32 = nmlst(2,i)
       if (word32(32:32) .eq. '&') then
         mult = 1
         lran = ichar ( word32(31:31) )
         lend = lbeg + lran - 1
         carray(jbeg,kbeg)(lbeg:lend) = word32(1:lran)
         lbeg = lend + 1
         ibeg = i + 1
         do 70 i=ibeg,nmax
           word24 = nmlst(1,i)(1:24)
           if (word24 .eq. cstr24 ) go to 80
70       continue
80       continue
         go to 40
       endif
c
c      If the character string was stored in pieces, "mult" will have
c  been set to 1.  If final character is not a '&', then this is the
c  last piece to read in.  Do not include trailing blanks in
c  "carray(jbeg,kbeg)".
c
c      If "mult" is 0, then the character string is stored in its
c  entirety in "nmlst(2,i)".  Thus, set carray(jbeg,kbeg) trivially.
c
       if (mult .eq. 1) then
         do 90 lran=31,1,-1
           if (word32(lran:lran) .ne. ' ') go to 100
90       continue
100      continue
         lend = lbeg + lran - 1
         carray(jbeg,kbeg)(lbeg:lend) = word32(1:lran)
       else
c
c      See comments from DAC, Jan/08 and Apr/08 in NLSDAC07.
c
c        if (word32 .ne. blank32) carray(jbeg,kbeg) = word32
         carray(jbeg,kbeg) = word32
       endif
c
c      Set desired range of "carray" to the desired constant.
c
       do 120 k=kbeg,kend
         do 110 j=jbeg,jend
           carray(j,k) = carray(jbeg,kbeg)
110      continue
120    continue
c
c      Search for next range of elements in "carray" to be set.
c
130    continue
       ibeg = i + 1
       if (ibeg .gt. nmax) go to 999
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 1 1             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 1 2             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac12 ( iarray, cstring, nmlst, nmax, nx )
c
c    dac:namelist.nlsdac12 <-------- fills two-dimensional integer array
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input values to a two-
c  dimensional integer array.
c
c  EXTERNALS:  NLSDAC19
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  word32  , blank32
       integer       nmax    , nx      , i       , ibeg    , j
     1             , jbeg    , jend    , k       , kbeg    , kend
     2             , ival
c
       character*32  nmlst   (   2,   *)
       integer       iarray  (  nx,   *)
c
c      Data statements
c
       data          blank8  / '        ' /
       data          blank32 / '                                ' /
c
c      External statements
c
       external      nlsdac19
c
c-----------------------------------------------------------------------
c
       ibeg = 1
10     continue
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. blank8) go to 999
         if (word8 .eq. cstring) go to 30
20     continue
30     continue
       word32 = nmlst(2,i)
       if (word32 .eq. blank32) go to 999
       ibeg = i + 1
       if (ibeg .gt. nmax+1) go to 999
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       call nlsdac19 (word32, jend )
       word32(1:4) = nmlst(1,i)(17:20)
       call nlsdac19 ( word32, kbeg )
       word32(1:4) = nmlst(1,i)(21:24)
       call nlsdac19 ( word32, kend )
       call nlsdac19 ( nmlst(2,i), ival )
       do 50 k=kbeg,kend
         do 40 j=jbeg,jend
           iarray(j,k) = ival
40       continue
50     continue
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 1 2             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 1 3             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac13 ( rarray, cstring, nmlst, nmax, nx )
c
c    dac:namelist.nlsdac13 <----------- fills two-dimensional real array
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input values to a two-
c  dimensional real array.
c
c  EXTERNALS:  NLSDAC19, NLSDAC21
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   cstring , word8   , blank8
       character*32  word32  , blank32
       integer       nmax    , nx      , i       , ibeg    , j
     1             , jbeg    , jend    , k       , kbeg    , kend
       real          rval
c
       character*32  nmlst   (   2,   *)
       real          rarray  (  nx,   *)
c
c      Data statements
c
       data          blank8  / '        ' /
       data          blank32 / '                                ' /
c
c      External statements
c
       external      nlsdac19, nlsdac21
c
c-----------------------------------------------------------------------
c
       ibeg = 1
10     continue
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. blank8) go to 999
         if (word8 .eq. cstring) go to 30
20     continue
30     continue
       word32 = nmlst(2,i)
       if (word32 .eq. blank32) go to 999
       ibeg = i + 1
       if (ibeg .gt. nmax+1) go to 999
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       call nlsdac19 ( word32, jend )
       word32(1:4) = nmlst(1,i)(17:20)
       call nlsdac19 ( word32, kbeg )
       word32(1:4) = nmlst(1,i)(21:24)
       call nlsdac19 ( word32, kend )
       call nlsdac21 ( nmlst(2,i), rval )
       do 50 k=kbeg,kend
         do 40 j=jbeg,jend
           rarray(j,k) = rval
40       continue
50     continue
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 1 3             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 1 4             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac14 ( larray, cstring, nmlst, nmax, nx )
c
c    dac:namelist.nlsdac14 <-------- fills two-dimensional logical array
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine assigns the input values to a two-
c  dimensional logical array.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       logical       lval
       character*8   cstring , word8   , blank8
       character*32  word32  , blank32
       integer       nmax    , nx      , i       , ibeg    , j
     1             , jbeg    , jend    , k       , kbeg    , kend
c
       logical       larray  (  nx,   *)
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank8  / '        ' /
       data          blank32 / '                                ' /
c
c-----------------------------------------------------------------------
c
       ibeg = 1
10     continue
       do 20 i=ibeg,nmax
         word8 = nmlst(1,i)(1:8)
         if (word8 .eq. blank8) go to 999
         if (word8 .eq. cstring) go to 30
20     continue
30     continue
       word32 = nmlst(2,i)
       if (word32 .eq. blank32) go to 999
       ibeg = i + 1
       if (ibeg .gt. nmax+1) go to 999
       word32 = blank32
       word32(1:4) = nmlst(1,i)(9:12)
       call nlsdac19 ( word32, jbeg )
       word32(1:4) = nmlst(1,i)(13:16)
       call nlsdac19 ( word32, jend )
       word32(1:4) = nmlst(1,i)(17:20)
       call nlsdac19 ( word32, kbeg )
       word32(1:4) = nmlst(1,i)(21:24)
       call nlsdac19 ( word32, kend )
       word8 = nmlst(2,i)(1:8)
       if (word8 .eq. '.true.  ') lval = .true.
       if (word8 .eq. '.t.     ') lval = .true.
       if (word8 .eq. '.false. ') lval = .false.
       if (word8 .eq. '.f.     ') lval = .false.
       do 50 k=kbeg,kend
         do 40 j=jbeg,jend
           larray(j,k) = lval
40       continue
50     continue
       go to 10
c
999    continue
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 1 4             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 1 5             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac15 ( phrase, ipoint, ierror )
c
c    dac:namelist.nlsdac15 <---------------------- issues error messages
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine is called when an error is detected in the
c  namelist by one of the subroutines.  The appropriate error message
c  is issued to the CRT, and execution is terminated.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*(*) phrase
       character*9   frmt
       integer       ipoint  , ierror
c
c-----------------------------------------------------------------------
c
       write (   6, 2010)
       write (   6, 2020) phrase
       write (frmt, 2030) ipoint - 1
       write (   6, frmt)
c
       if (ierror .eq.  1) write (6,2040)
       if (ierror .eq.  2) write (6,2050)
       if (ierror .eq.  3) write (6,2060)
       if (ierror .eq.  4) write (6,2070)
       if (ierror .eq.  5) write (6,2080)
       if (ierror .eq.  6) write (6,2090)
       if (ierror .eq.  7) write (6,2100)
       if (ierror .eq.  8) write (6,2110)
       if (ierror .eq.  9) write (6,2120)
       if (ierror .eq. 10) write (6,2130)
       if (ierror .eq. 11) write (6,2140)
       if (ierror .eq. 12) write (6,2150)
       if (ierror .eq. 13) write (6,2160)
       if (ierror .eq. 14) write (6,2170)
       if (ierror .eq. 15) write (6,2180)
       if (ierror .eq. 16) write (6,2190)
       if (ierror .eq. 17) write (6,2200)
       if (ierror .eq. 18) write (6,2210)
       if (ierror .eq. 19) write (6,2220)
       if (ierror .eq. 20) write (6,2230)
c
       write (6,2010)
       stop
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format('************************************'
     1       ,'************************************')
2020   format( (a) )
2030   format("(",i2.2,"x,'^')")
2040   format('NAMELIST ERROR  1 ---> column 1 reserved for comment '
     1       ,'sentinal: c')
2050   format('NAMELIST ERROR  2 ---> column 2 reserved for $ '
     1       ,'delimeter')
2060   format('NAMELIST ERROR  3 ---> variable not found in namelist')
2070   format('NAMELIST ERROR  4 ---> unexpected character - check '
     1       ,'syntax')
2080   format('NAMELIST ERROR  5 ---> invalid logical expression')
2090   format('NAMELIST ERROR  6 ---> namelist does not exist, or is '
     1       ,'out of sequence')
2100   format('NAMELIST ERROR  7 ---> error reading input deck')
2110   format('NAMELIST ERROR  8 ---> variable not declared as a '
     1       ,'vector')
2120   format('NAMELIST ERROR  9 ---> next namelist begun before '
     1       ,'closing quote found')
2130   format('NAMELIST ERROR 10 ---> missing opening quote')
2140   format('NAMELIST ERROR 11 ---> blank data')
2150   format('NAMELIST ERROR 12 ---> premature end of file')
2160   format('NAMELIST ERROR 13 ---> missing $ sentinal to close '
     1       ,'namelist')
2170   format('NAMELIST ERROR 14 ---> exponent must not exceed 999')
2180   format('NAMELIST ERROR 15 ---> no more than 15 digits in single '
     1       ,'precision')
2190   format('NAMELIST ERROR 16 ---> ')
2200   format('NAMELIST ERROR 17 ---> ')
2210   format('NAMELIST ERROR 18 ---> ')
2220   format('NAMELIST ERROR 19 ---> ')
2230   format('NAMELIST ERROR 20 ---> ')
c
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 1 5             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              N L S D A C 1 6              \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine nlsdac16 ( nlunit, line, jbeg, jend, jran, iquote
     1                     , word32 )
c
c    dac:namelist.nlsdac16 <-------------- returns next "word" in "line"
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine returns the next 32 character "word" found
c  after the input position of "jbeg" in "line".  The beginning and
c  ending positions of "word" are returned as well ("jbeg" and "jend").
c
c  There are two types of delimiters which define "word".  The first
c  type include the double and single quotation marks [" and '].  The
c  quotes are returned with "word".  Both the beginning and ending of
c  "word" must be delimited with the same type of quotation mark.
c
c  The second type include the equals sign [=], the asterisk [*], the
c  comma [,], the full colon [:], the opening parenthesis [(], the
c  closing parenthseis [)], the dollar sign [$], the blank, and the end
c  of "line".  These delimiters are not returned with "word", and so
c  "word" may be as long as 32 characters.  "word" may begin and end
c  with different delimiters of the second type.  (Note that $ and the
c  end of "line" can only delimit the end of "word".)  Delimiters of the
c  first type may be used to end "word" beginning with a delimiter of
c  the first type, and will not be returned with "word".  The reverse is
c  not true.  Delimiters of the second type found between like quotation
c  marks are returned as characters in "word".  Note that the search for
c  the next word will start directly at abs(jbeg) if "jbeg" < 0.
c
c  If the end of "line" is encountered before the next "word" is found,
c  the next "line" is read.  Both "line" and "word" are returned to the
c  calling subroutine.
c
c  EXTERNALS:  NLSDAC15
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1   , char2   , char3
       character*32  word32  , blank32
       character*72  line    , oldline
       integer       nlunit  , jbeg    , jend    , jran    , iquote
     1             , j       , j1      , j2      , iflag
c
c      Data statements
c
       data          blank32 /'                                '/
c
c      External statements
c
       external      nlsdac15
c
c-----------------------------------------------------------------------
c
c      Scan "line" for beginning of next "word".
c
       iflag = 1
       if (jbeg .lt. 0) then
         iflag = - 1
         jbeg  = - jbeg
         if (jbeg .gt. 72) go to 30
         go to 70
       endif
       j1 = jbeg
       if (jbeg .eq. 0) j1 =  3
10     continue
       do 20 j=j1,72
         char1 = line(j:j)
         if ( (char1 .eq. ' ') .or. (char1 .eq. ',') .or.
     1        (char1 .eq. '=') .or. (char1 .eq. ')') .or.
     2        (char1 .eq. '(') .or. (char1 .eq. '*') .or.
     3        (char1 .eq. ':') ) go to 20
         jbeg = j
         go to 70
20     continue
30     continue
c
c      The only way for execution to have reached this point is for the
c  end of the line to have been reached without finding another "word".
c  Read next "line", and resume search.
c
       oldline = line
40     continue
       read  (nlunit, 1010, end=50, err=60) line
c
c      Error message if column 1 contains anything but a 'c', 'C', or a
c  blank.
c
       char2 = line(1:1)
       if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1      (char2 .ne. ' ') ) call nlsdac15 ( line, 1, 1 )
c
c      Error message if column 2 contains anything but a '$' or a blank
c  (unless column 1 contains a 'c' or a 'C').
c
       char3 = line(2:2)
       if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1      (char3 .ne. '$') .and. (char3 .ne. ' ') )
     2   call nlsdac15 ( line, 2, 2 )
c
c      If column 1 contains a 'c' or a 'C', the line is "commented out",
c  and is echoed on the terminal.
c
       if ( (char2 .eq. 'c') .or. (char2 .eq. 'C') ) then
         write (6, 2010) line
         go to 40
       endif
c
c      If column 2 contains a '$' sentinal, then a new namelist has
c  begun without the previous one being closed.  Issue error message.
c
       if (char3 .eq. '$') then
         if (iquote .eq. 0) then
           call nlsdac15 ( oldline, 72, 13 )
         else
           call nlsdac15 ( line, 2, 9 )
         endif
       endif
c
c      New "line" is OK, resume scanning.
c
       if (iflag .eq. -1) then
         jbeg = 3
         go to 70
       else
         j1 = 3
         go to 10
       endif
c
c      Error: premature end of file.
c
50     continue
       call nlsdac15 ( line, 72, 12 )
c
c      Error: problem reading input deck
c
60     continue
       call nlsdac15 ( blank32, 0, 7 )
c
c      "jbeg" has been determined.  Now find "jend", which cannot be
c  greater than "jbeg" + 31.
c
70     continue
       j1   = jbeg + 1
       j2   = jbeg + 31
       if (j2 .gt. 72) j2 = 72
       jend = jbeg
c
c      Case:  first delimiter is a single quote.
c
       if ( (iquote .eq. 1) .or. (char1 .eq. '''') ) then
         do 80 j=j1,j2
           jend  = j
           char1 = line(j:j)
           if (char1 .eq. '''') go to 110
80       continue
c
c      Closing single quote not found.  Set "iquote" to 1.
c
         iquote = 1
         go to 120
       endif
c
c      Case:  first delimiter is a double quote.
c
       if ( (iquote .eq. 2) .or. (char1 .eq. '"') ) then
         do 90 j=j1,j2
           jend  = j
           char1 = line(j:j)
           if (char1 .eq. '"') go to 110
90       continue
c
c      Closing double quote not found.  Set "iquote" to 2.
c
         iquote = 2
         go to 120
       endif
c
c      Case:  first delimiter is not a quote.
c
       do 100 j=j1,j2
         char1 = line(j:j)
         if ( (char1 .eq. ' ') .or. (char1 .eq. ',') .or.
     1        (char1 .eq. '=') .or. (char1 .eq. ')') .or.
     2        (char1 .eq. '(') .or. (char1 .eq. '*') .or.
     3        (char1 .eq. ':') .or. (char1 .eq. '"') .or.
     4        (char1 .eq. '''') .or. (char1 .eq. '$') ) go to 110
         jend = j
100    continue
110    continue
       iquote = 0
120    continue
       jran   = jend - jbeg + 1
       word32 = blank32
       word32(1:jran) = line(jbeg:jend)
c
       return
c
c-----------------------------------------------------------------------
c----------------------- Read format statements ------------------------
c-----------------------------------------------------------------------
c
1010   format(a72)
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(a72)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              N L S D A C 1 6              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              N L S D A C 1 7              \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine nlsdac17 ( nlunit, line, jbeg, jend, char1 )
c
c    dac:namelist.nlsdac17 <----------- returns next non-blank character
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine returns the first non-blank character found
c  at or after the input position "jbeg" in "line".  If no non-blank
c  character is found, the next line is read and scanned for the first
c  non-blank character.
c
c  EXTERNALS:  NLSDAC15
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1   , char2   , char3
       character*8   blank8
       character*72  line    , oldline
       integer       nlunit  , jbeg    , jend    , j       , j1
c
c      Data statements
c
       data          blank8 / '        ' /
c
c      External statements
c
       external      nlsdac15
c
c-----------------------------------------------------------------------
c
c      Scan "line" for next non-blank character.
c
       j1 = jbeg
       if (j1 .eq. 0) j1 = 3
10     continue
       do 20 j=j1,72
         jbeg  = j
         jend  = j
         char1 = line(j:j)
         if (char1 .ne. ' ') return
20     continue
c
c      End of line reached before non-blank character found.  Read
c  next line.
c
       oldline = line
30     continue
       read  (nlunit, 1010, end=40, err=50) line
c
c      Error message if column 1 contains anything but a 'c', 'C', or a
c  blank.
c
       char2 = line(1:1)
       if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1      (char2 .ne. ' ') ) call nlsdac15 ( line, 1, 1 )
c
c      Error message if column 2 contains anything but a '$' or a blank
c  (unless column 1 contains a 'c' or a 'C').
c
       char3 = line(2:2)
       if ( (char2 .ne. 'c') .and. (char2 .ne. 'C') .and.
     1      (char3 .ne. '$') .and. (char3 .ne. ' ') )
     2   call nlsdac15 ( line, 2, 2 )
c
c      If column 1 contains a 'c' or a 'C', the line is "commented out",
c  and is echoed on the terminal.
c
       if ( (char2 .eq. 'c') .or. (char2 .eq. 'C') ) then
         write (6, 2010) line
         go to 30
       endif
c
c      If column 2 contains a '$' sentinal, then a new namelist has
c  begun without the previous one being closed.  Issue error message.
c
       if (char3 .eq. '$') call nlsdac15 ( oldline, 72, 13 )
c
c      New "line" is OK, resume scanning.
c
       j1 = 3
       go to 10
c
c      Error: premature end of file.
c
40     continue
       call nlsdac15 ( line, 72, 12 )
c
c      Error: problem reading input deck
c
50     continue
       call nlsdac15 ( blank8, 0, 7 )
c
c-----------------------------------------------------------------------
c----------------------- Read format statements ------------------------
c-----------------------------------------------------------------------
c
1010   format(a72)
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(a72)
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              N L S D A C 1 7              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              N L S D A C 1 8              \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac18 ( line, jbeg, word32 )
c
c    dac:namelist.nlsdac18 <---- checks for valid integer representation
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine calls nlsdac15 (which issues fatal error
c  messages) if the input character string ("word32") does not represent
c  an integer.
c
c  EXTERNALS:  NLSDAC15
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1
       character*32  word32
       character*72  line
       integer       jbeg    , ineg    , ipos    , idig    , iblnk
     1             , i       , ibeg    , iend    , j       , jpos
c
       character*1   ch      (  10)
c
c      Data statements
c
       data          ch       /'0','1','2','3','4','5','6','7','8','9'/
c
c      External statements
c
       external      nlsdac15
c
c-----------------------------------------------------------------------
c
c      Initialise parameters.
c
       ineg  = 0
       ipos  = 0
       idig  = 0
       iblnk = 1
c
c      Find first non-blank character.
c
       do 10 i=1,32
         ibeg  = i
         char1 = word32(i:i)
         if (char1 .ne. ' ') go to 20
10     continue
c
c      "word32" is blank.  Issue an error message.
c
       call nlsdac15 ( line, jbeg, 11 )
c
c      Scan word32 up to the next blank.  An error message is issued if:
c
c   1. more than one sign (+ or -) is encountered, or
c   2. a sign is embedded in the integer, or
c   3. if the integer is found to have more than 15 digits, or
c   4. if a character other than +, -, or a digit is found.
c
20     continue
       do 40 i=ibeg,32
         jpos  = jbeg + i
         iend  = i
         char1 = word32(i:i)
         if (char1 .eq. ' ') go to 50
         if (char1 .eq. '-') then
           ineg = ineg + 1
           if ( (ineg .gt. 1) .or. (ipos .gt. 0) )
     1       call nlsdac15 ( line, jpos, 4 )
           if (idig .gt. 0) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         if (char1 .eq. '+') then
           ipos = ipos + 1
           if ( (ipos .gt. 1) .or. (ineg .gt. 0) )
     1       call nlsdac15 ( line, jpos, 4 )
           if (idig .gt. 0) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         do 30 j=1,10
           if (char1 .eq. ch(j)) then
             idig = idig + 1
             if (idig .gt. 15) call nlsdac15 ( line, jpos, 15 )
             go to 40
           endif
30       continue
         call nlsdac15 ( line, jpos, 4 )
40     continue
c
c      First blank after data entry is found.
c
50     continue
c
c      If there are no digits after sign, issue error message.
c
       if (idig .eq. 0) call nlsdac15 ( line, jpos, 4 )
c
c      Scan rest of "word32" and issue error message if a non-blank
c  character is found.
c
       if (iend .lt. 32) then
         do 60 i=iend,32
           char1 = word32(i:i)
           jpos  = jbeg + i
           if (char1 .ne. ' ') call nlsdac15 ( line, jpos, 4 )
60       continue
       endif
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              N L S D A C 1 8              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              N L S D A C 1 9              \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac19 ( word32, ival )
c
c    dac:namelist.nlsdac19 <----- translates character string to integer
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine translates a character string to an
c  integer.  It is assumed that the character string is a valid
c  representation of an integer, and is error-free (i.e., NLSDAC18 has
c  been called).
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1
       character*32  word32
       integer       ival    , ichar1  , ifact   , i
c
       character*1   ch      (  10)
c
c      Data statements
c
       data          ch       /'0','1','2','3','4','5','6','7','8','9'/
c
c-----------------------------------------------------------------------
c
       ichar1 = 32
       ifact  = 1
       ival   = 0
10     continue
       char1 = word32(ichar1:ichar1)
       if (char1 .ne. ' ') then
         do 20 i=1,10
           if (char1 .eq. ch(i)) go to 30
20       continue
         if (char1 .eq. '-') then
           ival = - ival
           return
         endif
30       continue
         ival  = ival + ifact * (i - 1)
         ifact = ifact * 10
       endif
       ichar1 = ichar1 - 1
       if (ichar1 .gt. 0) go to 10
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              N L S D A C 1 9              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              N L S D A C 2 0              \\\\\\\\\\
c
c=======================================================================
c
c
       subroutine nlsdac20 ( ival, word32 )
c
c    dac:namelist.nlsdac20 <----- translates integer to character string
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine translates an integer into a left-justified
c  character string.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*32  word32  , blank32
       integer       ival    , j       , jj      , jbeg    , jend
     1             , ilog
       real          x       , x1      , xlog
c
       character*1   ch      (  10)
c
c      Data statements
c
       data          ch       /'0','1','2','3','4','5','6','7','8','9'/
       data          blank32  /'                                '/
c
c-----------------------------------------------------------------------
c
       word32 = blank32
       if (ival .lt. 0) then
         jbeg = 2
         ival = - ival
         word32(1:1) = '-'
       else
         jbeg = 1
       endif
       x = float(ival)
       if (ival .eq. 0) then
         ilog = 0
       else
         xlog = alog10(x)
         ilog = ifix (xlog + .000001)
       endif
       jend = jbeg + ilog
       if (jend .ge. 32) jend = 32
       do 10 j=jbeg,jend
         x1 = x / 10.0**ilog
         jj = ifix ( x1 + .000001 )
         word32(j:j) = ch(jj+1)
         x  = x - float(jj) * 10**ilog
         ilog = ilog - 1
10     continue
       return
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              N L S D A C 2 0              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 2 1             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac21 ( word32, rval )
c
c    dac:namelist.nlsdac21 <-------- translates character string to real
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine translates a character string to a real
c  constant.
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1
       character*32  word32
       integer       i       , esign   , ipnt    , npnt    , more
     1             , iblnk   , iman    , iexp    , j
       real          rval    , msign   , term    , fact
c
       character*1   ch      (  10)
       integer       exponent(   4), mantissa(  16)
c
c      Data statements
c
       data          ch       /'0','1','2','3','4','5','6','7','8','9'/
c
c-----------------------------------------------------------------------
c
c      Initialise parameters.
c
       do 10 i=1,4
         exponent(i) = 0
10     continue
       do 20 i=1,16
         mantissa(i) = 0
20     continue
       msign = 1.0
       esign = 1
       ipnt  = 0
       npnt  = 0
       more  = 1
       iblnk = 0
       iman  = 0
       iexp  = 0
c
c      Scan "word32".  It is assumed that "word32" has already been
c  determined to be error-free, and that it is a valid character
c  representation of a real value (i.e., NLSDAC23 has been called).
c
       do 40 i=1,32
         char1 = word32(i:i)
         if (char1 .eq. ' ') then
           iblnk = iblnk + 1
           go to 40
         endif
         if (char1 .eq. '-') then
           if (more .eq. 1) msign = -1.0
           if (more .eq. 2) esign = -1
           go to 40
         endif
         if (char1 .eq. '+') go to 40
         if (char1 .eq. '.') then
           npnt = 1
           ipnt = i - 2 - iblnk
           if (msign .eq. -1.0) ipnt = ipnt - 1
           go to 40
         endif
         if ( (char1 .eq. 'e') .or. (char1 .eq. 'd') ) then
           more = 2
           if (npnt .eq. 0) then
             npnt = 1
             ipnt = i - 2 - iblnk
             if (msign .eq. -1.0) ipnt = ipnt - 1
             if (ipnt .lt. 0) ipnt = 0
           endif
           go to 40
         endif
         do 30 j=1,10
           if (char1 .eq. ch(j)) then
             if (more .eq. 1) then
               iman = iman + 1
               mantissa(iman) = j - 1
             endif
             if (more .eq. 2) then
               iexp = iexp + 1
               exponent(iexp) = j - 1
             endif
             go to 40
           endif
30       continue
40     continue
       if (npnt .eq. 0) ipnt = iman - 1
c
c      Evaluate the mantissa.
c
       rval = 0.0
       if (iman .gt. 0) then
         do 50 i=1,iman
           term = float(mantissa(i)) * 10.0**ipnt
           rval = rval + term
           ipnt = ipnt - 1
50       continue
       else
         rval = 1.0
       endif
       rval = rval * msign
c
c      Evaluate the exponential factor.
c
       fact = 1.0
       if (iexp .gt. 0) then
         do 60 i=1,iexp
           ipnt = iexp - i
           fact = fact * 10.0 ** (exponent(i) * 10.0**ipnt)
60       continue
       endif
       if (esign .eq. -1) fact = 1.0 / fact
c
c      Return real representation of character string.
c
       rval = rval * fact
       return
c
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 2 1             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 2 2             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac22 ( line, jbeg, word32 )
c
c    dac:namelist.nlsdac22 <---- checks for valid logical representation
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine calls nlsdac15 (which issues fatal error
c  messages) if the input character string ("word32") does not represent
c  a valid logical value.
c
c  EXTERNALS:  NLSDAC15
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*32  word32
       character*72  line
       integer       jbeg
c
c      External statements
c
       external      nlsdac15
c
c-----------------------------------------------------------------------
c
       if ( (word32(1:8) .ne. '.true.  ') .and.
     1      (word32(1:8) .ne. '.t.     ') .and.
     2      (word32(1:8) .ne. '.false. ') .and.
     3      (word32(1:8) .ne. '.f.     ') )
     4   call nlsdac15 ( line, jbeg, 5 )
c
       return
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 2 2             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 2 3              \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac23 ( line, jbeg, word32 )
c
c    dac:namelist.nlsdac18 <-- determines if character string is a valid
c                                         representation of a real value
c                                                              may, 1989
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine calls nlsdac15 (which issues various fatal
c  error messages) if the input character string ("word32") does not
c  represent a real value.
c
c  EXTERNALS:  NLSDAC15
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   char1
       character*32  word32
       character*72  line
       integer       jbeg    , mneg    , eneg    , mpos    , epos
     1             , iexp    , iman    , ipnt    , more    , iblnk
     2             , i       , ibeg    , iend    , j       , jpos
c
       character*1   ch      (  10)
c
c      Data statements
c
       data          ch       /'0','1','2','3','4','5','6','7','8','9'/
c
c      External statements
c
       external      nlsdac15
c
c-----------------------------------------------------------------------
c
c      Initialise parameters.
c
       mneg  = 0
       eneg  = 0
       mpos  = 0
       epos  = 0
       iexp  = 0
       iman  = 0
       ipnt  = 0
       more  = 1
       iblnk = 1
c
c      Find first non-blank character.
c
       do 10 i=1,32
         ibeg  = i
         char1 = word32(i:i)
         if (char1 .ne. ' ') go to 20
10     continue
c
c      "word32" is blank.  Issue an error message.
c
       call nlsdac15 ( line, jbeg, 11 )
c
c      Scan word32 up to the next blank.  An error message is issued if:
c
c   1. more than one sign (+ or -) is encountered in the mantissa, or
c   2. a sign is embedded in the mantissa, or
c   3. more than one sign (+ or -) is encountered in the exponent, or
c   4. a sign is embedded in the exponent, or
c   5. if more than one decimal point is encountered in the mantissa, or
c   6. if a decimal point is encountered in the exponent, or
c   7. if more than one exponential sentinal ("e" or "d") is found, or
c   8. if the mantissa is found to have more than 16 digits, or
c   9. if the mantissa is found to have more than  4 digits, or
c  10. if a character other than +, -, ., e, d, or a digit is found.
c
20     continue
       do 40 i=ibeg,32
         jpos  = jbeg + i
         iend  = i
         char1 = word32(i:i)
         if (char1 .eq. ' ') go to 50
         if ( (char1 .eq. '-') .and. (more .eq. 1) ) then
           mneg = mneg + 1
           if ( (mneg .gt. 1) .or. (mpos .gt. 0) )
     1       call nlsdac15 ( line, jpos, 4 )
           if (iman .gt. 0) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         if ( (char1 .eq. '-') .and. (more .eq. 2) ) then
           eneg = eneg + 1
           if ( (eneg .gt. 1) .or. (epos .gt. 0) )
     1       call nlsdac15 ( line, jpos, 4 )
           if (iexp .gt. 0) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         if ( (char1 .eq. '+') .and. (more .eq. 1) ) then
           mpos = mpos + 1
           if ( (mpos .gt. 1) .or. (mneg .gt. 0) )
     1       call nlsdac15 ( line, jpos, 4 )
           if (iman .gt. 0) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         if ( (char1 .eq. '+') .and. (more .eq. 2) ) then
           epos = epos + 1
           if ( (epos .gt. 1) .or. (eneg .gt. 0) )
     1       call nlsdac15 ( line, jpos, 4 )
           if (iexp .gt. 0) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         if ( (char1 .eq. '.') .and. (more .eq. 1) ) then
           ipnt = ipnt + 1
           iman = iman + 1
           if (ipnt .gt. 1) call nlsdac15 ( line, jpos, 4 )
           go to 40
         endif
         if ( (char1 .eq. '.') .and. (more .eq. 2) ) then
           call nlsdac15 ( line, jpos, 4 )
         endif
         if ( (char1 .eq. 'e') .or. (char1 .eq. 'd') ) then
           if (more .eq. 2) call nlsdac15 ( line, jpos, 4 )
           more = 2
           go to 40
         endif
         do 30 j=1,10
           if (char1 .eq. ch(j)) then
             if (more .eq.  1) iman = iman + 1
             if (iman .gt. 16) call nlsdac15 ( line, jpos, 15 )
             if (more .eq.  2) iexp = iexp + 1
             if (iexp .gt.  3) call nlsdac15 ( line, jpos, 14 )
             go to 40
           endif
30       continue
         call nlsdac15 ( line, jpos, 4 )
40     continue
c
c      First blank after data entry is found.
c
50     continue
c
c      If there are no digits after sign and/or decimal point, issue
c  error message.
c
       iman = iman - ipnt
       if (iman .eq. 0) call nlsdac15 ( line, jpos, 4 )
c
c      Scan rest of "word32" and issue error message if a non-blank
c  character is found.
c
       if (iend .lt. 32) then
         do 60 i=iend,32
           char1 = word32(i:i)
           jpos  = jbeg + i
           if (char1 .ne. ' ') call nlsdac15 ( line, jpos, 4 )
60       continue
       endif
       return
c
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 2 3             \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c     \\\\\\\\\\     B E G I N   S U B R O U T I N E     //////////
c     //////////             N L S D A C 2 4             \\\\\\\\\\
c
c=======================================================================
c
       subroutine nlsdac24 ( lunit, cname, nmlst, nmax )
c
c    dac:namelist.nlsdac24 <---- dumps namelist values to specified unit
c                                                         february, 1991
c
c      Written by: David Clarke
c      Modified 1:
c
c  PURPOSE:  This subroutine dumps a formatted summary of all user-
c  specified namelist parameters in the namelist "cname" to the logical
c  unit "lunit".
c
c  EXTERNALS:  NONE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       logical       lval
       character*1   char1   , attr    , type
       character*4   jbeg    , jend    , kbeg    , kend
       character*8   cname   , word8   , temp8   , nword8
       character*25  var
       character*32  blank32
       character*512 cval
       integer       lunit   , nmax    , mult    , i       , ilist
     1             , ival    , lbeg    , lend    , lran    , j
     2             , j1      , j2      , mbeg    , mend
       real          rval
c
       character*32  nmlst   (   2,   *)
c
c      Data statements
c
       data          blank32  / '                                ' /
c
c      External statements
c
       external      nlsdac19, nlsdac21
c
c-----------------------------------------------------------------------
c
       mult = 0
       lbeg = 1
       do 10 j=1,16
         j2 = 32 * j
         j1 = j2 - 31
         cval(j1:j2) = blank32
10     continue
c
c      First line to output unit.
c
       write (lunit, 2010) cname
c
c      Read namelist entries, and write contents to output unit.
c
       do 100 i=1,nmax
         ilist = i
         if (nmlst(2,ilist) .eq. blank32) go to 100
         char1 = nmlst(1,ilist)(31:31)
         if (char1 .eq. '*') go to 100
         word8 = nmlst(1,ilist)( 1: 8)
         if (word8 .eq. '        ') go to 110
         nmlst(1,ilist)(31:31) = '*'
20       continue
         var   = blank32(1:25)
         attr  = nmlst(1,ilist)(30:30)
         type  = nmlst(1,ilist)(32:32)
c
c      Representation of variable name (contents of "nmlst(1,*)")
c  depends on type of variable (ie, scalar, vector, or 2-D array).
c
         if (type .ne. 's') then
           jbeg = nmlst(1,ilist)( 9:12)
           jend = nmlst(1,ilist)(13:16)
           if (jend .eq. '    ') jend = jbeg
           kbeg = nmlst(1,ilist)(17:20)
           kend = nmlst(1,ilist)(21:24)
           if (kend .eq. '    ') kend = kbeg
           if (type .eq. 'v') write (var, 2020) word8, jbeg, jend
           if (type .eq. 'a') write (var, 2030) word8, jbeg, jend
     1                                               , kbeg, kend
         else
           write (var, 2040) word8
         endif
c
c      Representation of variable value (contents of "nmlst(2,*)")
c  depends on attribute (ie, integer, real, logical, or character).
c
c  Case:  integer
c
         if (attr .eq. 'i') then
           call nlsdac19 ( nmlst(2,ilist), ival )
           write (lunit, 2050) var, ival
         endif
c
c  Case:  real
c
         if (attr .eq. 'r') then
           call nlsdac21 ( nmlst(2,ilist), rval )
           write (lunit, 2060) var, rval
         endif
c
c  Case:  logical
c
         if (attr .eq. 'l') then
           temp8 = nmlst(2,ilist)(1:8)
           if (temp8 .eq. '.true.  ') lval = .true.
           if (temp8 .eq. '.t.     ') lval = .true.
           if (temp8 .eq. '.false. ') lval = .false.
           if (temp8 .eq. '.f.     ') lval = .false.
           if (      lval) write (lunit, 2070) var
           if (.not. lval) write (lunit, 2080) var
         endif
c
c  Case:  character
c
c  For character strings, there is the possibility that the string is
c  stored in pieces throughout "nmlst(2,*)".  Thus, delay writing
c  the entry to the output unit until all the character string can be
c  gathered.
c
         if (attr .eq. 'c') then
           if (nmlst(2,ilist)(32:32) .eq. '&') then
             mult = 1
             lran = ichar ( nmlst(2,ilist)(31:31) )
             lend = lbeg + lran - 1
             cval(lbeg:lend) = nmlst(2,ilist)(1:lran)
             lbeg = lend + 1
           else
             do 50 lran=31,1,-1
               if (nmlst(2,ilist)(lran:lran) .ne. ' ') go to 60
50           continue
60           continue
             lend = lbeg + lran - 1
             cval(lbeg:lend) = nmlst(2,ilist)(1:lran)
             if (lend .le. 50) then
               write (lunit, 2090) var, cval(1:lend)
             else
               mbeg = 1
               mend = 50
               write (lunit, 2100) var, cval(mbeg:mend)
70             continue
               mbeg = mend + 1
               mend = mend + 50
               if (mend .ge. lend) then
                 write (lunit, 2110) cval(mbeg:lend)
               else
                 write (lunit, 2120) cval(mbeg:mend)
                 go to 70
               endif
             endif
             mult = 0
             lbeg = 1
             do 80 j=1,16
               j2 = 32 * j
               j1 = j2 - 31
               cval(j1:j2) = blank32
80           continue
           endif
         endif
c
c      Check the rest of "nmlst(1,*)" for any other variable entries
c  with the same variable name.  Such entries may exist for vectors and
c  arrays of all attributes, and scalars for character variables.  An
c  asterisk is put (temporarily) in column 31 of "nmlst(1,ilist)" so
c  that this entry will not be read again.
c
         if (ilist .ne. nmax) then
           do 90 j=ilist+1,nmax
             nword8  = nmlst(1,j)( 1: 8)
             if (nword8 .eq. '        ') go to 100
             if (nword8 .eq. word8) then
               nmlst(1,j)(31:31) = '*'
               ilist = j
               go to 20
             endif
90         continue
         endif
100    continue
110    continue
c
c      Last line to output unit.
c
       write (lunit, 2130) cname
c
c      Replace asterisks put in column 31 of "nmlst(1,*)" with blanks.
c
       do 120 i=1,nmax
         if (nmlst(1,i)(1:8) .eq. '        ') return
         nmlst(1,i)(31:31) = ' '
120    continue
c
       return
c
c-----------------------------------------------------------------------
c---------------------- Write format statements ------------------------
c-----------------------------------------------------------------------
c
2010   format(/,'======================================================'
     1       ,'> BEGIN NAMELIST: ',a8)
2020   format(a8,'(',a3,':',a3,')')
2030   format(a8,'(',a3,':',a3,',',a3,':',a3,')')
2040   format(a8)
2050   format(a25,' =',i10)
2060   format(a25,' =',1pg20.12)
2070   format(a25,' = .true.')
2080   format(a25,' = .false.')
2090   format(a25,' = "',a,'"')
2100   format(a25,' = "',a)
2110   format(29x,a,'"')
2120   format(29x,a)
2130   format('========================================================'
     1       ,'> END NAMELIST: ',a8)
c
       end
c
c=======================================================================
c
c     \\\\\\\\\\       E N D   S U B R O U T I N E       //////////
c     //////////             N L S D A C 2 4             \\\\\\\\\\
c
c=======================================================================
c
c
