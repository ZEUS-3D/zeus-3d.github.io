#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#============== SCRIPT FILE TO CREATE A NUMBERED LISTING ==============#
#                                                                      #
# User sets: SOURCECODE                                                #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE'
          , ibanner=1, job=1, inumber=3, itable=1, ixclude=1          \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22
