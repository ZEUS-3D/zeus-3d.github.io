#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#======== SCRIPT FILE TO MERGE A CHANGE DECK INTO A SOURCE CODE =======#
#                                                                      #
# User sets: CHANGEDECK, SOURCECODE, OUTNAME                           #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#--------------------------------------------------> Create change deck.
rm -f ./changes
cat << EOF > ./changes
*ident changes
*read CHANGEDECK
EOF
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE', outname='OUTNAME'
          , ibanner=1, job=3, idump=1, inum=0, ipre=0, chgdk='changes' \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22 ./changes ./changes.m
