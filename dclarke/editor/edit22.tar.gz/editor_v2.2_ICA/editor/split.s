#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#==== SCRIPT FILE TO SPLIT A SOURCE CODE INTO FILES FOR EACH DECK =====#
#                                                                      #
# User sets: DIRECTORY, SOURCECODE                                     #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#======================> If necessary, create the directory "DIRECTORY".
if(! -e ./DIRECTORY) mkdir ./DIRECTORY
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE', ibanner=1, job=6, idump=1, ext='.f'
          , branch='DIRECTORY'                                         \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22
