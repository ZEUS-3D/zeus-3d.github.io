#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#====== SCRIPT FILE TO MERGE TWO FILES AND PRECOMPILE THE RESULT ======#
#                                                                      #
# User sets: DIRECTORY, CHANGEDECK, SOURCECODE, MAKEFILE, EXECUTABLE,  #
#            COMPILER, LIBRARIES                                       #
#                                                                      #
# See precom.s for list of compilers and preset compiler options.      #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#========================> If necessary, create the directory DIRECTORY.
if(! -e ./DIRECTORY) mkdir ./DIRECTORY
#--------------------------------------------------> Create change deck.
rm -f ./changes
cat << EOF > ./changes
*ident changes
*delete par.3
       parameter ( idim=100, jdim=100, kdim=100 )
*read CHANGEDECK
EOF
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE', chgdk='changes'
          , ibanner=1, job=3, idump=1, inum=0, ipre=1
          , inmlst=1, iutask=0, iupdate=1, ext='.f'
          , branch='DIRECTORY', makename='MAKEFILE', xeq='EXECUTABLE'
          , compiler='COMPILER', coptions='debug'
          , libs='LIBRARIES'                                           \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22 ./changes ./changes.m
