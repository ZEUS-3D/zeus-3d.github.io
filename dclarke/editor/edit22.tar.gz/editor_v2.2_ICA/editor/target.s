#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#============ SCRIPT FILE TO TIDY UP FORTRAN SOURCE CODE ==============#
#                                                                      #
# User sets: SOURCECODE, FIRST, SECOND, FIRSTCD, FIRSTDK               #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE', ibanner=1, job=2, idump=1
          , ibegdo=  10, ienddo= 990, ibegre=1010, iendre=1990
          , ibegwr=2010, iendwr=2990
          , inc=10, irepl=1, ireseq=1, indent=2, ialpha=1
          , first='FIRST', secnd='SECOND', firstcd='FIRSTCD'
          , firstdk='FIRSTDK'                                          \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22
