#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#============= SCRIPT FILE TO CREATE THE EDITOR EXECUTABLE ============#
#---------------------------------------------> Select FORTRAN compiler.
#
#  Supported compilers include:
#     cf77 (Cray), f90 (Sun), g95 (Gnu), gfortran (Gnu), ifort (Intel),
#     pgf77 (Portland Group), xlf (IBM)
#
setenv FCOMP gfortran
#=======================================> Get files from home directory.
if(! -e ./libnmlst.a) cp ../nmlst/libnmlst.a .
#======================> If necessary, create the directory "editor2.2".
if(! -e ./editor2.2) mkdir ./editor2.2
#----------------------------------------------> Create the change deck.
rm -f ./chgedit
cat << EOF > ./chgedit
*define $FCOMP
*delete par.10,11
       parameter     ( k1=1000, k2=100000, k3=2000, k4=2000, k5=2000
     1               , k6=128, k7=1000, k8=1000, k9=4000 )
EOF
#=======================> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='edit22', chgdk='chgedit', safety=0.4
          , idump=1 ,job=3, ipre=1, inmlst=1, iupdate=1, iutask=0
          , ext='.f', branch='editor2.2', xeq='xedit22'
          , compiler='$FCOMP', makename='makeedit'
c         , coptions='debug'
          , coptions='optimise'
          , libs='libnmlst.a'                                        \$
EOF
chmod 755 ./xedit22
./xedit22
#==========================================> MAKE the EDITOR executable.
make -f ./makeedit
#===================================================> Tidy up directory.
rm -f ./inedit ./output ./editlp ./chgedit ./chgedit.m ./libnmlst.a
