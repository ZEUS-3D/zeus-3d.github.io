#---+----1----+----2----+----3----+--+----3----+----2----+----1----+---#
#=============== SCRIPT FILE TO PRECOMPILE A SOURCE CODE ==============#
#                                                                      #
# User sets: DIRECTORY, SOURCECODE, MAKEFILE, EXECUTABLE, COMPILER,    #
#            LIBRARIES                                                 #
#                                                                      #
# Supported compilers have preset "optimise" and "debug" settings:     #
#                                                                      #
# compiler  optimise  debug                                            #
# cf77      -O4       -g                                               #
# f90 -f77  -O4       -g -C -ftrap=common                              #
# g95       -O2       -g -fbounds-check -ftrace=full                   #
# gfortran  -O2       -g -fbounds-check -ffpe-trap=i,z,o               #
# ifort     -O2 -m32  -g -debug-parameters -check -fpe1 -traceback -m32#
# pgf77     -fast     -g -Ktrap=fp -Mbounds                            #
# xlf       -O4       -g -C -qextchk -qflttrap -qsigtrap               #
#                                                                      #
# otherwise, user sets compiler, coptions, loader, loptions directly.  #
#                                                                      #
#=======================================> Get files from home directory.
if(! -e ./xedit22) cp ~dclarke/editor/version2.2/xedit22 .
#======================> If necessary, create the directory "DIRECTORY".
if(! -e ./DIRECTORY) mkdir ./DIRECTORY
#-----------------------> Create the input deck for EDITOR, and execute.
rm -f ./inedit
cat << EOF > ./inedit
 \$editpar   inname='SOURCECODE', ibanner=1, job=4, idump=1
          , inmlst=1, iutask=0, iupdate=0, ext='.f'
          , branch='DIRECTORY', makename='MAKEFILE', xeq='EXECUTABLE'
          , compiler='COMPILER', coptions='debug'
          , libs='LIBRARIES'                                           \$
EOF
chmod 755 ./xedit22
./xedit22
#===================================================> Tidy up directory.
rm -f ./editlp ./inedit ./output ./xedit22
