c=======================================================================
c
       subroutine nsinit ( x, f, d2fdx2, ndim )
c
c    abcd:spline.nsinit <------------------- computes second derivatives
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine initialises the second derivative for a 
c  "natural cubic spline" by using a tridiagonal solver to evaluate the 
c  second derivatives of the input function consistent with continuous 
c  slopes at all points where the function is known.  For a natural 
c  spline, the second derivatives at the end points are assumed to be 
c  zero.
c
c  INPUT VARIABLES:
c    x         values of the independent variable where the function is 
c              known
c    f         functional values
c    ndim      dimension of x, f, and d2fdx2
c
c  OUTPUT VARIABLES:
c    d2fdx2    second derivative
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax
       parameter     ( nmax = 100 )
c
       integer       ndim    , n
c
       real*8        x       (ndim), f       (ndim), d2fdx2  (ndim)
     1             , h       (nmax), a       (nmax), b       (nmax)
     2             , r       (nmax), beta    (nmax), rho     (nmax)
c
c-----------------------------------------------------------------------
c
       if (ndim .gt. nmax) then
         write ( 6, 2010 ) nmax, ndim
         stop
       endif
c
c      Set grid spacing (h).
c
       do 10 n=1,ndim-1
         h(n) = x(n+1) - x(n)
10     continue
c
c      Set sub-, main, and super-diagonals (a, b, c), as well as the 
c  "source term" (r). Since a = c, we only need to set a.
c
       a(1) = 0.0d0
       do 20 n=2,ndim-1
         a(n) = h(n  )
         b(n) = 2.0d0 *   ( h(n-1) + h(n  ) )
         r(n) = 6.0d0 * ( ( f(n+1) - f(n  ) ) / h(n  )
     1                  - ( f(n  ) - f(n-1) ) / h(n-1) )
20     continue
c
c      Gauss-eliminate the sub-diagonal.
c
       beta(1) = 1.0d0
       rho (1) = 0.0d0
       do 30 n=2,ndim-1
         beta(n) = b(n) - a(n-1)**2         / beta(n-1)
         rho (n) = r(n) - a(n-1) * rho(n-1) / beta(n-1)
30     continue
c
c      Set natural spline boundary values, and perform the back 
c  substitutions.
c
       d2fdx2(1   ) = 0.0d0
       d2fdx2(ndim) = 0.0d0
       do 40 n=ndim-1,2,-1
         d2fdx2(n) = ( rho(n) - a(n) * d2fdx2(n+1) ) / beta(n)
40     continue
c
c----------------------- Write format statements -----------------------
c
2010   format('NSINIT  : Recompile with either ndim < ',i4
     1       ,', or nmax > ',i4,'.')
c
       return
       end
c
c=======================================================================
