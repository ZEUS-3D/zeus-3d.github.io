c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////               H E R M I T E               \\\\\\\\\\
c
c=======================================================================
c
       program hermite
c
c    abcd:hermite <-------------- hermite interpolation of Airy function
c                                                         february, 2004
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program performs a Hermite interpolation to the Bessel
c  function J1(x), then uses a bisection/secant root finder to find the 
c  first root of J1(x) beyond x=0.
c
c  EXTERNALS:
c    HERINT
c    BISCNT
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim    , idim    
       real*8        maxerr     
       parameter     ( ndim=11, idim=101, maxerr=1.0d-6 )
c
       integer       n       , i       , iter
       real          cpubeg  , cpuend  , cputot     
       real*8        dx      , xint    , j1int   , err     , xl
     1             , xr
c   
       real*8        x       (ndim), j0     (ndim), j1      (ndim)
     1             , j2      (ndim), j1p    (ndim)
c
       real*8        herint  , j1her
       external      herint  , j1her   , biscnt
c
       data          x
     1             / 0.0000000000d0, 1.0000000000d0, 2.0000000000d0
     2             , 3.0000000000d0, 4.0000000000d0, 5.0000000000d0
     3             , 6.0000000000d0, 7.0000000000d0, 8.0000000000d0
     4             , 9.0000000000d0, 1.0000000000d1 /
       data          j0
     1             / 1.0000000000d0, 0.7651976866d0, 0.2238907791d0
     2             ,-0.2600519549d0,-0.3971498099d0,-0.1775967713d0
     3             , 0.1506452573d0, 0.3000792705d0, 0.1716508071d0
     4             ,-0.0903336112d0,-0.2459357645d0 /
       data          j1
     1             / 0.0000000000d0, 0.4400505857d0, 0.5767248078d0
     2             , 0.3390589585d0,-0.0660433280d0,-0.3275791376d0
     3             ,-0.2766838581d0,-0.0046828235d0, 0.2346363469d0
     4             , 0.2453117866d0, 0.0434727462d0 /
       data          j2
     1             / 0.0000000000d0, 0.1149034849d0, 0.3528340286d0
     2             , 0.4860912606d0, 0.3641281459d0, 0.0465651163d0
     3             ,-0.2428732100d0,-0.3014172201d0,-0.1129917204d0
     4             , 0.1448473415d0, 0.2546303137d0 /
c
       common      / hercom   /
     1               x       , j1      , j1p
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
       dx   = 10.0d0 / dble ( idim - 1 )
c
c      Open disc files "herraw.dat" and "herint.dat", and write headers.
c
       open  ( 10, file='herraw.dat', status='unknown' )
       write ( 10, 2010 )
       open  ( 11, file='herint.dat', status='unknown' )
       write ( 11, 2020 )
c
c      Compute d(J1)/dx.
c
       do 10 n=1,ndim
         j1p(n) = 0.5d0 * ( j0(n) - j2(n) )
10     continue
c
c      Tabulate the uninterpolated data.
c
       do 20 n=1,ndim
         write ( 10, 2030 ) x(n), j1(n)
20     continue
c
c      Tabulate interpolated data.
c
       xint = 0.0d0
       do 30 i=1,idim
         j1int  = herint ( xint, x, j1, j1p, ndim )
         write ( 11, 2030 ) xint, j1int
         xint = xint + dx
30     continue
c
c      Close data files.
c
       close ( 10 )
       close ( 11 )
c
c      Find the first root of J1(x) beyond x=0 (between 3 and 5) using 
c  the hybrid bisection/secant method.
c
       xl = 3.0d0
       xr = 5.0d0
       call biscnt ( xl, xr, xint, j1her, maxerr, err, iter )
       write ( 6, 2040 ) xint, err, iter
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2050) cputot
c
       stop
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('#  Datafile containing the uninterpolated Bessel '
     1       ,'function J1(x).',/,'#',/
     2       ,'#        x                 J1(x)',/,'#')
2020   format('#  Datafile containing the interpolated Bessel '
     1       ,'function J1(x).',/,'#',/
     2       ,'#        x                 J1(x)',/,'#')
2030   format(1pg17.10,2x,g17.10)
2040   format('HERMITE : Root = ',1pg22.15,' +/- ',g9.2
     1       ,' after ',i3,' iterations.')
2050   format('HERMITE :',/
     1       ,'HERMITE : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////               H E R M I T E               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                H E R I N T                \\\\\\\\\\
c
c=======================================================================
c
       function herint ( xint, x, fofx, dfdx, ndim )
c
c    abcd:hermite.herint <----------------------- performs interpolation
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs a Hermite interpolation on the input 
c  function at the specified location.  A zeroth order extrapolation is 
c  returned if "xint" falls outside the domain of "x".
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
       integer       ndim    , n       , n0      , n0p1
       real*8        herint  , xint    , x1      , x2      , f1      
     1             , f2      , fp1     , fp2     
c
       real*8        x       (ndim), fofx    (ndim), dfdx    (ndim)
c
c-----------------------------------------------------------------------
c
c      If "xint" is outside domain of "x", return zeroth order 
c  extrapolation.
c
       if ( xint .lt. x(1) ) then
         write(6, 2010) xint, x(1), x(ndim)
         herint = fofx(1)
         return
       endif
       if ( xint .gt. x(ndim) ) then
         write(6, 2010) xint, x(1), x(ndim)
         herint = fofx(ndim)
         return
       endif
c
c      Determine in which interval "xint" falls.
c
       do 10 n=1,ndim-1
         if ( xint .ge. x(n) ) n0 = n
10     continue
c
c      Perform the Hermite interpolation.
c
       n0p1   = n0 + 1
       x1     = x   (n0  )
       x2     = x   (n0p1)
       f1     = fofx(n0  )
       f2     = fofx(n0p1)
       fp1    = dfdx(n0  )
       fp2    = dfdx(n0p1)
       herint = ( 3.0d0*x1 - 2.0d0*xint - x2 ) * ( xint - x2 )**2 * f1
     1        / ( x1 - x2 )**3
     2        + ( 3.0d0*x2 - 2.0d0*xint - x1 ) * ( xint - x1 )**2 * f2
     3        / ( x2 - x1 )**3
     4        + ( xint - x1 ) * ( xint - x2 )**2 * fp1 / ( x1 - x2 )**2
     5        + ( xint - x2 ) * ( xint - x1 )**2 * fp2 / ( x2 - x1 )**2
c
       return
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('HERINT  : *** WARNING *** Requested value for "xint" '
     1       ,1pg12.5,' is outside',/
     2       ,'HERINT  : the data domain (',g12.5,',',g12.5,').  A '
     3       ,'zeroth order',/
     3       ,'HERINT  : extrapolation will be returned for "fint".')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                H E R I N T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                B I S C N T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine biscnt ( xl, xr, xn, f, maxerr, err, iter )
c
c    abcd:roots.biscnt <------------------------ bisection/secant hybrid
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the hybrid bisection/secant method to
c  find the root of a function.
c
c  INPUT VARIABLES:
c    xl           value of x known to be less    than the root
c    xr           value of x known to be greater than the root
c    f            external function for which root is being sought.
c    maxerr       error tolerance for root
c
c  OUTPUT VARIABLES:
c    xn           returned as the root when the improvement over the
c                 previous iteration is less than the input value of 
c                 "maxerr".
c    err          estimated absolute error of xn.
c    iter         number of iterations to converge onto the final root 
c                 estimate xn; set to -1 if the root is not bracketed by
c                 input values "xl" and "xr".
c
c  EXTERNALS:
c    F
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       iter    , maxiter
       real*8        xl      , xr      , xnm1    , xn      , xnp1
     1             , fxl     , fxr     , fxnm1   , fxn     , dfxn
     2             , err     , ferr    , maxerr  , small
       real*8        f       
c
       data          maxiter , small   
     1             / 30    , 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       iter = 0
       fxl  = f(xl)
       fxr  = f(xr)
c
c      Data validation:  Make sure root lies in between the left- and 
c  right-hand value.  If not, return iter=0 to the calling routine.
c
       if (fxl*fxr .gt. 0.0d0) then
         write (6, 2010) xl, xr
         return
       endif
c
c      Starting values for "xn", "xnm1", "fxn", and "fxnm1".
c
       if (abs(fxl) .lt. abs(fxr)) then
         xn    = xl
         xnm1  = xr
         fxn   = fxl
         fxnm1 = fxr
       else
         xn    = xr
         xnm1  = xl
         fxn   = fxr
         fxnm1 = fxl
       endif
c
c-----------------------------------------------------------------------
c----- Top of hybrid loop. ---------------------------------------------
c-----------------------------------------------------------------------
c
10     continue
         iter = iter + 1
c
c      Compute the secant (dfxn) from current and previous guesses.
c
         dfxn = ( fxn - fxnm1 ) / ( ( xn - xnm1 ) + small )
c
c      Evaluate the next guess for the root.
c
         xnp1 = xn - fxn / ( dfxn + small )
c
c      A bisection step is taken if a secant step is not justified.  
c  Report to the user the interim value of the root and which algorithm 
c  is used.
c
         if ( (xl .lt. xnp1) .and. (xnp1 .lt. xr) ) then
           write (6, 2020) iter, xnp1
         else
           xnp1 = 0.5d0 * ( xl + xr )
           write (6, 2030) iter, xnp1
         endif
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found and execution is returned to the calling routine.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         xnm1 = xn
         xn   = xnp1
         if ( ferr .le. maxerr ) return
c
c      If the maximum number of iterations has been reached, return to 
c  the calling routine.
c
         if ( iter .ge. maxiter ) return
c
c      Prepare for next iteration.
c
         fxnm1 = fxn
         fxn   = f(xn)
c
c      Determine which half of the interval (xl,xr) "xn" is in, and 
c  reset either "xr" or "xl" as appropriate.
c
         if ( fxl * fxn .le. 0.0d0 ) then
           xr  = xn
           fxr = fxn
         else
           xl  = xn
           fxl = fxn
         endif
c
c      Go on to the next iteration.
c
         go to 10
20     continue
c
c-----------------------------------------------------------------------
c----- Bottom of hybrid loop. ------------------------------------------
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('BISCNT  : No unique root lies between the specified'
     1       ,' limits:',/
     2       ,'BISCNT  : xl = ', 1pg12.5,', and xr = ',g12.5)
2020   format('BISCNT  : Iteration: ',i3,' - SECANT        : root ='
     1       ,1pg22.15)
2030   format('BISCNT  : Iteration: ',i3,' - BISECTION     : root ='
     1       ,1pg22.15)
2040   format('BISCNT  : Maximum number of iterations ',i9
     1       ,' exceeded.',/
     2       ,'BISCNT  : Best guess at root is ',1pg22.15
     3       ,' +/- ',g9.2,'.  Abort!')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                B I S C N T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                 J 1 H E R                 \\\\\\\\\\
c
c=======================================================================
c
       function j1her ( xint )
c
c    abcd:hermite.j1her <---------------------------- interpolates j1(x)
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function interpolates the first Bessel function using
c  Hermite interpolation.  Data arrays are in common with the main 
c  program.
c
c  INPUT VARIABLES:
c    xint       value at which j1 is to be interpolated.
c
c  OUTPUT VARIABLES:
c    j1her      interpolated Bessel function
c
c  EXTERNALS:
c    HERINT
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim
       parameter     ( ndim = 11 )
c
       real*8        j1her   , xint       
c
       real*8        x       (ndim), j1      (ndim), j1p     (ndim)
c
       common      / hercom   /
     1               x       , j1      , j1p
c
       real*8        herint
       external      herint 
c
c-----------------------------------------------------------------------
c
c      Perform the Hermite interpolation to the specified value of x.
c
       j1her = herint ( xint, x, j1, j1p, ndim )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                 J 1 H E R                 \\\\\\\\\\
c
c=======================================================================
