c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////               R O M B E R G               \\\\\\\\\\
c
c=======================================================================
c
       program romberg
c
c    abcd:romberg <--------------------------------- romberg integration
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: March, 2011 by abcd; use the Romberg ratio to find when 
c                m is fine enough to begin Richardson extrapolation.
c
c  PURPOSE:  This program performs Romberg integration, which combines 
c  Richardson extrapolation with the Euler-Maclaurin series for 
c  approximating integrals.
c
c  This routine writes the results (the integral and the Richardson 
c  extrapolation table) to the screen and to the file romberg.dat.
c
c  Functions to be integrated are specified by the user at runtime.
c  Problems numbers refer to those in assignment 5 of PHYS 3210.
c
c      iprob = 1  =>  pi / ( 1 + cos pi*x) (limits [0:0.5])
c              2  =>  both Fresnel integrals (limits [0:5])
c              3  =>  elliptic integral of first kind (large-amplitude 
c                     pendulum) (limits [0:60])
c              4  =>  indefinite integral (xmin=0, xmax=a=100)
c
c  To plot the data in fresnel.dat, issue within gnuplot:  plot [0:5][0:0.8] "fresnel.dat" u 1:2 w lines, "fresnel.dat" u 1:3 w lines
c
c  The indefinite integral is actually doable analytically with the 
c  result of pi/2.  Using a=100 reduces the contribution of the 
c  improper portion of the integral which, while integrated accurately 
c  in the substituted variable "y", is not so accurate in the original 
c  variable "x" and this can undermine the agreement with the analytical 
c  solution.
c
c  For testing student programs, iprob=0 => functions set in FUNC, the
c  last routine in this program.  See FUNC for integration limits and 
c  correct answers.
c
c  To specify an integrand to be integrated, modify the statement
c  in the last function FUNC,
c
c    func = ...
c
c  and specify iprob=0 when asked by romberg to specify a problem.
c
c  EXTERNALS:
c    JETINIT
c    ROMB
c    PROB1   , PROB2A  , PROB2B  , PROB3   , PROB4A  , PROB4B
c    FUNC
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax    , imax
       real*8        tol     , one
       parameter     ( tol=1.0d-9, one=0.9999999999999d0
     1               , nmax=201, imax=6 )
c
       integer       iprob   , i       , ncall   , tcall
       real          cpubeg  , cpuend  , cputot     
       real*8        xmin    , xmax    , rint    , dlamb   , pi
     1             , dtheta  , thmax   , per0    , fper    , x1
     2             , x2      , err     , err1
c
       real*8        lamb    (nmax), fres1   (nmax), fres2   (nmax)
     1             , period  (imax)
c
       common      / limit    / thmax
c
       real*8        romb    , prob1   , prob2a  , prob2b  , prob3   
     1             , prob4a  , prob4b  , func
       external      romb    , prob1   , prob2a  , prob2b  , prob3   
     1             , prob4a  , prob4b  , func    , jetinit
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
       pi = acos ( -1.0d0 )
c
c      Ask user for which integral is to be solved and the domain over
c  which integration is to be performed.  
c
       write (6,2010)
       read  (5,   *) iprob
       if ( (iprob .lt. 1) .or. (iprob .gt. 4) ) iprob = 0
       write (6,2020)
       read  (5,   *) xmin, xmax
       tcall = 0
c
c      Problem generators.
c
c-- iprob = 0: user-specified function in "func" -----------------------
c
       if (iprob .eq. 0) then
         call jetinit ( xmin, xmax )
         rint = romb ( xmin, one, func, tol, 1, err, ncall )
         rint = romb ( 1.0d0, xmax, func, tol, 1, err, ncall ) + rint
         write(6,3000) rint
3000     format('Romberg integral = ',1pg22.15)
       endif
c
c-- iprob = 1: integrand = pi / ( 1 + cos(pi*x) ) ----------------------
c
       if (iprob .eq. 1) then
         rint = romb ( xmin, xmax, prob1, tol, 1, err, ncall )
         tcall = tcall + ncall
       endif
c
c-- iprob = 2: both Fresnel integrals ----------------------------------
c
       if (iprob .eq. 2) then
c
c      Open disc file.
c
         open ( 10, file='fresnel.dat', status='unknown' )
c
         dlamb    = ( xmax - xmin ) / dble(nmax-1)
         lamb (1) = 0.0d0
         fres1(1) = 0.0d0
         fres2(1) = 0.0d0
         do 10 i=2,nmax
           lamb (i) = lamb (i-1) + dlamb
           fres1(i) = fres1(i-1) 
     1              + romb ( lamb(i-1), lamb(i), prob2a, tol, 0, err
     1                     , ncall )
           tcall    = tcall + ncall
           fres2(i) = fres2(i-1) 
     1              + romb ( lamb(i-1), lamb(i), prob2b, tol, 0, err
     1                     , ncall )
           tcall    = tcall + ncall
           write (10,2040) lamb(i), fres1(i), fres2(i)
10       continue
c
c      close disc file.
c
         close (10)
c
       endif
c
c-- iprob = 3: period of large-amplitude pendulum ----------------------
c
       if (iprob .eq. 3) then
         dtheta = pi * ( xmax - xmin ) / dble(imax) / 1.8d2
         do 20 i=1,imax
           thmax     = dble(i) * dtheta
           period(i) = romb ( 0.0d0, pi/2.0d0, prob3, tol, 1, err
     1                      , ncall )
           tcall     = tcall + ncall
20       continue
c
c      Generate table
c
         per0 = 2.0d0*pi / sqrt(9.81d0)
         write (6,2050) per0
         do 30 i=1,imax
           thmax = 1.8d2 * dble(i) * dtheta / pi
           fper  = ( period(i) - per0 ) / per0
           write (6,2060) thmax, period(i), fper
30       continue
       endif
c
c-- iprob = 4: indefinite integral -------------------------------------
c
       if (iprob .eq. 4) then
c
c      In this case, xmax is interpreted as the "break point", where the
c  integral from 0 to infinity is broken into two parts: 0 to xmax, and 
c  xmax to infinity.
c
         x1    = xmin
         x2    = sqrt(xmax)
         rint  =        romb ( x1, x2, prob4a, tol, 1, err1, ncall )
         tcall = tcall + ncall
         x1    = 0.0d0
c
c      The first (second) limit "x2" corresponds to the first (second) 
c  function in PROB4B.  See note there.
c
c        x2    = 1.0d0 / xmax
         x2    = 1.0d0 / x2
         rint  = rint + romb ( x1, x2, prob4b, tol, 1, err, ncall )
         tcall = tcall + ncall
         err   = err + err1
c
         write (6,2070) rint, err
       endif
c
c-----------------------------------------------------------------------
c
c      Report the cpu time consumed and number of function calls made.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write (6,2080) cputot, tcall
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('ROMBERG : Enter problem selection:',/
     1       ,'ROMBERG : 0  =>  user-specified integrand in function '
     2       ,'"func";',/
     3       ,'ROMBERG : 1  =>  Problem 1) pi / (1+cos(pi*x)), (0,0.5);'
     4       ,/
     5       ,'ROMBERG : 2  =>  Problem 2) Fresnel integrals, (0,5);',/
     6       ,'ROMBERG : 3  =>  problem 3) period of large-amplitude '
     7       ,'pendulum (0,60);',/
     8       ,'ROMBERG : 4  =>  problem 4) indefinite integral '
     9       ,'(0,1).')
2020   format('ROMBERG : Enter "xmin" and "xmax", the domain of '
     1       ,'integration.')
2040   format(1p3g22.15)
2050   format('ROMBERG :',/
     1       ,'ROMBERG :   thmax',7x,'period',5x,'frac. diff.',6x
     2       ,'per0=',1pg12.5)
2060   format('ROMBERG : '1p3g12.5)
2070   format('ROMBERG : indefinite integral = ',1pg22.15,' +/- ',g8.2)
2080   format('ROMBERG :',/
     1       ,'ROMBERG : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds;',/
     3       ,'ROMBERG : Total number of function calls is ',i0,'.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////               R O M B E R G               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  R O M B                  \\\\\\\\\\
c
c=======================================================================
c
       function romb ( xa, xb, fofx, tol, iout, err, ncall )
c
c    abcd:romberg.romb <------------------- performs romberg integration
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: March, 2011 by abcd; beginning value for "m" is now 
c                calculated rather than set by calling routine, 
c                reorganised to match lecture notes better.
c
c  PURPOSE:  This routine performs romberg integration on the input 
c  function between the specified limits.
c
c  INPUT VARIABLES:
c    xa,xb      domain of integration
c    fofx       function to be integrated
c    tol        maximum error (tolerance)
c    iout       =1 => output to screen
c               =0 => suppress output to screen
c
c  OUTPUT VARIABLES:
c    romb       Romberg integration of f between limits xa, xb.  
c    err        estimated error of the integral
c    ncall      number of function calls made by CTR
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    CTR
c    FOFX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       mmax
       parameter     ( mmax=20 )
c
       character*34  frmt
       integer       iout    , m       , ncall   , j       , iquit   
     1             , jmax
       real*8        romb    , xa      , xb      , tol     , err
     1             , sum     , tmm1    , tm      , tmp1    , ratio
     2             , delt    , fact    , ferr    , anew    
c
       real*8        new     (mmax), old     (mmax)
c
       real*8        fofx
       external      ctr     , fofx
c
c-----------------------------------------------------------------------
c
c      Initialise extrapolation parameters.
c
       ncall = 0
       sum   = 0.0d0
       m     = 2
c
c      Use Romberg ratio to determine starting value for "m".  CTR is 
c  the routine that performs the composite trapezoid rule, which returns 
c  an updated value of "sum" having used the input value of "sum" to 
c  start it off.
c
       call ctr ( xa, xb, fofx, m-1, ncall, sum )
       tmm1  = sum
       call ctr ( xa, xb, fofx, m  , ncall, sum )
       tm    = sum
10     continue
       call ctr ( xa, xb, fofx, m+1, ncall, sum )
       tmp1  = sum
       ratio = 4.0d0
       delt  = 2.0d0 * abs ( ( tm - tmp1 ) / ( tm + tmp1 ) )
       if (delt .gt. tol) ratio = abs ( ( tmm1 - tm ) / ( tm - tmp1 ) ) 
       if (ratio .lt. 3.0d0) then
         if (m .lt. mmax) then 
c
c      If m < mmax, recompute Riemann sum with smaller interval. 
c 
           m    = m + 1
           tmm1 = tm
           tm   = tmp1
           go to 10
         endif
c
c      If m = mmax, warn user that Romberg ratio is still < 3.0, and 
c  continue on anyway to generate Richardson extrapolation table.
c
         write (6,2010) m, ratio
       endif
c
c      Report value of Romberg ratio.
c
       if (iout .eq. 1) write (6,2011) 2**m, ratio
c
c      Initialise and write first extrapolation table row.
c
       new(1) = tm
       do 20 j=2,mmax
         new(j) = 0.0d0
20     continue
       if (iout .eq. 1) write (6,2012) m, new(1)
c
       iquit = 0
       jmax  = 1
c
c----- Top of extrapolation loop ---------------------------------------
c
c      "new" is the current  row to the R.E. table.
c      "old" is the previous row of the R.E. table
c
30     continue
       old(1) = new(1)
       new(1) = sum
       do 40 j=1,jmax
         fact     = 4.0d0**j
         old(j+1) = new(j+1)
         new(j+1) = ( fact * new(j) - old(j) ) / ( fact - 1.0d0 )
40     continue
c
c      Write new row of extrapolation table.
c
       write ( frmt, 2020 ) mmax
       if (iout .eq. 1) write ( 6, frmt ) m+jmax, (new(j),j=1,jmax+1)
c
c      Test to see if extrapolation is finished.
c
       ferr = 2.0d0 * abs ( ( new(jmax+1) - new(jmax) )
     1                    / ( new(jmax+1) + new(jmax) ) )
       anew = abs ( new(jmax+1) )
       if ( (ferr .le. tol) .or. (anew .le. tol   ) ) iquit = 1
       if ( (iquit .eq. 0) .and. (jmax .eq. mmax-1) ) iquit = 2
c
c      If extrapolation is to be continued for another cycle, increment 
c  "jmax", recompute Euler-Mclaurin sum, and return to top of the loop.  
c  Otherwise, exit.
c
       if (iquit .eq. 0) then
         jmax = jmax + 1
         call ctr ( xa, xb, fofx, m+jmax, ncall, sum )
         go to 30
         endif
       if (iquit .eq. 2) write (6,2030) mmax
c
c----- Bottom of extrapolation loop ------------------------------------
c
       romb = new(jmax+1)
       err  = ferr * romb
       if (iout .eq. 1) write (6,2040) romb, err, jmax, ncall
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('ROMB    : ----WARNING----> At m = mmax = ',i2
     1       ,', Romberg ratio = ',1pg12.5,' < 3.5,'/
     2       ,'ROMB    : which may indicate convergence problems.  '
     3       ,'Execution continuing...',/
     4       ,'ROMB    :')
2011   format('ROMB    : With ',i4,' intervals, Romberg ratio = '
     1       ,1pg12.5,/
     2       ,'ROMB    :')
2012   format('ROMB    :  m        D1              D2              '
     1       ,'D3              D4',/
     2       ,'ROMB    :',/
     3       ,'ROMB    : ',i2,2x,1pg16.9)
2020   format('(''ROMB    : '',i2,2x,1p',i3.3,'g16.9)')
2030   format('ROMB    : Richardson extrapolation failed to converge '
     1       ,'after ',i2,' iterations.',/
     2       ,'ROMB    : Extrapolation terminated.')
2040   format('ROMB    :',/
     1       ,'ROMB    : integral = ',1pg22.15,' +/- ',g9.2,' after '
     2       ,i2,' iterations',/
     3       ,'ROMB    : with ',i6,' calls to the function.',/
     4       ,'ROMB    :')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  R O M B                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                   C T R                   \\\\\\\\\\
c
c=======================================================================
c
       subroutine ctr ( xa, xb, fofx, m, ncall, sum )
c
c    abcd:romberg.ctr <--------------- performs composite trapezoid rule
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the composite trapezoid rule for the 
c  input function fofx by dividing the domain [xa,xb] into 2**m equal 
c  regions.
c
c  INPUT VARIABLES:
c    xa,xb      domain of integration
c    m          domain is divided into 2**m equal regions 
c    fofx       input function
c
c  OUTPUT VARIABLES:
c    ncall      number of times fofx has been called
c    sum        Riemann sum using composite trapezoid rule.  
c
c  If sum=0 on input, sum is started from scratch (e.g., end points).  
c
c  If sum .ne. 0 on input, it is assumed sum contains the sum for step
c  m-1, and half of this value is added to the Riemann sum of the odd 
c  zones of the current step (m).
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    FOFX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       m       , ncall   , mm      , nreg    , deli    
     1             , i
       real*8        xa      , xb      , h       , sum     , x
       real*8   fxa,fxb,int,fx
c
       real*8        fofx
       external      fofx
c
c-----------------------------------------------------------------------
c
       mm   = max0 ( 1, m )
       nreg = 2**mm
       h    = ( xb - xa ) / dble ( nreg )
       if (sum .eq. 0.0d0) then
         deli  = 1
         sum   = 0.5d0 * ( fofx(xa) + fofx(xb) )
         ncall = 2
       else
         deli  = 2
         sum   = 0.5d0 * sum / h
       endif
       do 10 i=1,nreg-1,deli
         x     = xa  + dble(i) * h
         sum   = sum + fofx(x)
         ncall = ncall + 1
10     continue
       sum = sum * h
c       if (mm .eq. 1) then
c         fxa = fofx(xa)
c         fxb = fofx(xb)
c         x   = 0.5d0*(xa+xb)
c         fx  = fofx(x)
c         int = ( 0.5d0 * ( fxa + fxb ) + fx ) * h
c         write(6,3000) xa,xb,x,fxa,fxb,fx,int
c3000     format('xa,xb,x,fxa,fxb,fx,int=',1p7g12.5)
c       endif
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                   C T R                   \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  B J E T                  \\\\\\\\\\
c
c=======================================================================
c
       function bjet ( xi )
c
c    abcd:romberg.bjet <-------------- scale-free magnetic field profile
c    from dac:azeus.bjet                                    august, 2017
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function returns a single value in the magnetic field
c  profile at the normalised radial coordinate xi used in AZEuS.JETINIT.  
c  It is included here to find out why QROMB in AZEuS is susceptible to 
c  WARNING messages, and how it may be made more robust.
c
c  See comments in azeus.bjet for details on the profile itself.
c
c  INPUT VARIABLES:
c    xi          normalised radial coordinate.
c
c  OUTPUT VARIABLES:
c    bjet        value of scale-free magnetic field profile at "xi".
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        huge
       parameter     ( huge = 1.0d99 )
c
       integer       ibjet
       real*8        pi      , xij     , aind    , xic     , exp1    
     1             , exp2    , prat 
c
       common      / bjetcomi /
     1               ibjet
       common      / bjetcomr /
     1               pi      , xij     , aind    , xic     , exp1    
     1             , exp2    , prat 
c
       real*8        bjet    , xi      , q1      , josh    , folk
c
c-----------------------------------------------------------------------
c
       bjet = 0.0d0
       if (xi .le. xij) then
         if (xi .lt. 1.0d0) then
c
c      "Outward" (positive) portion of profile.
c
           if (ibjet .le. 4) then
             bjet = 1.0d0
             if ( (ibjet .eq. 2) .or. (ibjet .eq. 4) ) bjet = xi
             if (aind .lt. huge) then
               q1   = 0.5d0 * pi * xi**aind
               bjet = bjet * ( cos ( q1 ) )**2
             endif
           else
             if (xi .lt. xic) then
               josh = 0.5d0 * ( xi / xic )**exp1
             else
               folk = ( 1.0d0 - xi ) / ( 1.0d0 - xic )
               josh = 1.0d0 - 0.5d0 * folk**exp2
             endif
             bjet = ( sin ( pi * josh ) )**2
           endif
c
         else
c
c      "Return" (negative) portion of profile.
c
           if (ibjet .le. 2) then
             bjet =-prat
             if (aind .lt. huge) then
               q1    = pi / ( xij - 1.0d0 )
               bjet = prat * abs ( cos ( q1 * ( xi - 1.0d0 ) ) )**aind
     1              - prat
             endif
           endif
c
         endif
       endif
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  B J E T                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               J E T I N I T               \\\\\\\\\\
c
c=======================================================================
c
       subroutine jetinit ( ximn, ximx )
c
c    abcd:romberg.jetinit <------------- initialises parameters for bjet
c                                                           august, 2017
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This initialises various variables used by BJET, to mimic 
c  the conditions in which BJET is used in AZEuS.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c    ximn,ximx   limits of integration
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        huge
       parameter     ( huge = 1.0d99 )
c
       integer       ibjet
       real*8        pi      , xij     , aind    , xic     , exp1    
     1             , exp2    , prat
c
       common      / bjetcomi /
     1               ibjet
       common      / bjetcomr /
     1               pi      , xij     , aind    , xic     , exp1    
     1             , exp2    , prat
c
       integer       i
       real*8        ximn    , ximx, dxi, xi, fxi, bjet, anint
       external      bjet
c
c-----------------------------------------------------------------------
c
       ibjet = 2
       pi    = acos ( -1.0d0 )
       xij   = 1.25d0
       aind  = huge
       xic   = 0.999d0
       exp1  = 0.0d0
       exp2  = 0.0d0
       prat  = 1.185185185185d0
       ximn  = 0.63737743919910d0
c       ximn  = 1.0d0
       ximx  = 1.25d0
c
       open ( unit=10, file='bjet.txt', status='unknown')
       dxi = ( ximx - ximn ) / 999.0d0
       do 10 i=1,1000
         xi  = ximn + dble(i-1) * dxi
         fxi = bjet ( xi )
         write ( 10, * ) xi, fxi
10     continue
       close ( 10 )
c
       anint = 0.5d0 * ( 1.0d0 - ximn**2 ) - 0.25d0 * prat
       write(6,3000) anint
3000   format('Analytical integral = ',1pg22.15)
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               J E T I N I T               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                 P R O B 1                 \\\\\\\\\\
c
c=======================================================================
c
       function prob1 ( x )
c
c    abcd:romberg.prob1 <------------------------------------- problem 1
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value f(x) = pi / ( 1 + cos(pi*x) ) for problem
c  1 of PHYS3210 assignment 5.
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    prob1      function value.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        prob1   , x       , pi
c
c-----------------------------------------------------------------------
c
       pi    = acos(-1.0d0)
       prob1 = pi / ( 1.0d0 + cos(pi*x) )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                 P R O B 1                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                P R O B 2 A                \\\\\\\\\\
c
c=======================================================================
c
       function prob2a ( x )
c
c    abcd:romberg.prob2a <---------- first Fresnel integral in problem 2
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value f(x) = cos ( 0.5d0*pi*x**2 ) (first 
c  Fresnel integral) for problem 2 of PHYS3210 assignment 5.
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    prob2a     function value.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        prob2a  , x       , pi
c
c-----------------------------------------------------------------------
c
       pi     = acos(-1.0d0)
       prob2a = cos ( 0.5d0*pi*x**2 )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                P R O B 2 A                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                P R O B 2 B                \\\\\\\\\\
c
c=======================================================================
c
       function prob2b ( x )
c
c    abcd:romberg.prob2b <--------- second Fresnel integral in problem 2
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value f(x) = sin ( 0.5d0*pi*x**2 ) (second 
c  Fresnel integral) for problem 2 of PHYS3210 assignment 5.
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    prob2b     function value.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        prob2b  , x       , pi
c
c-----------------------------------------------------------------------
c
       pi     = acos(-1.0d0)
       prob2b = sin ( 0.5d0*pi*x**2 )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                P R O B 2 B                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                 P R O B 3                 \\\\\\\\\\
c
c=======================================================================
c
       function prob3 ( x )
c
c    abcd:romberg.prob3 <----- elliptic integrand of 1st kind, problem 3
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value of the elliptic integral of the first 
c  kind for problem 3 of PHYS3210 assignment 5.
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    prob3      function value.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        prob3   , x       , thmax   , kay     , fact
c
       common      / limit    / thmax
c
c-----------------------------------------------------------------------
c
       kay   = sin ( thmax / 2.0d0 )
       fact  = 4.0d0 / sqrt(9.81d0)
       prob3 = fact / sqrt ( 1.0d0 - ( kay * sin(x) )**2 )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                 P R O B 3                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                P R O B 4 A                \\\\\\\\\\
c
c=======================================================================
c
       function prob4a ( x )
c
c    abcd:romberg.prob4a <------------------------------------ problem 4
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value of the integrand for the proper half of 
c  the integral with the singualrity removed for problem 4 of PHYS3210 
c  assignment 5.
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    prob4a     function value.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        prob4a  , x       
c
c-----------------------------------------------------------------------
c
       prob4a = 2.0d0 / ( 1.0d0 + x**2 )**2
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                P R O B 4 A                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                P R O B 4 B                \\\\\\\\\\
c
c=======================================================================
c
       function prob4b ( x )
c
c    abcd:romberg.prob4b <------------------------------------ problem 4
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value of the integrand for the improper half of
c  the integral for problem 1d of PHYS3210 assignment 5.
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    prob4b     function value.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        prob4b  , x       
c
c-----------------------------------------------------------------------
c
c      The first function has a singularity at f'(0), the second one 
c  does not.  As a result, R.I has difficulty converging on the first 
c  function.
c
c      prob4b = sqrt(x) / ( 1.0d0 + x )**2
       prob4b = 2.0d0 * x**2 / ( 1.0d0 + x**2 )**2
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                P R O B 4 B                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  F U N C                  \\\\\\\\\\
c
c=======================================================================
c
       function func ( x )
c
c    abcd:romberg.func <----------------------- user-specified integrand
c                                                            march, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value of the user-specified integrand.  This 
c  routine is called when iprob=0 (user input at runtime).
c
c  The functions listed here are suggested integrands to try with 
c  students' programs.  For both, use domain [0,1].
c
c  For the sin**4 integrand, I = 0.829532127671161 +/- 1.05E-10 after 
c  4 iterations with 65 calls to the function.  (Romberg ratio = 46.368)
c
c  For the Gaussian integrand, I = 0.746824132811875 +/- 6.53E-12 after  
c  3 iterations with 33 calls to the function.  (Romberg ratio = 4.0305)
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    func       function value.
c
c  EXTERNALS:
c    BJET
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        func    , x       
c
       real*8        bjet
       external      bjet
c
c-----------------------------------------------------------------------
c
c       func = 0.0d0
c       if (x .ne. 0.0d0) func = sin ( acos(-1.0d0) * x )**4 / x
c       func = exp(-x**2)
c
c    For the N-body problem of starting the velocity at a half time 
c  step ahead of the position.
c
c       func = 1.0d0 / ( 1.0d0 + 0.44d0 * cos(x) )**2
c
c    For the magnetic and velocity profiles in azeus.jetinit...
c
       func = bjet ( x )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  F U N C                  \\\\\\\\\\
c
c=======================================================================
c
c
