c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                L I N A L G                \\\\\\\\\\
c
c=======================================================================
c
       program linalg
c
c    abcd:linalg <--------------------- linear algebraic equation solver
c    from abcd:linalgo                                    november, 2001
c
c    written by: A Busy Code Developer
c    modified 1: June, 2018 by ABCD; version with corrected row-swapping 
c                scheme in LUSOLVE
c
c  PURPOSE:  This program finds the unique solution to a system of 
c  linear algebraic equations, provided it exists, using a lower-upper 
c  triangular decomposition algorithm for solving the matrix equation 
c  (LUSOLVE).  Given a system of linear equations:
c
c                         A |x> = |b>
c
c  the user will be asked to provide the number of equations (n, an 
c  integer), and the name of a file (no more than 12 characters) that 
c  contains A and |b> in the following format stored "row-major":
c
c  A11 A12 ... A1n
c  A21 A22 ... A2n
c   :   :       :        (1)
c  An1 An2 ... Ann
c   b1  b2 ...  bn
c
c  where each line is separated by a carriage return, and where each of 
c  Aij and bi can be integer, real, or double precision.
c
c  Solutions |x> are written to "linalg.dat".
c
c  The data for a problem of 3 equations in 3 unknowns are in "test01".
c      3x +  y -  z = 2   |
c       x -  y + 2z = 1   |  =>  x=2/5, y=11/5, z=7/5
c      5x - 2y +  z =-1   |
c
c  The data for the "mad professor's circuit" are in "circuit01".
c
c  For ill-conditioned (Hilbert) matrices, see linalg2.f.
c
c  The original version of the subroutine LUSOLVE is due to DeVries' "A 
c  First Course in Computational Physics" (@1994, John Wiley), with 
c  corrections made by DAC to the row-swapping portion of the routine.
c
c  EXTERNALS:
c    LUSOLVE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim
       parameter     ( ndim=10 )
c
       character*12  inname
       integer       n       , i       , j
       real          cpubeg  , cpuend  , cputot  
       real*8        det
c
       real*8        x       (ndim), b       (ndim)
c
       real*8        a       (ndim,ndim)
c
       external      lusolve
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Ask user for the number of equations to be solved, and the name 
c  of the file containing the matrix A followed by the bra <b|.
c
       write (6, 2010)
       read  (5,    *) n
       write (6, 2020)
       read  (5,    *) inname
c
c      Open specified input file as well as an output file.
c
       open ( unit=10, file=inname, status='old', err=30 )
       open ( unit=11, file='linalg.dat', status='unknown' )
c
c      Read matrix A.  Since FORTRAN77 is column-major (first index runs
c  its course before second index is incremented), data are read by loop 
c  10 transposed to how one normally thinks of as matrix order.  Thus, 
c  the n x n matrix in equation (1) above will be stored as:
c
c  A11 A21 ... An1
c  A12 A22 ... An2
c   :   :       :        (2)
c  A1n A2n ... Ann
c
c  In FORTRAN77, in A(i,j), "i" is the column number and "j" is the row 
c  number.  However, stored transposed, one can then program as though 
c  the (i,j)th element were the element in row "i", column "j".  Thus, 
c  if I want the element in the first row, second column of A (normally 
c  thought of as A12), asking for A(1,2) gives me the element for i=1, 
c  j=2 which, in the transposed matrix (2), is A12.
c
       do 10 i=1,n
         read (10,*,err=40) (a(i,j),j=1,n)
10     continue
c
c      Read bra <b|.
c
       read (10,*,err=50) (b(i),i=1,n)
c
c      Solve.
c
       call lusolve ( a, x, b, det, ndim, n )
c
c      Report results.
c
       write (6 ,2030) det
       write (11,2030) det
       do 20 i=1,n
         write (6 ,2040) i, x(i)
         write (11,2040) i, x(i)
20     continue
       go to 60
c
c      Whoops!  Problem reading file inname.  Aborts!
c
30     continue
       write (6,2050) inname
       go to 60
c
c      Whoops!  Problem reading data into array a.  Aborts!
c
40     continue
       write (6,2060) i, j
       go to 60
c
c      Whoops!  Problem reading data into ket |b>.  Aborts!
c
50     continue
       write (6,2070) i
60     continue
c
c      Close data files.
c
       close (10)
       close (11)
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2080) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-------------0----+----1----+----2----+----3----+----4----+----5----+--
c
2010   format('LINALG  : Enter the number of equations to be solved '
     1       ,'(integer):')
2020   format('LINALG  : Enter the name of the input file (12 '
     1       ,'characters or less):')
2030   format('LINALG  : RESULTS FROM DOUBLE PRECISION CALCULATION:',/
     1       ,'LINALG  :',/
     2       ,'LINALG  : det(A) = ',1pg22.15,/
     3       ,'LINALG  : The values of the n variables in |x> are:')
2040   format('LINALG  : x(',i3,') = ',1pg22.15)
2050   format('LINALG  : Whoops!  Problem reading file ',a12
     1       ,'.  Aborts!')
2060   format('LINALG  : Whoops!  Problem reading data into array '
     1       ,'element A(',i3,',',i3,').  Aborts!')
2070   format('LINALG  : Whoops!  Problem reading data into vector '
     1       ,'element b(',i3,').  Aborts!')
2080   format('LINALG  :',/
     1       ,'LINALG  : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                L I N A L G                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               L U S O L V E               \\\\\\\\\\
c
c=======================================================================
c
       subroutine lusolve ( a, x, b, det, ndim, n )
c
c    abcd:linalg.lusolve <---------------------------- L-U decomposition
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1: June, 2018 by ABCD; replaced Devries' flawed row 
c                swapping scheme; see header of linalgo.lusolve (old 
c                version) for discussion.
c
c  PURPOSE:  This routine solves the linear set of equations
c
c                          A |x> = |b>                              (1)
c
c  by the method of lower-upper triangular decomposition of the matrix A
c  (from Crout).  Any matrix A can be written as a product of a lower 
c  and upper triangular matrix (L and U): A = LU.  In this case,
c
c                        L U |x> = |b>.
c
c  Let:
c                          U |x> = |z>.                             (2)
c
c  Then:
c                          L |z> = |b>.                             (3)
c
c  Equation (3) is easy to solve by "forward substitution".  Once |z> is
c  known, it is used in equation (2), which is then solved for |x> by 
c  "backward substitution".
c
c  The trick is then to find L and U, given A.  This is the primary 
c  purpose of this subroutine.
c
c  From Paul L. DeVries' "A First Course in Computational Physics" 
c  (@1994, John Wiley).
c
c  INPUT VARIABLES:
c    a          the n by n array to be decomposed
c    b          the n-ket representing the RHS of the equation
c    ndim       dimension of arrays, as declared in the calling routine
c    n          actual size of arrays; n .le. ndim
c
c  OUTPUT VARIABLES:
c    det        determinant of array a
c    x          the n-ket of unknowns
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim    , n       , i       , j       , k
     1             , eye     , ordi    , swap
       real*8        det     , prod    , sum     , pm1
c
       integer       order   (ndim), tmpord  (ndim)
       real*8        x       (ndim), b       (ndim)
c
       real*8        a       (ndim,ndim), p       (ndim,ndim)
     1             , pt      (ndim,ndim)
c
c-----------------------------------------------------------------------
c
       det = 1.0d0
       pm1 = 1.0d0
       do 1 i=1,ndim
         order(i) = 0
1      continue
c
c      A major wrinkle to the algorithm discussed in class is what to do 
c  should a zero be on the diagonal.  Note that computing rows of U 
c  requires division by a diagonal element of A.  A degree of freedom we 
c  can exploit is that it does not matter which order the equations are 
c  in.  This means we can swap rows of A so that no diagonal element is 
c  zero without worrying about whether this changes the solution.  BTW,
c  if it is not possible to arrange the rows so that no diagonal element 
c  is zero, this will mean det(A) = 0 => A has no inverse => there is no
c  solution to this system of equations.  Thus, so long as the system of 
c  equations is soluble, we can rearrange the rows so that no diagonal 
c  element of A is zero.
c
c  First, we need to see if there is even a problem.
c
       prod = 1.0d0
       do 10 i=1,n
         prod = prod * a(i,i)
10     continue
c
       if (prod .ne. 0.0d0) then
c
c      No element along A as given is zero, and there is no need to swap 
c  rows.  Set "order" to the current order of the rows, and move 
c  directly to the LU decomposition.
c
         do 20 i=1,n
           order(i) = i
20       continue
c
       else
c
c- | -- | -- | -- | -------------------------------- | -- | -- | -- | --
c \|/  \|/  \|/  \|/   DAC'S ROW SWAPPING ALGORITM  \|/  \|/  \|/  \|/
c- v -- v -- v -- v -------------------------------- v -- v -- v -- v --
c
c      At least one element along the diagonal is zero, and we must find 
c  a permutation of the rows that moves all zeros away from it.  Here is
c  the idea behind the scheme I've come up with.  Suppose the input 
c  matrix is:
c         _          _
c        | 0  0  1  2 |
c    A = | 5  1  0  0 |
c        |-3  0  3  0 |
c        |_0 -2  0  0_|
c
c  with two zeros along the diagonal.  A "permutation array", P, is 
c  constructed so that its (row i, column j) entry is j if row j in 
c  matrix A could be moved to row i.  The reason row j in A may not be 
c  able to go to row i is if Aij = 0 (in which case, once moved to row 
c  i, the zero would become element Aii, and thus along the diagonal).  
c  In this case, Pij is set to 0.
c
c  Thus, for the given A, P would look like:
c         _          _
c        | 0  2  3  0 |
c    P = | 0  2  0  4 |
c        | 1  0  3  0 |
c        |_1  0  0  0_|
c
c  As an example, the first row of P reads as follows:
c      P11 = 0 => row 1 in A cannot go to row 1
c      P12 = 2 => row 2 in A could  go to row 1
c      P13 = 3 => row 3 in A could  go to row 1
c      P14 = 4 => row 4 in A cannot go to row 1
c
c  Thus, the first row of P tells us either row 2 or 3 in A could move 
c  to row 1, the second row tells us either row 2 or 4 of A could move
c  to row 2, the third row tells us either row 1 or 3 of A could move to
c  row 3, and the fourth row of P tells us only row 1 of A could move to 
c  row 4 (since rows 2, 3, 4 all have 0s in their fourth slot).
c
c  With the constraint that each digit, 1 2 3 4, can appear only once in 
c  a given permutation, the human eye can quickly pick out the only
c  permutation that works: 2431.  The bulk of the following algorithm is 
c  to make the "computer eye" see this too.
c
c                          -------------------
c
c      Define a "permutation array", P, whose (row i, column j) entry
c  tells us if row j (yes, j) of matrix A *could* be moved to row i; 
c  that is, its ith element is not zero.  We'll do this by setting 
c  P(i,j) = 0 if A(j,i) = 0, or P(i,j) = j if A(j,i) .ne. 0.
c
         do 40 j=1,n
           do 30 i=1,n
             p(i,j) = j
             if (a(j,i) .eq. 0) p(i,j) = 0
30         continue
40       continue
c
c      Now we'll use P to determine which permutation of the rows will 
c  move all zeros away from the diagonal.  Note that we don't need to 
c  know all the permutations that'll do this; just one will do fine!
c
         i = 1
50       continue
c
c      If row counter "i" exceeds "n", we've found a permutation that
c  works.  Move on to LU decomposition after permuting the rows of "a".
c
         if (i .gt. n) go to 100
c
c      If we arrive here, we've still not found a complete permutation 
c  to rid the diagonal of zeros.  Start by loading a temporary 
c  permutation array.
c
         do 60 j=1,n
           pt(i,j) = p(i,j)
60       continue
c
c      Set values of "pt" already used in "order" to zero (so they won't 
c  be used again).
c
         do 70 eye=1,i-1
           pt(i,order(eye)) = 0
70       continue
80       continue
c
c      Set order for row "i" to first non-zero value in row "i" of "pt".
c
         do 90 j=1,n
           if (pt(i,j) .ne. 0) then
             order(i) = pt(i,j)
             i = i + 1
             go to 50
           endif
90       continue
c
c      If execution gets here, there were no non-zero values in row "i" 
c  of "pt".  This means this line of permutations has reached a dead-
c  end.  Further, if this dead-end was discovered on row 1, there is no 
c  permutation to keep zeros off the diagonal, and there is therefore no 
c  solution.  Inform the user of the ill-defined problem, and exit.
c
         i = i - 1
         if (i .lt. 1) then
           write (6, 2010)
           stop
         endif
c
c      If there are still rows to return to, go back up one row, 
c  eliminate the current value of "order" from that row of "pt", and 
c  resume search.
c
         pt(i,order(i)) = 0
         go to 80
c
100      continue
c
c      Now that a suitable permutation of the rows of "a" has been 
c  found, rearrange the matrix accordingly.  For this, we'll need a 
c  temporary array which can be "pt" since we are now finished wth it.
c  Assignment of "tmpord" at the end of loop 140 is to prepare for the 
c  following segment in loop 160.
c
         do 120 i=1,n
           do 110 j=1,n
             pt(i,j) = a(order(i),j)
110        continue
120      continue
         do 140 i=1,n
           do 130 j=1,n
             a(i,j) = pt(i,j)
130        continue
           tmpord(i) = order(i)
140      continue
c
c      To get the sign of the determinant right, determine whether the 
c  permutation chosen is even (+1) or odd (-1).  This segment determines 
c  the number of transpositions required to create the permutation 
c  found, the parity of which determines the parity of the permutation. 
c
         swap = 0
150      continue
         do 160 i=1,n
           ordi = tmpord(i)
           if (ordi .ne. i) then
             tmpord   (i) = tmpord(ordi)
             tmpord(ordi) = ordi
             swap         = swap + 1
             go to 150
           endif
160      continue
         if (2*(swap/2) .ne. swap) pm1 =-1.0d0
c
c- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ --
c /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  
c- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | --
c
       endif
c
c      Start the LU decomposition.  The original matrix A will be 
c  overwritten by the elements of L and U as they are determined since 
c  those elements of A are never needed again.  This saves having to 
c  declare two additional arrays L and U.  Note further that A can 
c  accommodate the non-zero unknown elements (those not equal to 1) of 
c  both L and U simultaneously.
c      The first row and column are specially treated, as is L(n,n).
c
       do 220 k=1,n-1
c
c      Do a column of L.
c
         if (k .ge. 2) then
c
c      Compute elements of L.
c
           do 180 i=k,n
             sum = a(i,k)
             do 170 j=1,k-1
               sum = sum - a(i,j) * a(j,k)
170          continue
             a(i,k) = sum
180        continue
         endif
c
c      Determinant is a product of the diagonal elements along L.
c
         det = det * a(k,k)
c
c      Now compute a row of U.  The first row of U is computed 
c  differently from the rest.
c
         if (k .eq. 1) then
           do 190 j=2,n
             a(1,j) = a(1,j) / a(1,1)
190        continue
         else
           do 210 j=k+1,n
             sum = a(k,j)
             do 200 i=1,k-1
               sum = sum - a(k,i) * a(i,j)
200          continue
             a(k,j) = sum / a(k,k)
210        continue
         endif
c
220    continue
c
c      Now for the last element of L.
c
       sum = a(n,n)
       do 230 j=1,n-1
         sum = sum - a(n,j) * a(j,n)
230    continue
       a(n,n) = sum
c
c      LU decomposition is now complete.  Include final factor in the 
c  determinant as well as compensation for even/odd permutations.
c
       det = det * a(n,n) * pm1
c
c      We now start the solution phase.  Since the equations may have 
c  been interchanged, interchange the elements of b the same way, 
c  putting the result into x.
c
       do 240 i=1,n
         x(i) = b(order(i))
240    continue
c
c      Perform forward substitution.  This puts the values of z (see 
c  equation (2) in the subroutine header) into the array x.  Note the 
c  division by the diagonal element of "a" that we were worried about in 
c  the row swapping segment above.
c
       x(1) = x(1) / a(1,1)
       do 260 i=2,n
         sum = x(i)
         do 250 k=1,i-1
           sum = sum - a(i,k) * x(k)
250      continue
         x(i) = sum / a(i,i)
260    continue
c
c      Perform backward substitution.  This puts the values of x (see 
c  equation (3) in the subroutine header) into the array x.
c
       do 280 i=1,n-1
         sum = x(n-i)
         do 270 k=n-i+1,n
           sum = sum - a(n-i,k) * x(k)
270      continue
         x(n-i) = sum
280    continue
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-------------0----+----1----+----2----+----3----+----4----+----5----+--
c
2010   format('LUSOLVE : |---ERROR---> Input array has no inverse.  '
     1       ,'Abort!')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               L U S O L V E               \\\\\\\\\\
c
c=======================================================================
c
