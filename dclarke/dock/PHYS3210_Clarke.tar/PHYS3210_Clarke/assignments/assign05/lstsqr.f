c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                L S T S Q R                \\\\\\\\\\
c
c=======================================================================
c
       program lstsqr
c
c    abcd:lstsqr <------------------------- performs a least-squares fit
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program performs a least squares fit of the input data
c  to a polynomial of the specified order.
c
c  The data to be fit need to be in a datafile with the following 
c  format:
c
c    x(1)   y(1)
c    x(2)   y(2)
c     :      :
c     :      :
c    x(N)   y(N)
c
c  where x are the independent variables, and y the corresponding 
c  dependent variables.
c
c  The data for problem 4 are in "infile".
c
c  The graph of the data along with the linear, quadratic, and cubic 
c  best fits is in "lstsqr.ps".
c
c  The best linear fit (determined with this program) is:
c
c    yl(t) = 2.4345 - 1.2995 t,
c
c  the best quadratic fit is:
c
c    yq(t) = 1.6541 + 3.9026 t - 5.2021 t**2
c
c  while the best cubic fit is
c
c    yc(t) = 1.6471 + 4.0148 t - 5.4963 t**2 + 0.1961 t**3.
c
c  The aggregate errors for the three fits are:
c
c    linear: 2.8410; quadratic: 0.5191; cubic: 0.5189
c
c  The kinematic equation for height as a function of time is:
c
c    y(t) = y0 + v0 t - (g/2) t**2
c
c  Thus, from the best quadratic fit data, we have 
c
c    y0 = 1.65 m
c    v0 = 3.90 m/s
c    g  = 10.4 m/s/s
c
c  The original version of the subroutine LUSOLVE is due to DeVries' "A 
c  First Course in Computational Physics" (@1994, John Wiley), with 
c  corrections made by DAC to the row-swapping portion of the routine.
c
c  EXTERNALS:
c    LUSOLVE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim    , nmax
       parameter     ( ndim=100, nmax=10000 )
c
       character*12  inname
       integer       n       , i       , j       , ndat    , iord
       real          cpubeg  , cpuend  , cputot     
       real*8        det     , err     , pofx    , merr
c
       real*8        x       (nmax), y       (nmax)
       real*8        c       (ndim), b       (ndim)
c
       real*8        a       (ndim,ndim), xp      (nmax,ndim)
c
       external      lusolve    
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Ask user for the name of the file containing the data to be fit
c  and the order of the polynomial fit to be made.
c
       write (6,2010)
       read  (5,   *) inname
10     continue
       write (6,2020)
       read  (5,   *) iord
       if (iord .gt. ndim-1) then
         write (6,2030) ndim-1
         go to 10
       endif
c
c      Open specified input file.
c
       open ( unit=10, file=inname, status='old' )
c
c      Read the data.
c
       do 20 n=1,ndim
         read (10,*,end=30) x(n), y(n)
20     continue
30     continue
       ndat = n - 1
c
c      Compute powers of x(n)
c
       do 50 n=1,ndat
         xp(n,1) = 1.0d0
         do 40 i=2,iord+1
           xp(n,i) = x(n)**(i-1)
40       continue
50     continue
c
c      Compute matrix elements for a
c
       a(1,1) = ndat
       do 70 j=2,iord+1
         a(1,j) = 0.0d0
         do 60 n=1,ndat
           a(1,j) = a(1,j) + xp(n,j)
60       continue
70     continue
       do 100 i=2,iord+1
         do 80 j=1,iord
           a(i,j) = a(i-1,j+1)
80       continue
         a(i,iord+1) = 0.0d0
         do 90 n=1,ndat
           a(i,iord+1) = a(i,iord+1) + xp(n,iord+1) * xp(n,i)
90       continue
100    continue
c
c      Compute vector elements for b
c
       do 120 i=1,iord+1
         b(i) = 0.0d0
         do 110 n=1,ndat
           b(i) = b(i) + y(n) * xp(n,i)
110      continue
120    continue
c
c      Solve the equation a |c> = |b> for |c>, which will be the 
c  coefficients for the best-fit polynomial of order iord.
c
       call lusolve ( a, c, b, det, ndim, iord+1 )
c
c      Compute the least-squares error.
c
       err = 0.0d0
       do 140 n=1,ndat
         pofx = 0.0d0
         do 130 i=1,iord+1
           pofx = pofx + c(i) * xp(n,i)
130      continue
         err = err + ( pofx - y(n) )**2
140    continue
       merr = sqrt ( err / ndat )
c
c      Report results.
c
       write (6,2040) err, merr
       do 150 i=1,iord+1
         write (6,2050) i, c(i)
150    continue
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2060) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('LSTSQR  : Enter the name of the input file (12 '
     1       ,'characters or less):')
2020   format('LSTSQR  : Enter the order of polynomial to be fit '
     1       ,'(integer):')
2030   format('LSTSQR  : Order of polynomial must be no larger than '
     1       ,i3,'.  Try again.')
2040   format('LSTSQR  : least squares accumulated error = ',g12.5,/
     1       ,'LSTSQR  : mean error (size of error bars) = ',g12.5,/
     2       ,'LSTSQR  :',/
     3       ,'LSTSQR  : The coefficients for the polynomial '
     4       ,'sum[c(i)*x**(i-1)] are:')
2050   format('LSTSQR  : c(',i3,') = ',1pg22.15)
2060   format('LSTSQR  :',/
     1       ,'LSTSQR  : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                L S T S Q R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               L U S O L V E               \\\\\\\\\\
c
c=======================================================================
c
       subroutine lusolve ( a, x, b, det, ndim, n )
c
c    abcd:linalg.lusolve <---------------------------- L-U decomposition
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1: June, 2018 by ABCD; replaced Devries' flawed row 
c                swapping scheme; see header of linalgo.lusolve (old 
c                version) for discussion.
c
c  PURPOSE:  This routine solves the linear set of equations
c
c                          A |x> = |b>                              (1)
c
c  by the method of lower-upper triangular decomposition of the matrix A
c  (from Crout).  Any matrix A can be written as a product of a lower 
c  and upper triangular matrix (L and U): A = LU.  In this case,
c
c                        L U |x> = |b>.
c
c  Let:
c                          U |x> = |z>.                             (2)
c
c  Then:
c                          L |z> = |b>.                             (3)
c
c  Equation (3) is easy to solve by "forward substitution".  Once |z> is
c  known, it is used in equation (2), which is then solved for |x> by 
c  "backward substitution".
c
c  The trick is then to find L and U, given A.  This is the primary 
c  purpose of this subroutine.
c
c  From Paul L. DeVries' "A First Course in Computational Physics" 
c  (@1994, John Wiley).
c
c  INPUT VARIABLES:
c    a          the n by n array to be decomposed
c    b          the n-ket representing the RHS of the equation
c    ndim       dimension of arrays, as declared in the calling routine
c    n          actual size of arrays; n .le. ndim
c
c  OUTPUT VARIABLES:
c    det        determinant of array a
c    x          the n-ket of unknowns
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim    , n       , i       , j       , k
     1             , eye     , ordi    , swap
       real*8        det     , prod    , sum     , pm1
c
       integer       order   (ndim), tmpord  (ndim)
       real*8        x       (ndim), b       (ndim)
c
       real*8        a       (ndim,ndim), p       (ndim,ndim)
     1             , pt      (ndim,ndim)
c
c-----------------------------------------------------------------------
c
       det = 1.0d0
       pm1 = 1.0d0
       do 1 i=1,ndim
         order(i) = 0
1      continue
c
c      A major wrinkle to the algorithm discussed in class is what to do 
c  should a zero be on the diagonal.  Note that computing rows of U 
c  requires division by a diagonal element of A.  A degree of freedom we 
c  can exploit is that it does not matter which order the equations are 
c  in.  This means we can swap rows of A so that no diagonal element is 
c  zero without worrying about whether this changes the solution.  BTW,
c  if it is not possible to arrange the rows so that no diagonal element 
c  is zero, this will mean det(A) = 0 => A has no inverse => there is no
c  solution to this system of equations.  Thus, so long as the system of 
c  equations is soluble, we can rearrange the rows so that no diagonal 
c  element of A is zero.
c
c  First, we need to see if there is even a problem.
c
       prod = 1.0d0
       do 10 i=1,n
         prod = prod * a(i,i)
10     continue
c
       if (prod .ne. 0.0d0) then
c
c      No element along A as given is zero, and there is no need to swap 
c  rows.  Set "order" to the current order of the rows, and move 
c  directly to the LU decomposition.
c
         do 20 i=1,n
           order(i) = i
20       continue
c
       else
c
c- | -- | -- | -- | -------------------------------- | -- | -- | -- | --
c \|/  \|/  \|/  \|/   DAC'S ROW SWAPPING ALGORITM  \|/  \|/  \|/  \|/
c- v -- v -- v -- v -------------------------------- v -- v -- v -- v --
c
c      At least one element along the diagonal is zero.  Start by 
c  defining a "permutation array", P, whose element in row i, column j 
c  tells us if row j (yes, j) of matrix A *could* be moved to row i; 
c  that is, its ith element is not zero.  We'll do this by setting 
c  P(i,j) = 0 if A(j,i) = 0, or P(i,j) = j if A(j,i) .ne. 0.
c
         do 40 j=1,n
           do 30 i=1,n
             p(i,j) = j
             if (a(j,i) .eq. 0) p(i,j) = 0
30         continue
40       continue
c
c      Now we'll use P to determine which permutation of the rows will 
c  move all zeroes away from the diagonal.  Note that we don't need to 
c  know all the permutations that'll do this; just one will do fine!
c
         i = 1
50       continue
c
c      If row counter "i" exceeds "n", we've found a permutation that
c  works.  Move on to LU decomposition after permuting the rows of "a".
c
         if (i .gt. n) go to 100
c
c      If we arrive here, we've still not found a complete permutation 
c  to rid the diagonal of zeroes.  Start by loading a temporary 
c  permutation array.
c
         do 60 j=1,n
           pt(i,j) = p(i,j)
60       continue
c
c      Set values of "pt" already used in "order" to zero (so they won't 
c  be used again).
c
         do 70 eye=1,i-1
           pt(i,order(eye)) = 0
70       continue
80       continue
c
c      Set order for row "i" to first non-zero value in row "i" of "pt".
c
         do 90 j=1,n
           if (pt(i,j) .ne. 0) then
             order(i) = pt(i,j)
             i = i + 1
             go to 50
           endif
90       continue
c
c      If execution gets here, there were no non-zero values in row "i" 
c  of "pt".  This means this line of permutations has reached a dead-
c  end.  Further, if this dead-end was discovered on row 1, there is no 
c  permutation to keep zeros off the diagonal, and there is therefore no 
c  solution.  Inform the user of the ill-defined problem, and exit.
c
         i = i - 1
         if (i .lt. 1) then
           write (6, 2010)
           stop
         endif
c
c      If there are still rows to return to, go back up one row, 
c  eliminate the current value of "order" from that row of "pt", and 
c  resume search.
c
         pt(i,order(i)) = 0
         go to 80
c
100      continue
c
c      Now that a suitable permutation of the rows of "a" has been 
c  found, rearrange the matrix accordingly.  For this, we'll need a 
c  temporary array which can be "pt" since we are now finished wth it.
c  Assignment of "tmpord" at the end of loop 140 is to prepare for the 
c  following segment in loop 160.
c
         do 120 i=1,n
           do 110 j=1,n
             pt(i,j) = a(order(i),j)
110        continue
120      continue
         do 140 i=1,n
           do 130 j=1,n
             a(i,j) = pt(i,j)
130        continue
           tmpord(i) = order(i)
140      continue
c
c      To get the sign of the determinant right, determine whether the 
c  permutation chosen is even (+1) or odd (-1).  This segment determines 
c  the number of transpositions required to create the permutation 
c  found, the parity of which determines the parity of the permutation. 
c
         swap = 0
150      continue
         do 160 i=1,n
           ordi = tmpord(i)
           if (ordi .ne. i) then
             tmpord   (i) = tmpord(ordi)
             tmpord(ordi) = ordi
             swap         = swap + 1
             go to 150
           endif
160      continue
         if (2*(swap/2) .ne. swap) pm1 =-1.0d0
c
c- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ -- ^ --
c /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  /|\  
c- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | --
c
       endif
c
c      Start the LU decomposition.  The original matrix A will be 
c  overwritten by the elements of L and U as they are determined since 
c  those elements of A are never needed again.  This saves having to 
c  declare two additional arrays L and U.  Note further that A can 
c  accommodate the non-zero unknown elements (those not equal to 1) of 
c  both L and U simultaneously.
c      The first row and column are specially treated, as is L(n,n).
c
       do 220 k=1,n-1
c
c      Do a column of L.
c
         if (k .ge. 2) then
c
c      Compute elements of L.
c
           do 180 i=k,n
             sum = a(i,k)
             do 170 j=1,k-1
               sum = sum - a(i,j) * a(j,k)
170          continue
             a(i,k) = sum
180        continue
         endif
c
c      Determinant is a product of the diagonal elements along L.
c
         det = det * a(k,k)
c
c      Now compute a row of U.  The first row of U is computed 
c  differently from the rest.
c
         if (k .eq. 1) then
           do 190 j=2,n
             a(1,j) = a(1,j) / a(1,1)
190        continue
         else
           do 210 j=k+1,n
             sum = a(k,j)
             do 200 i=1,k-1
               sum = sum - a(k,i) * a(i,j)
200          continue
             a(k,j) = sum / a(k,k)
210        continue
         endif
c
220    continue
c
c      Now for the last element of L.
c
       sum = a(n,n)
       do 230 j=1,n-1
         sum = sum - a(n,j) * a(j,n)
230    continue
       a(n,n) = sum
c
c      LU decomposition is now complete.  Include final factor in the 
c  determinant as well as compensation for even/odd permutations.
c
       det = det * a(n,n) * pm1
c
c      We now start the solution phase.  Since the equations may have 
c  been interchanged, interchange the elements of b the same way, 
c  putting the result into x.
c
       do 240 i=1,n
         x(i) = b(order(i))
240    continue
c
c      Perform forward substitution.  This puts the values of z (see 
c  equation (2) in the subroutine header) into the array x.  Note the 
c  division by the diagonal element of "a" that we were worried about in 
c  the row swapping segment above.
c
       x(1) = x(1) / a(1,1)
       do 260 i=2,n
         sum = x(i)
         do 250 k=1,i-1
           sum = sum - a(i,k) * x(k)
250      continue
         x(i) = sum / a(i,i)
260    continue
c
c      Perform backward substitution.  This puts the values of x (see 
c  equation (3) in the subroutine header) into the array x.
c
       do 280 i=1,n-1
         sum = x(n-i)
         do 270 k=n-i+1,n
           sum = sum - a(n-i,k) * x(k)
270      continue
         x(n-i) = sum
280    continue
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-------------0----+----1----+----2----+----3----+----4----+----5----+--
c
2010   format('LUSOLVE : |---ERROR---> Input array has no inverse.  '
     1       ,'Abort!')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               L U S O L V E               \\\\\\\\\\
c
c=======================================================================
