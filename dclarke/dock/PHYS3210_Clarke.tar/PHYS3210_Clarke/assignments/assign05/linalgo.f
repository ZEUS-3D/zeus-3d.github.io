c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////               L I N A L G O               \\\\\\\\\\
c
c=======================================================================
c
       program linalgo
c
c    abcd:linalgo <------- solves a system of linear algebraic equations
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1:
c
c***********************************************************************
c  THIS PROGRAM IS FLAWED AND RENAMED LINALGO; SEE COMMENT IN LUSOLVE.
c                 SEE LINALG FOR CORRECTED ALGORITHM.
c                                                        DAC, June, 2018
c***********************************************************************
c
c  PURPOSE:  This program finds the unique solution to a system of 
c  linear algebraic equations, provided it exists, using a lower-upper 
c  triangular decomposition algorithm for solving the matrix equation 
c  (LUSOLVE).  Given a system of linear equations:
c
c                         A |x> = |b>
c
c  the user will be asked to provide the number of equations (n, an 
c  integer), and the name of a file (no more than 12 characters) that 
c  contains A and |b> in the following format:
c
c  A11 A12 ... A1n
c  A21 A22 ... A2n
c   :   :       :
c  An1 An2 ... Ann
c   b1  b2 ...  bn
c
c  where each line is separated by a carriage return, and where each of 
c  Aij and bi can be integer, real, or double precision.
c
c  Solutions |x> are written to "linalgo.dat".
c
c  The data for a problem of 3 equations in 3 unknowns are in "test01".
c      3x +  y -  z = 2   |
c       x -  y + 2z = 1   |  =>  x=2/5, y=11/5, z=7/5
c      5x - 2y +  z =-1   |
c
c  The data for the "mad professor's circuit" are in "circuit01".
c
c  For ill-conditioned (Hilbert) matrices, see linalg2.f.
c
c  With minor modifications, the coding for the subroutine LUSOLVE is 
c  due to DeVries' "A First Course in Computational Physics" (@1994, 
c  John Wiley).
c
c  EXTERNALS:
c    LUSOLVE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim
       parameter     ( ndim=100 )
c
       character*12  inname
       integer       n       , i       , j
       real          cpubeg  , cpuend  , cputot  
       real*8        det
c
       real*8        x       (ndim), b       (ndim)
c
       real*8        a       (ndim,ndim)
c
       external      lusolve
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Ask user for the number of equations to be solved, and the name 
c  of the file containing the matrix A followed by the bra <b|.
c
       write (6, 2010)
       read  (5,    *) n
       write (6, 2020)
       read  (5,    *) inname
c
c      Open specified input file as well as an output file.
c
       open ( unit=10, file=inname, status='old', err=30 )
       open ( unit=11, file='linalgo.dat', status='unknown' )
c
c      Read matrix A.
c
       do 10 i=1,n
         read (10,*,err=40) (a(i,j),j=1,n)
10     continue
c
c      Read bra <b|.
c
       read (10,*,err=50) (b(i),i=1,n)
c
c      Solve.
c
       call lusolve ( a, x, b, det, ndim, n )
c
c      Report results.
c
       write (6 ,2030) det
       write (11,2030) det
       do 20 i=1,n
         write (6 ,2040) i, x(i)
         write (11,2040) i, x(i)
20     continue
       go to 60
c
c      Whoops!  Problem reading file inname.  Aborts!
c
30     continue
       write (6,2050) inname
       go to 60
c
c      Whoops!  Problem reading data into array a.  Aborts!
c
40     continue
       write (6,2060) i, j
       go to 60
c
c      Whoops!  Problem reading data into ket |b>.  Aborts!
c
50     continue
       write (6,2070) i
60     continue
c
c      Close data files.
c
       close (10)
       close (11)
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2080) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('LINALGO : Enter the number of equations to be solved '
     1       ,'(integer):')
2020   format('LINALGO : Enter the name of the input file (12 '
     1       ,'characters or less):')
2030   format('LINALGO : RESULTS FROM DOUBLE PRECISION CALCULATION:',/
     1       ,'LINALGO :',/
     2       ,'LINALGO : det(A) = ',1pg22.15,/
     3       ,'LINALGO : The values of the n variables in |x> are:')
2040   format('LINALGO : x(',i3,') = ',1pg22.15)
2050   format('LINALGO : Whoops!  Problem reading file ',a12
     1       ,'.  Aborts!')
2060   format('LINALGO : Whoops!  Problem reading data into array '
     1       ,'element A(',i3,',',i3,').  Aborts!')
2070   format('LINALGO : Whoops!  Problem reading data into vector '
     1       ,'element b(',i3,').  Aborts!')
2080   format('LINALGO :',/
     1       ,'LINALGO : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                L I N A L G                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               L U S O L V E               \\\\\\\\\\
c
c=======================================================================
c
       subroutine lusolve ( a, x, b, det, ndim, n )
c
c    abcd:linalgo.lusolve <-------------------- L-U decomposition method
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1:
c
c***********************************************************************
c  This version of LUSOLVE by Paul Devries is flawed.  The portion 
c  attributed to Crout is fine; it's the portion Devries added to 
c  swap rows to make sure that no zeroes appear along the diagonal (to 
c  avoid zero divides) that can create problems.  In his design, the 
c  swapping algorithm is embedded within the LU decomposition and, as a 
c  consequence, when numerous swaps are being done, rows can get swapped 
c  out before they take part in the decomposition (or added in again for 
c  another turn).  His idea is based on a false pretence that one can 
c  always arrange for the largest element in a given row to sit on the 
c  diagonal; this is simply untrue.
c
c  An example of a linear algebra problem Devries algorithm works fine 
c  on is:
c       _             _           _    _                _   _
c      | 3.0  1.0 -1.0 |         |  2.0 |              | 0.4 |
c  A = | 1.0 -1.0  2.0 |   |b> = |  1.0 |   =>   |x> = | 2.2 | ,
c      |_5.0 -2.0  1.0_|         |_-1.0_|              |_1.4_|
c
c  with det(A) = 15, all correct.  Conversely, for
c       _                       _           _       _ 
c      |  3.00    0.8415  0.8415 |         | -0.9597 |
c  A = |  8.00   -1250.0  2.00   |   |b> = |  620.0  | ,
c      |_-0.3679 -0.3679 20.00  _|         |_-29.37 _|
c
c  Devries' algorithm gets:
c         _         _
c        | -1410361. |
c  |x> = | -1126.35  |  with det(A) = -12.907,
c        |_-14.4193 _|
c
c  where the correct answer is:
c         _        _
c        |  0.23270 |
c  |x> = | -0.49687 |  with det(A) = -75522.5.
c        |_-1.47325_|
c
c  Note that Devrie's algorithm gets the second problem correctly when 
c  his swapping portion is bypassed, which isn't needed for this problem 
c  anyway because A has no zeroes.
c
c  I have designed a much better row swapping mechanism in the version 
c  of LUSOLVE in program linalg.f which gets both problems above 
c  correctly.
c***********************************************************************
c
c  PURPOSE:  This routine solves the linear set of equations
c
c                          A |x> = |b>                              (1)
c
c  by the method of lower-upper triangular decomposition of the matrix A
c  (from Crout).  Any matrix A can be written as a product of a lower 
c  and upper triangular matrix (L and U): A = LU.  In this case,
c
c                        L U |x> = |b>.
c
c  Let:
c                          U |x> = |z>.                             (2)
c
c  Then:
c                          L |z> = |b>.                             (3)
c
c  Equation (3) is easy to solve by "forward substitution".  Once |z> is
c  known, it is used in equation (2), which is then solved for |x> by 
c  "backward substitution".
c
c  The trick is then to find L and U, given A.  This is the primary 
c  purpose of this subroutine.
c
c  From Paul L. DeVries' "A First Course in Computational Physics" 
c  (@1994, John Wiley).
c
c  INPUT VARIABLES:
c    a          the n by n array to be decomposed
c    b          the n-ket representing the RHS of the equation
c    ndim       dimension of arrays, as declared in the calling routine
c    n          actual size of arrays; n .le. ndim
c
c  OUTPUT VARIABLES:
c    det        determinant of array a
c    x          the n-ket of unknowns
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax
       parameter     ( nmax = 100 )
c
       integer       ndim    , n       , i       , j       , k
     1             , imax    , itemp
       real*8        det     , amax    , amax0   , sum     , dtemp   
c
       integer       order   (nmax)
       real*8        x       (ndim), b       (ndim), scale   (nmax)
c
       real*8        a       (ndim,ndim)
c
c-----------------------------------------------------------------------
c
c      Stop if input array is too large.  Otherwise, initialise 
c  variables.
c
       if (n .gt. nmax) then
         write(6,2010) n, nmax
         stop
       endif
       det = 1.0d0
c
c      First, determine a scaling factor for each row.  We could 
c  normalise the equation by multiplying by this factor.  However, since
c  we only want it for comparison purposes, we don't actually need to
c  scale the rows.
c
       do 20 i=1,n
         order(i) = i
         amax     = 0.0d0
         do 10 j=1,n
           amax = max ( amax, abs(a(i,j)) )
10       continue
         scale(i) = 1.0d0 / amax
20     continue
c
c      Start the LU decomposition.  The original matrix A will be 
c  overwritten by the elements of L and U as they are determined since 
c  those elements of A are never needed again.  This saves having to 
c  declare two additional arrays L and U.  Note further that A can 
c  accommodate the non-zero unknown elements (those not equal to 1) of 
c  both L and U simultaneously.
c      The first row and column are specially treated, as is L(n,n).
c
       do 100 k=1,n-1
c
c      Do a column of L.
c
         if (k .ge. 2) then
c
c      Compute elements of L.
c
           do 40 i=k,n
             sum = a(i,k)
             do 30 j=1,k-1
               sum = sum - a(i,j) * a(j,k)
30           continue
             a(i,k) = sum
40         continue
         endif
c
c      The main complication from the basic algorithm is that should a 
c  row include a zero along the main diagonal, at some point the
c  algorithm will attempt to divide by that zero.  To avoid this, 
c  DeVries' algorithm swaps rows so that the largest value along any row 
c  will lie along the diagonal.  If *that* is zero, then the entire row 
c  is made up of zeros, in which case there is no solution anyway.
c      Swapping rows further complicates the algorithm by having to keep 
c  track of what it does to the determinant as well as having to 
c  remember the swap so that the same swaps can be applied to ket |b> 
c  afterward.
c
c      Do we need to interchange rows?  We want the largest (scaled) 
c  element of the recently computed column of L moved to the diagonal 
c  (k,k) location.
c
         amax = 0.0d0
         do 50 i=k,n
           amax0 = scale(i)*a(i,k)
           if (amax0 .ge. amax) then
             amax = amax0
             imax = i
           endif
50       continue
c
c      Largest element is L(imax,k).  If imax=k, the largest (scaled) 
c  element is already on the diagonal.
c
         if (imax .ne. k) then
c
c      Exchange rows,
c
           det =-det
           do 60 j=1,n
             dtemp     = a(imax,j)
             a(imax,j) = a(k,j)
             a(k,j)    = dtemp
60         continue
c
c  scale factors,
c
           dtemp       = scale(imax)
           scale(imax) = scale(k)
           scale(k)    = dtemp
c
c  and record changes in the ordering.
c
           itemp       = order(imax)
           order(imax) = order(k)
           order(k)    = itemp
         endif
c
c      Compute determinant from the forming matrix L.
c
         det = det * a(k,k)
c
c      Now compute a row of U.  The first row of U is computed 
c  differently from the rest.
c
         if (k .eq. 1) then
           do 70 j=2,n
             a(1,j) = a(1,j) / a(1,1)
70         continue
         else
           do 90 j=k+1,n
             sum = a(k,j)
             do 80 i=1,k-1
               sum = sum - a(k,i) * a(i,j)
80           continue
             a(k,j) = sum / a(k,k)
90         continue
         endif
100    continue
c
c      Now for the last element of L.
c
       sum = a(n,n)
       do 110 j=1,n-1
         sum = sum - a(n,j) * a(j,n)
110    continue
       a(n,n) = sum
       det    = det * a(n,n)
c
c      LU decomposition is now complete.  In addition, the determinant 
c  has been calculated and stored in "det".
c
c      We now start the solution phase.  Since the equations have been 
c  interchanged, we interchange the elements of b the same way, putting 
c  the result into x.
c
       do 120 i=1,n
         x(i) = b(order(i))
120    continue
c
c      Perform forward substitution.  This puts the values of z (see 
c  equation (2) in the subroutine header) into the array x.
c
       x(1) = x(1) / a(1,1)
       do 140 i=2,n
         sum = x(i)
         do 130 k=1,i-1
           sum = sum - a(i,k) * x(k)
130      continue
         x(i) = sum / a(i,i)
140    continue
c
c      Perform backward substitution.  This puts the values of x (see 
c  equation (3) in the subroutine header) into the array x.
c
       do 160 i=1,n-1
         sum = x(n-i)
         do 150 k=n-i+1,n
           sum = sum - a(n-i,k) * x(k)
150      continue
         x(n-i) = sum
160    continue
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('LUSOLVE : Matrix size n = ', i3,' is too large.  Try '
     1       ,'again with n < ', i3,'.  Abort!')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               L U S O L V E               \\\\\\\\\\
c
c=======================================================================
c
