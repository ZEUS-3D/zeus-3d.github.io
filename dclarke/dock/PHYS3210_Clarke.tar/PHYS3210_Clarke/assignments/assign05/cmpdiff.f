c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////               C M P D I F F               \\\\\\\\\\
c
c=======================================================================
c
       program cmpdiff
c
c    abcd:cmpdiff <-------------- compares various differencing formulae
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program compres the forward, backward, and central 
c  difference formulae for estimating the derivative of a given 
c  function.
c
c  To make the gnuplot graph for the log-log plot of errors vs h for 
c  comparing the forward, backward, and central differencing (required 
c  for problem 1, assignment 5):
c
c  set logscale xy
c  plot "cmpdiff.dat" u 1:2 w lines, "cmpdiff.dat" u 1:3 w lines, "cmpdiff.dat" u 1:4 w lines
c
c  EXTERNALS:
c    FOFX
c    DFDX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       i
       real*8        logdx   , dx      , x0      , fdiff   , bdiff   
     1             , cdiff   , fprime  , ferr    , berr    , cerr
c
c      External Statements
c
       real*8        fofx    , dfdx
       external      fofx    , dfdx
c
c-----------------------------------------------------------------------
c
c      Open data file "cmpdiff.dat", and write header.
c
       open  ( 10, file='cmpdiff.dat', status='unknown' )
       write ( 10, 2010 )
c
c      Compute and tabulate errors for forward, backward, and central 
c  difference formulae for derivatives.
c
       x0 = 2.0d0
       do 10 i=1,11
         logdx  = dble(1-i) * 0.20d0
         dx     = 10.0d0**logdx
         fdiff  = ( fofx(x0+dx) - fofx(x0   ) ) / dx
         bdiff  = ( fofx(x0   ) - fofx(x0-dx) ) / dx
         cdiff  = ( fofx(x0+dx) - fofx(x0-dx) ) / ( 2.0d0 * dx )
         fprime = dfdx(x0)
         ferr   = abs ( fprime - fdiff )
         berr   = abs ( fprime - bdiff )
         cerr   = abs ( fprime - cdiff )
         write ( 10, 2020 ) dx, ferr, berr, cerr
10     continue
c
       close ( 10 )
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('#  Datafile containing errors of forward, backward, and '
     1       ,'central differencing',/
     1       ,'#  as a function of step size.',/,'#',/
     2       ,'#       dx               forward           backward'
     3       ,'            central',/,'#')
2020   format(1pg17.10,2x,g17.10,2x,g17.10,2x,g17.10)
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////               C M P D I F F               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  F O F X                  \\\\\\\\\\
c
c=======================================================================
c
       function fofx ( x )
c
c    abcd:cmpdiff.fofx <------------------------ evaluates test function
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function returns the functional value x*exp(x)
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    fofx       x*exp(x)
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x      , fofx
c
c-----------------------------------------------------------------------
c
       fofx = x * exp ( x )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  F O F X                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  D F D X                  \\\\\\\\\\
c
c=======================================================================
c
       function dfdx ( x )
c
c    abcd:cmpdiff.fofx <---------- evaluates derivative of test function
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function returns the functional value d[x*exp(x)]/dx
c
c  INPUT VARIABLES:
c    x          independent variable
c
c  OUTPUT VARIABLES:
c    dfdx       d[x*exp(x)]/dx
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x      , dfdx
c
c-----------------------------------------------------------------------
c
       dfdx = ( x + 1.0d0 ) * exp ( x )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  D F D X                  \\\\\\\\\\
c
c=======================================================================
