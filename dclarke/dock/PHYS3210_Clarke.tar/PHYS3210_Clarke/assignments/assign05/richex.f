c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                R I C H E X                \\\\\\\\\\
c
c=======================================================================
c
       program richex
c
c    abcd:richex <----------------------------- richardson extrapolation
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program performs a Richardson extrapolation to compute
c  the first and second derivatives of a the function described by fofx
c  using the three-point centre-difference formula for each whose formal
c  error falls off, to leading order, as h**2:
c
c            f(x+h) - f(x-h)                 f(x+h) - 2 f(x) + f(x-h)
c  f'(x)  =  ---------------,     f''(x)  =  ------------------------
c                  2h                                  h**2
c
c  When asked to enter x and h, typical choices are 2 and 0.4.
c
c  EXTERNALS:
c    RICHARD
c    DFDX
c    D2FDX2
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       iter
       real          cpubeg  , cpuend  , cputot     
       real*8        x       , dx     , rext    , err
c
       real*8        dfdx    , d2fdx2
       external      dfdx    , d2fdx2    
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Open datafile.
c
       open ( 10, file='richex.dat', status='unknown' )
c
c      Ask user for initial data.
c
       write (6 ,2010)
       read  (5 ,   *) x, dx
c
c      Richardson extrapolation for df/dx.
c
       write (6 ,2020) x
       write (10,2020) x
       call richard ( x, dx, dfdx, rext, err, iter )
       write (6 ,2030) rext, 100.d0*err, iter
       write (10,2030) rext, 100.d0*err, iter
c
c      Richardson extrapolation for d2f/dx2.
c
       write (6 ,2040) x
       write (10,2040) x
       call richard ( x, dx, d2fdx2, rext, err, iter )
       write (6 ,2050) rext, 100.d0*err, iter
       write (10,2050) rext, 100.d0*err, iter
c
c      Close data file.
c
       close (10)
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2060) cputot
c
c----------------------- Write format statements -----------------------
c
2010   format('RICHEX  : Enter x (where derivatives are evaluated) '
     1       ,'and h (initial step size):')
2020   format('RICHEX  :',/
     1       ,'RICHEX  : Richardson Extrapolation Table for dfdx   at '
     2       ,'x = ',1pg12.5,/,'RICHEX  :')
2030   format('RICHEX  : df/dx   = ',1pg17.10,' +/- ',g9.2,'% after '
     1       ,i2,' iterations.')
2040   format('RICHEX  :',/
     1       ,'RICHEX  : Richardson Extrapolation Table for d2fdx2 at '
     2       ,'x = ',1pg12.5,/,'RICHEX  :')
2050   format('RICHEX  : d2f/dx2 = ',1pg17.10,' +/- ',g9.2,'% after '
     1       ,i2,' iterations.')
2060   format('RICHEX  :',/
     1       ,'RICHEX  : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                R I C H E X                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               R I C H A R D               \\\\\\\\\\
c
c=======================================================================
c
       subroutine richard ( x, dx, func, rext, err, iter )
c
c    abcd:richext;richard <--------------- performs an r.e. on func at x
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This subroutine performs a Richardson extrapolation on the 
c  function func at x and generates an extrapolation table.
c
c  INPUT VARIABLES:
c    x        location where Richardson extrapolation is performed
c    dx       initial step size
c    func     function on which Richardson extrapolation is performed
c             (e.g., the three-point centred derivative and the
c             three-point centred second derivative functions)
c
c  OUTPUT VARIABLES:
c    rext     the value of the Richardson extrapolation of func(x)
c    err      estimate of the error on rext
c    iter     number of Richardson extrapolation iterations to achieve 
c             estimate: maximum nmax (rarely needs to be greater than 5)
c
c  LOCAL VARIABLES: 
c    old      previous row in extrapolation table for step size = 2h
c    new      current  row in extrapolation table for step size = h
c    base     = 4.0 for functions such as the 3-point centred derivative
c                   and second derivative for which the error term 
c                   contains only the even powers of h (h**2, h**4, etc)
c             = 2.0 for functions such as the 2-point forward and 
c                   backward differenced derivatives for which the error
c                   term contains all powers of h.
c    iquit    is set to 1 once the tolerance is reached or the number of
c             allowed iterations (imax) is exceeded 
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       imax
       real*8        tiny    , tol     , base
       parameter     (imax=5, tiny=1.0d-99, tol=1.0d-9, base=4.0d0)
c
       integer       iter    , iquit   , i       
       real*8        x       , dx      , func    , rext    , err
     1             , h       , fact    , anew
c
       real*8        old     (imax), new     (imax)
c
c-----------------------------------------------------------------------
c
       write (6 ,2010)
       write (10,2010)
       h     = dx
       iter  = 0
       iquit = 0
c
c      Initialise current row in extrapolation table.
c
       do 10 i=1,imax
         new(i) = 0.0d0
10     continue
c
c----- Top of extrapolation loop ---------------------------------------
c
20     continue
         iter   = iter + 1
         old(1) = new(1)
         new(1) = func(x,h)
         if (iter .ge. 2) then
           do 30 i=2,iter
             fact   = base**(i-1)
             old(i) = new(i)
             new(i) = ( fact * new(i-1) - old(i-1) ) / ( fact - 1.0d0 )
30         continue
c
c      Test to see if extrapolation is finished.
c
           err  = abs ( (new(iter) - new(iter-1)) / (new(iter) + tiny) )
           anew = abs ( new(iter) )
           if ( (err .le. tol) .or. (anew .le. tol) ) iquit = 1
           if ( (iquit .eq. 0) .and. (iter .eq. imax) ) then
             write (6 ,2020) imax
             write (10,2020) imax
             iquit = 1
           endif
         endif
c
c      Write new row of extrapolation table.  If extrapolation is to be
c  continued for another cycle, halve h and return to top of loop.
c
         write (6 ,2030) h, (new(i),i=1,iter)
         write (10,2030) h, (new(i),i=1,iter)
         if (iquit .eq. 0) then
           h = h / 2.0d0
           go to 20
         endif
       continue
c
c----- Bottom of extrapolation loop ------------------------------------
c
       rext = new(iter)
c
c----------------------- Write format statements -----------------------
c
2010   format('RICHARD :    h       D1              D2              '
     1       ,'D3              D4',/,'RICHARD :')
2020   format('RICHARD : Richardson extrapolation failed to converge '
     1       ,'after ',i2,' iterations.',/
     2       ,'RICHARD : Extrapolation terminated.')
2030   format('RICHARD : ',f6.4,1p5g16.10)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               R I C H A R D               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  D F D X                  \\\\\\\\\\
c
c=======================================================================
c
       function dfdx ( x, h )
c
c    abcd:richex;dfdx <---------------------- 3-point centred derivative
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function returns the value of the three-point centred 
c  derivative of the function fofx at x with step size h.
c
c  INPUT VARIABLES:
c    x        independent variable
c    h        step size (dx)
c
c  OUTPUT VARIABLES:
c    dfdx     value of 3-point centred derivative of fofx
c
c  EXTERNALS:
c    FOFX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , h       , dfdx
c
       real*8        fofx
       external      fofx
c
c-----------------------------------------------------------------------
c
       dfdx = ( fofx(x+h) - fofx(x-h) ) / ( 2.0d0 * h )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  D F D X                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                D 2 F D X 2                \\\\\\\\\\
c
c=======================================================================
c
       function d2fdx2 ( x, h )
c
c    abcd:richex;d2fdx2 <------------- 3-point centred second derivative
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function returns the value of the three-point centred 
c  second derivative of the function fofx at x with step size h.
c
c  INPUT VARIABLES:
c    x        independent variable
c    h        step size (dx)
c
c  OUTPUT VARIABLES:
c    d2fdx2   value of 3-point centred second derivative of fofx
c
c  EXTERNALS:
c    FOFX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , h       , d2fdx2
c
       real*8        fofx
       external      fofx
c
c-----------------------------------------------------------------------
c
       d2fdx2 = ( fofx(x+h) - 2.0d0*fofx(x) + fofx(x-h) ) / h**2
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                D 2 F D X 2                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  F O F X                  \\\\\\\\\\
c
c=======================================================================
c
       function fofx ( x )
c
c    abcd:richex;fofx <------------------- function being differentiated
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  Returns the value of the function whose first and second 
c  derivatives are being evaluated by Richardson extrapolation.
c
c  INPUT VARIABLES:
c    x        independent variable
c
c  OUTPUT VARIABLES:
c    fofx     dependent variable
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , fofx
c
c-----------------------------------------------------------------------
c
       fofx = x * exp(x)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  F O F X                  \\\\\\\\\\
c
c=======================================================================
