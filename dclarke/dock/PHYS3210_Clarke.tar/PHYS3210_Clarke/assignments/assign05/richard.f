c=======================================================================
c
       subroutine richard ( x, dx, func, rext, err, iter )
c
c    abcd:richext;richard <--------------- performs an r.e. on func at x
c                                                            april, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This subroutine performs a Richardson extrapolation on the 
c  function func at x and generates an extrapolation table.
c
c  INPUT VARIABLES:
c    x        location where Richardson extrapolation is performed
c    dx       initial step size
c    func     function on which Richardson extrapolation is performed
c             (e.g., the three-point centred derivative and the
c             three-point centred second derivative functions)
c
c  OUTPUT VARIABLES:
c    rext     the value of the Richardson extrapolation of func(x)
c    err      estimate of the error on rext
c    iter     number of Richardson extrapolation iterations to achieve 
c             estimate: maximum nmax (rarely needs to be greater than 5)
c
c  LOCAL VARIABLES: 
c    old      previous row in extrapolation table for step size = 2h
c    new      current  row in extrapolation table for step size = h
c    base     = 4.0 for functions such as the 3-point centred derivative
c                   and second derivative for which the error term 
c                   contains only the even powers of h (h**2, h**4, etc)
c             = 2.0 for functions such as the 2-point forward and 
c                   backward differenced derivatives for which the error
c                   term contains all powers of h.
c    iquit    is set to 1 once the tolerance is reached or the number of
c             allowed iterations (imax) is exceeded 
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       imax
       real*8        tiny    , tol     , base
       parameter     (imax=5, tiny=1.0d-99, tol=1.0d-9, base=4.0d0)
c
       integer       iter    , iquit   , i       
       real*8        x       , dx      , func    , rext    , err
     1             , h       , fact    , anew
c
       real*8        old     (imax), new     (imax)
c
c-----------------------------------------------------------------------
c
       write (6 ,2010)
       h     = dx
       iter  = 0
       iquit = 0
c
c      Initialise current row in extrapolation table.
c
       do 10 i=1,imax
         new(i) = 0.0d0
10     continue
c
c----- Top of extrapolation loop ---------------------------------------
c
20     continue
         iter   = iter + 1
         old(1) = new(1)
         new(1) = func(x,h)
         if (iter .ge. 2) then
           do 30 i=2,iter
c
c      "new(i)", where i=1,2,..., corresponds to D_{i-1} in the notes, 
c  where the index on D starts at 0.  This accounts for the power on 
c  "base" being 1 less than the index on "new". (In the notes, the power 
c  on "base" is the same as the index on D.)
c
             fact   = base**(i-1)
             old(i) = new(i)
             new(i) = ( fact * new(i-1) - old(i-1) ) / ( fact - 1.0d0 )
30         continue
c
c      Test to see if extrapolation is finished.
c
           err  = abs ( (new(iter) - new(iter-1)) / (new(iter) + tiny) )
           anew = abs ( new(iter) )
           if ( (err .le. tol) .or. (anew .le. tol) ) iquit = 1
           if ( (iquit .eq. 0) .and. (iter .eq. imax) ) then
             write (6 ,2020) imax
             iquit = 1
           endif
         endif
c
c      Write new row of extrapolation table.  If extrapolation is to be
c  continued for another cycle, halve h and return to top of loop.
c
         write (6 ,2030) h, (new(i),i=1,iter)
         if (iquit .eq. 0) then
           h = h / 2.0d0
           go to 20
         endif
       continue
c
c----- Bottom of extrapolation loop ------------------------------------
c
       rext = new(iter)
c
c----------------------- Write format statements -----------------------
c
2010   format('RICHARD :    h       D1              D2              '
     1       ,'D3              D4',/,'RICHARD :')
2020   format('RICHARD : Richardson extrapolation failed to converge '
     1       ,'after ',i2,' iterations.',/
     2       ,'RICHARD : Extrapolation terminated.')
2030   format('RICHARD : ',f6.4,1p5g16.10)
c
       return
       end
c
c=======================================================================
