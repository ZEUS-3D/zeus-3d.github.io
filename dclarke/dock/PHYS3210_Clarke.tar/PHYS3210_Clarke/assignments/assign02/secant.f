c======================== BEGIN PROGRAM SECANT =========================
c
       program secant
c
c    written by: A Busy Code Developer, January 2003
c    modified 1:
c
c  PURPOSE:  This program finds the root of the function described in 
c  FOFX that lies between the input bounds using the Secant method.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   ans
       integer       maxiter , iter
       real*8        maxerr  , small   , xnm1    , fxnm1   , xn      
     1             , fxn     , dfxn    , xnp1    , err     , ferr
       real          cpubeg  , cpuend  , cputot  
c
       real*8        fofx    
       external      fofx    
c
       data          maxiter , maxerr  , small
     1             / 100     , 5.0d-9  , 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
10     continue
c
c      Ask user for two guesses.  Guesses could but need not bracket the 
c  root; they just should not be separated from the root by an extremum.
c
       write(6, 2010)
       read (5,    *) xn, xnm1
       fxnm1 = fofx(xnm1)
c
c-----------------------------------------------------------------------
c----- Top of secant loop ----------------------------------------------
c-----------------------------------------------------------------------
c
       iter = 0
20     continue
         iter = iter + 1
c
c      Compute the secant.  Note the use of "small" to prevent possible 
c  zero-divides.
c
         fxn  = fofx(xn)
         dfxn = ( fxn - fxnm1 ) / ( ( xn - xnm1 ) + small )
c
c      Evaluate the next secant guess.  Note that if "dfxn" is within
c  "small" of zero, then the routine is in trouble since this means the
c  extrapolation line is essentially horizontal which will intersect the 
c  x-axis only at very large values of x.
c
         xnp1 = xn - fxn / ( dfxn + small )
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found.  Report value of root, and move on to next root.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         if ( ferr .le. maxerr ) then
           write(6, 2020) xnp1, err, iter
           go to 30
         endif
c
c      If the maximum number of iterations has been reached, report best 
c  value found and move on to next root.  It is always a good idea to 
c  provide an "escape route" should your program find itself in an 
c  infinite loop.
c
         if ( iter .ge. maxiter ) then
           write (6, 2030) maxiter, xnp1, err
           go to 30
         endif
c
c      Report iteration progress.
c
         write (6, 2040) iter, xnp1, err
c
c      Prepare for and go on to next iteration.
c
         xnm1  = xn
         xn    = xnp1
         fxnm1 = fxn
         go to 20
30     continue
c
c-----------------------------------------------------------------------
c----- Bottom of secant loop -------------------------------------------
c-----------------------------------------------------------------------
c
c      Ask user if another root is to be found.
c
       write (6, 2050)
       read  (5,    *) ans
       if ( (ans .ne. 'y') .and. (ans .ne. 'n') ) go to 30
       if (ans .eq. 'y') go to 10
c
c      End CPU time counter, and report cpu time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2060) cputot
c
       stop
c
c----------------------- Write format statements -----------------------
c
2010   format('SECANT  : Enter two initial guesses for the root.  '
     1       ,'There should be no extremum',/
     2       ,'SECANT  : between the guesses and the root.')
2020   format('SECANT  : Root = ',1pg22.15,' +/- ',g9.2
     1       ,' after ',i3,' iterations.')
2030   format('SECANT  : Maximum number of iterations ',i9
     1       ,' exceeded.',/
     2       ,'SECANT  : Best guess at root is ',1pg22.15
     3       ,' +/- ',g9.2,'.')
2040   format('SECANT  : At iteration ',i3,', root = ',1pg22.15
     1       ,' +/- ',g9.2)
2050   format('SECANT  : Do you wish to search for another root? '
     1       ,'(answer y or n)')
2060   format('SECANT  : Total cpu usage for this run is ',1pg12.5
     1       ,' seconds.')
c
c-----------------------------------------------------------------------
c
       end
c
c========================= END PROGRAM SECANT ==========================
c
c========================= BEGIN FUNCTION FOFX =========================
c
       function fofx ( x )
c
c    written by: A Busy Code Developer, January 2003
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of cos(x) - x.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , fofx
c
c-----------------------------------------------------------------------
c
       fofx = cos(x) - x
c
       return
       end
c
c========================== END FUNCTION FOFX ==========================
