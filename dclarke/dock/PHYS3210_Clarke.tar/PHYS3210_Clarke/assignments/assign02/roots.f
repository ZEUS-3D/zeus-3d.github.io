c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                 R O O T S                 \\\\\\\\\\
c
c=======================================================================
c
       program roots
c
c    abcd:roots <--------------------------- finds root(s) of a function
c                                                         February, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program finds the root(s) of a given function that 
c  lies between the input bounds.  The user can select from three root-
c  finding algorithms:
c
c      ialg=1 => bisection/Newton-Raphson 
c      ialg=2 => bisection/secant
c      ialg=3 => Muller-Brent
c
c  Some coding segments are due to DeVries' "A First Course in 
c  Computational Physics" (@1994, John Wiley).
c
c  Available function for root-finding include:
c
c      cos(x) - x
c      even square well solutions
c      odd square well solutions
c      h(x) (cosmic rays)
c      f(phi) (jump in velocity across MHD shock)
c
c  which are relevant to PHYS3210 assignment 2, plus a number of other 
c  functions I have added over the years simply because I wanted to know 
c  their roots!
c
c  To select the desired function, go to function fofx (last module) and
c  comment/decomment the appropriate entry.  The function dfdx is 
c  required by the Newton-Raphson method, and only the cos(x)-x function
c  has its derivative available.
c
c  To force the N-R and secant hybrid methods to use a bisection step 
c  for the cos(x) - x function, use the brackets:
c
c      (-1.5, 3.0).  
c
c  These brackets will not force the M-B hybrid method to invoke a 
c  bisection step.
c
c  Root for f(x) = cos(x) - x is:    0.73908513
c
c  Roots for finite square well (a = 2 A, V = 100 eV) are:
c      EVEN:  E = 1.9496867, 17.458991, 47.877646, 90.367541 eV
c      ODD:   E = 7.7846611, 30.881162, 68.081068 eV.
c
c  To install h(x) into the student's program, append HUX1.F to the 
c  program, and follow the instructions in the header of the file.
c
c  For h(x), all roots lie between 0.0 and 10.0:
c      0.58672451, 1.11226118, 1.55031334, 
c      3.78997753, 5.61248600, 6.32455024
c
c  To find the second (hard) root individually, use brackets 1.1 1.2
c     - 10 iterations secant (including 3 bisection steps)
c     - 8 iterations M-B (no bisections)
c
c  To find the sixth  (easy) root individually, use brackets 6.2 6.4
c     - 6 iterations secant (no bisections)
c     - 6 iterations M-B (no bisections)
c
c  with maxerr = 5.0d-9
c
c  EXTERNALS:
c    HINIT     |---- initialisation routines for functions
c    MHDCOEF   |
c    FSET
c    REPORT
c    FINDROOT
c    FOFX
c    DFDX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax
       parameter     (nmax=100000)
       character*1   exsrch  , ans
       integer       maxiter , ialg    , nroot   , i       , ip1     
     1             , ip2     , imax
       real          cpubeg  , cpuend  , cputot     
       real*8        xmin    , xmax    , xl      , xr      , dx
     1             , dxmin   , dfl     , df      , dfr     , maxerr
c
       real*8        f       (nmax), x       (nmax)
c
       real*8        fofx    , dfdx   
       external      hinit   , mhdcoef , fset    , report  , findroot
     1             , fofx    , dfdx   
c
       data          maxiter , maxerr
     1             / 30      , 5.0d-9 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Initialise variables for some of the available functions
c
c  HINIT     initialises variables for cosmic ray function, h(x).
c  MHDCOEF   computes coefficients for cubic MHD jump function, f(phi).
c
       call hinit
       call mhdcoef
       nroot = 0
c
c      Ask user if exhaustive searching is to be done.
c
10     continue
       write(6, 2010)
       read (5,    *) exsrch
       if ( (exsrch  .ne. 'n') .and. (exsrch  .ne. 'y') ) then
         write(6, 2020)
         go to 10
       endif
       if (exsrch .eq. 'n') write(6, 2030)
c
c      Ask user to select algorithm (see PURPOSE above for types). 
c
20     continue
       write(6, 2040)
       read (5,    *) ialg
       if ( (ialg  .lt. 1) .or. (ialg  .gt. 3) ) then
         write(6, 2050)
         go to 20
       endif
c
c      Ask for initial limits/guesses.
c
30     continue
       if (exsrch .eq. 'n') then
         write(6, 2060)
40       continue
         read (5,    *) xl, xr
         if (xl .ge. xr) then
           write(6, 2070)
           go to 40
         endif
       else
         write(6, 2080)
50       continue
         read (5,    *) xmin, xmax
         if (xmin .ge. xmax) then
           write(6, 2090)
           go to 50
         endif
       endif
c
       if (exsrch .eq. 'y') then 
c
c      Initialise arrays f and x for exhaustive searching.
c
         dx    = ( xmax - xmin ) / dble(nmax)
         dxmin = 0.01d0 * dx
         call fset ( xmin, xmax, dx, dxmin, fofx, x, f, nmax, imax )
c
c      Write a gnuplot file.
c
         open (10, file='fofx.txt', status='unknown')
         do 60 i=1,imax
           write(10,*) x(i), f(i)
60       continue
         close (10)
c
c      For exhaustive searching, find all the roots by scanning through 
c  the function f.  If the product of adjacent values of f is negative, 
c  this is the signature if a root.  However, the function can also 
c  change sign at an odd-order (1st, 3rd, etc.) singularity.  Thus, we 
c  also test the product of adjacent differences in f.  If this is 
c  negative, then the change in sign in f is caused by a singularity, 
c  not a root.
c
c      Note that osculating roots (e.g., where functions "kiss" the 
c  x-axis such as x=0 for f(x)=x**2) will not be detected using this 
c  criterion.  Osculating roots are more difficult to find, and require 
c  a routine that detects local extrema, then evaluates the function at 
c  each extremum.  This is beyond the scope of this program.
c
         dfl = 0.0d0
         df  = f(2) - f(1)
         do 70 i=1,imax-1
           ip1 = i + 1
           ip2 = min ( i+2, imax )
           dfr = f(ip2) - f(ip1)
           if (f(i) .eq. 0.0d0) call report ( x(i), nroot )
           if (f(i)*f(ip1) .lt. 0.0d0) then
             if ( (dfl*df .ge. 0.0d0) .or. (df*dfr .ge. 0.0d0) ) then
               call findroot ( ialg, x(i), x(ip1), fofx, dfdx, maxerr
     1                       , maxiter, nroot )
             else
c
c      An odd-order singularity has been found.  We'll not bother 
c  reporting these here.
c
             endif
           endif
           dfl = df
           df  = dfr
70       continue
         if (f(imax) .eq. 0.0d0) call report ( x(imax), nroot )
c
       else
c
c      For single root search, the input values of "xl" and "xr" are
c  used.
c
         call findroot ( ialg, xl, xr, fofx, dfdx, maxerr, maxiter
     1                 , nroot )
80       continue
         write (6, 2090)
         read  (5,    *) ans
         if ( (ans .ne. 'n') .and. (ans .ne. 'y') ) then
           write (6, 2020)
           go to 80
         endif
         if (ans .eq. 'y') go to 20
c
       endif
c
c      Report total number of roots found and cpu time consumed.
c
       write(6, 2100) nroot
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2110) cputot
c
       stop
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('ROOTS   : Do you want exhaustive searching performed '
     1        ,'(type y or n)?')
2020   format('ROOTS   : You must enter y or n.  Try again.')
2030   format('ROOTS   : Only the first root encountered will be '
     1       ,'reported.')
2040   format('ROOTS   : Select algorithm:  1 => '
     1       ,'bisection/Newton-Raphson hybrid',/
     2       ,'ROOTS   :',20x,'2 => bisection/secant hybrid',/
     3       ,'ROOTS   :',20x,'3 => Muller-Brent method')
2050   format('ROOTS   : You must enter 1--3 for the algorithm.')
2060   format('ROOTS   : Enter xL and xR such that f(xL)*f(xR) < 0.'  
     3       ,'  Thus, xL < root < xR.')
2070   format('ROOTS   : The second value must be greater than the '
     1       ,'first.  Try again.')
2080   format('ROOTS   : All roots between xmin and xmax will be '
     1       ,'found.  Enter xmin and xmax.')
2090   format('ROOTS   : Would you like to search for another root '
     1       ,'(type y or n)?')
2100   format('ROOTS   : Total number of roots found = ',i3,'.')
2110   format('ROOTS   :',/
     1       ,'ROOTS   : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                 R O O T S                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  F S E T                  \\\\\\\\\\
c
c=======================================================================
c
       subroutine fset ( xmin, xmax, dx, dxmin, fofx, x, f, nmax, imax )
c
c    abcd:roots.fset <-------- sets arrays x and f for exhaustive search
c                                                         february, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine evaluates the input function fofx for enough 
c  values of x that all features of interest (zeroes, extrema and 
c  singularities) are resolved to within value dxmin.  
c
c  The interval Dx is chosen such that the path length:
c
c              x+Dx
c      Dl = int    sqrt(1 + f'**2) dx
c              x
c
c  can be determined with sufficient accuracy from
c
c      Dl  =  Dx * sqrt(1 + f'**2)
c
c  and thus the function sqrt(1 + f'**2) is sufficiently constant (say 
c  to within 50%, set by parameter frac) within the interval Dx, or 
c  equivalently over the path length Dl.  This will ensure that the 
c  function isn't changing so rapidly that important features inside 
c  interval Dx will be missed.
c
c  INPUT VARIABLES:
c    xmin         minimum value at which function is evaluated.
c    xmax         maximum value at which function is evaluated.
c    dx           seed value for x-increment
c    dxmin        smallest tolerated value for dx
c    fofx         external function to be examined
c    nmax         dimension of f and x
c
c  OUTPUT VARIABLES:
c    x            array of independent values
c    f            array of dependent values
c    imax         number of points at which x and f were evaluated
c
c  EXTERNALS:
c    FOFX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        fmax
       parameter     ( fmax=0.5 )
c
       integer       nmax    , imax    , i       , nfnc    
       real*8        xmin    , xmax    , dx      , dxmin   , xl      
     1             , xr      , xh      , fxl     , fxr     , fxh
     2             , dxh     , scale   , dfdx    , dldx    , dfdxh   
     3             , dldxh   , ferr    
c
       real*8        f       (nmax), x       (nmax)
c
c      External statements.
c
       real*8        fofx
       external      fofx
c
c-----------------------------------------------------------------------
c
c      Set left-most values of x and f.  "nfnc" keeps track of the 
c  number of function calls.
c
       i    = 1
       x(i) = xmin
       f(i) = fofx(xmin)
       nfnc = 1
       xl   = x(i)
       fxl  = f(i)
c
c----- TOP OF LOOP -----------------------------------------------------
c
10     continue
       i    = i + 1
       if (i .gt. nmax) then
         write (6, 2010) xmin, xmax, xr, dxmin, nmax
         stop
       endif
       dx   = min ( dx, xmax - xl )
       xr   = xl + dx
       fxr  = fofx(xr)
       nfnc = nfnc + 1     
c
c      Compute the secant (dfdx) using dx as the run, then compute 
c  dldx, the ratio of path length dl to dx.  Halve dx, then repeat 
c  calculations to get dldxh.  If dldx and dldxh differ by less than 
c  10%, then a larger dx can be used next time.  If dldx and dldxh 
c  differ by more than 50%, dx must be halved and a new comparison must 
c  be made until dldx and dldxh differ by less than 50%.  If dldx and 
c  dldxh differ by more than 10% but less than 50%, the current value of
c  dx is used to advance x and compute the next value of f.  In no case 
c  shall dx be allowed to become less than dxmin, and if dx ever reaches
c  dxmin, this is a sign that important structure in the function may be
c  unresolved (e.g., singularities, rapid oscillations, etc.).
c
c      NB: multiplying the derivative by "xl/fxl" "normalises" it.
c
       scale = max ( 1.0d0, abs(xl) ) / max ( abs(fxr), abs(fxl) )
       dfdx  = scale * ( fxr - fxl ) / dx 
       dldx  = sign ( 1.0d0, dfdx  ) * sqrt ( 1.0d0 + dfdx **2 )
20     continue
       dxh   = 0.5d0 * dx
       xh    = xl + dxh
       fxh   = fofx(xh)
       nfnc  = nfnc + 1
       dfdxh = scale * ( fxh - fxl ) / dxh
       dldxh = sign ( 1.0d0, dfdxh ) * sqrt ( 1.0d0 + dfdxh**2 )
       ferr  = abs ( ( dldx - dldxh ) / dldx )
       if (ferr .lt. 0.2d0*fmax) dx = 1.5d0 * dx
       if (ferr .gt.       fmax) then
         if (dxh .ge. dxmin) then
           dx   = dxh
           xr   = xh
           fxr  = fxh
           dldx = dldxh
           go to 20
         else
           dx   = dxmin
           xr   = xl + dx
           fxr  = fofx(xr)
           nfnc = nfnc + 1
           write (6, 2020) i, xl, xr
         endif
       endif
       x(i) = xr
       f(i) = fxr
       if (xr .ge. xmax) then
         imax = i
         write (6, 2030) nfnc, imax
         return
       endif
       xl   = xr
       fxl  = fxr
       go to 10
c
c----- BOTTOM OF LOOP --------------------------------------------------
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('FSET    : Unable to fill domain (xmin, xmax) = ('
     1       ,1pg9.2,', ',g9.2,').  Maximum',/
     2       ,'FSET    : value reached for x =',g9.2,'.  Either '
     3       ,'increase dxmin from current',/
     4       ,'FSET    : value of ',g9.2,', or increase nmax from '
     5       ,'current value of ',i6,'.')
2020   format('FSET    : ***WARNING*** dx set to dxmin in interval '
     1       ,'i = ',i6,', and',/
     1       ,'FSET    : (xl, xr) = (',1pg15.8,', ',g15.8,').')
2030   format('FSET    : Completed with ',i6,' function calls setting '
     1       ,i6,' data points.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  F S E T                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                R E P O R T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine report ( root, nroot )
c
c    abcd:roots.report <---------- reports root found by calling routine
c                                                         february, 2006
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  In the event that the calling routine happens upon a root 
c  itself, it is simply reported by this routine.
c
c  INPUT VARIABLES:
c    root         location of root found by calling routine 
c
c  OUTPUT VARIABLES:
c    nroot        running total of roots found
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nroot   
       real*8        root   
c
c-----------------------------------------------------------------------
c
c      Report the root found.
c
       nroot = nroot + 1
       write(6, 2010) nroot, root
c
       return
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('REPORT  : Root ',i3,' = ',1pg22.15,' to within machine '
     1       ,'round-off error.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                R E P O R T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              F I N D R O O T              \\\\\\\\\\
c
c=======================================================================
c
       subroutine findroot ( ialg, xl, xr, fofx, dfdx, maxerr, maxiter
     1                     , nroot )
c
c    abcd:roots.findroot <-------- finds root using one of three methods
c                                                         february, 2003
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program finds and reports the root between the input 
c  bounds, xl and xr.  Three root-finding algorithms are available.
c
c  INPUT VARIABLES:
c    ialg         1 => bisection/Newton-Raphson 
c                 2 => bisection/secant
c                 3 => Muller-Brent
c    xl, xr       left and right brackets for root.
c    fofx         external function for which root is to be found
c    dfdx         derivative of fofx (for Newton-Raphson method)
c    maxerr       maximum error tolerance
c    maxiter      maximum number of iterations to find root
c
c  OUTPUT VARIABLES:
c    nroot        running total of roots found
c
c  EXTERNALS:
c    BINRPH
c    BISCNT
c    BIMULB
c    FOFX
c    DFDX
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ialg    , maxiter , iter    , nroot   
       real*8        xl      , xr      , root    , maxerr  , err   
c
       real*8        fofx    , dfdx   
       external      fofx    , dfdx   
c
c-----------------------------------------------------------------------
c
c      Find the root using the method indicated by "ialg".  If "xl" and
c  "xr" don't contain a unique root, "iter" is returned as -1. 
c  Otherwise, "iter" is the number of iterations the routine took to 
c  converge on the root.
c
c      ialg=1 => bisection/Newton-Raphson hybrid.
c      ialg=2 => bisection/secant hybrid.
c      ialg=3 => Muller-Brent hybrid.
c
       if (ialg .eq. 1) 
     1   call binrph ( xl, xr, root, fofx, dfdx, maxerr, maxiter, err
     2               , iter )
c
       if (ialg .eq. 2)
     1   call biscnt ( xl, xr, root, fofx, maxerr, maxiter, err, iter )
c
       if (ialg .eq. 3)
     1   call mulbrt ( xl, xr, root, fofx, maxerr, maxiter, err, iter )
c
c      Report the root found or nearly found.
c
       if (iter .gt. 0) then
         nroot = nroot + 1
         if (iter .lt. maxiter) write(6, 2010) nroot, root, err, iter
         if (iter .eq. maxiter) write(6, 2020) maxiter, nroot, root, err
       endif
c
       return
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('FINDROOT: Root ',i3,' = ',1pg22.15,' +/- ',g9.2,' after '
     1       ,i3,' iterations.')
2020   format('FINDROOT: Maximum number of iterations ',i9,' exceeded.'
     1       ,/
     2       ,'FINDROOT: Best guess at root ',i3,' = ',1pg22.15,' +/- '
     3       ,g9.2,'.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              F I N D R O O T              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                B I N R P H                \\\\\\\\\\
c
c=======================================================================
c
       subroutine binrph ( xl, xr, xn, f, fprime, maxerr, maxiter, err
     1                   , iter )
c
c    abcd:roots.binrph <---------------- bisection/newton-raphson hybrid
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the hybrid bisection/Newton-Raphson
c  method to find the root of the function f whose derivative is fprime.
c
c  INPUT VARIABLES:
c    xl           value of x known to be less    than the root
c    xr           value of x known to be greater than the root
c    f            external function for which root is being sought.
c    fprime       df/dx
c    maxerr       error tolerance for root
c    maxiter      maximum number of iterations to find root
c
c  OUTPUT VARIABLES:
c    xn           returned as the root when the improvement over the
c                 previous iteration is less than the input value of 
c                 "maxerr".
c    err          estimated absolute error of xn.
c    iter         number of iterations to converge onto the final root 
c                 estimate xn; set to -1 if the root is not bracketed by
c                 input values "xl" and "xr".
c
c  EXTERNALS:
c    F
c    FPRIME
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       iter    , maxiter
       real*8        xl      , xr      , xn      , xnp1    , fxl
     1             , fxr     , fxn     , dfxn    , err     , ferr
     2             , maxerr  , small
       real*8        f       , fprime
c
       data          small   
     1             / 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       iter = 0
       fxl  = f(xl)
       fxr  = f(xr)
c
c      Data validation:  Make sure root lies in between the left- and 
c  right-hand value.  If not, return iter=0 to the calling routine.
c
       if (fxl*fxr .gt. 0.0d0) then
         write (6, 2010) xl, xr
         return
       endif
c
c      Starting values for "xn", "fxn", and "dfxn".
c
       if (abs(fxl) .lt. abs(fxr)) then
         xn  = xl
         fxn = fxl
       else
         xn  = xr
         fxn = fxr
       endif
       dfxn = fprime(xn)
c
c-----------------------------------------------------------------------
c----- Top of hybrid loop. ---------------------------------------------
c-----------------------------------------------------------------------
c
10     continue
         iter = iter + 1
c
c      Evaluate the next Newton-Raphson guess for the root (xnp1).
c
         xnp1 = xn - fxn / ( dfxn + small )
c
c      A bisection step is taken if a NR step is not justified.  Report
c  to the user the interim value of the root and which algorithm is
c  used.
c
         if ( (xl .lt. xnp1) .and. (xnp1 .lt. xr) ) then
           write (6, 2020) iter, xnp1
         else
           xnp1 = 0.5d0 * ( xl + xr )
           write (6, 2030) iter, xnp1
         endif
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found and execution is returned to the calling routine.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         xn   = xnp1
         if ( ferr .le. maxerr ) return
c
c      If the maximum number of iterations has been reached, return to 
c  the calling routine.
c
         if ( iter .ge. maxiter ) return
c
c      Prepare for next iteration.
c
         fxn  = f     (xn)
         dfxn = fprime(xn)
c
c      Determine which half of the interval (xl,xr) the root is in, and 
c  reset either xr or xl as appropriate.
c
         if ( fxl * fxn .le. 0.0d0 ) then
           xr  = xn
           fxr = fxn
         else
           xl  = xn
           fxl = fxn
         endif
c
c      Go on to the next iteration.
c
         go to 10
20     continue
c
c-----------------------------------------------------------------------
c----- Bottom of hybrid loop. ------------------------------------------
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('BINRPH  : No unique root lies between the specified'
     1       ,' limits:',/
     2       ,'BINRPH  : xl = ', 1pg12.5,', and xr = ',g12.5)
2020   format('BINRPH  : At iteration: ',i3,' (NEWTON/RAPHSON), root ='
     1       ,1pg22.15)
2030   format('BINRPH  : At iteration: ',i3,' (BISECTION),      root ='
     1       ,1pg22.15)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                B I N R P H                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                B I S C N T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine biscnt ( xl, xr, xn, f, maxerr, maxiter, err, iter )
c
c    abcd:roots.biscnt <------------------------ bisection/secant hybrid
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the hybrid bisection/secant method to
c  find the root of a function.
c
c  INPUT VARIABLES:
c    xl           value of x known to be less    than the root
c    xr           value of x known to be greater than the root
c    f            external function for which root is being sought.
c    maxerr       error tolerance for root
c    maxiter      maximum number of iterations to find root
c
c  OUTPUT VARIABLES:
c    xn           returned as the root when the improvement over the
c                 previous iteration is less than the input value of 
c                 "maxerr".
c    err          estimated absolute error of xn.
c    iter         number of iterations to converge onto the final root 
c                 estimate xn; set to -1 if the root is not bracketed by
c                 input values "xl" and "xr".
c
c  EXTERNALS:
c    F
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       iter    , maxiter
       real*8        xl      , xr      , xnm1    , xn      , xnp1
     1             , fxl     , fxr     , fxnm1   , fxn     , dfxn
     2             , err     , ferr    , maxerr  , small
       real*8        f       
c
       data          small   
     1             / 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       iter = 0
       fxl  = f(xl)
       fxr  = f(xr)
c
c      Data validation:  Make sure root lies in between the left- and 
c  right-hand value.  If not, return iter=0 to the calling routine.
c
       if (fxl*fxr .gt. 0.0d0) then
         write (6, 2010) xl, xr
         return
       endif
c
c      Starting values for "xn", "xnm1", "fxn", and "fxnm1".
c
       if (abs(fxl) .lt. abs(fxr)) then
         xn    = xl
         xnm1  = xr
         fxn   = fxl
         fxnm1 = fxr
       else
         xn    = xr
         xnm1  = xl
         fxn   = fxr
         fxnm1 = fxl
       endif
c
c-----------------------------------------------------------------------
c----- Top of hybrid loop. ---------------------------------------------
c-----------------------------------------------------------------------
c
10     continue
         iter = iter + 1
c
c      Compute the secant (dfxn) from current and previous guesses.
c
         dfxn = ( fxn - fxnm1 ) / ( xn - xnm1 )
c
c      Evaluate the next secant guess for the root (xnp1).
c
         xnp1 = xn - fxn / ( dfxn + small )
c
c      A bisection step is taken if a secant step is not justified.  
c  Report to the user the interim value of the root and which algorithm 
c  is used.
c
         if ( (xl .lt. xnp1) .and. (xnp1 .lt. xr) ) then
           write (6, 2020) iter, xnp1
         else
           xnp1 = 0.5d0 * ( xl + xr )
           write (6, 2030) iter, xnp1
         endif
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found and execution is returned to the calling routine.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         xnm1 = xn
         xn   = xnp1
         if ( ferr .le. maxerr ) return
c
c      If the maximum number of iterations has been reached, return to 
c  the calling routine.
c
         if ( iter .ge. maxiter ) return
c
c      Prepare for next iteration.
c
         fxnm1 = fxn
         fxn   = f(xn)
c
c      Determine which half of the interval (xl,xr) the root is in, and 
c  reset either xr or xl as appropriate.
c
         if ( fxl * fxn .le. 0.0d0 ) then
           xr  = xn
           fxr = fxn
         else
           xl  = xn
           fxl = fxn
         endif
c
c      Go on to the next iteration.
c
         go to 10
20     continue
c
c-----------------------------------------------------------------------
c----- Bottom of hybrid loop. ------------------------------------------
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('BISCNT  : No unique root lies between the specified'
     1       ,' limits:',/
     2       ,'BISCNT  : xl = ', 1pg12.5,', and xr = ',g12.5)
2020   format('BISCNT  : At iteration: ',i3,' (SECANT),    root ='
     1       ,1pg22.15)
2030   format('BISCNT  : At iteration: ',i3,' (BISECTION), root ='
     1       ,1pg22.15)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                B I S C N T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                M U L B R T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine mulbrt ( xl, xr, xn, f, maxerr, maxiter, err, iter )
c
c    abcd:roots.mulbrt <---------------------------- muller-brent method
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the Muller-Brent method to find the 
c  root of a function.
c
c  INPUT VARIABLES:
c    xl           value of x known to be less    than the root
c    xr           value of x known to be greater than the root
c    f            external function for which root is being sought.
c    maxerr       error tolerance for root
c    maxiter      maximum number of iterations to find root
c
c  OUTPUT VARIABLES:
c    xn           returned as the root when the improvement over the
c                 previous iteration is less than the input value of 
c                 "maxerr".
c    err          estimated absolute error of xn.
c    iter         number of iterations to converge onto the final root 
c                 estimate xn; set to -1 if the root is not bracketed by
c                 input values "xl" and "xr".
c
c  EXTERNALS:
c    F
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       iter    , maxiter
       real*8        xl      , xr      , xnm2    , xnm1    , xn
     1             , xnp1    , fxl     , fxr     , fxnm2   , fxnm1   
     2             , fxn     , dx12    , dx02    , dx01    , df02    
     3             , df12    , deni    , aa      , bb      , cc      
     4             , err     , ferr    , maxerr  , small
       real*8        f       
c
       data          small   
     1             / 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       iter = 0
       fxl  = f(xl)
       fxr  = f(xr)
c
c      Data validation:  Make sure root lies in between the left- and 
c  right-hand value.  If not, return iter=0 to the calling routine.
c
       if (fxl*fxr .gt. 0.0d0) then
         write (6, 2010) xl, xr
         return
       endif
c
c      Starting values for "xnm2", "xnm1", "xn", "fxnm2", "fxnm1", and 
c  "fxn".
c
         xnm2  = xr
         xnm1  = xl
         xn    = 0.5d0 * ( xl + xr )
         fxnm2 = fxr
         fxnm1 = fxl
         fxn   = f(xn)
c
c-----------------------------------------------------------------------
c----- Top of hybrid loop. ---------------------------------------------
c-----------------------------------------------------------------------
c
10     continue
         iter = iter + 1
c
c      Evaluate the next Muller guess for the root (xnp1).
c
         dx12 = xnm1 - xn
         dx02 = xnm2 - xn
         dx01 = xnm2 - xnm1
         df02 = dx12 * ( fxnm2 - fxn )
         df12 = dx02 * ( fxnm1 - fxn )
         deni = 1.0d0 / ( dx12 * dx02 * dx01 + small )
         aa   = (        df02 -        df12 ) * deni
         bb   = ( dx02 * df12 - dx12 * df02 ) * deni
         cc   = fxn
         xnp1 = xn - 2.0d0*cc / ( bb + sign ( 1.0d0, bb ) 
     1                               * sqrt ( bb**2 - 4.0d0*aa*cc ) )
c
c      A bisection step is taken if a Muller step is not justified.  
c  Report to the user the interim value of the root and which algorithm 
c  is used.
c
         if ( (xnp1 .gt. xl-0.1d0) .and. (xnp1 .lt. xr+0.1d0) ) then
           write (6, 2020) iter, xnp1
         else
           xnp1 = 0.5d0 * ( xl + xr )
           write (6, 2030) iter, xnp1
         endif
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found and execution is returned to the calling routine.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         xnm2 = xnm1
         xnm1 = xn
         xn   = xnp1
         if ( ferr .le. maxerr ) return
c
c      If the maximum number of iterations has been reached, return to 
c  the calling routine.
c
         if ( iter .ge. maxiter ) return
c
c      Prepare for next iteration.
c
         fxnm2 = fxnm1
         fxnm1 = fxn
         fxn   = f(xn)
c
c      Determine which half of the interval (xl,xr) the root is in, and 
c  reset either xr or xl as appropriate.
c
         if ( fxl * fxn .le. 0.0d0 ) then
           xr  = xn
           fxr = fxn
         else
           xl  = xn
           fxl = fxn
         endif
c
c      Go on to the next iteration.
c
         go to 10
20     continue
c
c-----------------------------------------------------------------------
c----- Bottom of hybrid loop. ------------------------------------------
c-----------------------------------------------------------------------
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('MULBRT  : No unique root lies between the specified'
     1       ,' limits:',/
     2       ,'MULBRT  : xl = ', 1pg12.5,', and xr = ',g12.5)
2020   format('MULBRT  : At iteration: ',i3,' (MULLER),       root ='
     1       ,1pg22.15)
2030   format('MULBRT  : At iteration: ',i3,' (BISECTION),    root ='
     1       ,1pg22.15)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                M U L B R T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                 E V E N 1                 \\\\\\\\\\
c
c=======================================================================
c
       function even1 ( E )
c
c    abcd:roots.even1 <-------------------- even solution to square-well
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of
c
c    f(E) = xi * tan (xi) - sqrt ( eta**2 - xi**2 )
c
c  where xi = sqrt(2 m E) a / hbar, eta = sqrt(2 m V0) a / hbar, and 
c  where a is the width of the square well, V0 its depth.  Roots to 
c  this equation are eigenvalues for the even wave functions of the 
c  square well problem.
c
c  For m = 1.0 m_e, V0 = 100 eV, and a = 2 Angtroms, there are four
c  roots to the even function:
c
c    E = 1.9496867, 17.458991, 47.877646, and 90.367541 eV
c
c  to eight significant figures.
c
c  INPUT VARIABLES:
c    E            value of independent variable (in eV)
c
c  OUTPUT VARIABLES:
c    even1        value of f(E).
c
c  LOCAL VARIABLES:
c    mass         in units of electron masses
c    V0           depth of potential well in eV
c    a            half-width of potential well in Angstroms (A)
c    const        = ( A * sqrt ( 2 * me * eV ) ) / hbar
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        even1   , E       , mass    , V0      , a       
     1             , const   , Elim    , eta     , xi
c
       parameter     ( mass=1.0d0, V0=100.0d0, a=2.0d0
     1               , const=0.512316585d0 )
c
c-----------------------------------------------------------------------
c
       Elim  = min ( V0, max ( E, 0.0d0 ) )
       eta   = sqrt ( mass * V0   ) * a * const
       xi    = sqrt ( mass * Elim ) * a * const
       even1 = xi * tan (xi) - sqrt ( eta**2 - xi**2 )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                 E V E N 1                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                 E V E N 2                 \\\\\\\\\\
c
c=======================================================================
c
       function even2 ( E )
c
c    abcd:roots.even2 <-------------------- even solution to square-well
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of
c
c    f(E) = xi * sin (xi) - sqrt ( eta**2 - xi**2 ) * cos(xi)
c
c  where xi = sqrt(2 m E) a / hbar, eta = sqrt(2 m V0) a / hbar, and 
c  where a is the width of the square well, V0 its depth.  Roots to 
c  this equation are eigenvalues for the even wave functions of the 
c  square well problem.
c
c  This function differs from EVEN1 by a factor of cos(xi), which 
c  eliminates the poles in the function with tan(xi), and introduces no 
c  extraneous roots.
c
c  For m = 1.0 m_e, V0 = 100 eV, and a = 2 Angtroms, there are four
c  roots to the even function:
c
c    E = 1.9496867, 17.458991, 47.877646, and 90.367541 eV
c
c  to eight significant figures.
c
c  INPUT VARIABLES:
c    E            value of independent variable (in eV)
c
c  OUTPUT VARIABLES:
c    even2        value of f(E).
c
c  LOCAL VARIABLES:
c    mass         in units of electron masses
c    V0           depth of potential well in eV
c    a            half-width of potential well in Angstroms (A)
c    const        = ( A * sqrt ( 2 * me * eV ) ) / hbar
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        even2   , E       , mass    , V0      , a       
     1             , const   , Elim    , eta     , xi
c
       parameter     ( mass=1.0d0, V0=100.0d0, a=2.0d0
     1               , const=0.512316585d0 )
c
c-----------------------------------------------------------------------
c
       Elim  = min ( V0, max ( E, 0.0d0 ) )
       eta   = sqrt ( mass * V0   ) * a * const
       xi    = sqrt ( mass * Elim ) * a * const
       even2 = xi * sin (xi) - sqrt ( eta**2 - xi**2 ) * cos(xi)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                 E V E N 2                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  O D D 1                  \\\\\\\\\\
c
c=======================================================================
c
       function odd1 ( E )
c
c    abcd:roots.odd1 <---------------------- odd solution to square-well
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of
c
c    f(E) = xi * cot (xi) + sqrt ( eta**2 - xi**2 )
c
c  where xi = sqrt(2 m E) a / hbar, eta = sqrt(2 m V0) a / hbar, and 
c  where a is the width of the square well, V0 its depth.  Roots to 
c  this equation are eigenvalues for the odd wave functions of the 
c  square well problem.
c
c  For m = 1.0 m_e, V0 = 100 eV, and a = 2 Angtroms, there are three
c  roots to the even function:
c
c    E = 7.7846611, 30.881162, and 68.081068 eV.
c
c  to eight significant figures.
c
c  INPUT VARIABLES:
c    E            value of independent variable (in eV)
c
c  OUTPUT VARIABLES:
c    odd1         value of f(E).
c
c  LOCAL VARIABLES:
c    mass         in units of electron masses
c    V0           depth of potential well in eV
c    a            half-width of potential well in Angstroms (A)
c    const        = ( A * sqrt ( 2 * me * eV ) ) / hbar
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        odd1    , E       , mass    , V0      , a       
     1             , const   , Elim    , eta     , xi
c
       parameter     ( mass=1.0d0, V0=100.0d0, a=2.0d0
     1               , const=0.512316585d0 )
c
c-----------------------------------------------------------------------
c
       Elim = min ( V0, max ( E, 0.0d0 ) )
       eta  = sqrt ( mass * V0   ) * a * const
       xi   = sqrt ( mass * Elim ) * a * const
       if (xi .eq. 0.0d0) then
         odd1 = 1.0d0 + eta
       else
         odd1 = xi / tan (xi) + sqrt ( eta**2 - xi**2 )
       endif
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  O D D 1                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  O D D 2                  \\\\\\\\\\
c
c=======================================================================
c
       function odd2 ( E )
c
c    abcd:roots.odd2 <---------------------- odd solution to square-well
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of
c
c    f(E) = xi * cos (xi) + sqrt ( eta**2 - xi**2 ) * sin(xi)
c
c  where xi = sqrt(2 m E) a / hbar, eta = sqrt(2 m V0) a / hbar, and 
c  where a is the width of the square well, V0 its depth.  Roots to 
c  this equation are eigenvalues for the odd wave functions of the 
c  square well problem.
c
c  This function differs from ODD1 by a factor of sin(xi), which 
c  eliminates the poles in the function with cot(xi), but introduces an 
c  extraneous root at xi=0.  This root is avoided by limiting E to 
c  epsilon over 0.
c
c  For m = 1.0 m_e, V0 = 100 eV, and a = 2 Angtroms, there are three
c  roots to the even function:
c
c    E = 7.7846611, 30.881162, and 68.081068 eV.
c
c  to eight significant figures.
c
c  INPUT VARIABLES:
c    E            value of independent variable (in eV)
c
c  OUTPUT VARIABLES:
c    odd2         value of f(E).
c
c  LOCAL VARIABLES:
c    mass         in units of electron masses
c    V0           depth of potential well in eV
c    a            half-width of potential well in Angstroms (A)
c    const        = ( A * sqrt ( 2 * me * eV ) ) / hbar
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        odd2    , E       , mass    , V0      , a       
     1             , const   , Elim    , eta     , xi      , small
c
       parameter     ( mass=1.0d0, V0=100.0d0, a=2.0d0
     1               , const=0.512316585d0, small=1.0d-20 )
c
c-----------------------------------------------------------------------
c
       Elim = min ( V0, max ( E, V0*small ) )
       eta  = sqrt ( mass * V0   ) * a * const
       xi   = sqrt ( mass * Elim ) * a * const
       odd2 = xi * cos (xi) + sqrt ( eta**2 - xi**2 ) * sin(xi)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  O D D 2                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  H U X 1                  \\\\\\\\\\
c
c=======================================================================
c
       function hux1 ( ux )
c
c    dac:crmhd.hux1 <----------------------------------- computes h(ux1)
c                                                           august, 1996
c
c    written by: David Clarke
c    modified 1: July, 2010 by DAC, updated.
c    modified 2: February, 2011 by DAC; version with in-line functions.
c
c  PURPOSE: Computes the CR-MHD 1-D shock jump conditions; suitable for 
c  use in root-finding programs written for assignment 2 of PHYS3210.
c
c  To engage this routine, it is necessary to replace the line in 
c  function fofx (or whatever the student has called this function)
c  that sets fofx with:
c
c       fofx = hux1(x)
c
c  In addition, the initialisation routine HINIT (included in this file) 
c  must be appended as well, and the first line of the main program 
c  should be:
c
c       call hinit
c
c  A single precision version of this routine (CRAY) exists in the 
c  program PLOTIT which can be used to generate publication quality 
c  plots.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        hux1    , ux      , ux2     , uy      , uy2     
     1             , q1      , fux2    , fuy     , eff     , gee     
c
       real*8        gammag  , gammac  , gamg    , gamc    , ii
     1             , jjx     , jjy     , kkx     , kky     , ll
     2             , mm      , small
       common      / comvar /
     1               gammag  , gammac  , gamg    , gamc    , ii
     2             , jjx     , jjy     , kkx     , kky     , ll
     3             , mm      , small
c
c      Statement functions.  Order is important: FORTRAN syntax requires 
c  statement functions (often incorrectly referred to as "in-line 
c  functions") to be declared before they are used, even by another 
c  statement function.
c
       fuy (ux   ) = ( kkx * kky + jjy * ux ) / ( ii * ux - kkx**2 )
c
       eff (ux,uy) = 0.5d0 * ii * ( ux**2 + uy**2 ) 
     1             + gamg * ll * ux * ( ii / ( ux + small ) )**gammag
     2             + kky * ( kky + kkx * uy ) / ( ux + small )
c
       gee (ux,uy) = ii * ux + ll * ( ii / ( ux + small ) )**gammag
     1             + 0.5d0 * ( kky + kkx * uy )**2 / ( ux + small )**2
c
       fux2(ux,uy) = ( eff(ux,uy) - mm ) / ( gee(ux,uy) - jjx ) / gamc
c
c-----------------------------------------------------------------------
c
       uy   = fuy (ux    )
       ux2  = fux2(ux ,uy)
       uy2  = fuy (ux2   )
       q1   = kky + uy2 * kkx 
       hux1 = ux2**3 * ii * ( 0.5d0 - gamg )
     1      + ux2**2 * gamg * gee(ux,uy) 
     2      + ux2    * ( 0.5d0 * ii * uy2**2 - eff(ux,uy) ) 
     3      +          q1 * ( kky - 0.5d0 * gamg * q1 )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  H U X 1                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 H I N I T                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine hinit
c
c    dac:crmhd.hinit <--------------------initialises variables for hux1
c                                                             march 2003
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE: This routine initialises variables for HUX1.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        dd0     , dux0    , duy0    , dpg0    , dpc0
     1             , dbx0    , dby0
c
       real*8        gammag  , gammac  , gamg    , gamc    , ii
     1             , jjx     , jjy     , kkx     , kky     , ll
     2             , mm      , small
       common      / comvar /
     1               gammag  , gammac  , gamg    , gamc    , ii
     2             , jjx     , jjy     , kkx     , kky     , ll
     3             , mm      , small
c
       data          small    / 1.0d-49 /
c
c-----------------------------------------------------------------------
c
c  dux0 = 5.6125 is a Mach 3 flow (as in the PDC paper (defunct)).
c
       dd0    = 1.0d0
       dux0   = 5.612486d0
       duy0   = 0.0d0
       dpg0   = 1.0d0
       dpc0   = 1.0d0
       dbx0   = sqrt(1.5d0)
       dby0   = sqrt(0.5d0)
c
       gammag = 5.0d0 / 3.0d0
       gammac = 4.0d0 / 3.0d0
       gamg   = gammag / ( gammag - 1.0d0 )
       gamc   = gammac / ( gammac - 1.0d0 )
c
       ii     = dd0 * dux0
       jjx    = ii * dux0 + dpg0 + dpc0 + 0.5d0 * dby0**2
       jjy    = ii * duy0 - dbx0 * dby0
       kkx    = dbx0
       kky    = dux0 * dby0 - duy0 * dbx0
       ll     = dpg0 * dd0**(-gammag)
       mm     = 0.5d0 * ii * ( dux0**2 + duy0**2 )
     1        + dux0 * ( gamg * dpg0 + gamc * dpc0 ) + dby0 * kky
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 H I N I T                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               M H D C O E F               \\\\\\\\\\
c
c=======================================================================
c
       subroutine mhdcoef
c
c    dac:roots.mhdcoef <---------------- cubic coefficients for mhd jump
c                                                              june 2015
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE: This routine initialises the polynomial coefficients for the 
c  cubic polynomial evaluated in MHDJUMP.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        gamma   , gamm2   , gamm1   , gamp1   , m1      
     1             , alphax  , alphay  , m1sq    , ax1sq   , ay1sq
     1             , m1sqi   , ax1sqi  , ay1sqi  , hh
c
       real*8        a0      , a1      , a2
       common      / mhdcom   /
     1               a0      , a1      , a2
c
c-----------------------------------------------------------------------
c
c      Adiabatic index.
c
       gamma = 5.0d0 / 3.0d0
       gamm2 = gamma - 2.0d0
       gamm1 = gamma - 1.0d0
       gamp1 = gamma + 1.0d0
c
c      Set upwind Mach number and MHD alphas.  For zero Bx and/or By, 
c  "alphax" and/or "alphay" --> infty.  In this case, set "alphax" and/
c  or "alphay" to zero, and they will be interpreted as infty (since
c  zero makes no sense anyway).
c
       m1     = 10.0d0
       alphax = 5.0d0 / 3.0d0
       alphay = 5.0d0 / 12.0d0
c
c      Compute squares of Mach and Alfven numbers, then compute their 
c  reciprocals.
c
       m1sq   = m1**2
       ax1sq  = m1sq * alphax
       ay1sq  = m1sq * alphay
       m1sqi  = 1.0d0 / m1sq
       ax1sqi = 0.0d0
       ay1sqi = 0.0d0
       if (alphax .gt. 0.0d0) ax1sqi = 1.0d0 / ax1sq
       if (alphay .gt. 0.0d0) ay1sqi = 1.0d0 / ay1sq
c
c      Evaluate hydrodynamical term along with polynomial coefficients.
c
       hh = ( gamm1 + 2.0d0 * m1sqi ) / gamp1
c
       a2 =-hh - 2.0d0 * ax1sqi - gamma * ay1sqi / gamp1
       a1 = ax1sqi * ( 2.0d0 * hh + ax1sqi + ay1sqi )
     1    + ay1sqi * gamm2 / gamp1
       a0 =-ax1sqi * ( hh * ax1sqi + ay1sqi * gamm1 / gamp1 )
c
       write (6, 2010) a0, a1, a2
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('MHDCOEF : a0, a1, a2 = ',1p3g18.10)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               M H D C O E F               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////               M H D J U M P               \\\\\\\\\\
c
c=======================================================================
c
       function mhdjump ( phi )
c
c    abcd:roots.mhdjump <------------ velocity jump across 1-D MHD shock
c                                                             june, 2015
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of the velocity jump across 
c  a general 1-D MHD shock described by equation (5.106) in the MHD 
c  text.
c
c  For the full problem, see ASTR5700/programs/mhdjump
c
c  INPUT VARIABLES:
c    phi         value of independent variable (vx_2/vx_1)
c
c  OUTPUT VARIABLES:
c    mhdjump     value of function described by equation 5.106.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        mhdjump , phi 
c
       real*8        a0      , a1      , a2
       common      / mhdcom   /
     1               a0      , a1      , a2
c
c-----------------------------------------------------------------------
c
       mhdjump = phi**3 + a2 * phi**2 + a1 * phi + a0
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////               M H D J U M P               \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                 B O N D I                 \\\\\\\\\\
c
c=======================================================================
c
       function bondi ( v )
c
c    abcd:roots.bondi <---------------- returns value of bondi function
c                                                           march, 2004
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of the spherically symmetric
c  Bondi function, namely:
c                     _          g-1    _
c      v^2   2    1  |  /   L   \        |
c      --- - - + --- |  | ----- |    - 1 | - RHS
c       2    x   g-1 |_ \ x^2 v /       _|
c
c  where 
c    g   = gamma (ratio of specific heats)
c    L   = lambda (the dimensionless accretion parameter and the Mach 
c          number (1) at the critical point)
c    RHS = L^2/2 - 2 if L .ge. 1, and 0.5 - 2/sqrt(L) if L .lt. 1.
c
c  INPUT VARIABLES:
c    v            value of independent variable (dimensionless velocity)
c
c  OUTPUT VARIABLES:
c    bondi        value of the bondi function.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        bondi   , v       , x       , gamma   , gamm1
       real*8        rhs     , lambda  , small
c
       data          small   , x       , gamma   , lambda
     1               / 1.0d-8, 0.25987d0, 1.4d0, 2.0d0 /
c
c-----------------------------------------------------------------------
c
       gamm1 = gamma - 1.0d0
       if (lambda .le. 1.0d0) then
         rhs = 0.5d0 * lambda**2 - 2.0d0
       else
         rhs = 0.5d0 - 2.0d0 / sqrt(lambda)
       endif
       if (gamma .ge. 5.0d0/3.0d0) rhs = rhs + small
       bondi = 0.5d0 * v**2 - 2.0d0 / x - rhs
     1       + ( ( lambda / (v*x**2) )**gamm1 - 1.0d0 ) / gamm1
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                 B O N D I                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  A L F A                  \\\\\\\\\\
c
c=======================================================================
c
       function alfa ( zeta )
c
c    abcd:roots.alfa <-------------- returns value of mhd-alpha function
c                                                         december, 2013
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of quartic in "zeta" (square 
c  root of the actual MHD alpha) stemming from problem 8 in chapter 5 of 
c  the MHD text.
c
c  INPUT VARIABLES:
c    zeta        value of independent variable
c
c  OUTPUT VARIABLES:
c    alfa        value of the mhd-alpha function.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
       real*8        a1      , a2      , a3      , a4      , a5
       parameter     ( a1 = 1.344d3, a2 =-8.88d2*sqrt(3.0d0)
     1               , a3 =-5.05d2 , a4 = 3.12d2*sqrt(3.0d0)
     2               , a5 = 1.44d2 )
c
       real*8        alfa    , zeta
c
c-----------------------------------------------------------------------
c
       alfa = a1 * zeta**4 + a2 * zeta**3 + a3 * zeta**2 + a4 * zeta
     1      + a5
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  A L F A                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  F O F A                  \\\\\\\\\\
c
c=======================================================================
c
       function fofa ( a )
c
c    abcd:roots.fofa <---------------- index for rounded linear function
c                                                            march, 2008
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine was written to experiment with the new 
c  "rounded linear profile" used in dzeus35 to set toroidal and poloidal
c  field components.  A linear function with its peak rounded off and 
c  then forced to fall to zero with zero slope at rz can be obtained 
c  with
c
c           b(xi)  =  xi cos**2(pi xi**a / 2)     xi = r/rz
c
c  If the input quantity is the location of the peak (rc < rz), then the
c  necessary exponent a can be found by setting the first derivative of 
c  (1) to zero, and solving the resulting trancendental equation:
c
c                     f(a)  =  2 a qc tan(qc) - 1
c
c  where qc = 0.5 pi (rc/rz)**a
c
c  It is this trancendental function f(a) that is described in this 
c  function.
c
c  INPUT VARIABLES:
c    a            value of index
c
c  OUTPUT VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        a       , pi      , rc      , rz      , qc      
     1             , fofa    , rl      , bc
c
       data          pi      , rc      , rz      
     1               / 3.141592653589793116d0, 0.14d0, 1.0d0 /
c
c-----------------------------------------------------------------------
c
       qc   = 0.5d0 * pi * ( rc / rz )**a
       fofa = 2.0d0 * a * qc * tan(qc) - 1.0d0
       rl   = ( 2.0d0 * acos ( sqrt ( 0.99d0 ) ) / pi )**(1.0d0/a) / rc
       bc   = rc * ( cos ( 0.5d0 * pi * rc**a ) )**2
       write (6, 2000) rc, a, rl, bc
2000   format('xic, a, xil/xic, b(xic) = ',1p4g12.5)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  F O F A                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  D F D X                  \\\\\\\\\\
c
c=======================================================================
c
       function dfdx ( x )
c
c    abcd:roots.dfdx <----------------- returns derivative of cos(x) - x
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of the derivative of the 
c  function cos(x) - x, namely -sin(x) - 1.
c
c  INPUT VARIABLES:
c    x            value of independent variable
c
c  OUTPUT VARIABLES:
c    dfdx         value of derivative of cos(x) - x.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , dfdx
c
c-----------------------------------------------------------------------
c
       dfdx =-sin(x) - 1.0d0
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  D F D X                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  F O F X                  \\\\\\\\\\
c
c=======================================================================
c
       function fofx ( x )
c
c    abcd:roots.fofx <---------------- returns value of desired function
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of the desired function.
c
c  INPUT VARIABLES:
c    x            value of independent variable
c
c  OUTPUT VARIABLES:
c    fofx         value of desired function.
c
c  EXTERNALS:
c    HUX1
c    EVEN1   , EVEN2
c    ODD1    , ODD2
c    BONDI
c    FOFA
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , fofx   
c
       real*8        hux1    , even1   , even2   , odd1    , odd2
     1             , bondi   , fofa    , alfa    , mhdjump
       external      hux1    , even1   , even2   , odd1    , odd2
     1             , bondi   , fofa    , alfa    , mhdjump
c
c-----------------------------------------------------------------------
c
ccc    fofx = cos(x) - x
       fofx = even1(x)
ccc    fofx = even2(x)
ccc    fofx = odd1(x)
ccc    fofx = odd2(x)
ccc    fofx = hux1(x)
ccc    fofx = bondi(x)
ccc    fofx = sin(x)
ccc    fofx = fofa(x)
ccc    fofx = alfa(x)
ccc    fofx = x**2 - 9.0d0
ccc    fofx = mhdjump(x)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  F O F X                  \\\\\\\\\\
c
c=======================================================================
c
c
