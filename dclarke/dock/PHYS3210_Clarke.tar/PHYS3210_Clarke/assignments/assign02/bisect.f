c======================== BEGIN PROGRAM BISECT =========================
c
       program bisect
c
c    written by: A Busy Code Developer, January 2011
c    modified 1:
c
c  PURPOSE:  This program finds the root of the function described in 
c  FOFX that lies between the input bounds using the bisection method.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   ans
       integer       maxiter , iter
       real*8        maxerr  , xl      , xr      , xm      , fxl     
     1             , fxr     , fxm     , err     , ferr
       real          cpubeg  , cpuend  , cputot     
c
       real*8        fofx
       external      fofx
c
       data          maxiter , maxerr  
     1             / 100     , 5.0d-9 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
10     continue
c
c      Ask user for root bracket.
c
       write(6, 2010)
       read (5,    *) xl, xr
c
c      Determine functional values.
c
       fxl  = fofx(xl)
       fxr  = fofx(xr)
c
c      Data validation:  Make sure root lies in between the left- and 
c  right-hand value.  If not, move on to next bracket.
c
       if (fxl*fxr .gt. 0.0d0) then
         write (6, 2020) xl, xr
         go to 30
       endif
c
c-----------------------------------------------------------------------
c----- Top of bisection loop -------------------------------------------
c-----------------------------------------------------------------------
c
       iter = 0
20     continue
         iter = iter + 1
c
c      Evaluate the next bisection guess.
c
         xm   = 0.5d0 * ( xl + xr )
c
c      If the fractional error of "xm" is less than "maxerr", the root 
c  has been found.  Report value of root, and move on to next root. 
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xm - xl )
         ferr = err / max ( abs(xl), abs(xr) )
         if ( ferr .le. maxerr ) then
           write(6, 2030) xm, err, iter
           go to 30
         endif
c
c      If the maximum number of iterations has been reached, report best 
c  value found and move on to next root.  It is always a good idea to 
c  provide an "escape route" should your program find itself in an 
c  infinite loop.  (It shouldn't in this program, but one never knows.)
c
         if ( iter .ge. maxiter ) then
           write (6, 2040) maxiter, xm, err
           go to 30
         endif
c
c      Report iteration progress.
c
         write (6, 2050) iter, xm, err
c
c      Determine which half of the interval (xl,xr) "xm" is in, and 
c  reset either "xr" or "xl" as appropriate.
c
         fxm = fofx(xm)
         if ( fxl * fxm .le. 0.0d0 ) then
           xr  = xm
           fxr = fxm
         else
           xl  = xm
           fxl = fxm
         endif
c
c      Go on to the next iteration.
c
         go to 20
30     continue
c
c-----------------------------------------------------------------------
c----- Bottom of bisection loop ----------------------------------------
c-----------------------------------------------------------------------
c
c      Ask user if another root is to be found.
c
       write (6, 2060)
       read  (5,    *) ans
       if ( (ans .ne. 'y') .and. (ans .ne. 'n') ) go to 30
       if (ans .eq. 'y') go to 10
c
c      End CPU time counter, and report cpu time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2070) cputot
c
       stop
c
c----------------------- Write format statements -----------------------
c
2010   format('BISECT  : Enter xL and xR such that f(xL)*f(xR) < 0.'  
     1       ,'  Thus, xL < root < xR.')
2020   format('BISECT  : No unique root lies between the specified'
     1       ,' limits:',/
     2       ,'BISECT  : xl = ', 1pg12.5,', and xr = ',g12.5)
2030   format('BISECT  : Root = ',1pg22.15,' +/- ',g9.2
     1       ,' after ',i3,' iterations.')
2040   format('BISECT  : Maximum number of iterations ',i9
     1       ,' exceeded.',/
     2       ,'BISECT  : Best guess at root is ',1pg22.15
     3       ,' +/- ',g9.2,'.')
2050   format('BISECT  : At iteration ',i3,', root = ',1pg22.15
     1       ,' +/- ',g9.2)
2060   format('BISECT  : Do you wish to search for another root? '
     1       ,'(answer y or n)')
2070   format('BISECT  : Total cpu usage for this run is ',1pg12.5
     1       ,' seconds.')
c
c-----------------------------------------------------------------------
c
       end
c
c========================= END PROGRAM BISECT ==========================
c
c========================= BEGIN FUNCTION FOFX =========================
c
       function fofx ( x )
c
c    written by: A Busy Code Developer, January 2003
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of cos(x) - x, whose root 
c  lies between 0.0 and 1.5.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , fofx
c
c-----------------------------------------------------------------------
c
       fofx = cos(x) - x
c
       return
       end
c
c========================== END FUNCTION FOFX ==========================
