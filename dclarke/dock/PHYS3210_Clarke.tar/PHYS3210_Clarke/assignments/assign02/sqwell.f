c=======================================================================
c
c                       B E G I N   P R O G R A M
c                              S Q W E L L
c
c=======================================================================
c
       program sqwell
c
c    abcd:sqwell <------------------- wave functions of frist two states
c                                                         february, 2002
c
c    written by: A Busy Code Developer
c    modified 1: February 2004 by ABCD; added remaining five wave 
c                functions.
c
c  PURPOSE:  This program prepares gnuplot files containing data for the
c  wave functions of the seven bound states of an electron trapped in a 
c  finite square well of half-width 2 Angstroms and depth 100 eV.
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       imax
       real*8        hbar    , a       , mass    , v0      , e0      
     1             , e1      , e2      , e3      , e4      , e5
     2             , e6      , scale
       parameter     ( imax=501 )
       parameter     ( hbar=2.760429d0, a=2.0d0, mass=1.0d0
     1               , v0=100.0d0, e0=1.949687d0, e1=7.784661d0
     2               , e2=17.45899d0, e3=30.88116d0, e4=47.87765d0
     3               , e5=68.08107d0, e6=90.36754d0, scale=10.0d0 )
c
       integer       i       
       real*8        xmin    , xmax    , dx      , d0      , d1      
     1             , d2      , d3      , d4      , d5      , d6      
     2             , beta0   , beta1   , beta2   , beta3   , beta4
     3             , beta5   , beta6   , alpha0  , alpha1  , alpha2
     4             , alpha3  , alpha4  , alpha5  , alpha6  , fact    
c
       real*8        x       (imax), psi0    (imax), psi1    (imax)
     1             , psi2    (imax), psi3    (imax), psi4    (imax)
     2             , psi5    (imax), psi6    (imax), pot     (imax)
     3             , ee0     (imax), ee1     (imax), ee2     (imax)
     4             , ee3     (imax), ee4     (imax), ee5     (imax)
     5             , ee6     (imax)
c
c-----------------------------------------------------------------------
c
c      Open data file, and write header.
c
       open ( 10, file='sqwell.txt', status='unknown' )
       write( 10, 2010 )
c
c      Evaluate x, psi0, and psi1, etc., and write each line of data as 
c  they are computed.
c
c  "scale" is to scale the wave functions so that they fit on an energy 
c  plot, which have energy units.
c
c  Wave functions have e0 (or e1, e2, etc.) added to them so that their 
c  "zeros" are the energy levels.
c
       fact   = sqrt ( 2.0d0 * mass ) / hbar
       alpha0 = fact * sqrt (      e0 )
       alpha1 = fact * sqrt (      e1 )
       alpha2 = fact * sqrt (      e2 )
       alpha3 = fact * sqrt (      e3 )
       alpha4 = fact * sqrt (      e4 )
       alpha5 = fact * sqrt (      e5 )
       alpha6 = fact * sqrt (      e6 )
       beta0  = fact * sqrt ( v0 - e0 )
       beta1  = fact * sqrt ( v0 - e1 )
       beta2  = fact * sqrt ( v0 - e2 )
       beta3  = fact * sqrt ( v0 - e3 )
       beta4  = fact * sqrt ( v0 - e4 )
       beta5  = fact * sqrt ( v0 - e5 )
       beta6  = fact * sqrt ( v0 - e6 )
       d0     = exp ( beta0 * a ) * cos ( alpha0 * a )
       d1     = exp ( beta1 * a ) * sin ( alpha1 * a )
       d2     = exp ( beta2 * a ) * cos ( alpha2 * a )
       d3     = exp ( beta3 * a ) * sin ( alpha3 * a )
       d4     = exp ( beta4 * a ) * cos ( alpha4 * a )
       d5     = exp ( beta5 * a ) * sin ( alpha5 * a )
       d6     = exp ( beta6 * a ) * cos ( alpha6 * a )
       xmax   = 2.0d0 * a
       xmin   =-xmax
       dx     = ( xmax - xmin ) / dble(imax-1)
       do 10 i=1,imax
         x(i) = xmin + dble(i-1) * dx
         if (x(i) .le. -a) then
           psi0(i) = d0 * exp ( beta0 * x(i) ) * scale + e0
           psi1(i) =-d1 * exp ( beta1 * x(i) ) * scale + e1
           psi2(i) = d2 * exp ( beta2 * x(i) ) * scale + e2
           psi3(i) =-d3 * exp ( beta3 * x(i) ) * scale + e3
           psi4(i) = d4 * exp ( beta4 * x(i) ) * scale + e4
           psi5(i) =-d5 * exp ( beta5 * x(i) ) * scale + e5
           psi6(i) = d6 * exp ( beta6 * x(i) ) * scale + e6
           pot (i) = v0
           ee0 (i) = e0
           ee1 (i) = e1
           ee2 (i) = e2
           ee3 (i) = e3
           ee4 (i) = e4
           ee5 (i) = e5
           ee6 (i) = e6
         endif
         if ( (x(i) .gt. -a) .and. (x(i) .lt. a) ) then
           psi0(i) = cos ( alpha0 * x(i) ) * scale + e0
           psi1(i) = sin ( alpha1 * x(i) ) * scale + e1
           psi2(i) = cos ( alpha2 * x(i) ) * scale + e2
           psi3(i) = sin ( alpha3 * x(i) ) * scale + e3
           psi4(i) = cos ( alpha4 * x(i) ) * scale + e4
           psi5(i) = sin ( alpha5 * x(i) ) * scale + e5
           psi6(i) = cos ( alpha6 * x(i) ) * scale + e6
           pot (i) = 0.0d0
           ee0 (i) = e0
           ee1 (i) = e1
           ee2 (i) = e2
           ee3 (i) = e3
           ee4 (i) = e4
           ee5 (i) = e5
           ee6 (i) = e6
         endif
         if (x(i) .ge. a) then
           psi0(i) = d0 * exp (-beta0 * x(i) ) * scale + e0
           psi1(i) = d1 * exp (-beta1 * x(i) ) * scale + e1
           psi2(i) = d2 * exp (-beta2 * x(i) ) * scale + e2
           psi3(i) = d3 * exp (-beta3 * x(i) ) * scale + e3
           psi4(i) = d4 * exp (-beta4 * x(i) ) * scale + e4
           psi5(i) = d5 * exp (-beta5 * x(i) ) * scale + e5
           psi6(i) = d6 * exp (-beta6 * x(i) ) * scale + e6
           pot (i) = v0
           ee0 (i) = e0
           ee1 (i) = e1
           ee2 (i) = e2
           ee3 (i) = e3
           ee4 (i) = e4
           ee5 (i) = e5
           ee6 (i) = e6
         endif
         write( 10, 2020 ) x(i), psi0(i), psi1(i), psi2(i), psi3(i)
     1                   , psi4(i), psi5(i), psi6(i), pot(i), ee0(i)
     2                   , ee1(i), ee2(i), ee3(i), ee4(i), ee5(i)
     3                   , ee6(i)
10     continue
c
c      Close data file.
c
       close(10)
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('#  Data file containing the seven wave functions in the '
     1       ,'finite square well potential, the square well, and the '
     2       ,'seven energy levels.',/,'#',/
     4       ,'#   x     psi0(x)       psi1(x)       psi2(x)       '
     5       ,'psi3(x)       psi4(x)       psi5(x)       psi6(x)      '
     6       ,'pot(x)    e0(x)    e1(x)    e2(x)    e3(x)    e4(x)    '
     7       ,'e5(x)    e6(x)',/,'#')
2020   format(f8.4,1x,1pg12.5,2x,g12.5,2x,g12.5,2x,g12.5,2x,g12.5,2x
     1       ,g12.5,2x,g12.5,2x,0pf8.4,1x,f8.4,1x,f8.4,1x,f8.4,1x,f8.4
     2       ,2x,f8.4,1x,f8.4,1x,f8.4)
c
       stop
       end
c
c=======================================================================
c
c                         E N D   P R O G R A M
c                              S Q W E L L
c
c=======================================================================
c
