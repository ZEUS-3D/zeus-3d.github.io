c======================== BEGIN PROGRAM NWTRPH =========================
c
       program nwtrph
c
c    written by: A Busy Code Developer, January 2003
c    modified 1:
c
c  PURPOSE:  This program finds the root of the function described in 
c  FOFX and whose first derivative is described in DFDX that lies 
c  between the input bounds using the Newton-Raphson method.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   ans
       integer       maxiter , iter
       real*8        maxerr  , small   , xn      , fxn     , dfxn    
     1             , xnp1    , err     , ferr
       real          cpubeg  , cpuend  , cputot  
c
       real*8        fofx    , dfdx
       external      fofx    , dfdx
c
       data          maxiter , maxerr  , small
     1             / 100     , 5.0d-9  , 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
10     continue
c
c      Ask user for "zeroth" guess.
c
       write(6, 2010)
       read (5,    *) xn
c
c-----------------------------------------------------------------------
c----- Top of Newton-Raphson loop --------------------------------------
c-----------------------------------------------------------------------
c
       iter = 0
20     continue
         iter = iter + 1
c
c      Set functional values.
c
         fxn  = fofx(xn)
         dfxn = dfdx(xn)
c
c      Evaluate the next Newton-Raphson guess.  Note the use of "small" 
c  to prevent possible zero-divides.  Note further that if "dfxn" is 
c  within "small" of zero, then the routine is in trouble since this 
c  means the current guess is at an extremum, and extrapolating from an 
c  extremum along the tangent will intersect the x-axis only at very 
c  large values of x.
c
         xnp1 = xn - fxn / ( dfxn + small )
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found.  Report value of root, and move on to next root.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         if ( ferr .le. maxerr ) then
           write(6, 2020) xnp1, err, iter
           go to 30
         endif
c
c      If the maximum number of iterations has been reached, report best 
c  value found and move on to next root.  It is always a good idea to 
c  provide an "escape route" should your program find itself in an 
c  infinite loop.
c
         if ( iter .ge. maxiter ) then
           write (6, 2030) maxiter, xnp1, err
           go to 30
         endif
c
c      Report iteration progress.
c
         write (6, 2040) iter, xnp1, err
c
c      Prepare for and go on to next iteration.
c
         xn = xnp1
         go to 20
30     continue
c
c-----------------------------------------------------------------------
c----- Bottom of Newton-Raphson loop -----------------------------------
c-----------------------------------------------------------------------
c
c      Ask user if another root is to be found.
c
       write (6, 2050)
       read  (5,    *) ans
       if ( (ans .ne. 'y') .and. (ans .ne. 'n') ) go to 30
       if (ans .eq. 'y') go to 10
c
c      End CPU time counter, and report cpu time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2060) cputot
c
       stop
c
c----------------------- Write format statements -----------------------
c
2010   format('NWTRPH  : Enter an initial guess for the root.  There '
     1       ,'should be no extremum',/
     2       ,'NWTRPH  : between the guess and the root.')
2020   format('NWTRPH  : Root = ',1pg22.15,' +/- ',g9.2
     1       ,' after ',i3,' iterations.')
2030   format('NWTRPH  : Maximum number of iterations ',i9
     1       ,' exceeded.',/
     2       ,'NWTRPH  : Best guess at root is ',1pg22.15
     3       ,' +/- ',g9.2,'.')
2040   format('NWTRPH  : At iteration ',i3,', root = ',1pg22.15
     1       ,' +/- ',g9.2)
2050   format('NWTRPH  : Do you wish to search for another root? '
     1       ,'(answer y or n)')
2060   format('NWTRPH  : Total cpu usage for this run is ',1pg12.5
     1       ,' seconds.')
c
c-----------------------------------------------------------------------
c
       end
c
c========================= END PROGRAM NWTRPH ==========================
c
c========================= BEGIN FUNCTION FOFX =========================
c
       function fofx ( x )
c
c    written by: A Busy Code Developer, January 2003
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of cos(x) - x.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , fofx
c
c-----------------------------------------------------------------------
c
       fofx = cos(x) - x
c
       return
       end
c
c========================== END FUNCTION FOFX ==========================
c
c========================= BEGIN FUNCTION DFDX =========================
c
       function dfdx ( x )
c
c    written by: A Busy Code Developer, January 2003
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of the derivative of fofx 
c  evaluated at x.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , dfdx
c
c-----------------------------------------------------------------------
c
       dfdx =-sin(x) - 1.0d0
c
       return
       end
c
c========================== END FUNCTION DFDX ==========================
