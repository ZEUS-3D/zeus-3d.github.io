c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  H U X 1                  \\\\\\\\\\
c
c=======================================================================
c
       function hux1 ( ux )
c
c    dac:crmhd.hux1 <----------------------------------- computes h(ux1)
c                                                           august, 1996
c
c    written by: David Clarke
c    modified 1: July, 2010 by DAC, updated.
c    modified 2: February, 2011 by DAC; version with in-line functions.
c
c  PURPOSE: Computes the CR-MHD 1-D shock jump conditions; suitable for 
c  use in root-finding programs written for assignment 2 of PHYS3210.
c
c  To engage this routine, it is necessary to replace the line in 
c  function fofx (or whatever the student has called this function)
c  that sets fofx with:
c
c       fofx = hux1(x)
c
c  and, assuming implicit none has been set, declare hux1 as real*8.
c
c  In addition, the initialisation routine HINIT (included in this file) 
c  must be appended as well, and the first line of the main program 
c  should be:
c
c       call hinit
c
c  All roots can be found by specifying the range 0.1, 10.
c
c  Roots of hux1 are:
c
c  Root   1 =  0.586724509493656 +/- 3.01E-10 after   4 M-B iterations.
c  Root   2 =   1.11226118034061 +/- 3.14E-09 after   3 M-B iterations.
c  Root   3 =   1.55031334246331 +/- 1.58E-11 after   4 M-B iterations.
c  Root   4 =   3.78997752714135 +/- 1.61E-08 after   4 M-B iterations.
c  Root   5 =   5.61248600000000 +/- 2.49E-09 after   4 M-B iterations.
c  Root   6 =   6.32455023739598 +/- 3.93E-09 after   4 M-B iterations.
c
c  A single precision version of this routine (CRAY) exists in the 
c  program PLOTIT which can be used to generate publication quality 
c  plots.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        hux1    , ux      , ux2     , uy      , uy2     
     1             , q1      , fux2    , fuy     , eff     , gee     
c
       real*8        gammag  , gammac  , gamg    , gamc    , ii
     1             , jjx     , jjy     , kkx     , kky     , ll
     2             , mm      , small
       common      / comvar /
     1               gammag  , gammac  , gamg    , gamc    , ii
     2             , jjx     , jjy     , kkx     , kky     , ll
     3             , mm      , small
c
c      Statement functions.  Order is important: FORTRAN syntax requires 
c  statement functions (often incorrectly referred to as "in-line 
c  functions") to be declared before they are used, even by another 
c  statement function.
c
       fuy (ux   ) = ( kkx * kky + jjy * ux ) / ( ii * ux - kkx**2 )
c
       eff (ux,uy) = 0.5d0 * ii * ( ux**2 + uy**2 ) 
     1             + gamg * ll * ux * ( ii / ( ux + small ) )**gammag
     2             + kky * ( kky + kkx * uy ) / ( ux + small )
c
       gee (ux,uy) = ii * ux + ll * ( ii / ( ux + small ) )**gammag
     1             + 0.5d0 * ( kky + kkx * uy )**2 / ( ux + small )**2
c
       fux2(ux,uy) = ( eff(ux,uy) - mm ) / ( gee(ux,uy) - jjx ) / gamc
c
c-----------------------------------------------------------------------
c
       uy   = fuy (ux    )
       ux2  = fux2(ux ,uy)
       uy2  = fuy (ux2   )
       q1   = kky + uy2 * kkx 
       hux1 = ux2**3 * ii * ( 0.5d0 - gamg )
     1      + ux2**2 * gamg * gee(ux,uy) 
     2      + ux2    * ( 0.5d0 * ii * uy2**2 - eff(ux,uy) ) 
     3      +          q1 * ( kky - 0.5d0 * gamg * q1 )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  H U X 1                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 H I N I T                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine hinit
c
c    dac:crmhd.hinit <--------------------initialises variables for hux1
c                                                             march 2003
c
c    written by: David Clarke
c    modified 1:
c
c  PURPOSE: This routine initialises variables for HUX1.
c
c  INPUT VARIABLES:
c
c  OUTPUT VARIABLES:
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        dd0     , dux0    , duy0    , dpg0    , dpc0
     1             , dbx0    , dby0
c
       real*8        gammag  , gammac  , gamg    , gamc    , ii
     1             , jjx     , jjy     , kkx     , kky     , ll
     2             , mm      , small
       common      / comvar /
     1               gammag  , gammac  , gamg    , gamc    , ii
     2             , jjx     , jjy     , kkx     , kky     , ll
     3             , mm      , small
c
       data          small    / 1.0d-49 /
c
c-----------------------------------------------------------------------
c
c  dux0 = 5.6125 is a Mach 3 flow (as in the PDC paper (defunct)).
c
       dd0    = 1.0d0
       dux0   = 5.612486d0
       duy0   = 0.0d0
       dpg0   = 1.0d0
       dpc0   = 1.0d0
       dbx0   = sqrt(1.5d0)
       dby0   = sqrt(0.5d0)
c
       gammag = 5.0d0 / 3.0d0
       gammac = 4.0d0 / 3.0d0
       gamg   = gammag / ( gammag - 1.0d0 )
       gamc   = gammac / ( gammac - 1.0d0 )
c
       ii     = dd0 * dux0
       jjx    = ii * dux0 + dpg0 + dpc0 + 0.5d0 * dby0**2
       jjy    = ii * duy0 - dbx0 * dby0
       kkx    = dbx0
       kky    = dux0 * dby0 - duy0 * dbx0
       ll     = dpg0 * dd0**(-gammag)
       mm     = 0.5d0 * ii * ( dux0**2 + duy0**2 )
     1        + dux0 * ( gamg * dpg0 + gamc * dpc0 ) + dby0 * kky
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 H I N I T                 \\\\\\\\\\
c
c=======================================================================
c
c
