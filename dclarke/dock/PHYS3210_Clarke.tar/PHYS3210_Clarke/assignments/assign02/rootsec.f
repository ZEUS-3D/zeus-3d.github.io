c======================== BEGIN PROGRAM ROOTSEC ========================
c
       program rootsec
c
c    written by: A Busy Code Developer, January 2011
c    modified 1:
c
c  PURPOSE:  This program finds the root of a given function that 
c  lies between the input bounds using the hybrid bisection/secant 
c  method.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*1   ans
       integer       maxiter , iter
       real*8        xl      , xr      , root    , maxerr , err
       real*8        fofx    
       real          cpubeg  , cpuend  , cputot     
c
       external      biscnt  , fofx    
c
       data          maxiter , maxerr
     1             / 30      , 5.0d-9 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
10     continue
c
c      Ask user for root bracket.
c
       write(6, 2010)
       read (5,    *) xl, xr
c
c      Find root, if any.  "iter" is returned as zero if no root is 
c  found.  Otherwise, it is the number of iterations taken to converge 
c  on the root.
c
       call biscnt ( xl, xr, root, fofx, maxerr, maxiter, err, iter )
c
c      Report value of root found.
c
       if (iter .eq. 0) write(6, 2020) xl, xr
       if (iter .eq. maxiter) write(6, 2030) maxiter, root, err
       if ( (iter .gt. 0) .and. (iter .lt. maxiter) )
     1   write(6, 2040) root, err, iter
c
c      Ask user if another root is to be found.
c
20     continue
       write (6, 2050)
       read  (5,    *) ans
       if ( (ans .ne. 'y') .and. (ans .ne. 'n') ) go to 20
       if (ans .eq. 'y') go to 10
c
c      End CPU time counter, and report cpu time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2060) cputot
c
       stop
c
c----------------------- Write format statements -----------------------
c
2010   format('ROOTSEC : Enter xL and xR such that f(xL)*f(xR) < 0.'  
     1       ,'  Thus, xL < root < xR.')
2020   format('ROOTSEC : No root found in domain (',1pg12.5,', ',g12.5
     1       ,').')
2030   format('ROOTSEC : Maximum number of iterations ',i9,' reached.',/
     1       ,'ROOTSEC : Best guess at root is ',1pg22.15,' +/- ',g9.2
     2       ,'.')
2040   format('ROOTSEC : Root = ',1pg22.15,' +/- ',g9.2,' after ',i3
     1       ,' iterations.')
2050   format('ROOTSEC : Do you wish to search for another root? '
     1       ,'(answer y or n)')
2060   format('ROOTSEC : Total cpu usage for this run is ',1pg12.5
     1       ,' seconds.')
c
c-----------------------------------------------------------------------
c
       end
c
c========================= END PROGRAM ROOTSEC =========================
c
c======================= BEGIN SUBROUTINE BISCNT =======================
c
       subroutine biscnt ( xl, xr, xn, f, maxerr, maxiter, err, iter )
c
c    written by: A Busy Code Developer, January 2011
c    modified 1: 
c
c  PURPOSE:  This routine performs the hybrid bisection/secant method to
c  find the root of a function.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       iter    , maxiter
       real*8        xl      , xr      , xnm1    , xn      , xnp1
     1             , fxl     , fxr     , fxnm1   , fxn     , dfxn
     2             , err     , ferr    , maxerr  , small
       real*8        f       
c
       data          small   
     1             / 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Initialise variables.
c
       iter = 0
       fxl  = f(xl)
       fxr  = f(xr)
c
c      Data validation:  Make sure root lies in between the left- and 
c  right-hand value.  If not, return iter=0 to the calling routine.
c
       if (fxl*fxr .gt. 0.0d0) then
         write (6, 2010) xl, xr
         return
       endif
c
c      Starting values for "xn", "xnm1", "fxn", and "fxnm1".
c
       if (abs(fxl) .lt. abs(fxr)) then
         xn    = xl
         xnm1  = xr
         fxn   = fxl
         fxnm1 = fxr
       else
         xn    = xr
         xnm1  = xl
         fxn   = fxr
         fxnm1 = fxl
       endif
c
c-----------------------------------------------------------------------
c----- Top of hybrid loop. ---------------------------------------------
c-----------------------------------------------------------------------
c
10     continue
         iter = iter + 1
c
c      Compute the secant (dfxn) from current and previous guesses.
c
         dfxn = ( fxn - fxnm1 ) / ( ( xn - xnm1 ) + small )
c
c      Evaluate the next guess for the root.
c
         xnp1 = xn - fxn / ( dfxn + small )
c
c      A bisection step is taken if a secant step is not justified.  
c  Report to the user the interim value of the root and which algorithm 
c  is used.
c
         if ( (xl .lt. xnp1) .and. (xnp1 .lt. xr) ) then
           write (6, 2020) iter, xnp1
         else
           xnp1 = 0.5d0 * ( xl + xr )
           write (6, 2030) iter, xnp1
         endif
c
c      If the fractional error of "xnp1" is less than "maxerr", the root 
c  has been found and execution is returned to the calling routine.
c  Note the use of the "max" function in the denominator of "ferr" to 
c  prevent possible zero-divides.
c
         err  = abs ( xnp1 - xn )
         ferr = err / max ( abs(xn), abs(xnp1) )
         xnm1 = xn
         xn   = xnp1
         if ( ferr .le. maxerr ) go to 20
c
c      If the maximum number of iterations has been reached, return to 
c  the calling routine.
c
         if ( iter .ge. maxiter ) go to 20
c
c      Prepare for next iteration.
c
         fxnm1 = fxn
         fxn   = f(xn)
c
c      Determine which half of the interval (xl,xr) "xn" is in, and 
c  reset either "xr" or "xl" as appropriate.
c
         if ( fxl * fxn .le. 0.0d0 ) then
           xr  = xn
           fxr = fxn
         else
           xl  = xn
           fxl = fxn
         endif
c
c      Go on to the next iteration.
c
         go to 10
20     continue
c
c-----------------------------------------------------------------------
c----- Bottom of hybrid loop. ------------------------------------------
c-----------------------------------------------------------------------
c
2010   format('BISCNT  : No unique root lies between the specified'
     1       ,' limits:',/
     2       ,'BISCNT  : xl = ', 1pg12.5,', and xr = ',g12.5)
2020   format('BISCNT  : At iteration ',i3,' (SECANT),    root ='
     1       ,1pg22.15)
2030   format('BISCNT  : At iteration ',i3,' (BISECTION), root ='
     1       ,1pg22.15)
c
       return
       end
c
c======================== END SUBROUTINE BISCNT ========================
c
c========================= BEGIN FUNCTION FOFX =========================
c
       function fofx ( x )
c
c    written by: A Busy Code Developer, January 2003
c    modified 1: 
c
c  PURPOSE:  This routine returns the value of cos(x) - x, whose root 
c  lies between 0.0 and 1.5.
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       real*8        x       , fofx
c
c-----------------------------------------------------------------------
c
       fofx = cos(x) - x
c
       return
       end
c
c========================== END FUNCTION FOFX ==========================
