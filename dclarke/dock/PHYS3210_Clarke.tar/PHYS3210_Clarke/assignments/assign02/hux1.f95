!---+----1----+----2----+----3----+----4----+----5----+----6----+-+----6----+----5----+----4----+----3----+----2----+----1----+----!
!=======================================================================
!
!    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
!    //////////                  H U X 1                  \\\\\\\\\\
!
!=======================================================================
!
       function hux1 ( ux )
!
!    dac:crmhd.hux1 <----------------------------------- computes h(ux1)
!                                                           august, 1996
!
!    written by: David Clarke
!    modified 1: July, 2010 by DAC, updated.
!    modified 2: February, 2011 by DAC; version with in-line functions.
!
!    F95 VERSION: ONLY DIFFERENCES BETWEEN THIS AND F77 VERSION ARE:
!
!       1. ! IS NEEDED FOR COMMENTS, NOT C;
!
!       2. CONTINUATION CHARACTERS ARE EXCLUSIVELY & AND MUST APPEAR AT THE END OF THE LINE BEING CONTINUED AS WELL AS THE 
!          CONTINUATION LINE; AND 
!
!       3. :: MUST SEPARATE DATA TYPE (E.G., INTEGER) FROM THE VARIABLES BEING DECLARED.
!
!  PURPOSE: Computes the CR-MHD 1-D shock jump conditions; suitable for 
!  use in root-finding programs written for assignment 2 of PHYS3210.
!
!  To engage this routine, it is necessary to replace the line in 
!  function fofx (or whatever the student has called this function)
!  that sets fofx with:
!
!       fofx = hux1(x)
!
!  and, assuming implicit none has been set, declare hux1 as real*8.
!
!  In addition, the initialisation routine HINIT (included in this file) 
!  must be appended as well, and the first line of the main program 
!  should be:
!
!       call hinit
!
!  All roots can be found by specifying the range 0.1, 10.
!
!  Roots of hux1 are:
!
!  Root   1 =  0.586724509493656 +/- 3.01E-10 after   4 M-B iterations.
!  Root   2 =   1.11226118034061 +/- 3.14E-09 after   3 M-B iterations.
!  Root   3 =   1.55031334246331 +/- 1.58E-11 after   4 M-B iterations.
!  Root   4 =   3.78997752714135 +/- 1.61E-08 after   4 M-B iterations.
!  Root   5 =   5.61248600000000 +/- 2.49E-09 after   4 M-B iterations.
!  Root   6 =   6.32455023739598 +/- 3.93E-09 after   4 M-B iterations.
!
!  A single precision version of this routine (CRAY) exists in the 
!  program PLOTIT which can be used to generate publication quality 
!  plots.
!
!  INPUT VARIABLES:
!
!  OUTPUT VARIABLES:
!
!  LOCAL VARIABLES:
!
!  EXTERNALS: [none]
!
!-----------------------------------------------------------------------
!
       implicit      none
!
       real*8::      hux1    , ux      , ux2     , uy      , uy2         &
     &             , q1      , fux2    , fuy     , eff     , gee     
!
       real*8::      gammag  , gammac  , gamg    , gamc    , ii          &
     &             , jjx     , jjy     , kkx     , kky     , ll          &
     &             , mm      , small
       common        / comvar /                                          &
     &               gammag  , gammac  , gamg    , gamc    , ii          &
     &             , jjx     , jjy     , kkx     , kky     , ll          &
     &             , mm      , small
!
!      Statement functions.  Order is important: FORTRAN syntax requires 
!  statement functions (often incorrectly referred to as "in-line 
!  functions") to be declared before they are used, even by another 
!  statement function.
!
       fuy (ux   ) = ( kkx * kky + jjy * ux ) / ( ii * ux - kkx**2 )
!
       eff (ux,uy) = 0.5d0 * ii * ( ux**2 + uy**2 )                      &
     &             + gamg * ll * ux * ( ii / ( ux + small ) )**gammag    &
     &             + kky * ( kky + kkx * uy ) / ( ux + small )            
!
       gee (ux,uy) = ii * ux + ll * ( ii / ( ux + small ) )**gammag      &
     &             + 0.5d0 * ( kky + kkx * uy )**2 / ( ux + small )**2
!
       fux2(ux,uy) = ( eff(ux,uy) - mm ) / ( gee(ux,uy) - jjx ) / gamc
!
!-----------------------------------------------------------------------
!
       uy   = fuy (ux    )
       ux2  = fux2(ux ,uy)
       uy2  = fuy (ux2   )
       q1   = kky + uy2 * kkx 
       hux1 = ux2**3 * ii * ( 0.5d0 - gamg )                             &
     &      + ux2**2 * gamg * gee(ux,uy)                                 &
     &      + ux2    * ( 0.5d0 * ii * uy2**2 - eff(ux,uy) )              &
     &      +          q1 * ( kky - 0.5d0 * gamg * q1 )
!
       return
       end 
!
!=======================================================================
!
!    \\\\\\\\\\          E N D   F U N C T I O N          //////////
!    //////////                  H U X 1                  \\\\\\\\\\
!
!=======================================================================
!
!
!=======================================================================
!
!    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
!    //////////                 H I N I T                 \\\\\\\\\\
!
!=======================================================================
!
       subroutine hinit
!
!    dac:crmhd.hinit <--------------------initialises variables for hux1
!                                                             march 2003
!
!    written by: David Clarke
!    modified 1:
!
!  PURPOSE: This routine initialises variables for HUX1.
!
!  INPUT VARIABLES:
!
!  OUTPUT VARIABLES:
!
!  LOCAL VARIABLES:
!
!  EXTERNALS: [none]
!
!-----------------------------------------------------------------------
!
       implicit      none
!
       real*8 ::     dd0     , dux0    , duy0    , dpg0    , dpc0        &
     &             , dbx0    , dby0
!
       real*8 ::     gammag  , gammac  , gamg    , gamc    , ii          &
     &             , jjx     , jjy     , kkx     , kky     , ll          &
     &             , mm      , small
       common        / comvar /                                          &
     &               gammag  , gammac  , gamg    , gamc    , ii          &
     &             , jjx     , jjy     , kkx     , kky     , ll          &
     &             , mm      , small
!
       data          small    / 1.0d-49 /
!
!-----------------------------------------------------------------------
!
!  dux0 = 5.6125 is a Mach 3 flow (as in the PDC paper (defunct)).
!
       dd0    = 1.0d0
       dux0   = 5.612486d0
       duy0   = 0.0d0
       dpg0   = 1.0d0
       dpc0   = 1.0d0
       dbx0   = sqrt(1.5d0)
       dby0   = sqrt(0.5d0)
!
       gammag = 5.0d0 / 3.0d0
       gammac = 4.0d0 / 3.0d0
       gamg   = gammag / ( gammag - 1.0d0 )
       gamc   = gammac / ( gammac - 1.0d0 )
!
       ii     = dd0 * dux0
       jjx    = ii * dux0 + dpg0 + dpc0 + 0.5d0 * dby0**2
       jjy    = ii * duy0 - dbx0 * dby0
       kkx    = dbx0
       kky    = dux0 * dby0 - duy0 * dbx0
       ll     = dpg0 * dd0**(-gammag)
       mm     = 0.5d0 * ii * ( dux0**2 + duy0**2 )                       &
     &        + dux0 * ( gamg * dpg0 + gamc * dpc0 ) + dby0 * kky
!
       return
       end 
!
!=======================================================================
!
!    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
!    //////////                 H I N I T                 \\\\\\\\\\
!
!=======================================================================
!
!
