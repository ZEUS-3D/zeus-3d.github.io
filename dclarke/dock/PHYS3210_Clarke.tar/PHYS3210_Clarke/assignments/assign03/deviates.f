c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////              D E V I A T E S              \\\\\\\\\\
c
c=======================================================================
c
       program deviates
c
c    dac:deviates <---------------- displays uniform and normal deviates
c                                                            march, 2004
c    written by: David Clarke
c    modified 1: April, 2011 by DAC; corrected usage of Gaussian 
c                statistics.
c
c  PURPOSE:  Program to test the uniform and normal deviate subroutines 
c  in Press et al., and to display their distributions.  nmax deviates 
c  (both uniform and normal) are chosen and the domain (-3:3) is divided 
c  into imax bins.  The number of deviates falling into each bin are 
c  counted and tabulated in the file "random.txt" in the format:
c
c      x     nudpb(x)     nndpb(x)
c
c  where nudpb(x) [nndpb(x)] is the number of uniform (normal) deviates
c  per bin centred at x with width dx.  Thus, nudpb(x) [nndpb(x)] is the 
c  histogram function for the uniform (normal) deviate whose peak 
c  depends on both the total number of random numbers generated (nmax) 
c  and the width of the histogram bins (domain/imax).  
c
c  Let nud(x) [nnd(x)] be the distribution density of the uniform 
c  (normal) deviate (number of values per unit domain).  Then
c
c      nudpb(x) = nud(x) dx    [nndpb(x) = nnd(x) dx]              (1)
c
c  Thus, and for example, for a normal distribution about 0 with unit 
c  standard deviation, we expect
c                                             ^
c  nnd(x)  =  n0 exp -( 0.5 * x**2 ), where  /  nnd(x) dx  =  nmax
c                                           v
c            1        ^
c  But,  ----------  /  exp -( 0.5 * x**2 ) dx  =  1
c        sqrt(2 pi) v
c
c  for unit sigma.  Thus, n0 = nmax / sqrt(2 pi) is the amplitude of the 
c  distribution function and, by equation (1), the amplitude of the 
c  histogram is: nmax dx / sqrt(2 pi) = 797.9  for nmax = 100,000 and 
c  dx = 0.02.
c
c  Similarly and more simply, the amplitude for the uniform deviate 
c  histogram is: nmax dx = 2,000.  Spreading the uniform deviate over 
c  (-1:1) instead of (0:1) reduces the amplitude of the histogram by 
c  half, and thus 1,000.
c
c  To view the data in "deviates.txt", issue the following command 
c  within gnuplot:
c
c  plot [-3:3][0:1100] "deviates.txt" u 1:2 w lines, "deviates.txt" u 1:3 w lines, 797.9*exp(-x*x/2), 1000
c
c  EXTERNALS:
c    RAN2
c    NORM
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax    , imax
       parameter     ( nmax=100000, imax=300 )
c
       integer       iseed   , i       , n       , index
       real*8        dx      , one     , cpubeg  , cpuend  , cputot 
c
       integer       nudpb   (imax), nndpb   (imax)
       real*8        udev    (nmax), ndev    (nmax), x       (imax)
c
       real*8        ran2    , norm
       external      ran2    , norm
c
       data          iseed    / 1 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
       open(10,file='deviates.txt',status='unknown')
c
c      The arithmetic on ran2 distributes the uniform deviate between -1 
c  and 1.
c
       do 10 n=1,nmax
         udev(n) = 2.0d0 * ran2(iseed) - 1.0d0
         ndev(n) = norm(iseed)
10     continue
c
c      The domain is set to [-3:3].
c
       dx = 6.0d0 / dble(imax)
       do 20 i=1,imax
         nudpb(i) = 0
         nndpb(i) = 0
         x    (i) = ( dble(i) - 0.5d0 ) * dx - 3.0d0
20     continue
c
c      For the purposes of creating the histogram, "nudpb" and "nndpb"
c  are the number of deviates per bin of width dx centred at x.
c
       do 30 n=1,nmax
         one          = 0.5d0 + sign ( 0.499999d0, udev(n) )
         index        = imax/2 + int ( one + udev(n)/dx )
         nudpb(index) = nudpb(index) + 1
         one          = 0.5d0 + sign ( 0.5d0, ndev(n) )
         index        = imax/2 + int ( one + ndev(n)/dx )
         if ( (index .ge. 1) .and. (index .le. imax) )
     1     nndpb(index) = nndpb(index) + 1
30     continue
c
c      Write a disc file suitable for gnuplot.
c
       do 40 i=1,imax
         write(10,*) x(i), nudpb(i), nndpb(i)
40     continue
c
       close(10)
c
c      Report cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2010) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('DEVIATES: Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////              D E V I A T E S              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  R A N 0                  \\\\\\\\\\
c
c=======================================================================
c
       function ran0 ( idum )
c
c    whp:zeus3d.ran0 <------------------- returns uniform random deviate
c    from numerical recipes                               december, 1992
c
c    written by: Press etal.
c    modified 1:
c
c  PURPOSE:  Returns a uniformly distrbuted random deviate between 0.0
c  and 1.0 (see Numerical Recipes, 1st edition for FORTRAN, page 196;
c  where the routine is called RAN1).
c
c  INPUT VARIABLES:
c    idum        .ge. 0 => get next random number from sequence
c                .lt. 0 => initialise sequence depending on absolute
c                          value of "idum", and gets next random number
c
c  OUTPUT VARIABLES:
c    ran0        deviate with uniform distribution between 0.0 and 1.0
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       imax    , m1      , ia1     , ic1     , m2
     1             , ia2     , ic2     , m3      , ia3     , ic3
       real*8        rm1     , rm2
       parameter     ( imax=97 )
       parameter     ( m1=259200, ia1=7141, ic1=54733, rm1=1.0d0/m1 )
       parameter     ( m2=134456, ia2=8121, ic2=28411, rm2=1.0d0/m2 )
       parameter     ( m3=243000, ia3=4561, ic3=51349 )
c
       integer       idum    , iff     , ix1     , ix2     , ix3
     1             , i
       real*8        ran0
c
       real*8        r       (imax)
c
c      Data statements
c
       data          iff      / 0 /
       save          iff     , ix1     , ix2     , ix3     , r
c
c-----------------------------------------------------------------------
c
c      If sequence is to be initialised, start here ...
c
       if ( (idum .lt. 0) .or. (iff .eq. 0) ) then
         iff = 1
         ix1 = mod ( ic1 - idum   , m1 )
         ix1 = mod ( ia1*ix1 + ic1, m1 )
         ix2 = mod ( ix1          , m2 )
         ix1 = mod ( ia1*ix1 + ic1, m1 )
         ix3 = mod ( ix1          , m3 )
         do 10 i=1,imax
           ix1  = mod ( ia1*ix1 + ic1, m1 )
           ix2  = mod ( ia2*ix2 + ic2, m2 )
           r(i) = ( dble(ix1) + dble(ix2) * rm2 ) * rm1
10       continue
         idum = 1
       endif
c
c      Otherwise, start here ....
c
       ix1  = mod ( ia1*ix1 + ic1, m1 )
       ix2  = mod ( ia2*ix2 + ic2, m2 )
       ix3  = mod ( ia3*ix3 + ic3, m3 )
       i    = 1 + ( imax * ix3 ) / m3
       ran0 = r(i)
       r(i) = ( dble(ix1) + dble(ix2) * rm2 ) * rm1
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  R A N 0                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  R A N 1                  \\\\\\\\\\
c
c=======================================================================
c
       function ran1 ( iseed )
c
c    whp:zeus3d.ran1 <--------------------------- uniform random deviate
c    from numerical recipes, ed. 2                            june, 1998
c
c    written by: W. Press et al.
c    modified 1: June, 1998; adapted by Ralf Klessen for ZEUS.
c    modified 2: June, 2008 by DAC; incorporated into dzeus36
c
c  PURPOSE:  This routine returns a uniform random deviate between 0.0 
c  and 1.0.  See Numerical Recipes, ed. 2, pg. 271.  It must be called 
c  with a negative seed and then a positive number from then on.
c
c  This routine supplants the version from edition 1, now called RAN0.
c  It provides statistically random numbers for up to 10**8 calls.  For 
c  an even greater number of calls (2 x 10**18), see RAN2.
c
c  INPUT VARIABLES: 
c    iseed       .lt. 0 => initialise sequence depending on absolute
c                          value
c                .ge. 0 => get next random number from sequence
c
c  OUTPUT VARIABLES:
c    ran1        deviate with uniform distribution between 0.0 and 1.0
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ia      , im      , iq      , ir      , ntab
     1             , ndiv
       real*8        am      , eps     , rnmx
       parameter   ( ia=16807, im=2147483647, iq=127773, ir=2836,
     1               ntab=32, ndiv=1+(im-1)/ntab )
       parameter   ( am=1.0d0/im, eps=1.2d-7, rnmx=1.0d0-eps )
c
       integer       iseed   , idum    , j       , k       , iy
       real*8        ran1
c
       integer       iv      (ntab)
c
       data          iv      , iy
     1             / ntab*0, 0 /
c
       common      / saveran1 /
     1               idum    , iv      , iy
c
c-----------------------------------------------------------------------
c
       if (iseed .le. 0) idum = iseed
c
c      If sequence is to be initialised, start here ...
c
       if ( (idum .le. 0) .or. (iy .eq. 0) ) then
         idum = max (-idum, 1 )
         do 10 j=ntab+8,1,-1
           k    = idum / iq
           idum = ia * ( idum - k * iq ) - ir * k
           if (idum .lt. 0   ) idum  = idum + im
           if (j    .le. ntab) iv(j) = idum
10       continue
         iy = iv(1)
       endif
c
c      Otherwise, start here ...
c
       k     = idum / iq
       idum  = ia * ( idum - k * iq ) - ir * k
       if (idum .lt. 0) idum = idum + im
       j     = 1 + iy / ndiv
       iy    = iv(j)
       iv(j) = idum
       ran1  = min ( am*iy, rnmx )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  R A N 1                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  R A N 2                  \\\\\\\\\\
c
c=======================================================================
c
       function ran2 ( idum )
c
c    whp:zeus3d.ran2 <----------------- "perfect" uniform random deviate
c    from numerical recipes, ed. 2                            june, 2008
c
c    written by: W. Press et al.
c    modified 1: June, 2008 by DAC; incorporated into dzeus36
c
c  PURPOSE:  This routine returns a "perfect" uniform random deviate 
c  between 0.0 and 1.0 (up to 2 x 10**18 calls).  See Numerical Recipes,
c  ed. 2, pg. 272.  It must be called with a negative seed and then a 
c  positive number from then on.
c
c  INPUT VARIABLES: 
c    idum        .lt. 0 => initialise sequence depending on absolute
c                          value
c                .ge. 0 => get next random number from sequence
c
c  OUTPUT VARIABLES:
c    ran2        deviate with uniform distribution between 0.0 and 1.0
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       im1     , im2     , ia1     , ia2     , iq1
     1             , iq2     , ir1     , ir2     , ntab    , ndiv
       real*8        am      , eps     , rnmx
       parameter   ( im1=2147483563, im2=2147483399, ia1=40014
     1             , ia2=40692, iq1=53668, iq2=52774, ir1=12211
     2             , ir2=3791, ntab=32, ndiv=1+(im1-1)/ntab )
       parameter   ( am=1.0d0/im1, eps=1.2d-13, rnmx=1.0d0-eps )
c
       integer       idum    , idum2   , j       , k       , iy
       real*8        ran2
c
       integer       iv      (ntab)
c
       save          iv      , iy      , idum2
c
       data          idum2   , iv      , iy
     1             / 123456789, ntab*0, 0 /
c
c-----------------------------------------------------------------------
c
c      If sequence is to be initialised, start here ...
c
       if (idum .le. 0) then
         idum  = max (-idum, 1 )
         idum2 = idum
         do 10 j=ntab+8,1,-1
           k    = idum / iq1
           idum = ia1 * ( idum - k * iq1 ) - k * ir1
           if (idum .lt. 0   ) idum  = idum + im1
           if (j    .le. ntab) iv(j) = idum
10       continue
         iy = iv(1)
       endif
c
c      Otherwise, start here ...
c
       k     = idum  / iq1
       idum  = ia1 * ( idum  - k * iq1 ) - k * ir1
       if (idum  .lt. 0) idum  = idum  + im1
       k     = idum2 / iq2
       idum2 = ia2 * ( idum2 - k * iq2 ) - k * ir2
       if (idum2 .lt. 0) idum2 = idum2 + im2
       j     = 1 + iy / ndiv
       iy    = iv(j) - idum2
       iv(j) = idum
       if (iy .lt. 1) iy = iy + im1 - 1
       ran2  = min ( am*iy, rnmx )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  R A N 2                  \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  N O R M                  \\\\\\\\\\
c
c=======================================================================
c
       function norm ( idum )
c
c    whp:zeus3d.norm <--------------------------- returns normal deviate
c    from numerical recipes                               december, 1992
c
c    written by: Press etal.
c    modified 1: December, 1992 by DAC; incorporated into ZEUS3D
c    modified 2: June, 2008 by DAC, upgraded to edition 2.
c
c  PURPOSE:  Returns a normal (Gaussian) deviate with zero mean and unit
c  variance (see Numerical Recipes, 2nd edition for FORTRAN, page 280).
c
c  INPUT VARIABLES:
c    idum        .lt. 0 => initialise sequence depending on absolute
c                          value
c                .ge. 0 => get next random number from sequence
c
c  OUTPUT VARIABLES:
c    norm        normal deviate
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    RAN2
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       idum    , inext
       real*8        norm    , v1      , v2      , rsq     , fact    
     1             , next
c
c      Data statements
c
       data          inext    / 0 /
       save          inext   , next
c
c      External statements
c
       real*8        ran2
       external      ran2
c
c-----------------------------------------------------------------------
c
       if (inext .eq. 0) then
10       continue
         v1    = 2.0d0 * ran2(idum) - 1.0d0
         v2    = 2.0d0 * ran2(idum) - 1.0d0
         rsq   = v1**2 + v2**2
         if ( (rsq .ge. 1.0d0) .or. (rsq .eq. 0.0d0) ) go to 10
         fact  = sqrt ( -2.0d0 * log(rsq) / rsq )
         next  = v1 * fact
         norm  = v2 * fact
         inext = 1
       else
         norm  = next
         inext = 0
       endif
c
       return
       end
c
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  N O R M                  \\\\\\\\\\
c
c=======================================================================
c
c
