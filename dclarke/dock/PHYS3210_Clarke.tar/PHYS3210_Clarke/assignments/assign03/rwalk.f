c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                 R W A L K                 \\\\\\\\\\
c
c=======================================================================
c
       program rwalk
c
c    dac:rwalk <---------------------------------- random walk generator
c                                                            march, 2011
c    written by: David Clarke
c    modified 1: April, 2012 by DAC; added user interface to input npth 
c                and nstp at runtime.
c
c  PURPOSE:  This program embodies the random walk experiment outlined 
c  in the lecture notes for PHYS 3210 (section 7), in which a particle 
c  collides with another particle after every mean-free-path (lambda) at 
c  a randomly selected new direction where "phi" and "costheta" are 
c  selected using a uniform deviate (subroutine RAN2).  The displacement 
c  from the origin as a function of steps taken (1:nstp) is averaged 
c  (using an rms) over all "npth" paths, and the data are written to the 
c  file "rwalk.txt" in a format suitable for gnuplot.  To see the 
c  results, issue the following command within gnuplot:
c
c  plot [0:2500][0:52] "rwalk.txt" u 1:2 w lines, sqrt(x) w lines
c
c  where values npth = 1000, nstp = 2500 have been used.
c
c  If students find they are getting a sqrt(n)-like plot, but about 10% 
c  lower than expected, it is likely they are doing a mean-root-square: 
c
c         are (ns) = are(ns) + sqrt ( eks**2 + why**2 + zed**2 )
c         dave(ns) = are(ns) / dble(npth)
c
c  rather than a proper root-mean-square: 
c
c         dsq (ns) = dsq(ns) + eks**2 + why**2 + zed**2 
c         dave(ns) = sqrt ( dsq(ns) / dble(npth) )
c
c  EXTERNALS:
c    RAN2
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       npmx    , nsmx
       real*8        lambda
       parameter     ( npmx=10000, nsmx=10000, lambda=1.0d0 )
c
       integer       iseed   , npth    , nstp    , m       , n
       real*8        pi      , cpubeg  , cpuend  , cputot  , eks
     1             , why     , zed     , phi     , costheta, sintheta
     2             , dx      , dy      , dz      , dr
c
       real*8        dsq     (nsmx), dave    (nsmx)
c
       real*8        ran2
       external      ran2
c
       data          iseed    / -1 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      As user for "npth" (number of paths) and "nstp" (number of steps 
c  per path), and idiot-proof.
c
       write(6, 2010) npmx, nsmx
       read (5,    *) npth, nstp
       if (npth .gt. npmx) then
         write(6, 2020) npmx
         stop
       endif
       if (nstp .gt. nsmx) then
         write(6, 2030) nsmx
         stop
       endif
c
       pi = acos ( -1.0d0 )
       open ( 10, file='rwalk.txt', status='unknown' )
c
c      Initialise all distance squares to zero.
c
       do 10 n=1,nstp
         dsq(n) = 0.0d0
10     continue
c
c      Compute each path of random walks, where "eks", "why", and "zed" 
c  are the coordinates of the particle as it moves forward a "mean-free 
c  path", then redirected by a random choice of "phi" and "costheta", 
c  each chosen from uniform deviates. 
c
c      "m" is the path number; "n" is the step number.
c
       do 30 m=1,npth
         eks = 0.0d0
         why = 0.0d0
         zed = 0.0d0
         do 20 n=2,nstp
           phi      = 2.0d0 * pi * ran2(iseed)
           costheta = 2.0d0 * ran2(iseed) - 1.0d0
           sintheta = sqrt ( 1.0d0 - costheta**2 )
           eks      = eks + lambda * sintheta * cos(phi)
           why      = why + lambda * sintheta * sin(phi)
           zed      = zed + lambda * costheta
           dsq  (n) = dsq(n) + eks**2 + why**2 + zed**2 
20       continue
30     continue
c
c      Perform root-mean-square averages of distances from the origin at 
c  each step in each path.
c
       do 40 n=1,nstp
         dave(n) = sqrt ( dsq(n) / dble(npth) )
40     continue
c
c      Write a disc file suitable for gnuplot.
c
       do 50 n=1,nstp
         write(10,*) n, dave(n)
50     continue
c
       close(10)
c
c      Report cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2040) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('RWALK   : Enter desired number of paths (.le. ',i5
     1       ,') and number of steps per',/
     2       ,'RWALK   : path (.le. ',i5,').')
2020   format('RWALK   : |----ERROR----> Number of paths must be .le. '
     1       ,'npmx = ',i5,', or program',/
     2       ,'RWALK   : must be recompiled with higher value of npmx. '
     3       ,'Abort!')
2030   format('RWALK   : |----ERROR----> Steps per paths must be .le. '
     1       ,'nsmx = ',i5,', or program',/
     2       ,'RWALK   : must be recompiled with higher value of nsmx. '
     3       ,'Abort!')
2040   format('RWALK   : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                 R W A L K                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                  R A N 2                  \\\\\\\\\\
c
c=======================================================================
c
       function ran2 ( idum )
c
c    whp:zeus3d.ran2 <----------------- "perfect" uniform random deviate
c    from numerical recipes, ed. 2                            june, 2008
c
c    written by: W. Press et al.
c    modified 1: June, 2008 by DAC; incorporated into dzeus36
c
c  PURPOSE:  This routine returns a "perfect" uniform random deviate 
c  between 0.0 and 1.0 (up to 2 x 10**18 calls).  See Numerical Recipes,
c  ed. 2, pg. 272.  It must be called with a negative seed and then a 
c  positive number from then on.
c
c  INPUT VARIABLES: 
c    idum        .lt. 0 => initialise sequence depending on absolute
c                          value
c                .ge. 0 => get next random number from sequence
c
c  OUTPUT VARIABLES:
c    ran2        deviate with uniform distribution between 0.0 and 1.0
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       im1     , im2     , ia1     , ia2     , iq1
     1             , iq2     , ir1     , ir2     , ntab    , ndiv
       real*8        am      , eps     , rnmx
       parameter   ( im1=2147483563, im2=2147483399, ia1=40014
     1             , ia2=40692, iq1=53668, iq2=52774, ir1=12211
     2             , ir2=3791, ntab=32, ndiv=1+(im1-1)/ntab )
       parameter   ( am=1.0d0/im1, eps=1.2d-13, rnmx=1.0d0-eps )
c
       integer       idum    , idum2   , j       , k       , iy
       real*8        ran2
c
       integer       iv      (ntab)
c
       save          iv      , iy      , idum2
c
       data          idum2   , iv      , iy
     1             / 123456789, ntab*0, 0 /
c
c-----------------------------------------------------------------------
c
c      If sequence is to be initialised, start here ...
c
       if (idum .le. 0) then
         idum  = max (-idum, 1 )
         idum2 = idum
         do 10 j=ntab+8,1,-1
           k    = idum / iq1
           idum = ia1 * ( idum - k * iq1 ) - k * ir1
           if (idum .lt. 0   ) idum  = idum + im1
           if (j    .le. ntab) iv(j) = idum
10       continue
         iy = iv(1)
       endif
c
c      Otherwise, start here ...
c
       k     = idum  / iq1
       idum  = ia1 * ( idum  - k * iq1 ) - k * ir1
       if (idum  .lt. 0) idum  = idum  + im1
       k     = idum2 / iq2
       idum2 = ia2 * ( idum2 - k * iq2 ) - k * ir2
       if (idum2 .lt. 0) idum2 = idum2 + im2
       j     = 1 + iy / ndiv
       iy    = iv(j) - idum2
       iv(j) = idum
       if (iy .lt. 1) iy = iy + im1 - 1
       ran2  = min ( am*iy, rnmx )
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                  R A N 2                  \\\\\\\\\\
c
c=======================================================================
c
c
