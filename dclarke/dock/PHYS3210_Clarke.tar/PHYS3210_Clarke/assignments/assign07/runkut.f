c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                R U N K U T                \\\\\\\\\\
c
c=======================================================================
c
       program runkut
c
c    abcd:runkut <------------- adaptive step-size nth-order Runge-kutta
c                                                            april, 2004
c
c    written by: A Busy Code Developer
c    modified 1: May, 2017 by ABCD; added problem 6 to demonstrate how 
c                the RK method can be used to solve two simultaneous 
c                first order ODEs (as opposed to the two first order
c                ODEs one creates from a second order ODE to solve 
c                that); adaptation realised by Michael Power, class of 
c                '18.  The only changes needed are in DERIVS; see 
c                comments for problem 6.
c
c  PURPOSE:  This program combines Richardson Extrapolation and adaptive
c  grid ideas with the basic Runge-Kutta ODE algorithm to solve a 
c  general nth order ODE
c
c         (n)                              (n-1)
c        y   (x) = f (x, y, y', y'', ..., y     )
c
c  which has been decomposed into n coupled first order ODEs as follows:
c
c        y '   = y
c         1       2
c
c        y '   = y
c         2       3
c              .
c              .
c              .
c
c        y   ' = y
c         n-1     n
c
c        y '   = f(x, y , y , ..., y   , y )
c         n            1   2        n-1   n
c
c  The desired solution is then stored in y_1, with all remaining 
c  components of y being the successively higher derivatives.
c
c  The highest order ODE this routine can solve is set by the parameter
c  nmax.  
c
c  The variable nord is set to the order of the ODE being solved.
c
c  This routine writes the results as a table of numbers to file 
c  runkut.dat.  To view the solution with GNUPLOT, issue the command:
c
c  plot [xmin:xmax][ymin:ymax] "runkut.dat" u 1:2 w lines
c
c  To view the ith derivative with GNUPLOT, issue the command:
c
c  plot [xmin:xmax][ymin:ymax] "runkut.dat" u 1:i+2 w lines
c
c  EXTERNALS:
c    RK
c
c-----------------------------------------------------------------------
c
       implicit      none
c
c  imax = maximum number of points at which y(x) is to be evaluated.
c  nmax = highest order of differential equation to be solved.
c
       integer       imax    , nmax
       real*8        errmax  , tiny
       parameter     ( imax=10000, nmax=9, errmax=1.0d-5
     1               , tiny=1.0d-99 )
c
       character*12  frmt
       integer       nwarn   , i       , n       , ipts    , nord
     1             , iprob
       real          cputot  , etime
       real*8        xmin    , xmax    , dx      , dxmin   , dxhalf  
     1             , xleft   , xmid    , xright  , err     , errn
c
       real          tdummy  (   2)
       real*8        x       (imax), y0      (nmax), yleft   (nmax)
     1             , ymid    (nmax), yright  (nmax), ytwid   (nmax)
     2             , ystar   (nmax), tmp1    (nmax), tmp2    (nmax)
     3             , tmp3    (nmax), tmp4    (nmax)
c
       real*8        y       (imax,nmax)
c
       common      / comvari  /
     1               nord    , iprob
c
       external      rk
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       cputot = etime ( tdummy )
c
c      Ask user for which problem is to be solved, domain over which ODE
c  is to be solved, the order of the ODE being solved, and the left 
c  boundary condition.
c
       write (6,2010)
       read  (5,   *) iprob
       if ( (iprob .lt. 1) .or. (iprob .gt. 6) ) iprob = 0
10     continue
       write (6,2020) nmax
       read  (5,   *) nord
       if (nord .gt. nmax) then
         write (6,2030) nmax
         go to 10
       endif
       write (6,2040)
       read  (5,   *) xmin, xmax
       write (6,2050) nord
       read  (5,   *) (y0(n), n=1,nord)
c
c      Initial values for step size and other variables.
c
       dx    = 0.1d0 * errmax * ( xmax - xmin )
       dxmin = 1.0d-3 * dx
       nwarn = 0
       i     = 1
       x(1)  = xmin
       xleft = xmin
       do 20 n=1,nord
         y  (1,n) = y0(n)
         yleft(n) = y0(n)
20     continue
c
c------start of adaptive loop-------------------------------------------
c
30     continue
       xright = min ( xleft + dx, xmax )
       dx     = xright - xleft
       dxhalf = 0.5d0 * dx
       xmid   = xleft + dxhalf
c
c      Runge-Kutta integrates yleft by a full step to ytwid, then again 
c  by two half steps to ystar.
c
       call rk ( xleft, yleft, ytwid, tmp1, tmp2, tmp3, tmp4, dx     )
       call rk ( xleft, yleft, ymid , tmp1, tmp2, tmp3, tmp4, dxhalf )
       call rk ( xmid , ymid , ystar, tmp1, tmp2, tmp3, tmp4, dxhalf )
c
c      Evaluate yright (y at the right side of the interval) using 
c  Richardson extrapolation on ytwid and ystar, then estimate the error.
c
       err = 0.0d0
       do 40 n=1,nord
         yright(n) = ( 16.0d0 * ystar(n) - ytwid(n) ) / 15.0d0
         errn      = abs ( ( yright(n) - ystar(n) )
     1                   / ( ( yright(n) + ystar(n) ) + tiny ) ) * 2.0d0
         err       = max ( err, errn )
40     continue
c
c      If the error is much smaller than needed, increase the step size 
c  for next time (but don't redo integration). 
c 
       if ( err .lt. 0.1d0*errmax ) dx = 1.5d0 * dx
c
c      If the error is too large, repeat iteration with half the step
c  size.  Note that dx is prevented from falling below dxmin, so that a
c  spiralling infinite loop is avoided.
c
       if ( err .gt. errmax ) then
         if (dxhalf .ge. dxmin) then
           dx = dxhalf
           go to 30
         else
           write (6,2060) xleft, dxmin, err
           nwarn = nwarn + 1
         endif
       endif
c
c      If execution arrives here, "yright" has been integrated to within 
c  error tolerance and is stored in the solution array "y".  "xright" is 
c  correspondingly stored in the independent variable array "x".  The
c  left-values ("xleft", "yleft") are then shifted to the right-values
c  ("xright", "yright") in preparation for the next iteration.  If 
c  xleft = xmax, the right side of the specified domain has been reached 
c  and the main loop is exited.
c
       i = i + 1
       if (i .le. imax) then
         do 50 n=1,nord
           y  (i,n) = yright(n)
           yleft(n) = yright(n)
50       continue
         x(i)  = xright
         xleft = xright
         if (xleft .lt. xmax) go to 30
       else
c
c      If execution arrives here, RK is taking more steps than number of 
c  points allowed by "imax".  This may be a problem of convergence, or 
c  simply that "imax" isn't high enough.  A warning is issued suggesting 
c  the latter, and the loop is exited.
c
         write (6,2070) xleft, imax
         nwarn = nwarn + 1
       endif
c
c------end of adaptive loop---------------------------------------------
c
c      Store solution in a format plotable by gnuplot.
c
       write ( frmt, 2080 ) nord + 1
       ipts = i
       open  ( 10, file='runkut.dat', status='unknown' )
       do 60 i=1,ipts
         if (iprob .eq. 2) y(i,1) = y(i,1) - cos(x(i))
         if (iprob .eq. 5) y(i,1) = exp(y(i,1))
         write ( 10, frmt ) x(i), (y(i,n),n=1,nord)
60     continue
       close ( 10 )
       write ( 6, 2170 ) ipts, nwarn
c
c      End CPU time counter, and report cpu time used.
c
       cputot = etime ( tdummy ) - cputot
       write (6,2180) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('RUNKUT  : Enter problem selection:',/
     1       ,'RUNKUT  : 0  =>  user-specified ODE in DERIVS;',/
     2       ,'RUNKUT  : 1  =>  sphere falling in viscous air '
     3       ,'(1, 0, 15, 0);',/
     4       ,'RUNKUT  : 2  =>  SHO with residuals stored '
     5       ,'(2, 0, 18.8, 1, 0);',/
     6       ,'RUNKUT  : 3  =>  Van der Pols oscillator '
     7       ,'(2, 0, 25.1, 0.5, 0);',/
     8       ,'RUNKUT  : 4  =>  Bonnor-Ebert sphere with y(1) = rho '
     9       ,'(2, 0, 10, 1, 0);',/
     1       ,'RUNKUT  : 5  =>  Bonnor-Ebert sphere with y(1) = '
     2       ,'exp(rho) (2, 0, 10, 0, 0).',/
     1       ,'RUNKUT  : 6  =>  ambipolar diffusive MHD c-shock '
     2       ,'(2, 0, 1.2d6, 0.0004, 0.70715).')
2020   format('RUNKUT  : Enter the order of the ODE (<',i2,').')
2030   format('RUNKUT  : The order of the ODE must be less than ',i2
     1       ,'.  Try again, or <ctrl C> to',/
     2       ,'RUNKUT  : abort and recompile with a larger value for '
     3       ,'nmax.')
2040   format('RUNKUT  : Enter "xmin" and "xmax", the domain of '
     1       ,'integration.')
2050   format('RUNKUT  : Enter the left-hand boundary conditions, the '
     1       ,'first for the function',/
     2       ,'RUNKUT  : and the remainder for the ever-successive '
     3       ,'derivatives (',i2,' entries).')
2060   format('RUNKUT  : ***WARNING*** At x = ',1pg10.3,', dx was '
     1       ,'prevented from falling below ',/
     2       ,'RUNKUT  : dxmin = ',g10.3,' where solution error = '
     3       ,g10.3,'.')
2070   format('RUNKUT  : ***WARNING*** Execution terminated before '
     1       ,'specified domain completed.',/
     2       ,'RUNKUT  : Solution stored to x = ',1pg10.3,' only.  '
     3       ,'Recompile with imax > ',i6,'.')
2080   format("(1p",i2.2,"g23.15)")
2170   format('RUNKUT  : Number of data points stored in '
     1       ,'"runkut.dat": ',i4,' with ',i3,' warnings.')
2180   format('RUNKUT  :',/
     1       ,'RUNKUT  : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                R U N K U T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                    R K                    \\\\\\\\\\
c
c=======================================================================
c
       subroutine rk ( x0, y0, y1, f0, fhtwid, fh, f1twid, h )
c
c    abcd:runkut.rk <-------------- performs the Runge-kutta integration
c                                                            april, 2004
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the basic Runge-Kutta ODE algorithm
c  to advance the solution forward by a single step.
c
c  INPUT VARIABLES:
c    x0         independent variable  at the left  side of the interval
c    y0         dependent   variables at the left  side of the interval
c    nord       order of the ODE
c    h          step size
c
c  OUTPUT VARIABLES:
c    y1         dependent   variables at the right side of the interval
c
c  LOCAL VARIABLES:
c    f0         temporary 1-D arrays dimensioned to nmax by the calling 
c    fhtwid     routine for storing the interim derivatives.
c    fh 
c    f1twid
c
c  EXTERNALS:
c    DERIVS
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       n       , nord    , iprob
       real*8        x0      , h       , halfh   , xh      , x1      

       real*8        y0      (   *), y1      (   *), f0      (   *)
     1             , fhtwid  (   *), fh      (   *), f1twid  (   *)
c
       common      / comvari  /
     1               nord    , iprob
c
       external      derivs
c
c-----------------------------------------------------------------------
c
       halfh = 0.5d0 * h
       xh    = x0 + halfh
       x1    = x0 + h
c
c      Evaluate derivatives and update y1 at each quarter step.
c
       call derivs ( x0, y0, f0 )
       do 10 n=1,nord
         y1(n) = y0(n) + halfh * f0(n)
10     continue
c
       call derivs ( xh, y1, fhtwid )
       do 20 n=1,nord
         y1(n) = y0(n) + halfh * fhtwid(n)
20     continue
c
       call derivs ( xh, y1, fh )
       do 30 n=1,nord
         y1(n) = y0(n) + h * fh(n)
30     continue
c
       call derivs ( x1, y1, f1twid )
       do 40 n=1,nord
         y1(n) = y0(n) + h * ( f0(n) + 2.0d0 * ( fhtwid(n) + fh(n) )
     1                       + f1twid(n) ) / 6.0d0
40     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                    R K                    \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                D E R I V S                \\\\\\\\\\
c
c=======================================================================
c
       subroutine derivs ( x, y, yp )
c
c    abcd:runkut.derivs <--------------------- evaluates the derivatives
c                                                            april, 2004
c
c    written by: A Busy Code Developer
c    modified 1: May, 2017 by ABCD; added problem 6; see header for main 
c                program.
c
c  PURPOSE:  For a general nth order ODE of the form
c
c         (n)                              (n-1)
c        y   (x) = f (x, y, y', y'', ..., y     )
c
c  this routine returns the values of all the decomposed derivatives 
c  evaluated at x, namely:
c
c        y '   = y
c         1       2
c
c        y '   = y
c         2       3
c              .
c              .
c              .
c
c        y   ' = y
c         n-1     n
c
c        y '   = f(x, y , y , ..., y   , y )
c         n            1   2        n-1   n
c
c  INPUT VARIABLES:
c    x          independent variable where derivatives are evaluated
c    y          1-D array of the dependent variable and its derivatives,
c               where y(1) is the function itself, y(2) is the first 
c               derivative, ..., y(nord) is the (nord-1)th derivative.
c    nord       order of ODE being solved
c
c  OUTPUT VARIABLES:
c    yp         1-D array of derivatives from the equations above, where
c               yp(1) is the first derivative, yp(2) is the second 
c               derivative, ..., yp(nord) is the (nord)th derivative.
c
c  EXTERNALS: [NONE]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nord    , n       , iprob
       real*8        x       , tiny    
c
c      For problem 6 (C-shock solution).
c
       real*8        b0      , gammaad , theta   , rhoi0   , rhon0
     1             , p0      , vs      , lambdan0, epsilon , aye
     1             , gamma   , gamm1   , sn      , rn      , are
     1             , gn      , lambdan
c
       real*8        y       (   *), yp      (   *)
c
       common      / comvari  /
     1               nord    , iprob
c
       data          tiny     / 1.0d-99 /
c
c-----------------------------------------------------------------------
c
c      Start by setting all derivatives in "yp" to input values of "y".
c
       if (nord .ge. 2) then
         do 10 n=1,nord-1
           yp(n) = y(n+1)
10       continue
       endif
c
c      Then, what distinguishes one differential equation from another 
c  is the function used to set the highest order derivative in the 
c  equation.  The first five "problems" are those posed in Assignment 6 
c  of PHYS 3210.  The sixth problem was never assigned in PHYS 3210, but 
c  added to demonstrate how the method can be used for two independent 
c  yet coupled first order ODEs.  At the very bottom (iprob=0), the user 
c  can specify the appropriate function for a different diff eq.
c
c------------------------------ problem 1 ------------------------------
c
c      A sphere of mass m=0.01 kg falling under the influence of gravity
c  with drag coefficient 0.0001.  Use domain [0,15], with y0=0.0 and
c  nord=1.  To plot, type inside gnuplot:
c
c  plot [0:15][0:35] "runkut.dat" u 1:2 w lines
c
       if (iprob .eq. 1) yp(1) = 9.81d0 - 0.01d0 * y(1)**2
c
c------------------------------ problem 2 ------------------------------
c
c      A SHO.  Use domain [0,6*pi] = [0,18.8] with y(0)=1, y'(0)=0 
c  (cosine function), and nord=2.  To plot residuals, type inside 
c  gnuplot:
c
c  plot [0:18.8][-1.0e-5:1.0e-5] "runkut.dat" u 1:2 w lines
c
       if (iprob .eq. 2) yp(2) = -y(1)
c
c------------------------------ problem 3 ------------------------------
c
c      A Van der Pol oscillator, with epsilon=1.  Use domain [0,8*pi] = 
c  [0,25.1] with y(0)=0.5, y'(0)=0.0, nord=2.  To plot, type inside 
c  gnuplot:
c
c  plot [0:25.1][-2.5:2.5] "runkut.dat" u 1:2 w lines
c
       if (iprob .eq. 3) yp(2) = -y(1) - ( y(1)**2 - 1.0d0 ) * y(2)
c
c------------------------------ problem 4 ------------------------------
c
c      A Bonnor-Ebert sphere where rho = y(1).  Use domain [0,10] with 
c  y(0) = 1, y'(0)=0, nord=2.  To plot, type inside gnuplot:
c
c  plot [0:10][0:1.1] "runkut.dat" u 1:2 w lines
c
       if (iprob .eq. 4) 
     1   yp(2) =-y(1)**2 - 2.0d0 * y(2) / ( x + tiny )
     2         + y(2)**2 / ( y(1) + tiny )
c
c------------------------------ problem 5 ------------------------------
c
c      A Bonnor-Ebert sphere where rho = exp(y(1)).  Use domain [0,10] 
c  with y(0) = 0, y'(0)=0, nord=2.  To plot rho, type inside gnuplot:
c
c  plot [0:10][0:1.1] "runkut.dat" u 1:2 w lines
c
       if (iprob .eq. 5) 
     1   yp(2) =-dexp ( y(1) ) - 2.0d0 * y(2) / ( x + tiny )
c
c------------------------------ problem 6 ------------------------------
c
       if (iprob .eq. 6) then
c
c      This is the "continuous shock" (C-shock) problem for MHD with 
c  ambipolar diffusion, and is an example of how the Runge-Kutta method
c  can be used to solve two simultaneous first order ODEs, with the
c  "order" of the differential equation acting proxy for the number of
c  independent first order ODEs to be solved.  In principle, M Nth 
c  order ODES can be solved simultaneously by turning "y" into a 3-D 
c  array, with the equation number being the third index, and all loops 
c  over "nord" being put inside another loop over "neqn" (number of 
c  equations).
c
c  This is the only place where the fact that "nord" is being 
c  interpreted as the number of equations makes any difference to the 
c  coding, where yp(1)--yp(nord-1) are set to the first derivative 
c  functions of the first nord-1 equations, rather than by do-loop 10 
c  above (whose effect is simply overwritten in what follows).
c
c  For this problem, set xmin, xmax = 0.0 1.2e6, nord=2, and the 
c  "Cauchy" BC to 0.0004 0.707142137 [1.00005/sqrt(2)].
c
         b0       = 1.0d0 / sqrt(2.0d0)
         p0       = 4.0d-4
         gammaad  = 1.0d0
         theta    = acos(-1.0d0) / 4.0d0
         rhoi0    = 1.0d-5
         rhon0    = 1.0d0
         vs       = 5.0d0
         lambdan0 = 5.0d-5
         epsilon  = 5.0d1
         aye      = 5.0d0
         gamma    = 1.4d0
         gamm1    = gamma - 1.0d0
         sn       = ( y(2) - b0 ) * ( cos(theta) / aye )**2 
         rn       = 1.0d0 / ( 1.0d0 - y(1) + p0
     1                      - 0.5d0 * ( y(2)**2 - b0**2 ) / aye**2 )
         are      = 1.0d0
     1            - ( y(2) * rn * ( sn + sin(theta) ) + cos(theta)**2 )
     1            / ( y(2)**2 + cos(theta)**2 )   
         gn       = gammaad * rhon0 * rhoi0 * ( vs * are )**2
     1            * ( y(2)**2 + cos(theta)**2 ) / ( y(2)**2 * rn )
c
         if (y(1) .gt. epsilon*p0) then
           lambdan = lambdan0 * gammaad * rhoi0 * ( y(1) / P0 )**3 / vs
         else
           lambdan = 0.0d0
         endif  
c   
         yp(1) = gammaad * gamm1 * rn * rhoi0
     2         * ( ( 1.0d0 / rn + gamma * y(1) / gamm1
     4             - ( sn + sin(theta) ) / y(2) ) * are
     5           + ( gn - lambdan )
     6             / ( gammaad * rhoi0 * rhon0 * vs**2 ) )
     1         / ( ( 1.0d0 - gamma * rn * y(1) ) * vs )
c
         yp(2) = gammaad * rhoi0 * aye**2 * are / ( y(2) * vs )
       endif
c
c------------------------------ problem 0 ------------------------------
c
       if (iprob .eq. 0) then
         yp(nord) = x
       endif
c
c-----------------------------------------------------------------------
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                D E R I V S                \\\\\\\\\\
c
c=======================================================================
c
c
