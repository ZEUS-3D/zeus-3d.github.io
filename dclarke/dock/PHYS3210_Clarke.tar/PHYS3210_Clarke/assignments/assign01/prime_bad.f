      program main
      open(10,file='main.txt',status='unknown')
      write(6,8)
8     format('Enter nmax')
      read(5,*)nmax
      m=0
      do 9 n=2,nmax
      ii=1
      r=float(n)
      s=sqrt(r)
      imax=int(s+.0001)
      do 1 i=2,imax
      q=r/float(i)
      num=i*int(q+.0001)
      if(num.eq.n)then
      ii=0
      goto 1
      endif
1     continue
      if(ii.eq.1)then
      m=m+1
      write(6,17)n
      write(10,17)n
17    format(i9)
      endif
9     continue
      write(6,3)m
      write(10,3)m
3     format(/,'m=',i4)
      close(10)
      stop
      end
