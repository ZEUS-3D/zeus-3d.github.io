c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                 P R I M E                 \\\\\\\\\\
c
c=======================================================================
c
       program prime
c
c    abcd:prime <--------------------- lists all prime numbers .le. nmax
c                                                        september, 2001
c
c    written by: A Busy Code Developer
c    modified 1: by ADCD, October 2001; modularised program by placing 
c                the coding that searches for divisors into a separate 
c                subroutine.
c
c  PURPOSE:  This routine generates all prime numbers less than or equal
c  to the input integer, and reports these in a list printed both to the
c  screen and a datafile.
c
c  EXTERNALS:
c    DIVISOR
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*9   filename
       logical       lflag
       integer       nmax    , icount  , n
       real          cpubeg  , cpuend  , cputot     
c
       external      divisor 
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Open disc file.
c
       filename = 'prime.txt'
       open (10, file=filename, status='unknown')
c
c      Input parameter `nmax', and write opening line to standard output
c  and `filename'.
c
       write( 6,2010)
       read ( 5,   *) nmax
       write( 6,2011) nmax, filename
       write(10,2020) nmax
c
c      Loop over all integers .le. nmax, and report all the prime 
c  numbers.
c
       icount = 0
c      do 10 n=2,nmax
       do 10 n=3,nmax,2
         call divisor ( n, lflag )
         if (lflag .eqv. .true.) then
           icount = icount + 1
           write(10,2030) n
         endif
10     continue
       write( 6,2040) icount, nmax
       write(10,2040) icount, nmax
c
       close ( 10 )
c
c      End CPU time counter, and report time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write( 6,2050) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('PRIME   : Enter the maximum integer to be checked for '
     1       ,'prime numbers.')
2011   format('PRIME   : All prime numbers less than or equal to ',i4
     1       ,' are listed in file ',/
     2       ,'PRIME   : ''',a9,'''.')
2020   format('PRIME   : The following is a list of all prime numbers '
     1       ,'.le. ',i8,'.',/
     2       ,'PRIME   :')
2030   format('PRIME   : ',i9)
2040   format('PRIME   :',/
     1       ,'PRIME   : There are ',i8,' prime numbers less than or '
     2       ,'equal to ',i8,'.')
2050   format('PRIME   :',/
     1       ,'PRIME   : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                 P R I M E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////               D I V I S O R               \\\\\\\\\\
c
c=======================================================================
c
       subroutine divisor ( number, lflag )
c
c    abcd:prime.divisor <---------- determines if input has any divisors
c                                                          october, 2001
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine searches the input number for any divisors 
c  other than 1 and itself.
c
c  INPUT VARIABLES:
c    number       integer for which divisors are sought
c
c  OUTPUT VARIABLES:
c    lflag        = .false. if a divisor is found
c                 = .true.  if no divisors are found
c
c  EXTERNALS:  [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       logical       lflag
       integer       number  , imax    , i       , num
       real          rnum    , sqrtnum , small   , qty
c
       data          small    / 0.0001 /
c
c-----------------------------------------------------------------------
c
       lflag = .true.
       if (number .le. 3) return
c
c      The maximum divisor that needs to be checked is the greatest 
c  integer less than or equal to the square root of the number (`imax').
c  The lowest divisor is 2.  Thus, check all divisors between 2 and 
c  `imax'.  As soon as one divisor is found, set `lflag' to .false., 
c  (i.e., "number" is not prime) and return to the calling program.
c
       rnum    = real ( number )
       sqrtnum = sqrt ( rnum )
       imax    = int  ( sqrtnum + small )
       do 10 i=3,imax,2
         qty = rnum / real ( i )
         num = i * int ( qty + small )
         if ( num .eq. number ) then
           lflag = .false.
           return
         endif
10     continue
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////               D I V I S O R               \\\\\\\\\\
c
c=======================================================================
