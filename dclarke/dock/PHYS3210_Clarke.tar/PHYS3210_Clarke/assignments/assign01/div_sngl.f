c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////              D I V I S O R S              \\\\\\\\\\
c
c=======================================================================
c
       program divisors
c
c    abcd:divisors <---------------- lists all divisors of input integer
c                                                         november, 2001
c
c    written by: A Busy Code Developer
c    modified 1: by ABCD, January 2011; modified for gfortran
c
c  PURPOSE:  This routine generates a list of all unique divisors for a 
c  given input integer, other than 1 and itself.
c
c  The divisors, i1, i2, etc, of an integer n are each prime numbers 
c  such that
c
c        n = i1 * i2 * ...
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*12  filename
       integer       n       , m       , enn
       real          cpubeg  , cpuend  , cputot     
       real          small   , realn   , sqrtn   , delm    , qty     
c
       data          small    / 1.0e-13 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Open disc file.
c
       filename = 'divisors.txt'
       open (10, file=filename, status='unknown')
c
c      Input integer `n', and write opening line to standard output and
c  `filename'.
c
       write( 6,2010)
       read ( 5,   *) n
       write( 6,2020) n
       write(10,2020) n
c
c      This is a case where a formal do-loop is impractical.  The 
c  algorithm I use is to start by dividing the input number n by m=2.  
c  If 2 goes into n evenly, I replace n with n/2, and then set 
c  m = m-1 = 1 so that at the top of the loop where m is increased by
c  delm (which is still 1), m=2 can be tried again.  m=2 is tried as 
c  often as it takes to get the ratio not divisible by 2.  Once 2 no 
c  longer works as a divisor, 3 is tried (at which point delm is 
c  increased to 2, so that no further even numbers are tried), then 5, 
c  then 7, then 9 (which won't work because all factors of 3 have been 
c  divided out), then 11, etc., until m reaches sqrt(n).  Once all 
c  divisors have been divided out and n has been divided down to 1, the 
c  loop is exited. 
c
c      Note the use of double precision, necessary to keep all ten 
c  digits of the largest integer intact.  Without double precision, the 
c  largest integer that can be decomposed is a seven-digit integer.
c
       realn = real(n)
       sqrtn = int ( sqrt ( realn ) )
       delm  = 1
       m     = 1
10     continue
         m   = m + delm
         if ( m .gt. 2     ) delm = 2
         if ( m .gt. sqrtn ) then
           write( 6,2030) n
           write(10,2030) n
           go to 20
         endif
         qty = realn / real ( m )
         enn = m * int ( qty + small )
         if ( enn .eq. n ) then
           write( 6,2030) m
           write(10,2030) m
           n     = n / m
           if (n .eq. 1) go to 20
           realn = real ( n )
           m     = m - delm
         endif
       go to 10
20     continue
c
       close ( 10 )
c
c      End CPU time counter, and report time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write( 6,2040) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('DIVISORS: Enter the integer to be decomposed to '
     1       ,'divisors.')
2020   format('DIVISORS: The following is a list of all divisors of '
     1       ,i10,'.')
2030   format('DIVISORS: ',i9)
2040   format('DIVISORS:',/
     1       ,'DIVISORS: Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////              D I V I S O R S              \\\\\\\\\\
c
c=======================================================================
