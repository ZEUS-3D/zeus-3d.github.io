       program averages
       implicit none
       real     x1, x2, xaves, xavef, sum
       external average, sum
       read(5,*) x1, x2
       call average (x1, x2, xaves)
       xavef = 0.5 * sum (x1, x2)
       write(6,"('xaves, xavef = ',1p2g12.5)") xaves, xavef
       stop
       end
c
       subroutine average (eks1, eks2, ave)
       implicit none
       real     eks1, eks2, ave
       ave = 0.5 * ( eks1 + eks2 )
       return
       end
c
       function sum (x1, x2)
       implicit none
       real     x1, x2, sum
       sum = x1 + x2
       return
       end
