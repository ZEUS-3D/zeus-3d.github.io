c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                S P L I N E                \\\\\\\\\\
c
c=======================================================================
c
       program spline
c
c    abcd:spline <------------------------------------- cubic spline fit
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c========== VERSION WITH BUILT-IN BUGS FOR DBX DEMO (CSINIT) ===========
c
c  PURPOSE:  This program performs a cubic spline fit to the Bessel 
c  function J1(x).  Both a clamped spline and natural spline are 
c  performed, and data are dumped to the disc file "spline.dat".  In 
c  addition, several clamped splines with incorrect derivatives at the 
c  starting point are attempted, and these data are dumped to the disc
c  file "bogus.dat".
c
c  To plot the data from "spline.dat" with gnuplot, use:
c
c  plot [0:10]"spline.dat"u 1:2 w lines, 0    for the natural spline
c  plot [0:10]"spline.dat"u 1:3 w lines, 0    for the clamped spline
c  plot [0:10]"spline.dat"u 1:4 w lines, 0    for their difference
c
c  To plot the data from "bogus.dat" with gnuplot, use (all one line):
c
c  plot [0:10] "bogus.dat" u 1:2 w lines, "bogus.dat" u 1:3 w lines, "bogus.dat" u 1:4 w lines, "bogus.dat" u 1:5 w lines, "bogus.dat" u 1:6 w lines, "bogus.dat" u 1:7 w lines, 0
c
c  EXTERNALS:
c    CSINIT
c    NSINIT
c    SPLINT
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim    , idim    
       real*8        err     
       parameter     ( ndim=11, idim=101, err=1.0d-6 )
c
       integer       i       
       real          cpubeg  , cpuend  , cputot     
       real*8        dx      , xint    , j1n     , j1c     , j11    
     1             , j12     , j13     , j14     , j15     , j16     
c
       real*8        j1p     (   2)
       real*8        j0      (ndim), j1      (ndim), j2      (ndim)
     1             , j1ppn   (ndim), j1ppc   (ndim), x       (ndim)
     1             , q1      (ndim), q2      (ndim), q3      (ndim)
     2             , q4      (ndim), q5      (ndim), q6      (ndim)
c
       real*8        splint
       external      csinit  , nsinit  , splint  
c
       data          x
     1             / 0.0000000000d0, 1.0000000000d0, 2.0000000000d0
     2             , 3.0000000000d0, 4.0000000000d0, 5.0000000000d0
     3             , 6.0000000000d0, 7.0000000000d0, 8.0000000000d0
     4             , 9.0000000000d0, 1.0000000000d1 /
       data          j0
     1             / 1.0000000000d0, 0.7651976866d0, 0.2238907791d0
     2             ,-0.2600519549d0,-0.3971498099d0,-0.1775967713d0
     3             , 0.1506452573d0, 0.3000792705d0, 0.1716508071d0
     4             ,-0.0903336112d0,-0.2459357645d0 /
       data          j1
     1             / 0.0000000000d0, 0.4400505857d0, 0.5767248078d0
     2             , 0.3390589585d0,-0.0660433280d0,-0.3275791376d0
     3             ,-0.2766838581d0,-0.0046828235d0, 0.2346363469d0
     4             , 0.2453117866d0, 0.0434727462d0 /
       data          j2
     1             / 0.0000000000d0, 0.1149034849d0, 0.3528340286d0
     2             , 0.4860912606d0, 0.3641281459d0, 0.0465651163d0
     3             ,-0.2428732100d0,-0.3014172201d0,-0.1129917204d0
     4             , 0.1448473415d0, 0.2546303137d0 /
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
       dx   = 10.0d0 / dble ( idim - 1 )
c
c      Open disc file "spline.dat" and write header.
c
       open  ( 10, file='spline.dat', status='unknown' )
       write ( 10, 2010 )
c
c      Initialise the second derivatives for the natural spline.
c
       call nsinit ( x, j1, j1ppn, ndim )
c
c      Initialise the second derivatives for the clamped spline.
c
       j1p(1) = 0.5d0 * ( j0(   1) - j2(   1) )
       j1p(2) = 0.5d0 * ( j0(ndim) - j2(ndim) )
       call csinit ( x, j1, j1p, j1ppc, ndim )
c
c      Tabulate interpolated values of J1(x) using the natural spline, 
c  the clamped spline, and the differences between the two splines.
c
       xint = 0.0d0
       do 10 i=1,idim
         j1n  = splint ( xint, x, j1, j1ppn, ndim ) 
         j1c  = splint ( xint, x, j1, j1ppc, ndim ) 
         write ( 10, 2020 ) xint, j1n, j1c, j1n-j1c
         xint = xint + dx
10     continue
       close ( 10 )
c
c     Open disc file "bogus.dat" and write header.
c
       open  ( 10, file='bogus.dat', status='unknown' )
       write ( 10, 2030 )
c
c      Try changing J1'(0) and see what difference it makes to the 
c  overall interpolation.
c
       j1p(1) =-2.0d0
       call csinit ( x, j1, j1p, q1, ndim )
       j1p(1) =-1.0d0
       call csinit ( x, j1, j1p, q2, ndim )
       j1p(1) = 0.0d0
       call csinit ( x, j1, j1p, q3, ndim )
       j1p(1) = 1.0d0
       call csinit ( x, j1, j1p, q4, ndim )
       j1p(1) = 2.0d0
       call csinit ( x, j1, j1p, q5, ndim )
       j1p(1) = 3.0d0
       call csinit ( x, j1, j1p, q6, ndim )
       xint   = 0.0d0
       do 20 i=1,idim
         j11  = splint ( xint, x, j1, q1, ndim ) 
         j12  = splint ( xint, x, j1, q2, ndim ) 
         j13  = splint ( xint, x, j1, q3, ndim ) 
         j14  = splint ( xint, x, j1, q4, ndim ) 
         j15  = splint ( xint, x, j1, q5, ndim ) 
         j16  = splint ( xint, x, j1, q6, ndim ) 
         write ( 10, 2040 ) xint, j11, j12, j13, j14, j15, j16
         xint = xint + dx
20     continue
       close ( 10 )
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2050) cputot
c
       stop
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('#  Datafile containing the natural and clamped spline '
     1       ,'fits of J1(x)',/,'#',/
     2       ,'#        x            J1(x) natural      J1(x) clamped'
     3       ,'      difference',/,'#')
2020   format(1pg17.10,2x,g17.10,2x,g17.10,2x,g17.10)
2030   format('#  Datafile containing the clamped spline fit of J1(x) '
     1       ,'for different values of J1''(0).',/,'#',/
     2       ,'#        x              J1''(0)=-2.0        J1''(0)=-1.0'
     4       ,'        J1''(0)=0.0         J1''(0)=1.0'
     5       ,'         J1''(0)=2.0         J1''(0)=3.0',/,'#')
2040   format(1pg17.10,2x,g17.10,2x,g17.10,2x,g17.10,2x,g17.10,2x,g17.10
     1       ,2x,g17.10)
2050   format('SPLINE  : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                S P L I N E                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                C S I N I T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine csinit ( x, f, fp, d2fdx2, ndim )
c
c    abcd:spline.csinit <------------------- computes second derivatives
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: March, 2013 by abcd; modified to match the algorithm 
c                developed in class more precisely.
c
c=============== VERSION WITH BUILT-IN BUGS FOR DBX DEMO ===============
c
c  1. r(1) = 6.0d0 * ( ( f(2) - f(1) ) / h(1) + fp(1) )
c                                             ^
c                                             should be -
c  2. do 40 n=ndim-2,2,-1
c                  ^ ^
c             both should be 1
c
c  PURPOSE:  This routine initialises the second derivative for a 
c  "clamped cubic spline" by using a tridiagonal solver to evaluate the 
c  second derivatives of the input function consistent with continuous 
c  slopes at all points where the function is known.  For a clamped 
c  spline, boundary values of the first derivative are required.
c
c  INPUT VARIABLES:
c    x         values of the independent variable where the function is 
c              known
c    f         functional values
c    fp(1)     derivative at the left  boundary
c    fp(2)     derivative at the right boundary
c    ndim      dimension of x, f, and d2fdx2
c
c  OUTPUT VARIABLES:
c    d2fdx2    second derivative
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax
       parameter     ( nmax = 100 )
c
       integer       ndim    , n
c
       real*8        fp      (   2)
       real*8        x       (ndim), f       (ndim), d2fdx2  (ndim)
     1             , h       (nmax), a       (nmax), b       (nmax)
     2             , r       (nmax), beta    (nmax), rho     (nmax)
c
c-----------------------------------------------------------------------
c
       if (ndim .gt. nmax) then
         write ( 6, 2010 ) nmax, ndim
         stop
       endif
c
c      Set grid spacing (h).
c
       do 10 n=1,ndim-1
         h(n) = x(n+1) - x(n)
10     continue
c
c      Set sub-, main, and super-diagonals (a, b, c), as well as the 
c  "source term" (r). Since a = c, we only need to set a.
c
       a(1) = h(1)
       b(1) = 2.0d0 * h(1)
       r(1) = 6.0d0 * ( ( f(2) - f(1) ) / h(1) - fp(1) )
       do 20 n=2,ndim-1
         a(n) = h(n  )
         b(n) = 2.0d0 *   ( h(n-1) + h(n  ) )
         r(n) = 6.0d0 * ( ( f(n+1) - f(n  ) ) / h(n  )
     1                  - ( f(n  ) - f(n-1) ) / h(n-1) )
20     continue
       b(ndim) = 2.0d0 * h(ndim-1)
       r(ndim) =-6.0d0 * ( ( f(ndim) - f(ndim-1) ) / h(ndim-1) - fp(2) )
c
c      Gauss-eliminate the sub-diagonal.
c
       beta(1) = b(1)
       rho (1) = r(1)
       do 30 n=2,ndim
         beta(n) = b(n) - a(n-1)**2         / beta(n-1)
         rho (n) = r(n) - a(n-1) * rho(n-1) / beta(n-1)
30     continue
c
c      Perform the back substitutions.
c
       d2fdx2(ndim) = rho(ndim) / beta(ndim)
       do 40 n=ndim-1,1,-1
         d2fdx2(n) = ( rho(n) - a(n) * d2fdx2(n+1) ) / beta(n)
40     continue
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('CSINIT  : Recompile with either ndim < ',i4
     1       ,', or nmax > ',i4,'.')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                C S I N I T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                N S I N I T                \\\\\\\\\\
c
c=======================================================================
c
       subroutine nsinit ( x, f, d2fdx2, ndim )
c
c    abcd:spline.nsinit <------------------- computes second derivatives
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: March, 2013 by abcd; modified to match the algorithm 
c                developed in class more precisely.
c
c  PURPOSE:  This routine initialises the second derivative for a 
c  "natural cubic spline" by using a tridiagonal solver to evaluate the 
c  second derivatives of the input function consistent with continuous 
c  slopes at all points where the function is known.  For a natural 
c  spline, the second derivatives at the end points are assumed to be 
c  zero.
c
c  INPUT VARIABLES:
c    x         values of the independent variable where the function is 
c              known
c    f         functional values
c    ndim      dimension of x, f, and d2fdx2
c
c  OUTPUT VARIABLES:
c    d2fdx2    second derivative
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax
       parameter     ( nmax = 100 )
c
       integer       ndim    , n
c
       real*8        x       (ndim), f       (ndim), d2fdx2  (ndim)
     1             , h       (nmax), a       (nmax), b       (nmax)
     2             , r       (nmax), beta    (nmax), rho     (nmax)
c
c-----------------------------------------------------------------------
c
       if (ndim .gt. nmax) then
         write ( 6, 2010 ) nmax, ndim
         stop
       endif
c
c      Set grid spacing (h).
c
       do 10 n=1,ndim-1
         h(n) = x(n+1) - x(n)
10     continue
c
c      Set sub-, main, and super-diagonals (a, b, c), as well as the 
c  "source term" (r). Since a = c, we only need to set a.
c
       a(1) = 0.0d0
       do 20 n=2,ndim-1
         a(n) = h(n  )
         b(n) = 2.0d0 *   ( h(n-1) + h(n  ) )
         r(n) = 6.0d0 * ( ( f(n+1) - f(n  ) ) / h(n  )
     1                  - ( f(n  ) - f(n-1) ) / h(n-1) )
20     continue
c
c      Gauss-eliminate the sub-diagonal.
c
       beta(1) = 1.0d0
       rho (1) = 0.0d0
       do 30 n=2,ndim-1
         beta(n) = b(n) - a(n-1)**2         / beta(n-1)
         rho (n) = r(n) - a(n-1) * rho(n-1) / beta(n-1)
30     continue
c
c      Set natural spline boundary values, and perform the back 
c  substitutions.
c
       d2fdx2(1   ) = 0.0d0
       d2fdx2(ndim) = 0.0d0
       do 40 n=ndim-1,2,-1
         d2fdx2(n) = ( rho(n) - a(n) * d2fdx2(n+1) ) / beta(n)
40     continue
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('NSINIT  : Recompile with either ndim < ',i4
     1       ,', or nmax > ',i4,'.')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                N S I N I T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                S P L I N T                \\\\\\\\\\
c
c=======================================================================
c
       function splint ( xint, x, fofx, d2fdx2, ndim )
c
c    abcd:spline.splint <-------------------- cubic spline interpolation
c                                                            march, 2002
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function returns the cubic spline interpolated value 
c  of the function f with second derivative d2fdx2 at position xint.
c
c  INPUT VARIABLES:
c    xint       location at which interpolation is to be evaluated
c    x          array of independent variable values
c    fofx       array of function values
c    d2fdx2     array of second derivative values (initiated by cspinit 
c               or nsplinit)
c    ndim       dimension of arrays x, fofx, d2fdx2.
c
c  OUTPUT VARIABLES:
c    splint     interpolated value
c
c  EXTERNALS:
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       ndim    , n       , n0      , n0p1
       real*8        xint    , f1      , f2      , fpp1    , fpp2
     1             , hn0     , dx
       real*8        splint
c
       real*8        x       (ndim), fofx    (ndim), d2fdx2  (ndim)
c
c-----------------------------------------------------------------------
c
c      If "xint" is outside domain of "x", return zeroth order 
c  extrapolation.
c
       if ( xint .lt. x(1) ) then
         write(6, 2010) xint, x(1), x(ndim)
         splint = fofx(1)
         return
       endif
       if ( xint .gt. x(ndim) ) then
         write(6, 2010) xint, x(1), x(ndim)
         splint = fofx(ndim)
         return
       endif
c
c      Determine in which interval "xint" falls.
c
       do 10 n=1,ndim-1
         if ( xint .ge. x(n) ) n0 = n
10     continue
c
c      Perform the Spline interpolation.
c
       n0p1   = n0 + 1
       f1     = fofx  (n0  )
       f2     = fofx  (n0p1)
       fpp1   = d2fdx2(n0  )
       fpp2   = d2fdx2(n0p1)
       hn0    = x(n0p1) - x(n0)
       dx     = xint    - x(n0)
       splint = f1 + ( ( f2 - f1 ) / hn0 
     1               - hn0 * ( fpp2 + 2.0d0 * fpp1 ) / 6.0d0 ) * dx
     2             + 0.5d0 * fpp1 * dx**2
     3             + ( fpp2 - fpp1 ) * dx**3 / ( 6.0d0 * hn0 )
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('SPLINT  : *** WARNING *** Requested value for "xint" '
     1       ,1pg12.5,' is outside',/
     2       ,'SPLINT  : the data domain (',g12.5,',',g12.5,').  A '
     3       ,'zeroth order',/
     3       ,'SPLINT  : extrapolation will be returned for "spline".')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                S P L I N T                \\\\\\\\\\
c
c=======================================================================
