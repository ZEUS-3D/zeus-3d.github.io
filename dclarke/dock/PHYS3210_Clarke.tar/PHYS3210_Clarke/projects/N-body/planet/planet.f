c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                P L A N E T                \\\\\\\\\\
c
c=======================================================================
c
       program planet
c
c    abcd:planet <---------- leap-frog test for a single planetary orbit
c    from abcd:earthorb.f                                    march, 2013
c
c    written by: A Busy Code Developer
c    modified 1: April 2014, by ABCD; added adaptive time step for leap 
c                frog algorithm, and removed R.E. version of leap-frog, 
c                which was surprisingly disastrous.
c    modified 2: February, 2023 by ABCD; tidied up program and 
c                introduced two working adaptive time step algorithms.
c
c  PURPOSE:  This program computes the circular or elliptical orbit of a 
c  single planet about the sun using both an explicit and leap-frog 
c  integrator.
c
c  When r is expressed in AU and v in units of earth's circular orbital 
c  speed, GM = 1, where M = mass of sun, and one earth year is 2 pi.  
c  This scaling is eventually used by the program, though the user 
c  interface is designed so that the user need not have to calculate a 
c  planet's circular speed and enter the value to 15 significant figures 
c  in order to assure accuracy.  Instead, the user is asked for the 
c  perihelion/aphelion of the planet in AU, the speed of the planet 
c  where v = 1 corresponds to its (not the earth's) circular orbital 
c  speed, an initial angular step in units of 2*pi radians (which is 
c  converted to an initial time step), the total integration time in 
c  units of the planet's (not the earth's) year, and the preferred 
c  integration algorithm(s).  Rescaling so that v is in units of earth's 
c  circular orbital speed is done automatically later.
c
c      r0 (AU) planet's initial distance from the sun.  r0=1 => earth.
c      v0      <1 => r0 is the aphelion of an elliptical orbit; 
c              =1 => orbit is circular;
c              >1 => r0 is the perihelion of an elliptical orbit.
c              >sqrt(2) => orbit is unbound.
c      dphi    initial angular step taken in orbit (units of 2*pi rad)
c      tmax    total integration time in units of planet's year.
c      alg     =1 => explicit integrator
c              =2 => non-adaptive leap-frog
c              =3 => adaptive step leap-frog
c              =4 => alternate adaptive step lap-frog
c              Setting alg=12, for example, causes both algorithms 1 and 
c              2 to be used, with data going to separate files.  
c              (However, alg 4 can only be specified by itself).
c
c  Before rescaling to the earth's circular orbital speed, the following 
c  are calculated:
c
c      eccentricity:     ecc  = |v0**2 - 1|
c      semi-major axis:  aye  = r0 / ( 2 - v0**2 )
c      orbital period:   per = 2 * pi * aye**(3/2)
c
c  Rescale v0 so that v=1 corresponds to earth's circular orbital speed:
c
c      v0 = v0 / sqrt(r0)
c
c  With "v0" rescaled, set "delt" and "tmax" where one earth year = 2 pi
c
c      delt = 2 * pi * r0 * dphi / v0
c      tmax = tmax * per
c
c  Elliptical orbits with v0 = 1.2 require a surprisingly small time 
c  step to achieve closed orbits.  For example, for v0 = 1, dt = 0.1 is 
c  adequate.  For v0 = 1.2, dt needs to be as small as 0.013 and, since 
c  the elliptical orbit has a much longer year with the planet slowing 
c  down as it recedes from the sun, this small time step can lead to a
c  large number of steps required to complete the orbit.
c
c  Note from ABCD, 2/23: Working adaptive leapfrog methods have been 
c  introduced which reduce dramatically the number of steps required to 
c  complete an elliptical orbit, even for v0=1.4 (barely bound).
c
c  for debugging on venus: f90 -g -C -ftrap=common planet.f
c
c  EXTERNALS:
c    LEAP
c
c-----------------------------------------------------------------------
c
       implicit      none
c
c  Parameters: 
c    imax   = number of points to plot in analytical and numerical
c             orbits
c    nmax   = maximum number of points in numerical orbit
c    stepmn = minimum number of steps to take since last time "dt" was
c             changed before considering changing "dt" again 
c             (adaptive L.F.)
c    tol    = tolerance for adaptive time step (adaptive L.F.)
c    dtrat  = ratio of "dtmn" to initial dt (adaptive L.F.)
c
       integer       imax    , nmax    , stepmn
       real*8        tol     , dtrat
       parameter     ( imax = 1000, nmax = 100000, stepmn = 10
     1               , tol = 1.0d-5, dtrat = 1.0d-3 )
c
       integer       alg     , i       , step    , nplt    , step0
     1             , allpnt
       real          cpubeg  , cpuend  , cputot
       real*8        twopi   , r0      , v0      , delt    , dtmn
     1             , tmax    , ecc     , aye     , per     , ell0    
     1             , nrg0    , dphi    , phi     , are     , dt      
     1             , t1      , x1      , y1      , vx1     , vx1n    
     1             , vy1     , vy1n    , r3i     , ax      , ay      
     1             , dbar    , bar     , vsq     , nrg     , dele    
     1             , ell     , dell    , drft    , del     , delx
     1             , dely    , dtd     , vxd     , vxh     , vyd     
     1             , vyh     , xd      , yd      , dth     , xtw     
     1             , ytw     , vxtw    , vytw
c
       real*8        t2      (nmax), x2      (nmax), y2      (nmax)
     1             , vx2     (nmax), vy2     (nmax)
c
       external      leap   
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
       twopi = 2.0d0 * acos(-1.0d0)
c
c      Ask user for "r0", the initial distance of the planet from the 
c  sun in AU, and the planet's speed, "v0", in units of the speed it 
c  would have were it in a circular orbit.  Note that if "v0" exceeds 
c  sqrt(2), the planet is unbound.  If v0 = 1, the orbit is circular.
c  If v0 > 1 (< 1), the orbit is elliptical where r0 is the perihelion 
c  (aphelion).
c
       write (6, 2010)
       read  (5,    *) r0, v0
c
c      "ecc" is the eccentricity of the orbit
c      "aye" is the semi-major axis of the orbit
c      "per" is period of orbit
c
       ecc = v0**2 - 1.0d0
       aye = 1.0d99
       if (v0**2 .lt. 2.0d0) aye = r0 / ( 2.0d0 - v0**2 )
       per = twopi * aye**(1.5d0)
       write (6, 2020) abs(ecc), aye, per/twopi
       v0  = v0 / sqrt ( r0 )
c
c      Ask user for initial angular step, "dphi", and integration time, 
c  "tmax".  The angular step is converted to a time step according to:
c
c          delt = 2 pi r0 dphi / v0. 
c
c  where the factor of 2*pi is so that "dphi" can be entered as a 
c  fraction of a complete circle (i.e., units of 2 pi radians).  For a 
c  circular orbit, this results in a constant angular step around the 
c  entire orbit.
c
c  At perihelion of an elliptical orbit, this time step results in 
c  progressively smaller angular steps as the planet slows down in its 
c  orbit and, without an adaptive time step algorithm, the orbit may 
c  become "hyper-resolved" far from the sun.  
c
c  At aphelion of an elliptical orbit, this time step results in 
c  progressively larger angular steps as the planet speeds up in its 
c  orbit and---again without an adaptive time step algorithm---may cause 
c  the planet to leave the orbit as it approaches the sun.
c
c  "tmax" is interpreted in units of the planet's period which, in turn, 
c  is in units where the earth's period is 2 pi.
c
       write (6, 2030)
       read  (5,    *) dphi, tmax
201    continue
       delt = twopi * r0 * dphi / v0
       dtmn = dtrat * delt
       tmax = tmax * per
c
c      Ask user for integration algorithm.  Algorithms 1, 2, and 3 may 
c  be asked for in isolation, e.g., alg=2, or together, e.g., alg=123, 
c  where each of algorithms 1, 2, and 3 are used sequentially with data 
c  going to separate files.  Note that alg=4 may only be used in 
c  isolation.
c
c  alg=1 => explicit integrator (first order)
c  alg=2 => non-adaptive leapfrog integrator (second order)
c  alg=3 => adaptive leapfrog integrator (second order)
c  alg=4 => alternate adaptive leapfrog integrator (second order)
c
c      Ask also for "allpnt"; 0 => plot points limited by "nmax"
c                             1 => all points written to disc file.
c
       write (6, 2040)
       read  (5,    *) alg, allpnt
c
c      Constants of the orbit: angular momentum and energy.
c
       ell0 = r0  * v0
       nrg0 = 0.5d0 * v0**2 - 1.0d0 / r0
c
c      Compute and record the analytical orbit for comparison.
c
       open  ( 10, file='analytic.txt', status='unknown' )
       dphi = twopi / dble(imax)
       phi  = 0.0d0
       do 10 i=1,imax+1
         are = ell0**2 / ( 1.0d0 + ecc * cos(phi) )
         x1  = are * cos(phi)
         y1  = are * sin(phi)
         write (10, 2050) i, x1, y1
         phi = phi + dphi
10     continue
       close ( 10 )
c
c================ E X P L I C I T   I N T E G R A T O R ================
c
       if ( (alg .eq. 1  ) .or. (alg .eq. 12 ) .or. (alg .eq. 21 ) .or. 
     1      (alg .eq. 13 ) .or. (alg .eq. 31 ) .or. (alg .eq. 123) .or. 
     2      (alg .eq. 231) .or. (alg .eq. 312) ) then
c
c      Initialise variables for explicit integration.
c
c      The sun (assumed fixed) is located at the origin, while the 
c  planet orbits in the x-y plane.  The initial position of the planet 
c  is (r0,0) and the initial velocity is (0,v0).
c
         dt     = delt
         t1     = 0.0d0
         x1     = r0
         y1     = 0.0d0
         vx1    = 0.0d0
         vy1    = v0
         step   = 1
         t2 (1) = t1
         x2 (1) = x1
         y2 (1) = y1
         vx2(1) = vx1
         vy2(1) = vy1
c
c------Top of explicit integration loop---------------------------------
c
20       continue
c
c      Compute the acceleration before (x,y) updated.  r3i is the 
c  inverse of r**(3).
c
           r3i = ( x1**2 + y1**2 )**(-1.5d0)
           ax  =-x1 * r3i
           ay  =-y1 * r3i
c
c      Update r with v at the beginning of the time step.
c
           x1  = x1  + vx1 * dt
           y1  = y1  + vy1 * dt
c
c      Update v with a at the beginning of the time step.
c
           vx1 = vx1 + ax * dt
           vy1 = vy1 + ay * dt
c
c      Update time.
c
           t1  = t1 + dt
c
c      Write data to arrays.
c
           step      = step + 1
           if (step .gt. nmax) then
             write(6, 2060) step
             stop
           endif
           t2 (step) = t1
           x2 (step) = x1
           y2 (step) = y1
           vx2(step) = vx1
           vy2(step) = vy1
c
c      Check if "tmax" has been reached.  If so, exit.
c
           if (t1 .ge. tmax) go to 30
           go to 20
30       continue
c
c------Bottom of explicit integration loop------------------------------
c
c      Open disc file, "explicit.txt".
c
         open  ( 10, file='explicit.txt', status='unknown' )
c
c      Write data to disc file "explicit.txt".  If number of steps, 
c  "step", exceeds maximum number of points to be plotted, "imax", data 
c  are thinned so that "imax" points spread evenly throughout the "step" 
c  steps are written to the disc file for plotting.
c
         nplt = 0
         dbar = dble(step) / dble(imax)
         if (allpnt .eq. 1) dbar = 0.0d0
         bar  = 0.0d0
         do 40 i=1,step
           if (i .gt. int(bar)) then
             nplt = nplt + 1
             bar  = bar + dbar
             write (10, 2070) nplt, t2(i), x2(i), y2(i), vx2(i), vy2(i)
           endif
40       continue
         close ( 10 )
         write (6, 2080) 'explicit', nplt, step
c
c      To view numerical and analytical orbit in gnuplot, type:
c
c  (unset logscale xy)
c  set size ratio -1
c  plot [-4:1.2][-1.2:1.8] "explicit.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  Diagnostics: dE, dL, and d, the drift from the original position,
c  should be taken after a single orbit has been completed.
c
c  The intent here is to do several calculations of the same orbit with 
c  the same algorithm with different "delt" (each ~half the previous).  
c  Since data files "zeros_exp.txt", "zeros_lf.txt" and "zeros_lf2.txt" 
c  are opened with "position='append', action='write'" set, diagnostic 
c  data are accumulated with each run, and can be plotted on a log-log 
c  plot to show the order of convergence.  Thus, data files from 
c  previous experiments should be deleted before a new one is begun.
c
c  In units where GM = 1 and R = 1, the potential, V, is -1/r0 at t = 0.
c  Likewise, the specific kinetic energy, K/m, = v0**2/2 at t = 0.
c  Thus, E0 = v0**2/2 - 1/r0 = -0.5 for the earth.  Similarly, the 
c  specific angular momentum is L = rv = r0v0 = 1 for the earth.
c
c  "x1", "y1", "vx1", and "vy1" are the values at the last step taken 
c  above in the presumed closed orbit.
c
         are  = sqrt ( x1**2 + y1**2 )
         vsq  = vx1**2 + vy1**2
         nrg  = 0.5d0 * vsq - 1.0d0 / are
         dele = abs ( nrg - nrg0 ) / abs ( nrg0 )
c
         ell  = x1 * vy1 - y1 * vx1
         dell = abs ( ell - ell0 ) / ell0
c
         drft = sqrt ( ( x1 - r0 )**2 + y1**2 ) / r0
c
         write (6, 2120) 'explicit', dt/per, tmax/per, step, dele, dell
     1                 , drft
c
c      Open disc file for monitored quantities and append them to file.
c  To view the monitored "zeros" on a log-log plot with gnuplot, type:
c
c  set size square
c  set logscale xy
c  plot [.004:0.3][.1:20] "zeros_exp.txt" u 1:2 w lines, "zeros_exp.txt" u 1:3 w lines, "zeros_exp.txt" u 1:4 w lines, "zeros_exp.txt" u 1:2 w points, "zeros_exp.txt" u 1:3 w points, "zeros_exp.txt" u 1:4 w points
c
         open  ( 10, file='zeros_exp.txt', status='unknown'
     1         , position='append', action='write' )
         write ( 10, 2130 ) dt/twopi, dele, dell, drft
         close ( 10 )
c
       endif
c
c============= N O N - A D A P T I V E   L E A P - F R O G =============
c
       if ( (alg .eq. 2  ) .or. (alg .eq. 21 ) .or. (alg .eq. 12 ) .or. 
     1      (alg .eq. 23 ) .or. (alg .eq. 32 ) .or. (alg .eq. 123) .or. 
     2      (alg .eq. 231) .or. (alg .eq. 312) ) then
c
c      Initialise variables for leap-frog integration.  Note that v is 
c  set to its value at the first half-time step.
c
         dt     = delt
         t1     = 0.0d0
         x1     = r0
         y1     = 0.0d0
         dphi   = 0.5d0 * v0 * dt / r0
         vx1    =-sin ( dphi ) / ell0
         vy1    = ( ecc + cos ( dphi ) ) / ell0
         step   = 1
         t2 (1) = t1
         x2 (1) = x1
         y2 (1) = y1
         vx2(1) = vx1
         vy2(1) = vy1
c
c------Top of leap-frog integration loop--------------------------------
c
50       continue
c
c      Perform a single leap with r over v, followed by v over r.
c
           call leap ( x1, y1, vx1, vy1, x1, y1, vx1, vy1, 0, dt )
c
c      Update time.
c
           t1  = t1 + dt
c
c      Write data to arrays.
c
           step      = step + 1
           if (step .gt. nmax) then
             write(6, 2060) step
             stop
           endif
           t2 (step) = t1
           x2 (step) = x1
           y2 (step) = y1
           vx2(step) = vx1
           vy2(step) = vy1
c
c      Check if "tmax" has been reached.  If so, exit.
c
           if (t1 .ge. tmax) go to 60
           go to 50
60       continue
c
c------Bottom of leap-frog integration loop-----------------------------
c
c      Open disc file, "leap_frog.txt".
c
         open  ( 10, file='leap_frog.txt', status='unknown' )
c
c      Write data to disc file "leap_frog.txt".  If number of steps, 
c  "step", exceeds maximum number of points to be plotted, "imax", data 
c  are thinned so that "imax" points spread evenly throughout the "step" 
c  steps are written to the disc file for plotting.
c
c  Note that the velocity components are time-averaged to be co-temporal 
c  with the position data written to the disc file.
c
         nplt = 0
         dbar = dble(step) / dble(imax)
         if (allpnt .eq. 1) dbar = 0.0d0
         bar  = 0.0d0
         do 70 i=1,step
           if (i .gt. int(bar)) then
             nplt = nplt + 1
             bar  = bar + dbar
             if (i .eq. 1) then
               vxh = 0.0d0
               vyh = v0
             else
               vxh = 0.5d0 * ( vx2(i) + vx2(i-1) )
               vyh = 0.5d0 * ( vy2(i) + vy2(i-1) )
             endif
             write (10, 2070) nplt, t2(i), x2(i), y2(i), vxh, vyh
           endif
70       continue
         close ( 10 )
         write (6, 2080) 'leap_frog', nplt, step
c
c      To view numerical and analytical orbit in gnuplot, type:
c
c  (unset logscale xy)
c  set size ratio -1
c
c  for circular orbit, r=1, v=1:
c
c  plot [-1.2:1.2][-1.2:1.2] "leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  for elliptical orbit, r=1, v=1.2
c
c  plot [-3.0:1.2][-2.0:2.0] "leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  for elliptical orbit, r=1, v=1.4
c
c  plot [-50.0:1.2][-10.0:10.0] "leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c      To view analytical results with both explicit and leap frog 
c  integrators, type:
c
c  set size ratio -1
c  plot [-4.0:1.2][-1.2:1.8] "leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines, "explicit.txt" u 3:4 w points
c
c      Diagnostics: dE, dL, and d, the drift from the original position
c  should be taken after 20 orbits have been completed.  See comments 
c  in the Explicit Integrator segment above.
c
c  (x1,y1) is the location of the particle at the end of "step" n.  For 
c  a co-temporal velocity, do a Lagrange quadratic interpolation on the 
c  last three entries.
c
         are  = sqrt ( x1**2 + y1**2 )
         vxd  = (-vx2(step-2) + 6.0d0 * vx2(step-1)
     1          + 3.0d0 * vx2(step) ) / 8.0d0
         vyd  = (-vy2(step-2) + 6.0d0 * vy2(step-1)
     1          + 3.0d0 * vy2(step) ) / 8.0d0
         vsq  = vxd**2 + vyd**2
         nrg  = 0.5d0 * vsq - 1.0d0 / are
         dele = abs ( nrg - nrg0 ) / abs ( nrg0 )
c
         ell  = x1 * vyd - y1 * vxd
         dell = abs ( ell - ell0 ) / ell0
c
         drft = sqrt ( ( x1 - r0 )**2 + y1**2 ) / r0
c
         write (6, 2120) 'non-adaptive leap frog', dt/per, tmax/per
     1                 , step, dele, dell, drft
c
c      Open disc file for monitored quantities and append them to file.
c  To view the monitored "zeros" on a log-log plot with gnuplot, type:
c
c  set size square
c  set logscale xy
c  plot [.004:0.3][.00005:200] "zeros_lf.txt" u 1:2 w lines, "zeros_lf.txt" u 1:3 w lines, "zeros_lf.txt" u 1:4 w lines, "zeros_lf.txt" u 1:2 w points, "zeros_lf.txt" u 1:3 w points, "zeros_lf.txt" u 1:4 w points
c
         open  ( 10, file='zeros_lf.txt', status='unknown'
     1         , position='append', action='write' )
         write ( 10, 2130 ) dt/twopi, dele, dell, drft
         close ( 10 )
c
       endif
c
c================= A D A P T I V E   L E A P - F R O G =================
c
c      This adaptive time step algorithm uses Lagrange interpolation on
c  the velocities (vx,vy) to time-centre them correctly.  The first 
c  interpolation is to get (vx,vy) co-temporal with (x,y) at time step 
c  n-1 so that a double leap from time step n-2 to n can be done.  The 
c  position (xd,yd) after the double leap is compared to the current 
c  position (x,y) at time step n and their fractional difference, "del", 
c  is calculated.  If "del is greater than the tolerance "tol", the time 
c  step is halved.  If "del is less than a tenth of "tol, the time step 
c  is doubled.
c
c  In halving the time step, another Lagrange interpolation is done on 
c  (vx,vy) to time step n+1/4 (current last velocity is at n+1/2) so 
c  that (x,y) at step n can leap to n+1/2 which, with the newly halved 
c  time step, will become step n+1.
c
c  In doubling the time step, data from the first interpolation and the 
c  double leap are used to reset the nth step for the next leap.
c
       if ( (alg .eq. 3  ) .or. (alg .eq. 32 ) .or. (alg .eq. 23 ) .or. 
     1      (alg .eq. 31 ) .or. (alg .eq. 13 ) .or. (alg .eq. 123) .or. 
     2      (alg .eq. 231) .or. (alg .eq. 312) ) then
c
c      Initialise variables for leap-frog integration.  Note that v is 
c  set to its value at the first half-time step.
c
         dt     = delt
         t1     = 0.0d0
         x1     = r0
         y1     = 0.0d0
         dphi   = 0.5d0 * v0 * dt / r0
         vx1    =-sin ( dphi ) / ell0
         vy1    = ( ecc + cos ( dphi ) ) / ell0
         step   = 1
         step0  = 0
         t2 (1) = t1
         x2 (1) = x1
         y2 (1) = y1
         vx2(1) = vx1
         vy2(1) = vy1
c
c------Top of adaptive leap-frog integration loop-----------------------
c
80       continue
c
c      Perform a single leap with r over v, followed by v over r.
c
           call leap ( x1, y1, vx1, vy1, x1, y1, vx1, vy1, 0, dt )
c
c      Update time.
c
           t1  = t1 + dt
c
c      Write data to arrays.
c
           step0 = step0 + 1
           step  = step  + 1
           if (step .gt. nmax) then
             write(6, 2060) step
             stop
           endif
           t2 (step) = t1
           x2 (step) = x1
           y2 (step) = y1
           vx2(step) = vx1
           vy2(step) = vy1
c
c      If there have been "stepmn" steps since last check, determine if 
c  a time-step adjustment is needed/warranted.
c
           if (step0 .gt. stepmn) then
             step0 = 0
c
c      Do a Lagrangian cubic interpolation of "vx2" and "vy2" to "step" 
c  n-1 to be co-temporal with "x2(n-1)" and "y2(n-1)".
c
             vxd = (-vx2(step-3) + 9.0d0 * vx2(step-2)
     1             + 9.0d0 * vx2(step-1) - vx2(step  ) ) / 16.0d0
             vyd = (-vy2(step-3) + 9.0d0 * vy2(step-2)
     1             + 9.0d0 * vy2(step-1) - vy2(step  ) ) / 16.0d0
c
c      Perform a double-step leapfrog from "step" n-2 to "step" n using 
c  the velocities "vxd" and "vyd" interpolated to "step" n-1 above.
c
             xd  = x2(step-2)
             yd  = y2(step-2)
             dtd = 2.0d0 * dt
             call leap ( xd, yd, vxd, vyd, xd, yd, vxd, vyd, 0, dtd )
c
c      Compare "xd" and "yd" with "x1" and "y1" at current "step" n.
c
             delx = 2.0d0 * abs ( ( xd - x1 ) / ( xd + x1 ) )
             dely = 2.0d0 * abs ( ( yd - y1 ) / ( yd + y1 ) )
             del  = max ( delx, dely )
c
             if (del .gt. tol) then
c
c      We must halve the time step.  Before doing so, make sure time
c  step is not already at its minimum allowed value.  If so, warn user 
c  and then continue with the time step not halved.
c
               if (dt .le. dtmn) then
                 write (6, 2090) step, dtmn
                 go to 90
               endif
               dt = 0.5d0 * dt
c
c      Do a Lagrangian quadratic interpolation of "vx2" and "vy2" to 
c  "step" n+1/4 and thus time centred between "step" n and "step" n+1/2 
c  which will become the new "step" n+1 using time step dt/2.
c
               vx1 = (- 3.0d0 * vx2(step-2) + 14.0d0 * vx2(step-1)
     1               + 21.0d0 * vx2(step  ) ) / 32.0d0
               vy1 = (- 3.0d0 * vy2(step-2) + 14.0d0 * vy2(step-1)
     1               + 21.0d0 * vy2(step  ) ) / 32.0d0
c
c      Overwrite previous "vx2" and "vy2" at "step" n with interpolated 
c  values, and inform user time step has been halved.
c
               vx2(step) = vx1
               vy2(step) = vy1
               write (6, 2100) step, t1/twopi, dt
             endif
c
             if (del .lt. 0.1d0*tol) then
c
c      Error is much smaller than needed, and we can double the time 
c  step.  To prepare for the next step, overwrite "vx2" and "vy2" at 
c  "step" n with "vxd" and "vyd" from double leap above, and inform user 
c  time step has been doubled.
c
               vx1       = vxd
               vy1       = vyd
               vx2(step) = vxd
               vy2(step) = vyd
               dt        = dtd
               write (6, 2110) step, t1/twopi, dt
             endif
           endif
90         continue
c
c      Check if "tmax" has been reached.  If so, exit.
c
           if (t1 .ge. tmax) go to 100
           go to 80
100      continue
c
c------Bottom of adaptive leap-frog integration loop--------------------
c
c      Open disc file, "a_leap_frog.txt".
c
         open  ( 10, file='a_leap_frog.txt', status='unknown' )
c
c      Write data to disc file "a_leap_frog.txt".  If number of steps, 
c  "step", exceeds maximum number of points to be plotted, "imax", data 
c  are thinned so that "imax" points spread evenly throughout the "step" 
c  steps are written to the disc file for plotting.
c
c  Note that the velocity components are time-averaged to be co-temporal 
c  with the position data written to the disc file.
c
         nplt = 0
         dbar = dble(step) / dble(imax)
         if (allpnt .eq. 1) dbar = 0.0d0
         bar  = 0.0d0
         do 110 i=1,step
           if (i .gt. int(bar)) then
             nplt = nplt + 1
             bar  = bar + dbar
             if (i .eq. 1) then
               vxh = 0.0d0
               vyh = v0
             else
               vxh = 0.5d0 * ( vx2(i) + vx2(i-1) )
               vyh = 0.5d0 * ( vy2(i) + vy2(i-1) )
             endif
             write (10, 2070) nplt, t2(i), x2(i), y2(i), vxh, vyh
           endif
110      continue
         close ( 10 )
         write (6, 2080) 'a_leap_frog', nplt, step
c
c      To view numerical and analytical orbit in gnuplot, type:
c
c  (unset logscale xy)
c  set size ratio -1
c
c  for circular orbit, r=1, v=1:
c
c  plot [-1.2:1.2][-1.2:1.2] "a_leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  for elliptical orbit, r=1, v=1.2
c
c  plot [-3.0:1.2][-2.0:2.0] "a_leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  for elliptical orbit, r=1, v=1.4
c
c  plot [-50.0:1.2][-10.0:10.0] "a_leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c      To view analytical results with both leap frog integrators, type:
c
c  set size ratio -1
c  plot [-4.0:1.2][-1.2:1.8] "leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines, "a_leap_frog.txt" u 3:4 w points
c
c      Diagnostics: dE, dL, and d, the drift from the original position
c  should be taken after 20 orbits have been completed.  See comments 
c  in the Explicit Integrator segment above.
c
c  (x1,y1) is the location of the particle at the end of "step" n.  For 
c  a co-temporal velocity, do a Lagrange quadratic interpolation on the 
c  last three entries.
c
         are  = sqrt ( x1**2 + y1**2 )
         vxd  = (-vx2(step-2) + 6.0d0 * vx2(step-1)
     1          + 3.0d0 * vx2(step) ) / 8.0d0
         vyd  = (-vy2(step-2) + 6.0d0 * vy2(step-1)
     1          + 3.0d0 * vy2(step) ) / 8.0d0
         vsq  = vxd**2 + vyd**2
         nrg  = 0.5d0 * vsq - 1.0d0 / are
         dele = abs ( nrg - nrg0 ) / abs ( nrg0 )
c
         ell  = x1 * vyd - y1 * vxd
         dell = abs ( ell - ell0 ) / ell0
c
         drft = sqrt ( ( x1 - r0 )**2 + y1**2 ) / r0
c
         write (6, 2120) 'adaptive leap frog', dt/per, tmax/per
     1                 , step, dele, dell, drft
c
c      Open disc file for monitored quantities and append them to file.
c  To view the monitored "zeros" on a log-log plot with gnuplot, type:
c
c  set size square
c  set logscale xy
c  plot [.004:0.3][.00005:200] "zeros_alf.txt" u 1:2 w lines, "zeros_alf.txt" u 1:3 w lines, "zeros_alf.txt" u 1:4 w lines, "zeros_alf.txt" u 1:2 w points, "zeros_alf.txt" u 1:3 w points, "zeros_alf.txt" u 1:4 w points
c
         open  ( 10, file='zeros_alf.txt', status='unknown'
     1         , position='append', action='write' )
         write ( 10, 2130 ) dt/twopi, dele, dell, drft
         close ( 10 )
c
       endif
c
c======= A L T E R N A T E   A D A P T I V E   L E A P - F R O G =======
c
c      This alternate adaptive algorithm differs from the first in that 
c  Lagrange interpolation is done on the positions instead of the 
c  velocities.  The idea was that perhaps interpolating on positions and 
c  then accelerating the velocities with the known forces might be 
c  better than interpolating on the velocities directly since the latter 
c  is not directly sensitive to the forces.  However, for the simple 
c  case of a single planet in an elliptical orbit around the sun, there 
c  is no measurable difference between the two algorithms.  This 
c  alternate algorithm is retained here in case future tests do detect a 
c  difference.
c 
       if (alg .eq. 4) then
c
c      Initialise variables for leap-frog integration.  Note that v is 
c  set to its value at the first half-time step.
c
         dt     = delt
         t1     = 0.0d0
         x1     = r0
         y1     = 0.0d0
         dphi   = 0.5d0 * v0 * dt / r0
         vx1    =-sin ( dphi ) / ell0
         vy1    = ( ecc + cos ( dphi ) ) / ell0
         step   = 1
         step0  = 0
         t2 (1) = t1
         x2 (1) = x1
         y2 (1) = y1
         vx2(1) = vx1
         vy2(1) = vy1
c
c------Top of alternate adaptive leap-frog integration loop-------------
c
120      continue
c
c      Perform a single leap with r over v, followed by v over r.
c
           call leap ( x1, y1, vx1, vy1, x1, y1, vx1, vy1, 0, dt )
c
c      Update time.
c
           t1  = t1 + dt
c
c      Write data to arrays.
c
           step0 = step0 + 1
           step  = step  + 1
           if (step .gt. nmax) then
             write(6, 2060) step
             stop
           endif
           t2 (step) = t1
           x2 (step) = x1
           y2 (step) = y1
           vx2(step) = vx1
           vy2(step) = vy1
c
c      If there have been "stepmn" steps since last check, determine if 
c  a time-step adjustment is required.
c
           if (step0 .gt. stepmn) then
             step0 = 0
c
c      Do a Lagrangian cubic interpolation of "x2" and "y2" to "step"
c  n-5/4.
c
             xtw = (-  5.0d0 * x2(step-3) + 35.0d0 * x2(step-2)
     1             + 105.0d0 * x2(step-1) -  7.0d0 * x2(step  ) )
     2           / 128.0d0
             ytw = (-  5.0d0 * y2(step-3) + 35.0d0 * y2(step-2)
     1             + 105.0d0 * y2(step-1) -  7.0d0 * y2(step  ) )
     2           / 128.0d0
c
c      Perform a half leap-frog step on the velocity from "step" n-3/2 
c  to "step" n-1 using the interpolated values "xtw" and "ytw" above.  
c  Note that the time step used here is dt/2 and positions are not 
c  updated.
c
             vxtw = vx2(step-2)
             vytw = vy2(step-2)
             dth  = 0.5d0 * dt
             call leap ( xtw, ytw, vxtw, vytw, xtw, ytw, vxtw, vytw, 1
     1                 , dth )
c
c      Now do a full and double leap-frog step from "step" n-2 to "step"
c  n using "vxtw" and "vytw" leapt to "step" n-1 above.
c
             xd  = x2(step-2)
             yd  = y2(step-2)
             dtd = 2.0d0 * dt
             call leap ( xd, yd, vxtw, vytw, xd, yd, vxd, vyd, 0, dtd )
c
c      Compare "xd" and "yd" with "x1" and "y1" at current "step" n.
c
             delx = 2.0d0 * abs ( ( xd - x1 ) / ( xd + x1 ) )
             dely = 2.0d0 * abs ( ( yd - y1 ) / ( yd + y1 ) )
             del  = max ( delx, dely )
c
             if (del .gt. tol) then
c
c      We must halve the time step.  Before doing so, make sure time
c  step is not already at its minimum allowed value.  If so, warn user 
c  and then continue with the time step not halved.
c
               if (dt .le. dtmn) then
                 write (6, 2090) step, dtmn
                 go to 130
               endif
               dt = dth
c
c      Data at "step" n are abandoned.  Reduce "step" by 1 and overwrite
c  previous "x2", "y2", "vx2" and  "vy2" at "step" n-1 with interpolated
c  values "xtw" and "ytw", and leapt-to values "vxtw" and "vytw".  Set 
c  problem time "t1" back by 2.5 of the new time steps to be consistent
c  with position (x1,y1), and inform user time step has been halved.
c
               step      = step - 1
               x1        = xtw
               y1        = ytw
               x2 (step) = xtw
               y2 (step) = ytw
               vx1       = vxtw
               vy1       = vytw
               vx2(step) = vxtw
               vy2(step) = vytw
               t1        = t1 - 2.5d0 * dt
               t2 (step) = t1
               write (6, 2100) step, t1/twopi, dt
             endif
c
             if (del .lt. 0.1d0*tol) then
c
c      Error is much smaller than needed, and we can double the time 
c  step.  To prepare for the next step, overwrite "vx2" and "vy2" at 
c  "step" n with "vxd" and "vyd" leapt-to above, and inform user time 
c  step has been doubled.  Note that in this case, the problem time "t1" 
c  need not be altered.
c
               vx1       = vxd
               vy1       = vyd
               vx2(step) = vxd
               vy2(step) = vyd
               dt        = dtd
               write (6, 2110) step, t1/twopi, dt
             endif
           endif
130        continue
c
c      Check if "tmax" has been reached.  If so, exit.
c
           if (t1 .ge. tmax) go to 140
           go to 120
140      continue
c
c------Bottom of alternate adaptive leap-frog integration loop----------
c
c      Open disc file, "a2_leap_frog.txt".
c
         open  ( 10, file='a2_leap_frog.txt', status='unknown' )
c
c      Write data to disc file "a2_leap_frog.txt".  If number of steps, 
c  "step", exceeds maximum number of points to be plotted, "imax", data 
c  are thinned so that "imax" points spread evenly throughout the "step" 
c  steps are written to the disc file for plotting.
c
c  Note that the velocity components are time-averaged to be co-temporal 
c  with the position data written to the disc file.
c
         nplt = 0
         dbar = dble(step) / dble(imax)
         if (allpnt .eq. 1) dbar = 0.0d0
         bar  = 0.0d0
         do 150 i=1,step
           if (i .gt. int(bar)) then
             nplt = nplt + 1
             bar  = bar + dbar
             if (i .eq. 1) then
               vxh = 0.0d0
               vyh = v0
             else
               vxh = 0.5d0 * ( vx2(i) + vx2(i-1) )
               vyh = 0.5d0 * ( vy2(i) + vy2(i-1) )
             endif
             write (10, 2070) nplt, t2(i), x2(i), y2(i), vxh, vyh
           endif
150      continue
         close ( 10 )
         write (6, 2080) 'a2_leap_frog', nplt, step
c
c      To view numerical and analytical orbit in gnuplot, type:
c
c  (unset logscale xy)
c  set size ratio -1
c
c  for circular orbit, r=1, v=1:
c
c  plot [-1.2:1.2][-1.2:1.2] "a2_leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  for elliptical orbit, r=1, v=1.2
c
c  plot [-3.0:1.2][-2.0:2.0] "a2_leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c  for elliptical orbit, r=1, v=1.4
c
c  plot [-50.0:1.2][-10.0:10.0] "a2_leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines
c
c      To view analytical results with both leap frog integrators, type:
c
c  set size ratio -1
c  plot [-4.0:1.2][-1.2:1.8] "leap_frog.txt" u 3:4 w points, "analytic.txt" u 2:3 w lines, "a2_leap_frog.txt" u 3:4 w points
c
c      Diagnostics: dE, dL, and d, the drift from the original position
c  should be taken after 20 orbits have been completed.  See comments 
c  in the Explicit Integrator segment above.
c
c  (x1,y1) is the location of the particle at the end of "step" n.  For 
c  a co-temporal velocity, do a Lagrange quadratic interpolation on the 
c  last three entries.
c
         are  = sqrt ( x1**2 + y1**2 )
         vxd  = (-vx2(step-2) + 6.0d0 * vx2(step-1)
     1          + 3.0d0 * vx2(step) ) / 8.0d0
         vyd  = (-vy2(step-2) + 6.0d0 * vy2(step-1)
     1          + 3.0d0 * vy2(step) ) / 8.0d0
         vsq  = vxd**2 + vyd**2
         nrg  = 0.5d0 * vsq - 1.0d0 / are
         dele = abs ( nrg - nrg0 ) / abs ( nrg0 )
c
         ell  = x1 * vyd - y1 * vxd
         dell = abs ( ell - ell0 ) / ell0
c
         drft = sqrt ( ( x1 - r0 )**2 + y1**2 ) / r0
c
         write (6, 2120) '2nd adaptive leap frog', dt/per, tmax/per
     1                 , step, dele, dell, drft
c
c      Open disc file for monitored quantities and append them to file.
c  To view the monitored "zeros" on a log-log plot with gnuplot, type:
c
c  set size square
c  set logscale xy
c  plot [.004:0.3][.00005:200] "zeros_a2lf.txt" u 1:2 w lines, "zeros_alf.txt" u 1:3 w lines, "zeros_a2lf.txt" u 1:4 w lines, "zeros_alf.txt" u 1:2 w points, "zeros_a2lf.txt" u 1:3 w points, "zeros_alf.txt" u 1:4 w points
c
         open  ( 10, file='zeros_a2lf.txt', status='unknown'
     1         , position='append', action='write' )
         write ( 10, 2130 ) dt/twopi, dele, dell, drft
         close ( 10 )
c
       endif
c
c=======================================================================
c
c      End CPU time counter, and report cpu time used.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write(6, 2140) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('PLANET  : Enter perihelion/aphelion, r0, in AU and '
     1       ,'velocity, v0:',/
     2       ,'PLANET  :       v0 = 1.0     => circular orbit;',/
     3       ,'PLANET  : 1.0 < v0 < sqrt(2) => r0 is perihelion of '
     4       ,'elliptical orbit;',/
     5       ,'PLANET  :       v0 < 1.0     => r0 is aphelion   of '
     6       ,'elliptical orbit.')
2020   format('PLANET  : eccentricity    of orbit = ',1pg12.5,';',/
     1       ,'PLANET  : semi-major axis of orbit = ',g12.5,' AU;',/
     2       ,'PLANET  : period          of orbit = ',g12.5,' earth '
     3       ,'years.',/
     4       ,'PLANET  :')
2030   format('PLANET  : Enter initial "dphi" (2*pi rad) and '
     1       ,'integration time (planet years).')
2040   format('PLANET  : Algorithm(s)?  1 => explicit; 2 => '
     1       ,'leapfrog; 3 => adaptive leapfrog.',/
     2       ,'PLANET  : All points?    1 => all points to disc file; '
     3       ,'0 => limited by "nmax".')
2050   format(i9,1p2g13.5)
2060   format('PLANET  : |----ERROR----> # of steps, ',i0
     1       ,', exceeds nmax = ',i0,'.  Abort!')
2070   format(i9,1p5g13.5)
2080   format('PLANET  : Data file ',a,'.txt written with ',i0
     1       ,' entries from ',i0,' steps.')
2090   format('PLANET  : |---WARNING---> At step ',i6,', time step '
     1       ,'reached dtmn: ',1pg12.5,'.')
2100   format('PLANET  : At step ',i6,', t = ',1pg12.5
     1       ,', time step reduced   to ',g12.5,'.')
2110   format('PLANET  : At step ',i6,', t = ',1pg12.5
     1       ,', time step increased to ',g12.5,'.')
2120   format('PLANET  : For the ',a,' integrator with dt/T = '
     1       ,1pg12.5,':',/
     1       ,'PLANET  : After ',g9.2,' orbits and ',i7,' time steps, '
     2       ,'"zero quantities" are:',/
     3       ,'PLANET  :     del E = ',g12.5,', del L = ',g12.5
     4       ,', drift = ',g12.5)
2130   format(1p4g13.5)
2140   format('PLANET  :',/
     1       ,'PLANET  : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                P L A N E T                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                  L E A P                  \\\\\\\\\\
c
c=======================================================================
c
       subroutine leap ( x0, y0, vx0, vy0, x1, y1, vx1, vy1, vonly, dt )
c
c    abcd: <------------------------- position-led leap frog integration
c                                                            april, 2014
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine performs the leap frog integration in the 
c  sequence r over v, v over r for the time step "dt".
c
c  INPUT VARIABLES:
c    x0 , y0     coordinates of particle at time step n
c    vx0, vy0    velocity    of particle at time step n+1/2 
c    vonly       =1 => take only the velocity leap
c                =0 => do the full leap-frog step
c    dt          time step
c
c  OUTPUT VARIABLES:
c    x1 , y1     coordinates of particle at time step n+1
c    vx1, vy1    velocity    of particle at time step n+3/2 
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer        vonly
       real*8         x0      , y0      , vx0     , vy0     , x1      
     1              , y1      , vx1     , vy1     , dt      , r3i
     2              , ax      , ay
c
c-----------------------------------------------------------------------
c
c      Update (x,y) from step n to step n+1 with v at step n+1/2.
c
       if (vonly .eq. 0) then
         x1 = x0 + vx0 * dt
         y1 = y0 + vy0 * dt
       endif
c
c      Compute acceleration at step n+1.  r3i is r**(-3).
c
       r3i = ( x1**2 + y1**2 )**(-1.5d0)
       ax  =-x1 * r3i
       ay  =-y1 * r3i
c
c      Update (vx,vy) from step n+1/2 to n+3/2 with (ax,ay) at step n+1.
c
       vx1 = vx0 + ax * dt
       vy1 = vy0 + ay * dt
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                  L E A P                  \\\\\\\\\\
c
c=======================================================================
c
c
