!	####### ####### ####### ####### ######   #####  ### ### ### 
!	#     # #     # #     # #     # #     # #     # ### ### ### 
!	#     # #     # #     # #     # #     # #       ### ### ### 
!	#     # #     # #     # #     # ######   #####   #   #   #  
! 	#     # #     # #     # #     # #             #             
! 	#     # #     # #     # #     # #       #     # ### ### ### 
!	 ####### ####### ####### ####### #        #####  ### ### ### 
!      
!                   
!
!	The code was meant to be more commented and better structured
!	with a 1 more subroutine to calculate the forces and the 
!	accelerations. Unfortunately my code went missing so i tried
!	to reproduce it from the last version i had . pardon the poor
!	do loop numberring and sloppiness.
!	
!
!
!
!
!
!
!=======================================================================
!
!    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
!    //////////                 PLASMA                    \\\\\\\\\\
!
!=======================================================================
!
	program plasma
!
!    
!    written by: MHH, February 2012. 
!
!  PURPOSE:  This program uses a leapfrog N-Body algorithm to simulate 
!  plasma. The forces considered are the columb and Lorentz forces. 
!
!
!  Input:	File
!  		Mesh generator
!		Manual input (in case of 1 to 3 particles)
!
!  Output:	Final position file
!		Position at each timestep file
!		dv file to test the leapfrogs
!		file of the points with the magnetic fields.
!
!-----------------------------------------------------------------------
!
	implicit      none
!		      dummy filename
	character*11  flname	
!		      ! used for CPU timing
	real          cputot  , etime  , tdummy  ( 2 )
!	i: particle of interest		npart: total number of particles
!	tag: used in file numberring    ndt  : max # of dts
	integer       i          , npart 	, k , j  , n, tag, ndt
!	box: dimensions of the box to contain the plasma in
	real*8	      box
!
!******************Remember to define npart, box and ndt*****************
!!	**************************************************************
!	**************************************************************
!	**************************************************************
!
!
	parameter (npart = 125, box = 3.0d0 , ndt = 1800)
!
!
!	**************************************************************
!	**************************************************************
!	**************************************************************
!
! r0i: initial position (x,y,z, (1 to fix the particle 0 to allow it to move) )
! v0i: initial velocity		
! a0i: initial acceleration	
!
	real*8        r0i(npart,4)   , v0i(npart,3)   , a0i(npart,3)
!
! rni: position (x,y,z)  at full time step
! vni: velocity		at full time step
! ani: acceleration	at full time step
!
!
	real*8        rni(npart,3)   , vni(npart,3)   , ani(npart,3)
!
! rnp1i: position (x,y,z) at n+1 time step
! vnp1i: velocity	at n+1 time step
! anp1i: acceleration   at n+1 time step 
!
	real*8        rnp1i(npart,3) , vnp1i(npart,3) , anp1i(npart,3)  
! 
! rcm: position of the center of mass
!
	real*8	      rcm(3)
!
! mtot: total mass
! mpos: dummy variable
! mdum: dummy variable
!
	real*8	      mtot	, mpos(3) , mdum(3)
!
! fij: force between i and j
! fijh: force between i and j at half time step
!
	real*8	      fij( npart,npart,3) , f(npart,3)
!
	real*8	      fijh(npart,npart,3) , fh(npart,3)
!
! rnphi: position (x,y,z)  at half time step
! vnphi: velocity	at half time step
! anphi: acceleration	at half time step
!
	real*8        rnphi(npart,3)   , vnphi(npart,3) , anphi(npart,3)
!
! rnp3hi: position (x,y,z) at 3 halves time step
! vnp3hi: velocity	at 3 halves time step
! anp3hi: accelerationat 3 halves time step
! 
	real*8        rnp3hi(npart,3) , vnp3hi(npart,3) ,anp3hi(npart,3) 	      
!
! B : magnetic field
! E : electric field
! vxB: function (cross product)
! dv: difference between full time step average velocity and half time step
!     velocity to test dual LF
!
	real*8	      B(3) , E(3) , vxB	, dv(3)
!
	real*8	      rnp1inew, vnp1inew, anp1inew
!
!	dt -- time incriment --    m -- mass of the particle 
!
	real*8        dt         , pi     , m(npart)
!
	real*8	      me	 , small      , q(npart)
!
	real 	      epsilon0
!
	data	small
     1	       /0.1d-99/
!
!
!
!
!-----------------------------------------------------------------------
!
!	Start up CPU time counter.
!
	cputot = etime ( tdummy )
!
!
!-----------------------------------------------------------------------
!
!	Set up data files' headers
!
!	file including the positions with magnetic field vectors
!	used with gnuplot 'w vectors' 
	open  (200 , file = 'magln.dat'        , status ='unknown')
!	file including initial positions
	open  (150 , file = 'traj0.dat'        , status ='unknown')
!	file including final positions
	open  (250 , file = 'final.dat'        , status ='unknown')
! 	file including the dv to test dual LF
	open  (999 , file = 'dv.dat'	       , status ='unknown')
!
	write	( 50, 2010)
	write	( 50, 2020)
!
!-----------------------------------------------------------------------
!
!	Determine the time increments dt
!
!	This is a random choice. dt can go way higher. it is a matter of taste
!
	dt 	 =  0.01d0
!
!	**************************************************************
!	**************************************************************
!	**************************************************************
!	
!			Determine E 
!
	E( 1 )    =  0.0d0
 	E( 2 )    =  0.0d0
	E( 3 )    =  0.0d0
!
c	B( 1 )    =  0.0d0
c	B( 2 )    =  0.0d0
c	B( 3 )    =  0.0d0
!
!		For B we will be calling mag accordingly
!	in case you are interested in a constant B declare it up here
!	**************************************************************
!	**************************************************************
!	**************************************************************
!	Declare some data!
!
!       m -- mass of the orbiting particle --
!
	me	 =  1.0d0
	epsilon0 =  1.0d0
	pi 	 =  1.0d0
!
!	**************************************************************
!
!	Start by defining the initial conditions r0 and v0.
!
	call mesh ( r0i, v0i, q , (1.0d0) , npart)
!
!	Manual definitions
!
!	r0i( 1,1 ) =  1.0d0
!	r0i( 1,2 ) =  0.0d0
!	r0i( 1,3 ) = -1.0d0
!
!	v0i( 1,1 ) =  0.0d0
!	v0i( 1,2 ) =  1.0d0
!	v0i( 1,3 ) =  0.05d0 
!
!	Read from a file called cluster.dat
!	IF READING FROM FILE REMEMBER TO COMMENT OUT THE THE Q AND M SECTIONS
!
c	open ( 87, file = 'cluster.dat', status='old')
c	do 452 i = 1, npart
c	read ( 87, *) r0i(i,1), r0i(i,2), r0i(i,3), v0i(i,1), 
c     1        v0i(i,2), v0i(i,3), m(i), q(i)
c452	continue
!
!	Get files ready !
!
	tag = 0
	write ( flname, 2001) tag
!
	open   ( tag, file =  flname , status = 'unknown')
c	do 444 i = 1 , npart	
c	write  ( tag, 2030 ) r0i(i,1), r0i(i,2), r0i(i,3)
c444	continue
c	close (tag)
!
!
	do 235 j = 1 , npart
	m(j) = me
235	continue
!
!	Determining the charge of the particles
!
	do 236 j = 1 , npart
	q(j) = (-1.0d0)**j
236	continue
!
!	**************************************************************
!
!	Defining the total mass
!
	mtot = 0
	do 8 j = 1 , npart
	mtot = mtot + m(j)
8	continue
!
!	Defining the total weighted position
!
	mpos(1) = 0.0d0
	mpos(2) = 0.0d0
	mpos(3) = 0.0d0 
!
!	**************************************************************
!
!
!
	do 9  k = 1 , 3	
	mdum (k) = 0.0d0
	do 10 j = 1 , npart
	mdum (k) = m(j) * r0i( j,k )
	mpos (k) = mpos(k) + mdum(k)
10	continue
	rcm( k )   = ( 1.0d0 / mtot ) * ( mpos(k) )
9	continue
!
!
!	**************************************************************
!
!	Switching to com reference frame.... usually i initialize the 
!	points in the COM reference frame
!
	   do 5 j = 1 , npart 
cerr	   do 6 k = 1 , 3 
cerr	   r0i( j,k ) = r0i( j,k ) - rcm( k )
cerr6	   continue
cerr	   r0i( j,4 ) = r0i( j,4 )
	write (150, 2030) r0i( j,1 ), r0i( j,2 ), r0i( j,3 )
5	   continue
!
!
!	**************************************************************
!
!	Start by calculating the first acceleration a0
!
	do 20 j = 1 , npart
	do 21 k = 1 , 3 
	f(j,k) = 0.0d0
21	continue
20	continue
!
!
	do 1855 i = 1 , npart-1
	print*, 'finding the 0 forces******************'
	do 1856 j = i+1, npart
	do 1857 k = 1 , 3
	fij(i,j,k) =( q(i) * q(j) ) / ( ( 4.0d0 * pi * epsilon0 ) * 
     1              ( ( ( (r0i( i,1 )-r0i( j,1 ))**2 ) + 
     2              ( (r0i( i,2 )-r0i( j,2 ))**2 ) +   
     3              ( (r0i( i,3 )-r0i( j,3 ))**2 ) )**1.5)+small ) * 
     4		    ( r0i( i,k )-r0i( j,k ) )

	if (abs(fij(i,j,k)) .ge. 1.0d-16) then
	fij(i,j,k)=0.0d0
	endif

	fij(j,i,k) = -1.0d0 * fij(i,j,k)

	f(i,k)     = f(i,k) + fij(i,j,k)
	f(j,k)	   = f(j,k) + fij(j,i,k)
	
1857	continue
1856	continue
1855	continue
!
	do 1858 i = 1 , npart
!
!	in case of constant B comment out B lines
!
	print*, 'Calling B0********i**********', i
	call mag ( r0i, i, npart, box, B) 
	print*, B(1), B(2), B(3)
	write (200,*) B(1), B(2), B(3)
	write(tag,*) r0i(i,1), r0i(i,2), r0i(i,3), B(1), B(2), B(3)
	do 14 k = 1 , 3
	if ( r0i(i,4) .eq. 1.0d0 ) then
	a0i(i,k) = 0.0d0
	v0i(i,k) = 0.0d0
	else
!
	a0i( i,k ) = ( 1/m(i) ) * ( f(i,k) + ( q(i) * E(k) ) +
     1              ( q(i) * vxB( v0i , B , k , i , npart ) ) )
	endif
14	continue
1858	continue
	close (tag)
!
!
!
!	**************************************************************
!
	do 109 j = 1 , npart
	do 110 k = 1 , 3
	rni( j,k )  =  r0i( j,k )
	vni( j,k )  =  v0i( j,k )
	ani( j,k )  =  a0i( j,k )
110	continue
109	continue
!
!	**************************************************************
!
!
!
!
!	**************************************************************
!
!		Initialize half time steps
!
!
	do 177 j = 1 , npart
!
	do 178 k = 1 , 3
	vnphi( j,k) = vni( j,k ) + ( 0.5 * dt * ani( j,k ) )
!
	rnphi( j,k) = rni( j,k ) + ( 0.5 * dt * vni( j,k ) )	
178	continue
177	continue
!
!		Now finding the half time step acceleration
!
!
!
	do 420 j = 1 , npart
	do 121 k = 1 , 3 
	fh(j,k) = 0.0d0
121	continue
420	continue
!
!
	do 190 i = 1 , npart-1
	print*, 'Finding the h forces******************'
	do 191 j = i+1, npart
	do 192 k = 1 , 3
	fijh(i,j,k) =( q(i) * q(j) ) / ( ( 4.0d0 * pi * epsilon0 ) * 
     1              ( ( ( (rnphi( i,1 )-rnphi( j,1 ))**2 ) + 
     2              ( (rnphi( i,2 )-rnphi( j,2 ))**2 ) +   
     3              ( (rnphi( i,3 )-rnphi( j,3 ))**2 ) )**1.5)+small ) * 
     4		    ( rnphi( i,k )-rnphi( j,k ) )

	if (abs(fijh(i,j,k)) .ge. 1.0d-16) then
	fijh(i,j,k)=0.0d0
	endif

	fijh(j,i,k) = -1.0d0 * fij(i,j,k)

	fh(i,k)     = fh(i,k) + fijh(i,j,k)
	fh(j,k)	    = fh(j,k) + fijh(j,i,k)
	
192	continue
191	continue
190	continue
!
	do 1193 i = 1 , npart
!
!	IN CASE OF CST B COMMENT OUT B LINES	
!
	print*, 'Calling Bh********i**********', i
	call mag ( rnphi, i, npart, box, B) 
	do 193 k = 1 , 3
	if ( r0i(i,4) .eq. 1.0d0 ) then
	anphi(i,k) = 0.0d0
	vnphi(i,k) = 0.0d0
	else
	anphi( i,k ) = ( 1/m(i) ) * ( fh(i,k) + ( q(i) * E(k) ) +
     1              ( q(i) * vxB( vnphi , B , k , i , npart ) ) )
	endif
193	continue
1193	continue
!
!
!
!	**************************************************************
!
!	 #####                               #                            
!	#     # #####   ##   #####  #####    #        ####   ####  #####  
!	#         #    #  #  #    #   #      #       #    # #    # #    # 
!	 #####    #   #    # #    #   #      #       #    # #    # #    # 
!	      #   #   ###### #####    #      #       #    # #    # #####  
!	#     #   #   #    # #   #    #      #       #    # #    # #      
!	 #####    #   #    # #    #   #      #######  ####   ####  #      
!
!
!	**************************************************************
!
!	
!
	do 120 n = 1 , ndt
!
!
!	   		Variable timestep goes here.
!	because the plasma particles have high velocities and they are 
!	close together, a variable timestep can be ignored. 
!	I tried a variable timestep but it didnt change anything in the
!	output over ~ 50000 dts so i decided to ignore it
!
	print*, '*************** The value for n is: ', n
!
!	getting file ready to print positions to.
!
	tag = tag + 1
	write (flname, 2001) tag
	open   ( 66, file =  flname , status = 'unknown')	
!
!	finding full time step positions
!
	do 115 j = 1 , npart
	do 116 k = 1 , 3
	if ( r0i(j,4) .eq. 1.0d0 ) then
	rnp1i( j,k ) = r0i( j,k )
	else
	rnp1i( j,k ) = rni( j,k ) + ( vnphi( j,k ) * dt )
	endif
116	continue
115	continue
!
!	finding full time step velocities
!
	do 200 i = 1 , npart
	do 201 k = 1 , 3
	vnp1i( i,k ) = vni( i,k ) + ( anphi( i,k ) * dt )
201	continue
200	continue
! 
!	calculating forces
!
	do 71 i = 1 , npart
	do 72 k = 1 , 3 
	f(i,k) = 0.0d0
72	continue
71	continue
!
!
!
	do 31 i = 1 , npart-1
	do 32 j = i+1, npart

	do 33 k = 1 , 3

	fij(i,j,k) =( q(i) * q(j) ) / ( ( 4.0d0 * pi * epsilon0 ) * 
     1              ( ( ( (rnp1i( i,1 )-rnp1i( j,1 ))**2 ) + 
     2              ( (rnp1i( i,2 )-rnp1i( j,2 ))**2 ) +   
     3              ( (rnp1i( i,3 )-rnp1i( j,3 ))**2 ) )**1.5)+small )* 
     4		    ( rnp1i( i,k )-rnp1i( j,k ) )

	if (abs(fij(i,j,k)) .ge. 1.0d-16) then
	fij(i,j,k)=0.0d0
	endif

	fij(j,i,k) = -1.0d0 * fij(i,j,k)

	f(i,k)     = f(i,k) + fij(i,j,k) 	
	f(j,k)     = f(j,k) + fij(j,i,k) 

33	continue
32	continue
31	continue
!
	do 61 i = 1 , npart
!
!	in case of a cst B comment out B lines
!
	print*, 'Calling B***n,i****', n, i
	call mag ( rnp1i, i, npart, box, B) 
	write(66,*) rnp1i(i,1),rnp1i(i,2),rnp1i(i,3),B(1),B(2),B(3)
	do 63 k = 1 , 3
	if ( r0i(i,4) .eq. 1.0d0 ) then
	anp1i(i,k) = 0.0d0
	vnp1i(i,k) = 0.0d0
	else
	anp1i( i,k ) = ( 1/m(i) ) * ( f(i,k) + ( q(i) * E(k) ) +
     1              ( q(i) * vxB( vnp1i , B , k , i , npart ) ) )
!
	endif
63	continue
61	continue
	close (66)
!
!
!
!		The same over the half time step now!!!
!
!
!
	do 215 j = 1 , npart
	do 216 k = 1 , 3
	rnp3hi( j,k ) = rnphi( j,k ) + ( vnp1i( j,k ) * dt )
216	continue
215	continue
!
	do 210 j = 1 , npart
	do 211 k = 1 , 3
	vnp3hi( j,k ) = vnphi( j,k ) + ( anp1i( j,k ) * dt )
211	continue
210	continue
! 
	do 271 i = 1 , npart
	do 272 k = 1 , 3 
	fh(i,k) = 0.0d0
272	continue
271	continue
!
!
	do 231 i = 1 , npart-1
	do 232 j = i+1, npart
	do 233 k = 1 , 3

	fijh(i,j,k) =( q(i) * q(j) ) / ( ( 4.0d0 * pi * epsilon0 ) * 
     1              ( ( ( (rnp3hi( i,1 )-rnp3hi( j,1 ))**2 ) + 
     2              ( (rnp3hi( i,2 )-rnp3hi( j,2 ))**2 ) +   
     3              ( (rnp3hi( i,3 )-rnp3hi( j,3 ))**2 ))**1.5)+small)* 
     4		    ( rnp3hi( i,k )-rnp3hi( j,k ) )
!
	if (abs(fijh(i,j,k)) .ge. 1.0d-16) then
	fijh(i,j,k)=0.0d0
	endif
!
	fijh(j,i,k) = -1.0d0 * fij(i,j,k)

	fh(i,k)     = fh(i,k) + fijh(i,j,k) 	
	fh(j,k)     = fh(j,k) + fijh(j,i,k) 

233	continue
232	continue
231	continue
!
!
	do 261 i = 1 , npart
!
!	In case of B lines comment out B lines
!
	call mag ( rnp3hi, i, npart, box, B)
	do 263 k = 1 , 3
	if ( r0i(i,4) .eq. 1.0d0 ) then
	anp3hi(i,k) = 0.0d0
	vnp3hi(i,k) = 0.0d0
	else 
	anp3hi( i,k ) = ( 1/m(i) ) * ( f(i,k) + ( q(i) * E(k) ) +
     1              ( q(i) * vxB( vnp3hi , B , k , i , npart ) ) )
	endif
263	continue
261	continue
!
!
!
!	**************************************************************
!	**************************************************************
!		Reflective Boundary Conditions !!!
!			Bounce back into box.
!
!	do 250 i = 1 , npart
!	do 251 k = 1 , 3
!
!765	if (abs(rnp1i(i,k)) .ge. box) then
!	call bounce( rnp1i( i,k ) , vnp1i( i,k ) , anp1i( i,k ),
!     1			   box , rnp1inew, vnp1inew, anp1inew )  
!	rnp1i(i,k) = rnp1inew
!	vnp1i(i,k) = vnp1inew
!	anp1i(i,k) = anp1inew
!	goto 765
!	endif
!
!766	if (abs(rnp3hi(i,k)) .ge. box) then
!	call bounce( rnp3hi( i,k ), vnp3hi( i,k ) ,anp3hi( i,k ),
!     1			   box , rnp1inew, vnp1inew, anp1inew ) 
!	rnp3hi(i,k) = rnp1inew
!	vnp3hi(i,k) = vnp1inew
!	anp3hi(i,k) = anp1inew
!	goto 766
!	endif
!
!251	continue
!250	continue
!
!	**************************************************************
!	**************************************************************
!			absorbing boundary effects
!
!
	do 1250 i = 1 , npart
	do 1251 k = 1 , 3
!
	if (rnp1i(i,k) .ge. 2*box) then
	rnp1i(i,k) = box
	vnp1i(i,k) = 0.0d0
	anp1i(i,k) = 0.0d0
	endif
!
	if (rnp1i(i,k) .le. -2*box) then
	rnp1i(i,k) = box
	vnp1i(i,k) = 0.0d0
	anp1i(i,k) = 0.0d0
	endif
!
	if (rnp3hi(i,k) .ge. 2*box) then
	rnp3hi(i,k) = box
	vnp3hi(i,k) = 0.0d0
	anp3hi(i,k) = 0.0d0
	endif
!
	if (rnp3hi(i,k) .le. -2*box) then
	rnp3hi(i,k) = box
	vnp3hi(i,k) = 0.0d0
	anp3hi(i,k) = 0.0d0
	endif
!
1251	continue
1250	continue
!
!
!	**************************************************************
!
!	Finding the center of mass	
!
!	Defining the total weighted position
!
cerr	mpos(1) = 0.0d0
cerr	mpos(2) = 0.0d0
cerr	mpos(3) = 0.0d0
!
!	Determing the center of mass
cerr	do 39  k = 1 , 3	
cerr	do 40 j = 1 , npart
cerr	mdum (k) = m(j) * rnp1i( j,k )
cerr	mpos (k) = mpos(k) + mdum(k)
!
cerr	continue
cerr	rcm( k )   = ( 1 / mtot ) * ( mpos(k) )
cerr	continue
!
cerr	print*, 'The position of the com is:', rcm(1), rcm(2), rcm(3)
!
!	**************************************************************
!	**************************************************************
!			Test the dual leap frog.
!
	do 220 i = 1 , npart
	do 221 k = 1 , 3
	dv(k)=(abs((abs(vnp1i(i,k) + vni(i,k))*0.5)-abs(vnphi(i,k))))/
     1	     ((abs(vnp1i(i,k))+abs(vni(i,k))+abs(vnphi(i,k)))/3+small)
221	continue
	write(999, * ) n , dv(1),dv(2),dv(3)
220	continue
!
!	**************************************************************
!	**************************************************************
!
!	Return to the COM reference frame
!
!
cerr	if(rcm(1).ge. 1.0d-4 .or. rcm(2).ge. 1.0d-4 .or. rcm(2).ge. 
cerr     1     1.0d-4) then
!	do 567 j = 1 , npart
cerr	do 568 k = 1 , 3
cerr	rnp1i( j,k ) = rnp1i( j,k ) - rcm( k )
cerr568	continue
!	write ( 50, 2030) rnp1i(j,1), rnp1i(j,2), rnp1i(j,3), n
!567	continue
cerr	else
cerr	do 3 j = 1 , npart
cerr	write ( 50, 2030) rnp1i(j,1), rnp1i(j,2), rnp1i(j,3), n
cerr3	continue
cerr	endif
!
!
!
!
!
!	**************************************************************
!
!
	   do 1133 j = 1 , npart
	   do 133 k = 1 , 3
	   ani( j,k ) = anp1i( j,k )
	   vni( j,k ) = vnp1i( j,k )
	   rni( j,k ) = rnp1i( j,k )
!
	   if (n.eq.ndt) then
	   write (250, 2030) rnp1i(j,1), rnp1i(j,2), rnp1i(j,3)
	   endif
!
!
	   anphi( j,k ) = anp3hi( j,k )
	   vnphi( j,k ) = vnp3hi( j,k )
	   rnphi( j,k ) = rnp3hi( j,k )

133	   continue
1133	   continue
!
!
!
120	continue
!
!			End of THE LOOP!!
!		
!	**************************************************************
!
!      End CPU time counter, and report cpu time used.
!
	close ( 250 )
	close ( 150 )
	close ( 999 )
!
!
666	cputot = etime ( tdummy ) - cputot
	write(6, 2080) cputot
!
!-----------------------------------------------------------------------
!----------------------- Write format statements -----------------------
!-----------------------------------------------------------------------
!
2001	format ('pl',i7.7,'.dat')
!
2010    format('#Eor: This files contains the coordinates of the'
     1        ,' particle.')
!
2020    format('# x		y		z ' )
!
2030    format(1pg17.10,2x,1pg17.10,3x,1pg17.10,i6)
!
2080    format('Eor:'
     1        ,'   Total cpu usage for this run is ',1pg12.5
     2        ,' seconds.')
!
        stop
        end
!
!=======================================================================
!
!    \\\\\\\\\\           E N D   P R O G R A M           //////////
!    //////////                                           \\\\\\\\\\
!
!=======================================================================
!
!
!
!
!
!
!=======================================================================
!
!    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
!    //////////                 BOUNCE                    \\\\\\\\\\
!
!=======================================================================
!
        subroutine bounce(rnp1i, vnp1i, anp1i, box, rnp1inew, vnp1inew, 
     1			  anp1inew)
!
!    abcd: <--------------------- 
!                                                            march, 2002
!
!    written by: A Busy Code Developer
!    modified 1: 
!
!  PURPOSE:  This routine is to bounce the particle back inside the cube.
!			Reflective Boundaries 
!
!  INPUT VARIABLES:
!
!  OUTPUT VARIABLES:
!
!  EXTERNALS:
!
!-----------------------------------------------------------------------
!
	implicit none
!
	real*8	box, boxnew, rnp1i , vnp1i, rnp1inew, vnp1inew
	real*8  anp1i, anp1inew
!
!-----------------------------------------------------------------------
!
	if (rnp1i .lt. 0.0d0 ) then
	boxnew = -1.0d0 * box
	else
	boxnew = box
	endif
!
	rnp1inew = (2.0d0 * boxnew) - rnp1i 
	anp1inew = -1.0d0 * anp1i
	vnp1inew = -1.0d0 * vnp1i
!
!	if ( (vnp1i * boxnew) .gt. 0.0d0 ) then
!	vnp1inew = -1.0d0 * vnp1i
!	else if ( (vnp1i * boxnew) .lt. 0.0d0 ) then
!	vnp1inew = vnp1i
!	endif
!
        return
        end
!
!=======================================================================
!
!    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
!    //////////                 BOUNCE                    \\\\\\\\\\
!
!=======================================================================
!
!
!
!=======================================================================
!
!    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
!    //////////                   MESH                    \\\\\\\\\\
!
!=======================================================================
!
       subroutine mesh ( r0i, v0i, qi , bpart , npart) 
!
!  written by: MHH, February 2012
!
!  PURPOSE:  This subroutine generates a mesh of particles.
!
!  EXTERNALS:
!
!-----------------------------------------------------------------------
!
	implicit none
!
	real*8	dx	,	dy	,	dz	,	bpart
!							bpart = box - 1
	real*8	x	,	y	,	z	,	q
!
	real*8  r0i(npart,4)	,	v0i(npart,3)	,     qi(npart)	
!
	integer	i	,	j	,	k	,	ndim
!
	integer pt	,	npart
!
!-----------------------------------------------------------------------
!
!
	ndim = npart**(1.0d0/3.0d0) -0.6d0 
!	print*, 'The value of ndim is:------', ndim,' ------'
	pt = 0
	x = -0.5d0*bpart
	y = -0.5d0*bpart
	z = -0.5d0*bpart
!
	dx = ( bpart ) / ndim			!!!!!!!!!!!!!!!!!
	dy = ( bpart ) / ndim		!!!! npart = ( ndim + 1 ) ** 3
	dz = ( bpart ) / ndim 			!!!!!!!!!!!!!!!!!
!

	do 1 i = 1 , ndim+1
	do 2 j = 1 , ndim+1
	do 3 k = 1 , ndim+1
!	
	pt = pt + 1
!	q = ( 1.60d-19 ) * ( -1.0d0 )**( i + j + k - 3.0d0 )
	q = ( -1.0d0 )**( i + j + k - 3.0d0 )
!
!	populate particles' position array !!
!	
	r0i(pt,1)  = x
	r0i(pt,2)  = y
	r0i(pt,3)  = z
	r0i(pt,4)  = 0.0d0     ! this allows the particles to move or stay put
	qi(  pt )  = q
!
	v0i(pt,1)  = 1.0d0
	v0i(pt,2)  = 1.0d0
	v0i(pt,3)  = 0.0d0
!
!	to create a lattice with fixed boundaries un comment the if statemetn
!
c	if (x .eq. (-0.5d0*bpart) .or. y .eq. (-0.5d0*bpart) .or. z 
c      1 .eq. (-0.5d0*bpart) 
c     2 .or. x .eq. (-0.5d0*bpart) .or. y .eq. (-0.5d0*bpart) .or. z 
c     3 .eq. (-0.5d0*bpart) ) then 
c	r0i(pt,4)  = 1.0d0
c	endif
!			!!!!   1 = fixed,  0 = can move  !!!!
!
	write ( 10, 2010) r0i(pt,1), r0i(pt,2) , r0i(pt,3), r0i(pt,4), q
!
	z = z + dz
3	continue	
!
	y = y + dy
	z = -0.5d0*bpart
2	continue
!
	x = x + dx
	y = -0.5d0*bpart
	z = -0.5d0*bpart
1	continue
!
!-----------------------------------------------------------------------
!------------------------Write format statements------------------------             
!-----------------------------------------------------------------------
!
2010	format(1pg17.10,2x,g17.10,3x,g17.10,4x,g17.10,5x,g17.10)
!
!
	return
	end
!
!=======================================================================
!
!    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
!    //////////                   MESH                    \\\\\\\\\\
!
!=======================================================================
!
!
!
!
!
!=======================================================================
!
!    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
!    //////////                 vxB                       \\\\\\\\\\
!
!=======================================================================
!
        function vxB( v , B , k , i , npart )
!
!    abcd: <--------------------- 
!                                                            march, 2002
!
!    written by: A Busy Code Developer
!    modified 1: 
!
!  PURPOSE:  This function returns the cross product ( v x B )
!
!  INPUT VARIABLES:   v		- array of velocities
!		      B		- magnetic field array
!		      k		- coordinate of interest
!		      i		- particle of interest
!
!
!  OUTPUT VARIABLES:		   
!		      vxB	- v x B cross product 
!
!  EXTERNALS: NONE
!
!-----------------------------------------------------------------------
!
        implicit      none
!
	integer i	, k 	, npart
!
	real*8	v(npart,3)	,	B(3)	,	vxB
!
!-----------------------------------------------------------------------
!

	if (k .eq. 1) then
	vxB = v(i,2)*B(3) - v(i,3)*B(2)
!
	else if (k .eq. 2) then
	vxB = v(i,3)*B(1) - v(i,1)*B(3)
!
	else if (k .eq. 3) then
	vxB = v(i,1)*B(2) - v(i,2)*B(1)
!
	endif
!
        return
        end
!
!=======================================================================
!
!    \\\\\\\\\\          E N D   F U N C T I O N          //////////
!    //////////                 vxB                       \\\\\\\\\\
!
!=======================================================================
!
!
!
!
!
!
!
!
!=======================================================================
!
!    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
!    //////////                   MAG                     \\\\\\\\\\
!
!=======================================================================
!
       subroutine mag ( ri, j, npart, box, B) 
!			 j is particle number
!
!  written by: MHH, February 2012
!
!  PURPOSE:  This subroutine finds the magnetic field in case of a 
!             magnetic bottle
!
!  EXTERNALS:
!
!-----------------------------------------------------------------------
!
	implicit none
!
	real*8	ri(npart,3) , B(3), tiny, box, h, r, k, bigk, bige, Br
!
	real*8  bigkme
!
	integer npart, i, j
!
	data	tiny
     1	       /0.1d-99/
!
!-----------------------------------------------------------------------
!
!	print*, 'mag has been called*******MAG********', j
!
	B(1) = 0.0d0
	B(2) = 0.0d0
	B(3) = 0.0d0
	Br   = 0.0d0
!
	r = sqrt((ri(j,1)**2)+(ri(j,2)**2)) 
	h =  2.0d0
!
1	continue
!
	k = sqrt((4.0d0*r)/((r+1)**2+(ri(j,3)-h)**2))
! 
!	Call integrator to solve the integrals
!
!
c	print*, 'Call for bigk'
	call integrate ( k , bigk, 1)
c	print*, bigk
c	print*, 'Call for bige'
	call integrate ( k , bige, 2)
c	print*, bige
c	print*, 'Call for ker'
	call integrate ( k , bigkme, 3)
c	print*, bigkme
!
	B(3) = B(3) + ((1.0d0/((2.0d0 * sqrt ((r+1.0d0)**2 + 
     1        (ri(j,3)-h)**2) ) + tiny) ) * ( 
     2        bigk + ((((r+1.0d0) / ((( (r+1.0d0)**2 + (ri(j,3)-h)**2)
     3        * ( 1.0d0 - k**2)) +tiny))-(1.0d0/ ((1.0d0- k**2)+tiny))
     4        *bige))))
!
	Br   = Br + ((ri(j,3)-h)/( (2.0d0 * sqrt ((r+1.0d0)**2 + 
     1        (ri(j,3)-h)**2) +tiny ) ) ) * ( ( (4.0d0/(((r+1.0d0)**2 +
     2        (ri(j,3)-h)**2) +tiny) ) * bigkme ) +
     3        ((2.0d0*bige) / ( ( (r+1.0d0)**2 + (ri(j,3)-h)**2) + tiny
     4        ) ) * ( 1.0d0 / ( ( 1.0d0 - k**2 )+ tiny ) ) )
!
!	loop back for the other coil
!
	if (h.gt. 0) then
	h = -2.0d0
	goto 1
	endif
!
	B(1) = (Br)*(ri(j,1)/( r + tiny))
!
	B(2) = (Br)*(ri(j,2)/( r + tiny))
!
!	magnifying B because B in a bottle is >>1
!
!
	B(1) = 50.0d0 * B(1)
	B(2) = 50.0d0 * B(2)
	B(3) = 50.0d0 * B(3)
!
!
	return
	end
!
!=======================================================================
!
!    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
!    //////////                   MAG                     \\\\\\\\\\
!
!=======================================================================
!
!
!
!
!
!
!=======================================================================
!
!    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
!    //////////                 foxe                      \\\\\\\\\\
!
!=======================================================================
!
        function fox( choice, k, x)
!
!    abcd: <--------------------- 
!                                                            march, 2002
!
!    written by: A Busy Code Developer
!    modified 1: 
!
!  PURPOSE:  The integrals we wish to integrate for the mag field
! 
!  EXTERNALS: NONE
!
!-----------------------------------------------------------------------
!
        implicit      none
!
!
	real*8	x , k ,	foxe , tiny , fox
!
	integer choice
!         
	data	tiny
     1	       /0.1d-99/
!
!-----------------------------------------------------------------------
!
	if (choice .eq. 1 ) then
	fox = 1.0d0/( sqrt( 1.0d0-((k**2)*(sin(x))**2) ) + tiny)
	elseif (choice .eq. 2) then
	fox =  sqrt( 1.0d0-((k**2)*(sin(x))**2) )
	elseif (choice .eq. 3) then
	fox =  ( ((sin(x))**2) -1.0d0 ) / (sqrt( 1.0d0-( (k**2)*
     1          (sin(x))**2) ) +tiny )
	endif

!
        return
        end
!
!=======================================================================
!
!    \\\\\\\\\\          E N D   F U N C T I O N          //////////
!    //////////                 foxe                      \\\\\\\\\\
!
!=======================================================================
!
!
!		a COPY OF THE RMGRG FROM THE ASSIGNMENT
!
!
!
!
c-----------------------------------------------------------------------
c-----------------------------BEGIN  PROGRAM----------------------------
c---------------------------------RMBRG---------------------------------
c-----------------------------------------------------------------------
c
       subroutine integrate ( kay , ans, choice)
c
c    MHH:	RMBRG		<---------------------Romberg integrator 
c                                                            March, 2012
c  Written by: MHH, March 2012
c
c  PURPOSE:  This is a Romberg integrator. The integrand is the function
c	     fofx.
c
c  EXTERNALS:	EMsum		RMratio		fox
c  	   
c
c-----------------------------------------------------------------------
c
	implicit none
c
	integer choice
c
	integer	dim
	parameter (dim = 10000)
c
c	increment of ind.var.	Euler Maclaurin Sum	Romberg ratio  
c	        hm		  T     m  ,  j		  Rm
	real*8	Tmj(dim,dim)	, Rm(dim)	, int
c
	real*8	a		, b			, tol
c
	real*8	fox		, epsilon		, tiny
c
	real*8  foxk            , foxe        , ans    , kay
c
	real	cpubeg		, cpuend 		, cputot  
c				correction step		
	integer	m		, j			, k 	,i
c
	data	 epsilon	, tiny
     1		/1.0d-5		, 1.0d-99/
c
	external EMsum		, RMratio
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
c
c      The data is to be written to a file. Open file and set headers.
c
c     	 Open disc files "table.dat" which will include the 
c		richardson extrapolation table
c
c      	           Start by writing headers.
c
	a = 0.0d0
	b = acos(0.0d0)
c
!	print*, 'RMBRG has been called*******RMBRG*******'
c-----------------------------------------------------------------------
c
c	Start by Determining T(1,0)		! j = correction +1 ! 
c
!	print*, 'RMBRG: Calculating T1,1 *******RMBRG*******'
c
	Tmj(1,1) = ( 0.25d0 * (b-a) * ( fox(choice, kay, a) + 
     1              fox(choice, kay, b) ) ) +  
     2		   ( 0.5d0 * (b-a) * ( fox( choice, kay, a + 0.5d0 * (b-a)
     3              ) ) )
c
!	print*, 'RMBRG: Finished T1,1 *******RMBRG*******'
c
c	Calculate T(2,0) and T(3,0)
c
!	print*, 'RMBRG: Calculating T2 , T3 *******RMBRG*******'
c
	do 1 m = 2 , 3
	call EMsum( a, b, m, Tmj(m-1,1), Tmj(m,1) , choice, kay)
!	print*, 'RMBRG: if 0 *******RMBRG*******'	
	if ( Tmj(m,1) .eq. Tmj(m-1,1) ) then
	ans = Tmj(m,1)
	goto 20 
	endif
1	continue
!	print*, 'RMBRG: Finished T2 , T3 *******RMBRG*******'
	m = 3
c
c	Calculate the Romberg ratio for m = 2 -- R(2) --
c
50	continue!print*, 'RMBRG: Calculating R2 *******RMBRG*******'
c
	call RMratio( Tmj(m-2,1), Tmj(m-1,1), Tmj(m,1), Rm(m-1) ) 
!
!	print*, 'RMBRG: Finished R2 *******RMBRG*******'           
c
c	Check if R(2) > 3.5
c
!	print*, 'RMBRG: if 1 *******RMBRG*******'
c
	if (m-1 .gt. dim) then
!	print*, 'RMBRG: Could not find R>3.5 :-('
	goto 20
	endif
c
c	if R(2) < 3.5 --> continue calculating T(m+1,0)
c
!	print*, 'RMBRG: if 2 *******RMBRG*******'
c
	if (Rm(m-1) .le. 3.5d0) then
	m = m + 1
c
!	print*, 'RMBRG: Calculating Tm,1 *******RMBRG*******', m
c
	call EMsum( a, b, m, Tmj(m-1,1), Tmj(m,1) , choice, kay)
c
!	print*, 'RMBRG: Finished Tm,1 *******RMBRG*******'
c
	!if T(m,j) is constant we already converged --> end program!
!	print*, 'RMBRG: if 3 *******RMBRG*******'
c
	if ( Tmj(m,1) .eq. Tmj(m-1,1) ) then
	ans = Tmj(m,1)
!	print*, 'RMBRG: Converged fast 1 *******RMBRG*******'
	goto 20 
	endif
	goto 50
c
c	if R(2) > 3.5 --> fix m and proceed to generate the RE table
c
!	print*, 'RMBRG: if 4 *******RMBRG*******'
c
	else if (Rm(m-1) .gt. 3.5d0) then
	m = m-1  			          !Fixing m!
!	print*, 'RMBRG: Romberg Ration > 3.5 *******RMBRG*******'
	goto 60				          !Proceeding to generate RE table !
	endif 
c
c	Generating the RE table
c
60	do 5 k = 1 , dim-m
c
	do 10 j = 2 , k+1
c
c	Finding the nth corrections
c
!	print*, 'RMBRG: Calculating Tm+k,j *******RMBRG*******', m+k, j
c
	Tmj(m+k,j) = (((4.0d0**j) * Tmj(m+k,j-1)) - Tmj(m+k-1,j-1))/
     1			( ( ( 4.0d0**j ) -1.0d0 ) + tiny)
c
!	print*, 'RMBRG: Finished Tm+k,j *******RMBRG*******'
10	continue
c
c	Checking for the tolerance
c
!	print*, 'RMBRG: Calculating tol *******RMBRG*******'
c
	tol = 2 * abs( ( Tmj(m+k,k+1) - Tmj(m+k,k) ) /
     1		     ( ( Tmj(m+k,k+1) + Tmj(m+k,k) ) + tiny ) )
c
!	print*, 'RMBRG: Finished tol *******RMBRG*******'
c
c
c	if tolerance < desired tolerance (epsilon) , terminate !!!
c	if tolerance > desired tolerance (epsilon) , continue crunching numbers...
c
!	print*, 'RMBRG: if 5*******RMBRG*******'
c
	if ( tol .lt. epsilon )	then	
	ans = Tmj(m+k,k)
!	print*, 'RMBRG: Completed and returning 2 *******RMBRG*******'
	goto 20
	endif
c
c	if k exceeds the dimention given by the user
c
	print*, 'RMBRG: if 6*******RMBRG*******'
c
	if ( k .eq. dim-m ) then
	ans = Tmj(m+k,k)
!	print*, 'RMBRG: Completed and returning 3 *******RMBRG*******'
	goto 20
	endif
c	
c	finding the value T(m+k+1,0) for the next iteration.
c
!	print*, 'RMBRG: Calculating Tm+k+1,1*******RMBRG*******', m+k+1
c
	call EMsum( a, b, m+k+1, Tmj(m+k,1), Tmj(m+k+1,1), choice,kay)
c
!	print*, 'RMBRG: Finished Tm+k+1 *******RMBRG*******'
c
	!if T(m,j) is constant we already converged --> end program!
!	print*, 'RMBRG: if 7*******RMBRG*******'
c
	if ( Tmj(m+k,1) .eq. Tmj(m+k+1,k+1) ) then
	ans = Tmj(m+k+1,1)
!	print*, 'RMBRG: Completed and returning 4 *******RMBRG*******'
	goto 20 
	endif
c
5	continue
c

c
c-----------------------------------------------------------------------
c      			 RMBRG's almost done!!!
c-----------------------------------------------------------------------
c
c      Final setup:	         Close Files
c     				 End CPU time counter
c     				 Report cpu time used.
c	
20	continue
c
c
c-----------------------------------------------------------------------
c------------------------Write format statements------------------------             
c-----------------------------------------------------------------------
c
2010	format('RMBRG: This is the Richardson extrapolation-like '
     1        ,'table.',/
     2        ,'	Step  	   no".int 	   Euler-Mac. 	 '
     3        ,'     1st corr.  	2nd corr.    '
     4        ,'   ......................    nth corr.')
c
2020	format('RMBRH: What is the region you would like to integrate '
     1        ,'over?--- input a <return> b <return> where a < b ---')
c
c2030   format(i7,1pg16.10,1p7g16.10)
2030   format(5p9g16.10)
c
2040   format('RMBRG : RMBRG failed to converge '
     1       ,'after ',i9,' iterations.',/
     2       ,'RMBRG : Program terminated.')
c
2050   format('RMBRG : RMBRG failed to reach a Romberg ratio > 3.5 '
     1       ,'after ',i9,' iterations.',/
     2       ,'RMBRG : Program terminated.')
c
2080	format('RMBRG: Total cpu usage for this run is ',1pg12.5
     1        ,' seconds.')
c
	return
	end
c
c-----------------------------------------------------------------------
c-------------------------------End Program-----------------------------             
c---------------------------------RMBRG---------------------------------
c-----------------------------------------------------------------------
c
c
c
c
c
c-----------------------------------------------------------------------
c---------------------------BEGIN  SUBROUTINE---------------------------
c-------------------------------- EMsum --------------------------------
c-----------------------------------------------------------------------
c
	subroutine EMsum( a, b, n, Tmj, Tmp1j , choice, k)
c
c    abcd:	RMBRG . EMsum  <-------------------- Euler-Maclaurin Sum
c                                                            March, 2012
c
c    written by: MHH, March 2012
c
c  PURPOSE: This subroutine finds the Euler - Maclaurin sum of a funct'n
c
c  INPUT VARIABLES:		a,b  -  The interval over which we wish
c					to integrate
c				n    -  The value of m for T(m,j)
c
c  OUTPUT VARIABLES:		Tmj  - The Euler Maclaurin Sum
c
c  EXTERNALS: 			fox
c
c-----------------------------------------------------------------------
c
	implicit none
c
	real*8	a	, b	, Tmj	, Tmp1j
c
	real*8	fox , foxk, foxe  , k
c
	integer	i	, n   , choice
c
c
c-----------------------------------------------------------------------
c
c
	Tmp1j = 0.0d0
c
	do 1 i = 1 , (2**(n))-1, 2
	Tmp1j = Tmp1j + fox( choice, k,(a+(i*((b-a)*(0.5d0**(n))))))
1	continue
c
	Tmp1j = (0.5d0 * Tmj ) + ( ((b-a)*(0.5d0**(n))) * 
     1			Tmp1j )
c
	return
	end
c
c-----------------------------------------------------------------------
c-------------------------END SUBROUTINE EMsum--------------------------
c-----------------------------------------------------------------------
c
c
c
c
c
c-----------------------------------------------------------------------
c---------------------------BEGIN  SUBROUTINE---------------------------
c-------------------------------- RMratio ------------------------------
c-----------------------------------------------------------------------
c
       subroutine RMratio( Tmm1j, Tmj, Tmp1j, Rm )
c
c
c    abcd:	RMBRG . RMratio  <------------- Romberg Ratio Calculator
c                                                            March, 2012
c
c    written by: MHH, March 2012
c
c  PURPOSE: This subroutine finds the Romberg Ration
c
c  INPUT VARIABLES:		Tmj  -  Euler Maclaurin Sum
c				m    -  The value m for which Rm is to
c					be calculated
c
c  OUTPUT VARIABLES:		Rm   -	The Romberg ratio 
c
c  EXTERNALS: 			none
c
c-----------------------------------------------------------------------
c
	implicit none
c
	real*8	Tmm1j	, Tmj, Tmp1j	, Rm	, tiny
c
	data	tiny
     1		/1.0d-99/
c
c-----------------------------------------------------------------------
c
	Rm = abs( ( Tmm1j - Tmj ) / 
     1		   ( ( Tmj - Tmp1j ) + tiny ) )
c
	return
	end
c
c-----------------------------------------------------------------------
c------------------------END SUBROUTINE RMratio------------------------
c-----------------------------------------------------------------------




