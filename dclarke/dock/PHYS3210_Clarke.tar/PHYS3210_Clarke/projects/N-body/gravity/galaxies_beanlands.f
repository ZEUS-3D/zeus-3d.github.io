c--------------------------------------------------------------------------------------
c--------------------------------------------------------------------------------------
c       _____              _                  __    __  _____   ____    ___ 
c      / ____|     /\     | |          /\     \ \  / / |_   _| |  __|  / __|
c     | |  __     /  \    | |         /  \     \ \/ /    | |   | |_   | |___  
c     | | |_ |   / /\ \   | |        / /\ \     >  <     | |   |  _|   \___ \ 
c     | |__| |  / ____ \  | |____   / ____ \   / /\ \   _| |_  | |__     __| |
c      \_____/ /_/    \_\ |______| /_/    \_\ /_/  \_\ |_____| |____|   |___/ 
c                                                            
c--------------------------------------------------------------------------------------                                                            
c--------------------------------------------------------------------------------------
c
      program galaxies
c
c
c    written by: Jennifer Beanlands (Winter 2012)
c
c  PURPOSE: This program lets you either create a new galaxy, or collide two galacies
c           together, dependig on what the user inputs. Althought the individual
c           galaxy may have as many stars as the user would look, the collisions are set 
c           to two galaxies of 1000 stars each. The data for the collisions can be found
c           at ~jbeanlan/{file}.dat (see include data files section). A data file is
c           created for each time step with the new positions of each star.
c
c  INCLUDE DATA FILES:
c                       rxmed.dat
c                       rymed.dat
c                       rxmed.dat
c                       vxslow.dat
c                       vxmed.dat
c                       vxfast.dat
c                       vymed.dat
c                       vzmed.dat
c    
c  EXTERNALS: Deviates
c
c--------------------------------------------------------------------------------------
c
       implicit      none
c
       integer       n
       parameter     ( n=2000 )
c
       character(len=70)   fn
       integer      i       , j       , k      , t       , tend
     1             ,outunit , initial
       real          cpubeg  , cpuend  , cputot
       real*8        dt      , rtot    , vabs   , ekin    , epot    
     1             , etoti   , etotf   , abserr , relerr  , dtout
     2             , rsquared, tout    , pi     , small   , phi
     3             , rtwo    , l       , mtot   , G
c
       real*8        r(n, 3), v(n, 3), a(n, 3)   , drel(3) , m
c
c
c
       external      deviates
c
c--------------------------------------------------------------------------------------
c
c
       write(6, *)'would you like to create a single galaxy (type 1)'
     1         ,', a  collision at low velocity (type 2), a collision'
     2         , ' at an intermediate velocity (type 3), or a '
     3         , 'collision at a high velocity (type 4).'
       read (5, *) initial
c
c
      if (initial .eq. 1) then  
c
         write(6, *) 'Make sure to change the number of stars to 1000.' 
c
c     Call random number generator for initial conditions.
c
         call deviates
         open (10, FILE='rx.dat', STATUS='OLD')
         open (11, FILE='ry.dat', STATUS='OLD')
         open (12, FILE='rz.dat', STATUS='OLD')
         open (13, FILE='vx.dat', STATUS='OLD')
         open (14, FILE='vy.dat', STATUS='OLD')
         open (15, FILE='vz.dat', STATUS='OLD')
         do 11 i= 1, n
            read(10, *) r(i, 1)
            read(11, *) r(i, 2)
            read(12, *) r(i, 3)
            read(13, *) v(i, 1)
            read(14, *) v(i, 2)
            read(15, *) v(i, 3)
11    continue
      else if (initial .eq. 2) then 
         write(6, *) 'Make sure to change the number of stars to 2000.' 
         open (16, FILE='rxmed.dat', STATUS='OLD')
         open (17, FILE='rymed.dat', STATUS='OLD')
         open (18, FILE='rzmed.dat', STATUS='OLD')
         open (19, FILE='vxslow.dat', STATUS='OLD')
         open (20, FILE='vymed.dat', STATUS='OLD')
         open (21, FILE='vzmed.dat', STATUS='OLD')
         do 12 i= 1, n
            read(16, *) r(i, 1)
            read(17, *) r(i, 2)
            read(18, *) r(i, 3)
            read(19, *) v(i, 1)
            read(20, *) v(i, 2)
            read(21, *) v(i, 3)
12       continue
      else if (initial .eq. 3) then
         write(6, *) 'Make sure to change the number of stars to 2000.'  
         open (21, FILE='rxmed.dat', STATUS='OLD')
         open (22, FILE='rymed.dat', STATUS='OLD')
         open (23, FILE='rzmed.dat', STATUS='OLD')
         open (24, FILE='vxmed.dat', STATUS='OLD')
         open (25, FILE='vymed.dat', STATUS='OLD')
         open (26, FILE='vzmed.dat', STATUS='OLD')
         do 13 i= 1, n
            read(21, *) r(i, 1)
            read(22, *) r(i, 2)
            read(23, *) r(i, 3)
            read(24, *) v(i, 1)
            read(25, *) v(i, 2)
            read(26, *) v(i, 3)
13       continue
      else if (initial .eq. 4) then 
         write(6, *) 'Make sure to change the number of stars to 2000.' 
         open (27, FILE='rxmed.dat', STATUS='OLD')
         open (28, FILE='rymed.dat', STATUS='OLD')
         open (29, FILE='rzmed.dat', STATUS='OLD')
         open (30, FILE='vxfast.dat', STATUS='OLD')
         open (31, FILE='vymed.dat', STATUS='OLD')
         open (32, FILE='vzmed.dat', STATUS='OLD')
         do 14 i= 1, n
            read(27, *) r(i, 1)
            read(26, *) r(i, 2)
            read(29, *) r(i, 3)
            read(30, *) v(i, 1)
            read(31, *) v(i, 2)
            read(31, *) v(i, 3)
14       continue
      endif
c 
       write(6, *) 'Please enter a duration'
       read (5, *) tend 
c
c      Set initial conditions.
c 
       pi      = 3.14159265d0
       G       = 1.0d0
       small   = 1.0d-19
       outunit = 44
       dt      = 0.1d0
       m       = 1.0d0
       dtout = 0.01d0
       tout  = dtout
c
c
c      Set all initial accelleration to zero
c 
       do 20 i = 1, n
          do 30 k = 1, 3
             a(i, k) = 0.0d0
30        continue
20     continue
c
c
c
       do 70 t = 1, tend
          write(fn,fmt='(i0,a)') t, '.dat'
          open(unit = outunit, file=fn, form='formatted')
          do 71 i = 1, n
             do 72 k = 1, 3
c
c      calculate the 'half step' in velocity.
c 
                v(i, k) = v(i, k) + ( a(i, k) * dt / 2.0d0 )
72           continue
             do 73 k = 1, 3
c
c      calculate the new position vector
c 
                r(i, k) = r(i, k) + ( v(i, k) * dt )
73           continue
71        continue
          do 74 i = 1, n
             do 75 k = 1, 3
c        
c       Reset all accellerations from the previous step back to zero 
c 
                a(i, k) = 0.0d0
75           continue
74        continue
          do 76 i = 1, n
             do 77 j = (i + 1), n 
                do 78 k = 1, 3
c
c        Calculate the relitive distance between the two stars.
c 
                   drel(k) = r(j, k) - r(i, k)
c
c        variable time step!
c 
                   if (abs(drel(k)) .lt. 0.01d0) then
                      dt = dt / 10.0d0
                   else
                      dt = 0.01d0
                   endif
78              continue 
                rtwo = 0.0d0
                do 79 k = 1, 3
                   rtwo = rtwo + ( drel(k)**2 )
79              continue
                do 80 k = 1, 3
c
c         Calculate new accellerations to be used for velocity.
c 
                   a(i, k) = a(i, k) + ( ( m*m * drel(k) ) / ( sqrt( 
     1                      (rtwo * sqrt ( rtwo ))**2 + small**2 ) ) )
                   a(j, k) = a(j, k) - ( ( m*m * drel(k) ) / ( sqrt( 
     1                      (rtwo * sqrt ( rtwo ))**2 + small**2 ) ) )
80              continue
77           continue
76        continue
c          do 81 i = 1,n
c             do 82 k = 1, 3
c
c              calculate the half step velocity
c
c                v(i, k) = v(i, k) + ( ( a(i, k) * dt ) / 2.0d0 ) 
c82           continue
c81        continue
              do 83 i = 1, n
c      
c      print to file
c
                write(outunit, *)r(i, 1), r(i, 2), r(i, 3)
83           continue     
             close(outunit)
             continue
             tout = tout + dtout
70     continue 
c
c
      if (initial .eq. 1) then  
         close (10)
         close (11)
         close (12)
         close (13)
         close (14)
         close (15)
      else if (initial .eq. 2) then  
         close (16)
         close (17)
         close (18)
         close (19)
         close (20)
         close (21)
      else if (initial .eq. 3) then  
         close (22)
         close (23)
         close (24)
         close (25)
         close (26)
         close (27)
      else if (initial .eq. 4) then  
         close (28)
         close (29)
         close (30)
         close (31)
         close (32)
         close (33)
      endif
c 
      stop
      end
c=======================================================================
c
c                        BEGIN SUBROUTINE DEVIATES
c
c=======================================================================
c 
       subroutine deviates
c
c    dac:deviates <---------------- displays uniform and normal deviates
c                                                            march, 2004
c    written by: David Clarke
c    modified 1: April, 2011 by DAC; corrected usage of Gaussian 
c                statistics.
c
c  PURPOSE:  Creates a 
c
c  EXTERNALS:
c    RAN2
c    NORM
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax    , imax
       parameter     ( nmax=1000, imax=50 )
c
       integer       iseed   , i       , n       , index
       real*8        dx      , one
c
       real*8        rx   (nmax), ry   (nmax), rz      (nmax)
     1              ,vx   (nmax), vy   (nmax), vz      (nmax)
c
       real*8        ran2    , norm
       external      ran2    , norm
c
       data          iseed    / 1 /
c
c-----------------------------------------------------------------------
c
       open(10,file='rx.dat',status='unknown')
       open(11,file='ry.dat',status='unknown')
       open(12,file='rz.dat',status='unknown')
       open(13,file='vx.dat',status='unknown')
       open(14,file='vy.dat',status='unknown')
       open(15,file='vz.dat',status='unknown')
c
c      The arithmetic on ran2 distributes the uniform deviate between -1 
c  and 1.
c
       do 10 n=1,nmax
         rx(n) = norm(iseed) * 2.0d0
         ry(n) = norm(iseed) * 2.0d0
         rz(n) = norm(iseed) * 2.0d0
         vx(n) = norm(iseed)
         vy(n) = norm(iseed)
         vz(n) = norm(iseed)
10     continue
c
c      The domain is set to [-3:3].
c 
         call normalize (rx, ry, rz, vx, vy, vz, nmax)
c
c
c      Write a disc file suitable for gnuplot.
c
       do 40 i=1,nmax
         write(10,*) rx(i)
         write(11,*) ry(i)
         write(12,*) rz(i)
         write(13,*) vx(i)
         write(14,*) vy(i)
         write(15,*) vz(i)
40     continue
c
       close(10)
       close(11)
       close(12)
       close(13)
       close(14)
       close(15)
c
       return
       end
c
c=======================================================================
c
c                         END SUBROUTINE DEVIATES        
c
c=======================================================================
c
c
c=======================================================================
c
c                           BEGIN FUNCTION RAN2
c
c=======================================================================
c
       function ran2 ( idum )
c
c    whp:zeus3d.ran2 <----------------- "perfect" uniform random deviate
c    from numerical recipes, ed. 2                            june, 2008
c
c    written by: W. Press et al.
c    modified 1: June, 2008 by DAC; incorporated into dzeus36
c
c  PURPOSE:  This routine returns a "perfect" uniform random deviate 
c  between 0.0 and 1.0 (up to 2 x 10**18 calls).  See Numerical Recipes,
c  ed. 2, pg. 272.  It must be called with a negative seed and then a 
c  positive number from then on.
c
c  INPUT VARIABLES: 
c    idum        .lt. 0 => initialise sequence depending on absolute
c                          value
c                .ge. 0 => get next random number from sequence
c
c  OUTPUT VARIABLES:
c    ran2        deviate with uniform distribution between 0.0 and 1.0
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       im1     , im2     , ia1     , ia2     , iq1
     1             , iq2     , ir1     , ir2     , ntab    , ndiv
       real*8        am      , eps     , rnmx
       parameter   ( im1=2147483563, im2=2147483399, ia1=40014
     1             , ia2=40692, iq1=53668, iq2=52774, ir1=12211
     2             , ir2=3791, ntab=32, ndiv=1+(im1-1)/ntab )
       parameter   ( am=1.0d0/im1, eps=1.2d-13, rnmx=1.0d0-eps )
c
       integer       idum    , idum2   , j       , k       , iy
       real*8        ran2
c
       integer       iv      (ntab)
c
       save          iv      , iy      , idum2
c
       data          idum2   , iv      , iy
     1             / 123456789, ntab*0, 0 /
c
c-----------------------------------------------------------------------
c
c      If sequence is to be initialised, start here ...
c
       if (idum .le. 0) then
         idum  = max (-idum, 1 )
         idum2 = idum
         do 10 j=ntab+8,1,-1
           k    = idum / iq1
           idum = ia1 * ( idum - k * iq1 ) - k * ir1
           if (idum .lt. 0   ) idum  = idum + im1
           if (j    .le. ntab) iv(j) = idum
10       continue
         iy = iv(1)
       endif
c
c      Otherwise, start here ...
c
       k     = idum  / iq1
       idum  = ia1 * ( idum  - k * iq1 ) - k * ir1
       if (idum  .lt. 0) idum  = idum  + im1
       k     = idum2 / iq2
       idum2 = ia2 * ( idum2 - k * iq2 ) - k * ir2
       if (idum2 .lt. 0) idum2 = idum2 + im2
       j     = 1 + iy / ndiv
       iy    = iv(j) - idum2
       iv(j) = idum
       if (iy .lt. 1) iy = iy + im1 - 1
       ran2  = min ( am*iy, rnmx )
c
       return
       end
c
c=======================================================================
c
c                           END FUNCTION RAN2
c
c=======================================================================
c
c
c=======================================================================
c
c                          BEGIN FUNCTION NORM
c
c=======================================================================
c
       function norm ( idum )
c
c    whp:zeus3d.norm <--------------------------- returns normal deviate
c    from numerical recipes                               december, 1992
c
c    written by: Press etal.
c    modified 1: December, 1992 by DAC; incorporated into ZEUS3D
c    modified 2: June, 2008 by DAC, upgraded to edition 2.
c
c  PURPOSE:  Returns a normal (Gaussian) deviate with zero mean and unit
c  variance (see Numerical Recipes, 2nd edition for FORTRAN, page 280).
c
c  INPUT VARIABLES:
c    idum        .lt. 0 => initialise sequence depending on absolute
c                          value
c                .ge. 0 => get next random number from sequence
c
c  OUTPUT VARIABLES:
c    norm        normal deviate
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    RAN2
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       idum    , inext
       real*8        norm    , v1      , v2      , rsq     , fact    
     1             , next
c
c      Data statements
c
       data          inext    / 0 /
       save          inext   , next
c
c      External statements
c
       real*8        ran2
       external      ran2
c
c-----------------------------------------------------------------------
c
       if (inext .eq. 0) then
10       continue
         v1    = 2.0d0 * ran2(idum) - 1.0d0
         v2    = 2.0d0 * ran2(idum) - 1.0d0
         rsq   = v1**2 + v2**2
         if ( (rsq .ge. 1.0d0) .or. (rsq .eq. 0.0d0) ) go to 10
         fact  = sqrt ( -2.0d0 * log(rsq) / rsq )
         next  = v1 * fact
         norm  = v2 * fact
         inext = 1
       else
         norm  = next
         inext = 0
       endif
c
       return
       end
c
c
c=======================================================================
c
c                          END FUNCTION NORM
c
c=======================================================================
c
c
c=======================================================================
c
c                        BEGIN FUNCTION NORMALIZE
c
c=======================================================================
c 
       subroutine normalize (rx, ry, rz, vx, vy, vz, nmax)
c
c
c    written by: Jenn Beanlands (March 2012)
c
c  PURPOSE:  Normalises the random velocities using the virial theorem 
c
c  INPUT VARIABLES:
c                    rx - random x positions
c                    ry - random y positions
c                    rz - random z positions
c                    vx - random unnormalized x positions
c                    vy - random unnormalized y positions
c                    vz - random unnormalized z positions
c                    nmax - total number of particals
c
c  OUTPUT VARIABLES:
c                    vx - normalized x positions
c                    vy - normalized y positions
c                    vz - normalized z positions
c
c
c  EXTERNALS:
c                    none
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       nmax    , i       , j
       real*8        vmax    , rtot    , vscale  , epot
c
       real*8        rx(nmax), ry(nmax), rz(nmax)
     1             , vx(nmax), vy(nmax), vz(nmax)
     2             , rmax (3)
c
c
c      External statements
c
c
c-----------------------------------------------------------------------
c
      vmax = 0.0d0
      rmax = 0.0d0
      epot = 0.0d0
c
c     Caculate total 
c 
      do 10 i=1, nmax  
         vmax = vmax + vx(i) + vy(i) + vz(i) 
10    continue
c
      do 11 i=1, nmax
         do 12 j=(i+1), nmax
            rmax(1) = ( rx(j) - rx(i) )
            rmax(2) = ( ry(j) - ry(i) )
            rmax(3) = ( rz(j) - rz(i) )
c 
            rtot = 0.0d0
            rtot = rtot + rmax(1)**2
c
c      Calculate total potential energy
c 
            epot = epot - (1.0d0 / sqrt( rtot ) )
            rtot = rtot + rmax(2)**2
            epot = epot - (1.0d0 / sqrt( rtot ) )
            rtot = rtot + rmax(3)**2
            epot = epot - (1.0d0 / sqrt( rtot ) )
12       continue
11    continue
c
c 
c     
      vscale = sqrt(-epot / nmax)
c     print*, vscale
c      print*, vmax
c
c     Scale the velocities
c
      do 13 i=1, nmax
         vx(i) = ( vx(i)  * 12.0d0*(vscale/vmax))
         vy(i) = ( vy(i)  * 8.0d0*(vscale/vmax))
         vz(i) = ( vz(i)  * 8.0d0*(vscale/vmax))
13    continue
c
      return
      stop
      end
c
c
c=======================================================================
c
c                      END SUBROUTINE NORMALIZE
c
c=======================================================================

