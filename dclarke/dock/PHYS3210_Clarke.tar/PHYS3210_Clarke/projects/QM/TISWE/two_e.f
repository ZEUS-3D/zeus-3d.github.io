c=======================================================================
c
c    \\\\\\\\\\         B E G I N   P R O G R A M         //////////
c    //////////                 T W O _ E                 \\\\\\\\\\
c
c=======================================================================
c
       program two_e
c
c    abcd:twoe <-------------------- ground state for two-electron atoms
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This program follows the numerical algorithm outlined in 
c  Stephen Koonin's text "Computational Physics" (ISBN 0-201-12279-0; 
c  sec. III.4, pp. 72-76) to find the ground state binding energy of a
c  two-electron atom with its 1s shell filled using the "Hartree-Fock" 
c  approach.  Required methodology includes the Numerov algorithm, the 
c  shooting method, and a second-order numerical version of l'Hopital's 
c  rule.
c
c  The problem for many (> 2) electrons is significantly different as it 
c  requires additional shells (e.g., 2s, 2p, etc.) and some different 
c  methodology (e.g., Green's function solution rather than the shooting 
c  method).
c
c  This code for a two-electron atom is complete and self-contained.  A 
c  start to the many-electron problem is in many_e.f.
c
c  EXTERNALS:
c    RINIT
c    RHOOFR
c    PHIOFR
c    ENERGY
c    SHOOTING
c
c-----------------------------------------------------------------------
c
       implicit      none
c
c  Parameters
c    imax = maximum number of points in independent variable (r)
c    nmax = maximum number of iterations allowed to minimise energy.
c    tol  = convergence when energy changes from one iteration to the 
c           next by less than "tol".
c
       integer       imax    , nmax
       real*8        tol     
       parameter     ( imax=10001, nmax=100, tol=1.0d-9 )
c
       integer       i       , n
       real          cpubeg  , cpuend  , cputot     
       real*8        rmax    , nrg     , nrg0    , ferr
c
       real*8        r       (imax), rho     (imax), phi     (imax)
     1             , you     (imax), scr     (imax)
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c      External statements.
c
       external      rinit   , rhoofr  , phiofr  , energy  , shooting
c
c-----------------------------------------------------------------------
c
c      Start up CPU time counter.
c
       call cpu_time ( cpubeg )
c
c      Ask user for number of protons (zed .ge. 1) and electrons 
c  (1 .le. ne .le. 2), and idiot-proof.
c
       write (6, 2010)
       read  (5,    *) zed, ne
       if (ne .lt. 1) then
         write (6, 2020)
         ne = 1
       endif
       if (ne .gt. 2) then
         write (6, 2030)
         ne = 2
       endif
c
c      Ask user for desired level of diagnostics (diag).
c
c  diag = 0  =>  no diagnostics reported, other than final results.
c         1  =>  primary diagnostics (values reported to screen)
c         2  =>  secondary diagnostics added (plot files after 
c                convergence)
c         3  =>  tertiary diagnostics added (all others, including plots
c                at intermediate steps in convergence loops)
c
       write (6, 2040)
       read  (5,    *) diag
c
c  Notes on setting rmax and npt.
c
c  1. As Z increases, lowest states are more compressed to r -> 0 so 
c     that even by Z=4, u(r) is sufficiently close to zero for much of 
c     r in [0:3] that machine round-off error at higher r makes it 
c     difficult to determine asymptotic behaviour.  For r too large, the 
c     eigenvalue "lambda" in SHOOTING bounces around by one part in 
c     10**15 (machine round-off), and each bounce can send u(r) to +/- 
c     huge after having hugged the r-axis for some time.  In such cases, 
c     it is best to reduce the domain, as in the table below.
c
c 2.  Also as Z increases, the bulge in the wave function gets sucked 
c     tighter into r = 0, and one needs more zones to resolve the bulge 
c     sufficiently to get the right energy and wave function, as in the 
c     table below.
c
c  for two electrons...
c
c  Z | poor-man HF  ground.f  experimental  % disc  domain  intervals
c    |   E (eV)      E (eV)      E (eV)             (A) 0:
c ---+---------------------------------------------------------------
c  2 |    -77.48      -77.84      -78.88     1.34    3.00      300
c  3 |   -196.54     -196.87     -198.04     0.59    2.00      400
c  4 |   -370.01     -370.33     -371.51     0.32    1.50      500
c  5 |   -597.91     -598.22     -599.43     0.20    1.20      600
c  6 |   -880.22     -880.53     -881.83     0.15    1.00      700
c  7 |  -1216.97    -1217.27    -1218.76     0.12    0.86      800
c  8 |  -1608.13    -1608.43    -1610.23     0.11    0.75      900
c  9 |  -2053.71    -2054.01    -2054.80     0.04    0.67     1000
c
c      The empirical formulae below used to set "rmax" and "npt" as 
c  functions of zed are based on these observations. 
c
       rmax = 6.0d0 / zed
       npt  = int ( zed ) * 100 + 101
c
c      Constants:
c
c  eta    = hbar^2 / (2 me) in units of eV Angstroms^2
c  a0     = Bohr radius in Angstroms
c  ry     = the Rydberg in eV [e^2/(4 pi epsilon_0)/(2 a0)]
c  esq    = e^2/(4 pi epsilon_0) = 2 a0 ry
c  zesq   = Z e^2
c  zstar  = Z*, "shielded atomic number" (Koonin III.20).
c  fourpi = 4 pi
c  dr     = grid spacing
c
       eta  = 3.809981940d0
       a0   = 0.5291772109d0
       ry   = 13.60569253d0
       esq  = 2.0d0 * a0 * ry
       zesq = zed * esq
       if (ne .eq. 1) then
         zstar = zed
       else
         zstar = zed - 0.3125d0
       endif
       fourpi  = 4.0d0 * acos(-1.0d0)
       dr      = rmax / dble ( npt - 1 )
c
c      Set face-centred "r" and initialise "phi".
c
       do i=1,npt
         r  (i) = dble ( i - 1 ) * dr
         phi(i) = 0.0d0
       enddo
c
c      Initialise the radial functions, u(r), to the "shielded" radial 
c  functions for the one-electron atom ("poor-man's Hartree-Fock") as a 
c  reasonable place to start.
c
       call rinit  ( r, you )
       nrg  =-dble(ne) * zstar**2 * ry
       iter = 0
       write (6, 2050) int(zed), ne, nrg, rmax, npt-1
c
c-------------------------- top of main loop ---------------------------
c
10     continue
         if (diag .ge. 1) write (6, 2060) iter, nrg
c
c      Compute charge density from u(r).
c
         call rhoofr ( r, you, rho )
c
c      Compute Phi(r) for a given rho(r) by solving the Poisson equation 
c  (III.18 in Koonin) using a Numerov method.
c
         if (ne .gt. 1) call phiofr ( r, rho, scr, phi )
c
c      Step 2 in Koonin (pg. 73): compute the energy for a given "you", 
c  "rho", and "phi".
c
         nrg0 = nrg
         call energy ( r, rho, phi, you, nrg )
c
c      Test for convergence.
c
         ferr = 2.0d2 * abs ( ( nrg - nrg0 ) / ( nrg + nrg0 ) )
         if (diag .ge. 1) write (6, 2070) nrg0, nrg, ferr
         if (ferr .lt. tol) go to 20
         iter = iter + 1
         if (iter .gt. nmax) then
           write (6, 2080) nmax
           go to 20
         endif
c
c      Step 3 in Koonin (pg. 73): use the shooting method to find u(r), 
c  given phi(r).
c
         call shooting ( r, phi, scr, you )
         go to 10
c
c------------------------- bottom of main loop -------------------------
c
20     continue
       write (6, 2090) nrg, iter, ne
c
c      Write the final data file containing u(r).  To plot data in 
c  u.dat, issue within gnuplot:
c  
c  plot "u.dat" u 2:3 w lines
c
       if (diag .ge. 2) then
         open (10, file='u.dat', status='unknown')
         do i=1,npt
           write (10, 2100) i, r(i), you(i)
         enddo
         close (10)
       endif
c
c      Report the cpu time consumed.
c
       call cpu_time ( cpuend )
       cputot = cpuend - cpubeg
       write (6, 2110) cputot
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('TWO_E   : Enter the atomic number (Z) and the number of '
     1       ,'electrons (Ne).')
2020   format('TWO_E   : |---WARNING---> ne .ge. 1.  ne reset to 1; '
     1       ,'execution continuing...')
2030   format('TWO_E   : |---WARNING---> ne .le. 2.  ne reset to 2; '
     1       ,'execution continuing...')
2040   format('TWO_E   : Enter desired level of diagnostics '
     1       ,'(0 => none, 3 => all).')
2050   format('TWO_E   : ',/
     1       ,'TWO_E   : Begin main loop for Z = ',i2,', Ne = ',i2
     2       ,', poor-man H-F E = ',1pg14.7,',',/
     3       ,'TWO_E   :     on a domain [0:',0pf5.3,'A] divided into '
     4       ,i4,' intervals.')
2060   format('TWO_E   : ',/
     1       ,'TWO_E   : Starting iteration ',i2,' with tentative '
     2       ,'TWO_E  state E0 = ',1pg14.7)
2070   format('TWO_E   : E0, E = ',1p2g20.13,', ferr = ',g11.4,'%.')
2080   format('TWO_E   : Failed to converge after ',i3,' iterations.')
2090   format('TWO_E   :',/
     1       ,'TWO_E   : Converged on ground state E = ',1pg14.7
     2       ,' after ',i3,' iterations.',/
     3       ,'TWO_E   : Writing Ne = ',i2,' wave function(s) in data '
     4       ,'file "u.dat".')
2100   format(i6,1p2g13.5)
2110   format('TWO_E   :',/
     1       ,'TWO_E   : Total cpu usage for this run is ',1pg12.5
     2       ,' seconds.')
c
       stop
       end
c
c=======================================================================
c
c    \\\\\\\\\\           E N D   P R O G R A M           //////////
c    //////////                 T W O _ E                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                 R I N I T                 \\\\\\\\\\
c
c=======================================================================
c
       subroutine rinit ( r, you )
c
c    abcd:ground.rinit <-------------------- initialises radial function
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine initialises the radial function to the 
c  1-electron 1s ground state using shielded nucleus (zstar).
c
c  INPUT VARIABLES:
c    r          radial grid
c
c  OUTPUT VARIABLES:
c    you        initial guess for the radial function, u(r)=rR(r)
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       i  
       real*8        zbya0   , qty     
c
       real*8        r       (   *), you     (   *)
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c-----------------------------------------------------------------------
c
       zbya0 = zstar / a0
       qty   = 2.0d0 * sqrt ( zbya0 ) * zbya0
c
c      Set "you" according to Koonin III.19.
c
c      Set initial state to the 1s state.  
c
       do i=1,npt
         you(i) = qty * r(i) * exp (-zbya0 * r(i) )
       enddo
c
c      Verification.  To plot data in u_00.dat, issue within gnuplot:
c  
c  plot "u_00.dat" u 2:3 w lines
c
       if (diag .ge. 2) then
         open  (10, file='u_00.dat', status='unknown')
         do i=1,npt
           write (10, 2010) i, r(i), you(i)
         enddo
         close (10)
       endif
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format(i6,1p2g13.5)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                 R I N I T                 \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                R H O O F R                \\\\\\\\\\
c
c=======================================================================
c
       subroutine rhoofr ( r, you, rho )
c
c    abcd:ground.rhoofr <----------------------- computes charge density
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine computes the charge density from the radial 
c  function(s).
c
c  INPUT VARIABLES:
c    r          radial grid
c    you        current best-guess of radial function, u(r)=rR(r)
c
c  OUTPUT VARIABLES:
c    rho        1-D array containing radial charge distribution
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*10  filename
       integer       i       
       real*8        dbne    , rpr0    
c
       real*8        r       (   *), you     (   *), rho     (   *)
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c-----------------------------------------------------------------------
c
       dbne = dble(ne)
c
c      Compute charge density from u(r) for all points but the origin.
c
       do i=2,npt
         rho(i) = dbne * you(i)**2 / ( fourpi * r(i)**2 )
       enddo
c
c      The origin was avoided because of the (removable) singularity.  
c  Since R^2(r) ~ r^{2n} with n .ge. 1 as r -> 0, we employ a second 
c  order numerical version of l'Hopital's rule:
c                         _        _  _        _
c                 R^2    |       R  ||       R  |
c            lim  ---  = |  lim --- ||  lim --- |  =  [R']^2
c            r->0 r^2    |_ r->0 r _||_ r->0 r _|
c
c  To find R'(r) as r -> 0, fit the three points i = 1, 2, 3 to the 
c  quadratic y(r) = ar^2 + br + c.  Since u(1) = 0, r(1) = 0, and 
c  r(3) = 2r(2),
c 
c                 u(3)-2u(2)         4u(2)-u(3)
c             a = ----------;    b = ----------;    c = 0,
c                  2r(2)^2             2r(2)
c
c  Then, R'(r=0) ~ y'(r=0) = 2ar + b = b.
c
c  If u(r) ~ r as r -> 0, u(3) = 2u(2) => b -> u(2)/r(2) as expected.
c
c  If u(r) ~ r^2 as r -> 0, u(3) = 4u(2) and b -> 0, again as expected.
c
       rpr0   = 0.5d0 * ( 4.0d0 * you(2) - you(3) ) / r(2)
       rho(1) = dbne * rpr0**2 / fourpi
c
c      Verification.  To plot data in rho_00.dat, issue within gnuplot:
c  
c  plot "rho_00.dat" u 2:3 w lines
c
       if (diag .ge. 2) then
         write (filename, 2010) iter
         open  (10, file=filename, status='unknown')
         do i=1,npt
           write (10, 2020) i, r(i), rho(i)
         enddo
         close (10)
       endif
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('rho_',i2.2,'.dat')
2020   format(i6,1p2g13.5)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                R H O O F R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                P H I O F R                \\\\\\\\\\
c
c=======================================================================
c
       subroutine phiofr ( r, rho, src, phi )
c
c    abcd:ground.phiofr <-------------- computes interelectron potential
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine computes the repulsive potential energy term
c  term between the two electrons using the Numerov algorithm.  
c
c  The Numerov algorithm requires two boundary conditions at the same 
c  boundary, e.g. phi(1) and phi(2)), to get started.  In practise, we 
c  usually only have phi(1), and thus we have to make a guess at phi(2),
c  resulting in a solution with an unphysical asymptotic limit.
c
c  For example, consider:
c                        __ 2
c                        \/  Phi = -4 pi rho                         (1)
c
c  If rho(r,theta,phi) peaks at the origin, then for sufficiently large 
c  r (where most of the charge is located within R << r), we can think 
c  of (1) as spherically symmetric, in which case:
c              _        _
c       1  d  |     dPhi |                   d^2 phi
c      --- -- | r^2 ---- | = -4 pi rho  =>  ------- = -4 pi r rho    (2)
c      r^2 dr |_     dr _|                    dr^2
c    
c  where phi = r Phi.  For r -> infty, RHS -> 0 in which case:
c
c        d^2phi
c        ------ -> 0   =>   phi(r) -> r or 1  =>  Phi -> 1 or 1/r
c         dr^2
c
c  => general asymptotic solution is phi = Ar + B  =>  Phi = A + B/r.  
c  Analytically, boundary conditions would select A and B and, in 
c  particular, would find A = 0 so that Phi ~ 1/r, consistent with a 
c  Coulomb potential.
c
c  Numerically, choosing a bad phi(2) is tantamount to not selecting 
c  A = 0 and thus, asymptotically, the numerical solution for phi(r) 
c  determined from the bad phi(2) will asymptote to the linear function, 
c  Ar + B, rather than just B.  To correct for this, we can subtract off 
c  the linear component from the entire solution as measured from the
c  asymptotic limit once it has been detected.
c
c  INPUT VARIABLES:
c    r          radial grid
c    rho        charge density
c
c  OUTPUT VARIABLES:
c    phi        repulsive inter-electron potential
c
c  LOCAL VARIABLES:
c    src        source term computed and used here, but passed to this 
c               routine properly dimensioned by the calling routine
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*10  fname10
       character*13  fname13
       integer       i
       real*8        qty     , m05     , m10     , ferr    , tiny
c
       real*8        r       (   *), rho     (   *), src     (   *)
     1             , phi     (   *)
c
       data          tiny     / 1.0d-99 /
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c-----------------------------------------------------------------------
c
       if (ne .eq. 1) return
c
c      Evaluate the source term.
c
       qty = fourpi * esq
       do i=1,npt
         src(i) =-qty * r(i) * rho(i)
       enddo
c
c      Set boundary conditions, and employ the Numerov algorithm to 
c  integrate phi(r).
c
c      phi(1) = 0.0 (since r(1) = 0.0 and Phi(1) is finite)
c      phi(2) = 1.0 is a WFAG to be corrected later by subtracting off
c               the asymptotic linear term.  Note that the final result
c               should be independent of this guess.
c
       phi(1) = 0.0d0
       phi(2) = 1.0d0
       qty    = dr**2 / 12.0d0
       do i=3,npt
         phi(i) = 2.0d0 * phi(i-1) - phi(i-2)
     1          + qty * ( src(i) + 10.0d0 * src(i-1) + src(i-2) )
       enddo
c
c      At this point, "phi" includes the linear asymptotic solution 
c  because of the guess at phi(2)
c
c  Verification.  To plot data in philin_00.dat, issue within gnuplot:
c  
c  plot "philin_00.dat" u 2:3 w lines
c
       if (diag .ge. 2) then
         write (fname13, 2010) iter
         open (10, file=fname13, status='unknown')
         do i=1,npt
           write (10, 2020) i, r(i), phi(i)
         enddo
         close (10)
       endif
c
c      Assuming the asymptotic region has been reached at r(npt),
c  subtract off the linear term.  "m05" and "m10" are the slopes of the 
c  asymptotic regime using the last 5 and 10 intervals respectively.  
c  How well they agree (reported in the verification step below) is a 
c  measure of well the asymptotic limit has been reached.
c
       m05 = 0.2d0 * ( phi(npt) - phi(npt- 5) ) / dr
       m10 = 0.1d0 * ( phi(npt) - phi(npt-10) ) / dr
       do i=1,npt
         phi(i) = phi(i) - m05 * r(i)
       enddo
c
c      At this point, "phi" has the right asymptotic behaviour (-> 0 
c  as r -> infty).  Subtracting off the linear term has effectively 
c  corrected the WFAG at phi(2).
c
c  Verification.  To plot data in phi_00.dat, issue within gnuplot:
c  
c  plot "phi_00.dat" u 2:3 w lines
c
       if (diag .ge. 2) then
         write (fname10, 2030) iter
         open (10, file=fname10, status='unknown')
         do i=1,npt
           write (10, 2020) i, r(i), phi(i)
         enddo
         close (10)
         ferr = 2.0d0 * ( m10 - m05 ) / ( m10 + m05 + tiny )
         write (6, 2040) m05, m10, ferr
       endif
c
c  Now divide through by r to obtain the actual potential, Phi(r).  This 
c  poses a problem at r = 0, and thus we evaluate Phi(1) with the second
c  order numerical version of l'Hopital's rule used in RHOOFR.
c
       phi(1) = 0.5d0 * ( 4.0d0 * phi(2) - phi(3) ) / r(2)
       do i=2,npt
         phi(i) = phi(i) / r(i)
       enddo
c
c      Verification.  To plot data in bigphi_00.dat, issue within 
c  gnuplot:
c  
c  plot [][0:100] "bigphi_00.dat" u 2:3 w lines
c
       if (diag .ge. 2) then
         write (fname13, 2050) iter
         open (10, file=fname13, status='unknown')
         do i=1,npt
           write (10, 2020) i, r(i), phi(i)
         enddo
         close (10)
       endif
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('philin_',i2.2,'.dat')
2020   format(i6,1p2g13.5)
2030   format('phi_',i2.2,'.dat')
2040   format('PHIOFR  : slopes m05, m10 = ',1p2g14.7,' (+/- ',g10.3
     1       ,'%)')
2050   format('bigphi_',i2.2,'.dat')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                P H I O F R                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////                E N E R G Y                \\\\\\\\\\
c
c=======================================================================
c
       subroutine energy ( r, rho, phi, you, nrg )
c
c    abcd:ground.energy <---------------------------- expectation energy
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine computes the energy using equation III.16 in 
c  Koonin.
c
c  INPUT VARIABLES:
c    r          radial grid
c    rho        current guess of charge distribution
c    phi        current guess of inter-electron repulsive potential
c    you        current guess of radial function, u(r)=rR(r)
c
c  OUTPUT VARIABLES:
c    nrg        energy of state.
c
c  LOCAL VARIABLES:
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       i      
       real*8        nrg     , dbne    , ke      , pe      
c
       real*8        r       (   *), rho     (   *), phi     (   *)
     1             , you     (   *)
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c-----------------------------------------------------------------------
c
c      Integrate the zone-centred kinetic energy "density" with a direct 
c  Riemann sum (differences in "you" are zone-centred).
c
       dbne = dble(ne)
       ke   = 0.0d0
       do i=1,npt-1
         ke = ke + dbne * ( you(i+1) - you(i) )**2
       enddo
       ke   = ke * eta / dr
c
c      Integrate the face-centred potential energy "density" using the 
c  composite trapezoid rule.  Since rho -> 0 as r^2, there is no 
c  contribution to "pe" at r = 0 (i = 1).
c
       pe = 0.5d0 * ( 0.25d0 * phi(npt) - zesq/r(npt) ) * rho(npt)
     1    * r(npt)**2
       do i=2,npt-1
         pe = pe + ( 0.25d0 * phi(i) - zesq/r(i) ) * rho(i) * r(i)**2
       enddo
       pe = fourpi * pe * dr
c
c      Finally, compute the total energy.
c
       nrg = ke + pe
c
c      Verification.
c
       if (diag .ge. 1) write (6, 2010) ke, pe, nrg
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format('ENERGY  : K = ',1pg14.7,', U = ',g14.7,', E = ',g14.7)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////                E N E R G Y                \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\      B E G I N   S U B R O U T I N E      //////////
c    //////////              S H O O T I N G              \\\\\\\\\\
c
c=======================================================================
c
       subroutine shooting ( r, phi, scr, you )
c
c    abcd:ground.shooting <------- computes u(r) using "shooting method"
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This routine computes u(r) for a given phi(r) using the 
c  "shooting method", a combination of the Numerov method tailored for 
c  the TISWE (NUMSWE) and a secant-like root-finding method.
c
c  The free parameter in this method is the eigenvalue "lambda".  For a
c  given "lambda", the Numerov method will return a function u(r) which,
c  in general, will not have the correct right boundary condition
c  (u(r) -> 0 as r -> infty).  Using a secant-like method, "lambda" is 
c  adjusted until u(r) has the desired asymptotic behaviour.
c
c  INPUT VARIABLES:
c    r          radial grid
c    phi        current guess of inter-electron repulsive potential
c    scr        scratch array used by NUMSWE (Numerov for SWE)
c
c  OUTPUT VARIABLES:
c    you        updated guess for radial function, u(r)=rR(r)
c
c  LOCAL VARIABLES:
c
c  EXTERNALS:
c    NUMSWE
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       character*8   fname8
       character*11  fname11
       character*15  frmt
       integer       cmax    , count   , i       , nlevel  , m
       real*8        tol     , small   , lam2    , younpt2 , lam1    
     1             , younpt1 , lambda  , younpt  , deps    , yousq   
     2             , magyoui
c
       real*8        r       (   *), phi     (   *), scr     (   *)
     1             , you     (   *)
c
c      To avoid completely a zero-divide when assigning "lambda" at the 
c  top of the shooting loop, "small" must be no smaller than 1.0d-13.
c
       data          cmax    , tol     , small   
     1             / 100     , 1.0d-9  , 1.0d-13 /
c
c      Externals
c
       real*8        numswe
       external      numswe
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c-----------------------------------------------------------------------
c
c      Initialise first two guesses for "lambda" to and just above the 
c  hydrogenic energy for one electron (-zed^2*ry), which will be less 
c  (more negative) than the actual energy because of the repulsive term.  
c  Since we seek the ground state, we low-ball both guesses for lambda, 
c  knowing that the secant method will quickly hone in on the desired 
c  root.
c
c      The Numerov integration of u(r) for a given eigenvalue "lambda" 
c  happens in the function call to NUMSWE.  As a function, NUMSWE is set 
c  to u(npt) which should -> 0 as r -> infty.  Treated as a function of 
c  "lambda", the secant method is used to find the value of "lambda" 
c  which makes u(npt) = 0.
c
       lam2    =-zstar**2 * ry
       younpt2 = numswe ( lam2, r, phi, scr, you )
       lam1    = 0.99d0 * lam2
       younpt1 = numswe ( lam1, r, phi, scr, you )
       count   = 0
c
c------------------------ Top of shooting loop -------------------------
c
20     continue
c
c      Based on the previous two guesses, update "lambda" using a 
c  secant interpolation step, and update u(r) for the new eigenvalue.
c
         lambda = lam2
     1          - younpt2 * ( lam1 - lam2 ) / ( younpt1 - younpt2 )
         younpt = numswe ( lambda, r, phi, scr, you )
         count  = count + 1
c
c      Verification.  To plot data in u_00-01.dat, issue within
c  gnuplot:
c  
c  plot "u_00-01.dat" u 2:3 w lines, 0
c
         if (diag .ge. 3) then
           write (fname11, 2020) iter-1, count
           open  (10, file=fname11, status='unknown')
           do i=1,npt
             write (10, 2010) i, r(i), you(i)
           enddo
           close (10)
           write (6, 2030) count, lambda, younpt
         endif
c
c      If count exceeds cmax, issue warning and leave shooting loop.
c
         if (count .gt. cmax) then
           write (6, 2040) iter, cmax
           if (younpt .gt. 0.0d0) write (6, 2050) younpt, tol
           if (younpt .lt. 0.0d0) write (6, 2060) younpt,-tol
           go to 30
         endif
c
c      Impose the right BC: u(r) -> 0 as r -> infty.  If |u(npt)| > tol, 
c  shuffle the guesses and return to top of shooting loop.  Conversely, 
c  if |u(npt)| < tol, we've converged on u(r) for the current guess of 
c  "phi".
c
         if (abs(younpt) .gt. tol) then
           lam2    = lam1
           younpt2 = younpt1
           lam1    = lambda
           younpt1 = younpt
c
c      Secondary convergence criterion: For r too large, u(npt) can be
c  an exceedingly sensitive function of "lambda", to the point where a
c  one part in 10**15 change in "lambda" can elicit enormous changes in 
c  u(npt).  Thus, 
c
c  1.  r should be limited so that u(npt) asymptotes to 0 (see comments 
c      near the top of TWO_E), necessary for evaluating rho, phi, and 
c      ultimately the ground state energy;
c
c  2.  convergence process should be stopped once |(lam1 - lam2) / lam1| 
c      < 10**-14 to avoid making minuscule changes to "lambda" at the 
c      expense of large changes in u(npt).
c
           deps = abs ( ( lam1 - lam2 ) / lam1 )
           if (deps .lt. small) then
             write (6, 2070) iter, count, younpt
             go to 30
           endif
c
           go to 20
         endif
c
c      u(r) has been found to within tolerance.
c
         if (diag .ge. 1) write (6, 2080) count
c
c----------------------- Bottom of shooting loop -----------------------
c
c      Normalise u(r) (Koonin, III.15).  Integration done with composite 
c  trapezoid rule.
c
30     continue
       yousq = 0.5d0 * ( you(1)**2 + you(npt)**2 )
       do i=2,npt-1
         yousq = yousq + you(i)**2
       enddo
       magyoui = 1.0d0 / sqrt ( yousq * dr )
       do i=1,npt
         you(i) = magyoui * you(i)
       enddo
c
c      Verification.  To plot data in u_01.dat, issue within gnuplot:
c  
c  plot "u_01.dat" u 2:3 w lines, 0
c
       if (diag .ge. 2) then
         write (fname8, 2090) iter
         open  (10, file=fname8, status='unknown')
         do i=1,npt
           write (10, 2010) i, r(i), you(i)
         enddo
         close (10)
       endif
c
c-----------------------------------------------------------------------
c----------------------- Write format statements -----------------------
c-----------------------------------------------------------------------
c
2010   format(i6,1p2g13.5)
2020   format('u_',i2.2,'-',i2.2,'.dat')
2030   format('SHOOTING: step: ',i3,', lambda = ',1pg22.15,', u(npt) ='
     1       ,1pg15.8)
2040   format('SHOOTING: In iteration ',i2
     1       ,', unable to converge on u(r) after ',i3,' steps.')
2050   format('SHOOTING: u(npt) = ',1pg12.5,' > "tol" = ',g12.5,'.')
2060   format('SHOOTING: u(npt) = ',1pg12.5,' < -"tol" = ',g12.5,'.')
2070   format('SHOOTING: |---WARNING---> During iteration ',i3
     1       ,' and after ',i3,' steps, "lambda"',/
     2       ,'SHOOTING: converges before u(npt) = ',1pg12.5
     3       ,' > tol.  Execution continuing...')
2080   format('SHOOTING: Converged on u(r) after ',i3,' steps.')
2090   format('u_',i2.2,'.dat')
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\        E N D   S U B R O U T I N E        //////////
c    //////////              S H O O T I N G              \\\\\\\\\\
c
c=======================================================================
c
c
c=======================================================================
c
c    \\\\\\\\\\        B E G I N   F U N C T I O N        //////////
c    //////////                N U M S W E                \\\\\\\\\\
c
c=======================================================================
c
       function numswe ( lambda, r, phi, ksq, you )
c
c    abcd:ground.numswe <-------------------- numerov solution for TISWE
c                                                            march, 2012
c
c    written by: A Busy Code Developer
c    modified 1: 
c
c  PURPOSE:  This function uses the Numerov algorithm to solve the time-
c  independent Schrodinger wave equation for the radial wave function, 
c  u(r), given the input eigenvalue, "lambda", and repulsive potential, 
c  phi(r).
c
c  For the left boundary values, we use the zero-boundary condition for 
c  u(1) and impose an arbitrary second boundary condition, u(2), to 
c  start the Numerov algorithm.  Special care also has to be exercised 
c  for u(3).  Once an eigenvalue has been found that gives u(r) the 
c  desired right boundary condition, u(2) is set by normalisation.
c
c  INPUT VARIABLES:
c    lambda     current guess of eigenvalue
c    r          radial grid
c    phi        current guess of inter-electron repulsive potential
c
c  OUTPUT VARIABLES:
c    you        current guess of the radial function, u(r)=rR(r)
c
c  LOCAL VARIABLES:
c    ksq        scratch array from main program used for exponential 
c               factor k^2(r)
c
c  EXTERNALS: [none]
c
c-----------------------------------------------------------------------
c
       implicit      none
c
       integer       i       
       real*8        numswe  , lambda  , q1      , q2      
c
       real*8        r       (   *), phi     (   *), ksq     (   *)
     1             , you     (   *)
c
c      Common blocks for global variables.
c
       integer       ne      , npt     , diag    , iter
       real*8        zed     , eta     , a0      , ry      , esq
     1             , zesq    , zstar   , fourpi  , dr
c
       common      / comi     /
     1               ne      , npt     , diag    , iter
       common      / comr     /
     1               zed     , eta     , a0      , ry      , esq
     2             , zesq    , zstar   , fourpi  , dr
c
c-----------------------------------------------------------------------
c
c      Evaluate the oscillatory/exponential factor k^2(r).  Because of 
c  the 1/r term in k^2, we avoid i = 1, where r(1) = 0, and deal with 
c  where k^2(1) is needed (in u(3)) as a special case below.
c
       do i=2,npt
         ksq(i) = ( zesq / r(i) - 0.5d0 * phi(i) + lambda ) / eta
       enddo
c
c      Set boundary conditions, and employ the Numerov algorithm to 
c  integrate u(r).
c
c  you(1) = 0.0 (where r(1) = 0.0)
c  you(2) = 1.0 is a blind guess to be corrected later by normalisation.
c  you(3) = the Numerov expression with the quadratic l'Hopital formula
c           (RHOOFR) built in to deal with the (zesq/r)*R term.  Since 
c           the quadratic l'Hopital formula requires you(2) and you(3) 
c           to replace you(1)/r(1), this yields an implicit expression 
c           for you(3), whose solution is what you(3) is set to below.
c
       q1     = 12.0d0 / dr**2
       q2     = zesq / eta / dr
       you(1) = 0.0d0
       you(2) = 1.0d0
       you(3) = 2.0d0 * you(2) * ( q1 - 5.0d0 * ksq(2) - q2 )
     1        / ( q1 + ksq(3) - 0.5 * q2 )
       do i=4,npt
         you(i) = ( 2.0d0 * you(i-1) * ( q1 - 5.0d0 * ksq(i-1) )
     1            - you(i-2) * ( q1 + ksq(i-2) ) ) / ( q1 + ksq(i) )
       enddo
       numswe = you(npt)
c
       return
       end
c
c=======================================================================
c
c    \\\\\\\\\\          E N D   F U N C T I O N          //////////
c    //////////                N U M S W E                \\\\\\\\\\
c
c=======================================================================
c
c
